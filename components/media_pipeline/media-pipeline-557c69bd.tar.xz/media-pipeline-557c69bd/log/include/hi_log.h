/*
 * Copyright (c) HiSilicon (Shanghai) Technologies Co., Ltd. 2025-2026. All rights reserved.
 */

#ifndef __HI_LOG_H__
#define __HI_LOG_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <assert.h>

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/* ---------------------------- ANSI 颜色宏 ---------------------------- */

#define HI_LOG_COLOR_RED     "\033[1;31m"   /* 红色，用于 ERROR/FATAL */
#define HI_LOG_COLOR_YELLOW  "\033[1;33m"   /* 黄色，用于 WARNING */
#define HI_LOG_COLOR_GREEN   "\033[1;32m"   /* 绿色，用于 INFO    */
#define HI_LOG_COLOR_GRAY    "\033[0;36m"   /* 青色，用于 DEBUG   */
#define HI_LOG_COLOR_RESET   "\033[m"       /* 重置颜色           */

/* ---------------------------- 日志等级定义 ---------------------------- */

typedef enum {
    HI_LOG_LEVEL_FATAL = 0, /* 致命：系统崩溃，最高优先级 */
    HI_LOG_LEVEL_ERROR,     /* 错误：不可恢复             */
    HI_LOG_LEVEL_WARN,      /* 警告：可恢复的异常         */
    HI_LOG_LEVEL_INFO,      /* 信息：关键流程节点（默认） */
    HI_LOG_LEVEL_DEBUG,     /* 调试：详细调试信息         */
    HI_LOG_LEVEL_BUTT
} HI_LOG_LEVEL_E;

/* 默认日志等级（运行时可通过 HI_LOG_Init 覆盖） */
#define HI_LOG_DEFAULT_LEVEL HI_LOG_LEVEL_INFO

/* ============================================================================
 * 初始化/反初始化接口
 * ============================================================================ */

#ifdef LOG_ENABLE

/**
 * @brief 初始化日志模块
 * @param[in] filePath  日志文件路径，仅 LOG_SAVE_TO_FILE=ON 时有效
 *                      NULL 或空字符串 → 写入默认路径 logFile/system_log.log
 *                      非空路径 → 写入指定路径（不能以 '/' 结尾）
 *                      LOG_SAVE_TO_FILE=OFF 时此参数被忽略，始终使用终端输出
 * @param[in] level     初始日志输出等级指针（NULL 表示使用默认等级 INFO）
 *                      运行时可通过 HI_LOG_SetEnabledLevel() 在此上限内收紧
 * @param[in] fileSize  单文件最大字节数，0 表示使用默认值 5 MB
 *                      仅 LOG_SAVE_TO_FILE=ON 且 filePath 有效时生效
 * @return 0 成功，-1 失败（参数非法 / 已初始化 / 文件打开失败）
 * @note 重复调用返回 -1，需先调用 HI_LOG_Deinit
 * @warning 文件模式不支持多进程同时写入同一文件。
 *          若多进程必须共用同一文件，所有进程必须指定完全相同的 fileSize，
 *          即使如此，各进程轮转计数独立，文件实际大小仍可能超过 fileSize 限制。
 *          推荐做法：每个进程使用独立文件路径，配合 hiloggrep 通配符统一查询。
 */
int HI_LOG_Init(const char *filePath, HI_LOG_LEVEL_E *level, unsigned int fileSize);

/**
 * @brief 反初始化日志模块
 *        文件模式下刷盘并关闭文件，重置所有运行时状态
 * @return 0 成功，-1 未初始化（需先调用 HI_LOG_Init）
 */
int HI_LOG_Deinit(void);

/* HI_LOG_OpenSaveFile / HI_LOG_CloseSaveFile 为内部 static 函数，
 * 定义在 hi_log.c 中，不对外暴露，头文件不声明。 */

#else /* !LOG_ENABLE */

#define HI_LOG_Init(filePath, level, fileSize) \
    ((void)(filePath), (void)(level), (void)(fileSize), 0)

#define HI_LOG_Deinit() \
    ((void)0)

#define HI_LOG_OpenSaveFile(filePath, filePathLen, fileSize) \
    ((void)(filePath), (void)(filePathLen), (void)(fileSize), 0)

#define HI_LOG_CloseSaveFile() \
    ((void)0)

#endif /* LOG_ENABLE */

/* ============================================================================
 * 对外接口声明 / 空操作桩
 *
 * LOG_ENABLE=ON ：声明真实函数，由 hi_log.c 提供实现。
 * LOG_ENABLE=OFF：提供空操作宏桩，调用方无需 #ifdef 保护。
 * ============================================================================ */

#ifdef LOG_ENABLE

/**
 * @brief 设置日志运行时输出等级
 * @param[in] level 目标等级，范围 [HI_LOG_LEVEL_FATAL, HI_LOG_LEVEL_DEBUG]
 *                  不允许超过 HI_LOG_Init 时设定的初始等级（上限约束）
 *                  例如 Init 时设定 INFO，则运行时只能收紧到 FATAL/ERROR/WARN，
 *                  不能放宽到 DEBUG
 * @return 0 成功，-1 参数非法或超过初始化时设定的等级上限
 */
int HI_LOG_SetEnabledLevel(HI_LOG_LEVEL_E level);

/**
 * @brief 获取日志运行时输出等级
 * @return 当前输出等级
 */
HI_LOG_LEVEL_E HI_LOG_GetEnabledLevel(void);

/**
 * @brief 获取当前日志文件路径
 * @return 当前打开的日志文件路径（文件模式且已打开时），否则返回 NULL
 */
const char* HI_LOG_GetCurrentFilePath(void);

/**
 * @brief 判断是否处于文件输出模式
 * @return true 表示文件模式，false 表示终端模式
 */
bool HI_LOG_IsFileMode(void);

/**
 * @brief 日志输出核心函数（不建议直接调用，请使用 HI_LOGx 宏封装）
 * @param[in] modName 模块名标签字符串
 * @param[in] logLevel    日志等级
 * @param[in] func       函数名（传入 __FUNCTION__）
 * @param[in] line       行号（传入 __LINE__）
 * @param[in] fmt     printf 格式串
 * @note expr 的返回值必须与 int 兼容（int / int32_t / td_s32 等）
 */
int HI_LOG_PrintfInfo(const char *modName, HI_LOG_LEVEL_E logLevel,
                      const char *func, int line,
                      const char *fmt, ...);

#else /* !LOG_ENABLE */

#define HI_LOG_SetEnabledLevel(level) \
    ((void)(level), 0)

#define HI_LOG_GetEnabledLevel() \
    ((HI_LOG_LEVEL_E)(HI_LOG_LEVEL_INFO))

#define HI_LOG_GetCurrentFilePath() \
    ((const char*)NULL)

#define HI_LOG_IsFileMode() \
    (false)

#endif /* LOG_ENABLE */

/* ============================================================================
 * 宏封装：日志打印 / 断言 / 返回值检查
 *
 * LOG_ENABLE=ON ：展开为完整实现，调用 HI_LOG_PrintfInfo。
 * LOG_ENABLE=OFF：日志宏裁剪为 ((void)0)，断言退化为 assert()，
 *                 检查宏保留逻辑但不输出日志。
 * ============================================================================ */

#ifdef LOG_ENABLE

/* 日志打印 */

#define HI_LOG_CHECK_MODE_TYPE(mode) \
    (void)sizeof(*(mode))

#define HI_LOGF(mode, ...) \
    do { \
        HI_LOG_CHECK_MODE_TYPE(mode); \
        ((void)HI_LOG_PrintfInfo((const char *)(mode), HI_LOG_LEVEL_FATAL, \
                                  __FUNCTION__, __LINE__, __VA_ARGS__)); \
    } while (0)

#define HI_LOGE(mode, ...) \
    do { \
        HI_LOG_CHECK_MODE_TYPE(mode); \
        ((void)HI_LOG_PrintfInfo((const char *)(mode), HI_LOG_LEVEL_ERROR, \
                                  __FUNCTION__, __LINE__, __VA_ARGS__)); \
    } while (0)

#define HI_LOGW(mode, ...) \
    do { \
        HI_LOG_CHECK_MODE_TYPE(mode); \
        ((void)HI_LOG_PrintfInfo((const char *)(mode), HI_LOG_LEVEL_WARN, \
                                  __FUNCTION__, __LINE__, __VA_ARGS__)); \
    } while (0)

#define HI_LOGI(mode, ...) \
    do { \
        HI_LOG_CHECK_MODE_TYPE(mode); \
        ((void)HI_LOG_PrintfInfo((const char *)(mode), HI_LOG_LEVEL_INFO, \
                                  __FUNCTION__, __LINE__, __VA_ARGS__)); \
    } while (0)

#define HI_LOGD(mode, ...) \
    do { \
        HI_LOG_CHECK_MODE_TYPE(mode); \
        ((void)HI_LOG_PrintfInfo((const char *)(mode), HI_LOG_LEVEL_DEBUG, \
                                  __FUNCTION__, __LINE__, __VA_ARGS__)); \
    } while (0)

/* 断言 */

#define HI_ASSERT(expr) \
    do { \
        if (!(expr)) { \
            fprintf(stderr, "[ASSERT] Assertion failed: %s, file: %s, line: %d\n", \
                    #expr, __FILE__, __LINE__); \
            abort(); \
        } \
    } while (0)

#define HI_ASSERT_MSG(expr, fmt, ...) \
    do { \
        if (!(expr)) { \
            fprintf(stderr, "[ASSERT] Assertion failed: %s, " fmt ", file: %s, line: %d\n", \
                    #expr, ##__VA_ARGS__, __FILE__, __LINE__); \
            abort(); \
        } \
    } while (0)

/* 返回值检查 */

#define HI_CHECK_RET(expr) \
    do { \
        int _ret = (expr); \
        if (_ret != 0) { \
            HI_LOGE("CHECK_RET", #expr " failed, ret = %d (0x%x)", _ret, (unsigned int)_ret); \
            return _ret; \
        } \
    } while (0)

#define HI_CHECK_RET_MSG(expr, fmt, ...) \
    do { \
        int _ret = (expr); \
        if (_ret != 0) { \
            HI_LOGE("CHECK_RET", #expr " failed, " fmt ", ret = %d (0x%x)", \
                    ##__VA_ARGS__, _ret, (unsigned int)_ret); \
            return _ret; \
        } \
    } while (0)

#define HI_CHECK_RET_VAL(expr, expectVal) \
    do { \
        int _ret = (expr); \
        if (_ret != (int)(expectVal)) { \
            HI_LOGE("CHECK_RET_VAL", #expr " = 0x%x, expected = 0x%x", \
                    (unsigned int)_ret, (unsigned int)(expectVal)); \
            return _ret; \
        } \
    } while (0)

#define HI_CHECK_RET_VAL_MSG(expr, expectVal, fmt, ...) \
    do { \
        int _ret = (expr); \
        if (_ret != (int)(expectVal)) { \
            HI_LOGE("CHECK_RET_VAL", #expr " = 0x%x, expected = 0x%x, " fmt, \
                    (unsigned int)_ret, (unsigned int)(expectVal), ##__VA_ARGS__); \
            return _ret; \
        } \
    } while (0)

#define HI_CHECK_NULL(ptr, errCode) \
    do { \
        if ((ptr) == NULL) { \
            HI_LOGE("CHECK_NULL", "Pointer [%s] is NULL, file: %s, line: %d", \
                    #ptr, __FILE__, __LINE__); \
            return (errCode); \
        } \
    } while (0)

#define HI_CHECK_TRUE(expr, errCode) \
    do { \
        if (!(expr)) { \
            HI_LOGE("CHECK_TRUE", "Condition [%s] is false, file: %s, line: %d", \
                    #expr, __FILE__, __LINE__); \
            return (errCode); \
        } \
    } while (0)

#define HI_CHECK_TRUE_MSG(expr, errCode, fmt, ...) \
    do { \
        if (!(expr)) { \
            HI_LOGE("CHECK_TRUE", "Condition [%s] is false, " fmt ", file: %s, line: %d", \
                    #expr, ##__VA_ARGS__, __FILE__, __LINE__); \
            return (errCode); \
        } \
    } while (0)

#define HI_LOG_RET(expr) \
    do { \
        int _ret = (expr); \
        if (_ret != 0) { \
            HI_LOGW("CHECK_RET", #expr " failed, ret = 0x%x", (unsigned int)_ret); \
        } \
    } while (0)

#define HI_LOG_RET_VAL(expr, expectVal) \
    do { \
        int _ret = (expr); \
        if (_ret != (int)(expectVal)) { \
            HI_LOGW("CHECK_RET_VAL", #expr " failed, ret = 0x%x, expected = 0x%x", \
                    (unsigned int)_ret, (unsigned int)(expectVal)); \
        } \
    } while (0)

#define HI_CHECK_GOTO(expr, label, stmt) \
    do { \
        if (!(expr)) { \
            HI_LOGE("CHECK_GOTO", "Condition [%s] is false, goto " #label ", file: %s, line: %d", \
                    #expr, __FILE__, __LINE__); \
            stmt; \
            goto label; \
        } \
    } while (0)

#else /* !LOG_ENABLE */

#define HI_LOGF(mode, ...) ((void)0)
#define HI_LOGE(mode, ...) ((void)0)
#define HI_LOGW(mode, ...) ((void)0)
#define HI_LOGI(mode, ...) ((void)0)
#define HI_LOGD(mode, ...) ((void)0)

#define HI_ASSERT(expr)                  assert(expr)
#define HI_ASSERT_MSG(expr, fmt, ...)    do { \
                                            if (!(expr)) { \
                                                fprintf(stderr, "[ASSERT] %s: " fmt "\n", #expr, ##__VA_ARGS__); \
                                                abort(); \
                                            } \
                                        } while (0)

#define HI_CHECK_RET(expr) \
    do { \
        int _ret = (expr); \
        if (_ret != 0) { \
            return _ret; \
        } \
    } while (0)

#define HI_CHECK_RET_MSG(expr, fmt, ...) HI_CHECK_RET(expr)

#define HI_CHECK_RET_VAL(expr, expectVal) \
    do { \
        int _ret = (expr); \
        if (_ret != (int)(expectVal)) { \
            return _ret; \
        } \
    } while (0)
 
#define HI_CHECK_RET_VAL_MSG(expr, expectVal, fmt, ...) \
    HI_CHECK_RET_VAL(expr, expectVal)

#define HI_CHECK_NULL(ptr, errCode) \
    do { \
        if ((ptr) == NULL) { \
            return (errCode); \
        } \
    } while (0)

#define HI_CHECK_TRUE(expr, errCode) \
    do { \
        if (!(expr)) { \
            return (errCode); \
        } \
    } while (0)

#define HI_CHECK_TRUE_MSG(expr, errCode, fmt, ...) HI_CHECK_TRUE(expr, errCode)

#define HI_LOG_RET(expr)                 (void)(expr)
#define HI_LOG_RET_VAL(expr, expectVal)  (void)(expr)

#define HI_CHECK_GOTO(expr, label, stmt) \
    do { \
        if (!(expr)) { \
            stmt; \
            goto label; \
        } \
    } while (0)

#endif /* LOG_ENABLE */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_LOG_H__ */
