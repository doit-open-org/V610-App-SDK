/*
 * Copyright (c) HiSilicon (Shanghai) Technologies Co., Ltd. 2025-2026. All rights reserved.
 */

#include "hi_log.h"
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <time.h>
#include <pthread.h>

#include <sys/stat.h>
#include <sys/types.h>

#ifdef LOG_SAVE_TO_FILE
#include <fcntl.h>
#include <errno.h>
#endif /* LOG_SAVE_TO_FILE */

/* ---------------------------- 全局状态 ---------------------------- */

/* 缓冲区大小常量（全局有效）*/
#define HI_LOG_USER_BUF_SIZE 384
#define HI_LOG_TS_BUF_SIZE    32
#define HI_LOG_LOG_BUF_SIZE   512

static HI_LOG_LEVEL_E g_enabledLevel  = HI_LOG_DEFAULT_LEVEL;
static HI_LOG_LEVEL_E g_maxLevel      = HI_LOG_DEFAULT_LEVEL;
static bool           g_isFileMode     = false;
static bool           g_isInitialized  = false;
static int            g_isTty         = -1;
static pthread_once_t g_isTtyOnce    = PTHREAD_ONCE_INIT;

static void hi_log_init_is_tty(void)
{
    g_isTty = isatty(STDERR_FILENO) ? 1 : 0;
}

#ifdef LOG_SAVE_TO_FILE
#define HI_LOG_DEFAULT_FILE_PATH "logfile/system_log.log"
#define HI_LOG_DEFAULT_FILE_SIZE (5u * 1024u * 1024u)

/* 文件操作权限常量 */
#define HI_LOG_DIR_MODE  0755
#define HI_LOG_FILE_MODE 0644

/* 文件上下文结构体 */
typedef struct {
    int         fd;
    char        path[PATH_MAX];
    char        path2[PATH_MAX];
    unsigned int maxSize;
    unsigned int currentSize;
    bool        opened;
    bool        isFirstFile;
} hi_log_file_ctx_t;

static pthread_mutex_t     g_fileMutex = PTHREAD_MUTEX_INITIALIZER;
static hi_log_file_ctx_t   g_fileCtx   = {
    .fd          = -1,
    .path[0]     = '\0',
    .path2[0]    = '\0',
    .maxSize     = 0,
    .currentSize = 0,
    .opened      = false,
    .isFirstFile = true
};
#endif /* LOG_SAVE_TO_FILE */

/* ---------------------------- 内部辅助函数 ---------------------------- */

static void hi_log_timestamp(char *buf, size_t bufLen)
{
    if (buf == NULL || bufLen == 0) {
        return;
    }
    time_t now = time(NULL);
    struct tm tmInfo;
    if (localtime_r(&now, &tmInfo) == NULL) {
        buf[0] = '\0';
        return;
    }
    (void)strftime(buf, bufLen, "%Y/%m/%d %H:%M:%S", &tmInfo);
}

static const char *hi_log_level_str(HI_LOG_LEVEL_E level)
{
    switch (level) {
        case HI_LOG_LEVEL_FATAL: return "FATAL";
        case HI_LOG_LEVEL_ERROR: return "ERROR";
        case HI_LOG_LEVEL_WARN:  return "WARNING";
        case HI_LOG_LEVEL_INFO:  return "INFO";
        case HI_LOG_LEVEL_DEBUG: return "DEBUG";
        default:                 return "UNKNOWN";
    }
}

static const char *hi_log_level_color(HI_LOG_LEVEL_E level)
{
    switch (level) {
        case HI_LOG_LEVEL_FATAL: return HI_LOG_COLOR_RED;
        case HI_LOG_LEVEL_ERROR: return HI_LOG_COLOR_RED;
        case HI_LOG_LEVEL_WARN:  return HI_LOG_COLOR_YELLOW;
        case HI_LOG_LEVEL_INFO:  return HI_LOG_COLOR_GREEN;
        case HI_LOG_LEVEL_DEBUG: return HI_LOG_COLOR_GRAY;
        default:                 return "";
    }
}

static int hi_log_console_output(const char *modName, HI_LOG_LEVEL_E logLevel,
                                  const char *func, int line,
                                  const char *fmt, va_list args);

#ifdef LOG_SAVE_TO_FILE
static int hi_log_mkdir_recursive(const char *path, mode_t mode)
{
    if (path == NULL || path[0] == '\0') {
        return -1;
    }

    char tmp[PATH_MAX] = {0};
    size_t len = strlen(path);
    if (len >= sizeof(tmp)) {
        return -1;
    }
    (void)memcpy(tmp, path, len);
    tmp[len] = '\0';

    if (tmp[len - 1] == '/') {
        tmp[len - 1] = '\0';
    }

    char *p = tmp;
    for (p = tmp + 1; *p != '\0'; p++) {
        if (*p == '/') {
            *p = '\0';
            (void)mkdir(tmp, mode);
            *p = '/';
        }
    }
    (void)mkdir(tmp, mode);
    return 0;
}

static int hi_log_validate_file_path(const char *filePath, size_t filePathLen)
{
    if (filePathLen >= PATH_MAX) {
        fprintf(stderr, "[hi_log] file path too long\n");
        return -1;
    }
    if (filePathLen >= 2 && filePath[filePathLen - 2] == '/') {
        fprintf(stderr, "[hi_log] file path must not end with '/': %s\n", filePath);
        return -1;
    }
    if (strstr(filePath, "..") != NULL) {
        fprintf(stderr, "[hi_log] file path must not contain '..': %s\n", filePath);
        return -1;
    }
    return 0;
}

static int hi_log_convert_to_absolute(void)
{
    if (g_fileCtx.path[0] == '/') {
        return 0;
    }

    char *absPath = realpath(g_fileCtx.path, NULL);
    if (absPath != NULL) {
        size_t absLen = strlen(absPath);
        if (absLen < sizeof(g_fileCtx.path)) {
            (void)memcpy(g_fileCtx.path, absPath, absLen + 1);
            free(absPath);
            return 0;
        }
        fprintf(stderr, "[hi_log] realpath result too long\n");
        free(absPath);
        return -1;
    }

    char cwd[PATH_MAX] = {0};
    if (getcwd(cwd, sizeof(cwd) - 1) == NULL) {
        fprintf(stderr, "[hi_log] getcwd failed: %d\n", errno);
        return -1;
    }

    size_t cwdLen = strlen(cwd);
    size_t relPathLen = strlen(g_fileCtx.path);
    if (cwdLen == 0 || cwdLen >= sizeof(cwd) - 1) {
        fprintf(stderr, "[hi_log] getcwd result invalid\n");
        return -1;
    }
    if (cwdLen + 1 + relPathLen >= sizeof(g_fileCtx.path)) {
        fprintf(stderr, "[hi_log] combined path too long\n");
        return -1;
    }

    char tempPath[PATH_MAX] = {0};
    if (snprintf(tempPath, sizeof(tempPath), "%s/%s", cwd, g_fileCtx.path) < 0) {
        fprintf(stderr, "[hi_log] snprintf failed in path conversion\n");
        return -1;
    }
    (void)memcpy(g_fileCtx.path, tempPath, strlen(tempPath) + 1);
    return 0;
}

static void hi_log_build_rotate_path(void)
{
    const char *dot = strrchr(g_fileCtx.path, '.');
    if (dot != NULL) {
        size_t baseLen = (size_t)(dot - g_fileCtx.path);
        size_t dotLen = strlen(dot);
        if (baseLen + 2 + dotLen + 1 <= sizeof(g_fileCtx.path2)) {
            memcpy(g_fileCtx.path2, g_fileCtx.path, baseLen);
            memcpy(g_fileCtx.path2 + baseLen, "_2", 2);
            memcpy(g_fileCtx.path2 + baseLen + 2, dot, dotLen + 1);
            return;
        }
    }
    g_fileCtx.path2[0] = '\0';
}

static int hi_log_open_and_sync_size(void)
{
    g_fileCtx.fd = open(g_fileCtx.path, O_RDWR | O_CREAT | O_APPEND, HI_LOG_FILE_MODE);
    if (g_fileCtx.fd < 0) {
        fprintf(stderr, "[hi_log] open file failed: %s, error: %d\n", g_fileCtx.path, errno);
        return -1;
    }

    struct stat st;
    if (fstat(g_fileCtx.fd, &st) == 0) {
        g_fileCtx.currentSize = (st.st_size > UINT_MAX) ? UINT_MAX : (unsigned int)st.st_size;
    } else {
        g_fileCtx.currentSize = 0;
    }
    return 0;
}

static int hi_log_handle_exceeded_file(void)
{
    (void)close(g_fileCtx.fd);
    g_fileCtx.fd = -1;

    struct stat st2;
    bool file2Exists = (stat(g_fileCtx.path2, &st2) == 0);
    unsigned int file2Size = file2Exists ? (unsigned int)st2.st_size : 0;

    if (file2Size < g_fileCtx.maxSize) {
        g_fileCtx.fd = open(g_fileCtx.path2, O_RDWR | O_CREAT | O_APPEND, HI_LOG_FILE_MODE);
        g_fileCtx.currentSize = file2Size;
        g_fileCtx.isFirstFile = false;
    } else {
        g_fileCtx.fd = open(g_fileCtx.path, O_RDWR | O_CREAT | O_TRUNC, HI_LOG_FILE_MODE);
        g_fileCtx.currentSize = 0;
        g_fileCtx.isFirstFile = true;
    }

    if (g_fileCtx.fd < 0) {
        fprintf(stderr, "[hi_log] open rotate file failed: %d\n", errno);
        return -1;
    }
    return 0;
}

static int hi_log_open_save_file_locked(const char *filePath, size_t filePathLen, unsigned int fileSize)
{
    if (g_fileCtx.fd >= 0) {
        (void)fsync(g_fileCtx.fd);
        (void)close(g_fileCtx.fd);
        g_fileCtx.fd = -1;
    }
    g_fileCtx.opened = false;
    g_fileCtx.currentSize = 0;
    g_fileCtx.path[0] = '\0';
    g_fileCtx.path2[0] = '\0';
    g_fileCtx.maxSize = 0;
    g_fileCtx.isFirstFile = true;

    if (filePath != NULL && filePathLen > 0 && filePath[0] != '\0') {
        if (hi_log_validate_file_path(filePath, filePathLen) != 0) {
            return -1;
        }
        size_t copyLen = (filePathLen - 1 < sizeof(g_fileCtx.path) - 1)
                         ? filePathLen - 1 : sizeof(g_fileCtx.path) - 1;
        memcpy(g_fileCtx.path, filePath, copyLen);
        g_fileCtx.path[copyLen] = '\0';
    } else {
        (void)strncpy(g_fileCtx.path, HI_LOG_DEFAULT_FILE_PATH, sizeof(g_fileCtx.path) - 1);
        g_fileCtx.path[sizeof(g_fileCtx.path) - 1] = '\0';
    }

    if (hi_log_convert_to_absolute() != 0) {
        return -1;
    }

    hi_log_build_rotate_path();
    g_fileCtx.maxSize = (fileSize > 0) ? fileSize : HI_LOG_DEFAULT_FILE_SIZE;

    char dirPath[PATH_MAX] = {0};
    const char *lastSlash = strrchr(g_fileCtx.path, '/');
    if (lastSlash != NULL) {
        size_t dirLen = (size_t)(lastSlash - g_fileCtx.path);
        if (dirLen > 0 && dirLen < sizeof(dirPath)) {
            memcpy(dirPath, g_fileCtx.path, dirLen);
            dirPath[dirLen] = '\0';
            (void)hi_log_mkdir_recursive(dirPath, HI_LOG_DIR_MODE);
        }
    }

    if (hi_log_open_and_sync_size() != 0) {
        return -1;
    }

    if (g_fileCtx.currentSize > g_fileCtx.maxSize) {
        if (hi_log_handle_exceeded_file() != 0) {
            return -1;
        }
    }

    g_fileCtx.opened = true;
    return 0;
}

static void hi_log_file_fallback(const char *modName, HI_LOG_LEVEL_E logLevel,
                                 const char *func, int line,
                                 const char *fmt, va_list args, const char *msg)
{
    fprintf(stderr, "[hi_log] %s: %s, error: %d, fallback to console\n", msg, g_fileCtx.path, errno);
    g_isFileMode = false;
    g_fileCtx.opened = false;
    (void)pthread_mutex_unlock(&g_fileMutex);
    (void)hi_log_console_output(modName, logLevel, func, line, fmt, args);
}

static int hi_log_file_rotate(const char *modName, HI_LOG_LEVEL_E logLevel,
                              const char *func, int line,
                              const char *fmt, va_list args)
{
    (void)fsync(g_fileCtx.fd);
    (void)close(g_fileCtx.fd);
    g_fileCtx.fd = -1;

    g_fileCtx.isFirstFile = !g_fileCtx.isFirstFile;
    const char *newPath = g_fileCtx.isFirstFile ? g_fileCtx.path : g_fileCtx.path2;
    g_fileCtx.fd = open(newPath, O_RDWR | O_CREAT | O_TRUNC, HI_LOG_FILE_MODE);

    if (g_fileCtx.fd >= 0) {
        g_fileCtx.currentSize = 0;
        return 0;
    }

    hi_log_file_fallback(modName, logLevel, func, line, fmt, args, "file rotation open failed");
    return -1;
}

static int hi_log_file_write(const char *modName, HI_LOG_LEVEL_E logLevel,
                             const char *func, int line,
                             const char *userBuf, const char *fmt, va_list args)
{
    char logBuf[HI_LOG_LOG_BUF_SIZE] = {0};
    char tsBuf[HI_LOG_TS_BUF_SIZE] = {0};
    hi_log_timestamp(tsBuf, sizeof(tsBuf));
    int written = snprintf(logBuf, sizeof(logBuf),
            "%s [%s][%s] %s:%d: %s\n",
            tsBuf, hi_log_level_str(logLevel),
            (modName != NULL) ? modName : "",
            (func != NULL) ? func : "", line,
            userBuf);

    if (written < 0) {
        fprintf(stderr, "[hi_log] snprintf encoding error\n");
        (void)pthread_mutex_unlock(&g_fileMutex);
        return -1;
    }

    if (written > 0) {
        size_t writeLen = ((size_t)written < sizeof(logBuf))
                          ? (size_t)written : sizeof(logBuf) - 1;
        ssize_t n = write(g_fileCtx.fd, logBuf, writeLen);

        if (n > 0) {
            g_fileCtx.currentSize += (unsigned int)n;
            if (g_fileCtx.currentSize > UINT_MAX) {
                g_fileCtx.currentSize = UINT_MAX;
            }

            if (g_fileCtx.currentSize > g_fileCtx.maxSize) {
                if (hi_log_file_rotate(modName, logLevel, func, line, fmt, args) != 0) {
                    return -1;
                }
            }

            if (logLevel == HI_LOG_LEVEL_ERROR && g_fileCtx.fd >= 0) {
                (void)fsync(g_fileCtx.fd);
            }
        } else if (n < 0) {
            hi_log_file_fallback(modName, logLevel, func, line, fmt, args, "write failed");
            return -1;
        }
    }
    return 0;
}

static int hi_log_file_output(const char *modName, HI_LOG_LEVEL_E logLevel,
                               const char *func, int line,
                               const char *fmt, va_list args)
{
    char userBuf[HI_LOG_USER_BUF_SIZE] = {0};
    int ret = vsnprintf(userBuf, sizeof(userBuf), fmt, args);

    if (ret < 0) {
        fprintf(stderr, "[hi_log] vsnprintf encoding error\n");
    } else if ((size_t)ret >= sizeof(userBuf)) {
        fprintf(stderr, "[hi_log] log message truncated (buffer size: %zu)\n", sizeof(userBuf));
    }

    (void)pthread_mutex_lock(&g_fileMutex);

    if (!g_fileCtx.opened) {
        int reopenRet = hi_log_open_save_file_locked(NULL, 0, 0);
        if (reopenRet != 0) {
            fprintf(stderr, "[hi_log] auto reopen failed, ret=%d\n", reopenRet);
        }
    }

    if (g_fileCtx.opened && g_fileCtx.fd >= 0) {
        (void)hi_log_file_write(modName, logLevel, func, line, userBuf, fmt, args);
    } else {
        hi_log_file_fallback(modName, logLevel, func, line, fmt, args, "file not opened");
        (void)pthread_mutex_unlock(&g_fileMutex);
        return -1;
    }

    (void)pthread_mutex_unlock(&g_fileMutex);
    return 0;
}
#endif /* LOG_SAVE_TO_FILE */

/* ---------------------------- 初始化/反初始化接口 ---------------------------- */

int HI_LOG_Init(const char *filePath, HI_LOG_LEVEL_E *level, unsigned int fileSize)
{
#ifdef LOG_SAVE_TO_FILE
    (void)pthread_mutex_lock(&g_fileMutex);
#endif

    if (g_isInitialized) {
#ifdef LOG_SAVE_TO_FILE
        (void)pthread_mutex_unlock(&g_fileMutex);
#endif
        fprintf(stderr, "[hi_log] already initialized, call HI_LOG_Deinit first\n");
        return -1;
    }

    if (level != NULL) {
        if (*level < HI_LOG_LEVEL_FATAL || *level >= HI_LOG_LEVEL_BUTT) {
#ifdef LOG_SAVE_TO_FILE
            (void)pthread_mutex_unlock(&g_fileMutex);
#endif
            return -1;
        }
        g_enabledLevel = *level;
        g_maxLevel     = *level;
    } else {
        g_enabledLevel = HI_LOG_DEFAULT_LEVEL;
        g_maxLevel     = HI_LOG_DEFAULT_LEVEL;
    }

#ifdef LOG_SAVE_TO_FILE
    g_isFileMode = true;
    size_t filePathLen = (filePath != NULL && filePath[0] != '\0')
                         ? strlen(filePath) + 1 : 0;

    int ret = hi_log_open_save_file_locked(filePath, filePathLen, fileSize);
    if (ret != 0) {
        g_isFileMode = false;
        (void)pthread_mutex_unlock(&g_fileMutex);
        return ret;
    }
#else
    (void)filePath;
    (void)fileSize;
    g_isFileMode = false;
#endif

    g_isInitialized = true;

#ifdef LOG_SAVE_TO_FILE
    (void)pthread_mutex_unlock(&g_fileMutex);
#endif
    return 0;
}

int HI_LOG_Deinit(void)
{
    if (!g_isInitialized) {
        return -1;
    }

#ifdef LOG_SAVE_TO_FILE
    (void)pthread_mutex_lock(&g_fileMutex);
    if (g_isFileMode && g_fileCtx.fd >= 0) {
        (void)fsync(g_fileCtx.fd);
        (void)close(g_fileCtx.fd);
        g_fileCtx.fd = -1;
    }
    g_fileCtx.opened = false;
    g_fileCtx.currentSize = 0;
    g_fileCtx.path[0] = '\0';
    g_fileCtx.path2[0] = '\0';
    g_fileCtx.maxSize = 0;
    g_isFileMode = false;
    g_enabledLevel = HI_LOG_DEFAULT_LEVEL;
    g_maxLevel = HI_LOG_DEFAULT_LEVEL;
    (void)pthread_mutex_unlock(&g_fileMutex);
#endif

    g_isInitialized = false;
    return 0;
}

/* ---------------------------- 终端输出实现 ---------------------------- */

static int hi_log_console_output(const char *modName, HI_LOG_LEVEL_E logLevel,
                                  const char *func, int line,
                                  const char *fmt, va_list args)
{
    char userBuf[HI_LOG_USER_BUF_SIZE] = {0};
    int ret = vsnprintf(userBuf, sizeof(userBuf), fmt, args);

    if (ret < 0) {
        fprintf(stderr, "[hi_log] vsnprintf encoding error\n");
    } else if ((size_t)ret >= sizeof(userBuf)) {
        fprintf(stderr, "[hi_log] log message truncated (buffer size: %zu)\n", sizeof(userBuf));
    }

    (void)pthread_once(&g_isTtyOnce, hi_log_init_is_tty);
    const char *color = g_isTty ? hi_log_level_color(logLevel) : "";
    const char *reset = g_isTty ? HI_LOG_COLOR_RESET : "";

    char tsBuf[HI_LOG_TS_BUF_SIZE] = {0};
    hi_log_timestamp(tsBuf, sizeof(tsBuf));
    fprintf(stderr, "%s%s [%s][%s] %s:%d: %s%s\n",
            color, tsBuf, hi_log_level_str(logLevel),
            (modName != NULL) ? modName : "",
            (func != NULL) ? func : "", line,
            userBuf, reset);

    return 0;
}

/* ---------------------------- 核心日志输出函数 ---------------------------- */

int HI_LOG_PrintfInfo(const char *modName, HI_LOG_LEVEL_E logLevel,
                      const char *func, int line,
                      const char *fmt, ...)
{
    if (logLevel > g_enabledLevel) {
        return 0;
    }

    va_list args;
    va_start(args, fmt);

#ifdef LOG_SAVE_TO_FILE
    bool isFileMode;
    (void)pthread_mutex_lock(&g_fileMutex);
    isFileMode = g_isFileMode;
    (void)pthread_mutex_unlock(&g_fileMutex);
    if (isFileMode) {
        hi_log_file_output(modName, logLevel, func, line, fmt, args);
    } else
#endif
    {
        hi_log_console_output(modName, logLevel, func, line, fmt, args);
    }

    va_end(args);
    return 0;
}

/* ---------------------------- 公共接口实现 ---------------------------- */

int HI_LOG_SetEnabledLevel(HI_LOG_LEVEL_E level)
{
    if (level < HI_LOG_LEVEL_FATAL || level >= HI_LOG_LEVEL_BUTT) {
        return -1;
    }
    if (level > g_maxLevel) {
        return -1;
    }
    g_enabledLevel = level;
    return 0;
}

HI_LOG_LEVEL_E HI_LOG_GetEnabledLevel(void)
{
    return g_enabledLevel;
}

const char* HI_LOG_GetCurrentFilePath(void)
{
#ifdef LOG_SAVE_TO_FILE
    return (g_fileCtx.opened && g_fileCtx.path[0] != '\0') ? g_fileCtx.path : NULL;
#else
    return NULL;
#endif /* LOG_SAVE_TO_FILE */
}

bool HI_LOG_IsFileMode(void)
{
#ifdef LOG_SAVE_TO_FILE
    return g_isFileMode;
#else
    return false;
#endif /* LOG_SAVE_TO_FILE */
}
