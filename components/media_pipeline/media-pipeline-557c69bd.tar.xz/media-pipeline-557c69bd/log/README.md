# log

平台无关的轻量日志组件，作为 `components/media` 实用组件为框架层、组件层和应用层提供统一的打印、断言与返回值处理接口，屏蔽底层输出差异。

**功能特性：**

- 支持 FATAL / ERROR / WARNING / INFO / DEBUG 四级日志，运行时通过 `HI_LOG_SetEnabledLevel()` 在初始化等级上限内动态收紧输出范围
- 编译期裁剪：`-DLOG_ENABLE=OFF` 时所有日志宏展开为 `((void)0)`，零运行时开销
- 两种输出后端：终端模式（带 `isatty` 检查的 ANSI 彩色输出）和文件模式（双文件自动轮转，多线程安全），通过 `-DLOG_SAVE_TO_FILE` 编译选项切换
- 统一初始化接口 `HI_LOG_Init`，运行时指定输出路径、初始等级和文件大小阈值
- 提供断言宏 `HI_ASSERT` / `HI_ASSERT_MSG`，失败时打印文件名、行号并终止进程
- 提供返回值检查宏族（`HI_CHECK_RET` / `HI_CHECK_RET_VAL` / `HI_CHECK_NULL` / `HI_CHECK_TRUE` / `HI_LOG_RET` / `HI_CHECK_GOTO`），统一处理错误传播

---

## 目录结构

```
components/media/log/
├── CMakeLists.txt      # 组件 CMake 入口
├── include/
│   └── hi_log.h        # 对外头文件：宏、枚举、接口声明
└── src/
    └── hi_log.c        # 后端实现：终端输出 / 文件输出
```

---

## 支持平台

| 芯片 | 开发板 | 备注 |
|------|--------|------|
| Hi3516CV610 | cv610_ev_board | 已验证 |
| 其他 HiSpark 平台 | — | 仅依赖标准 C 和 POSIX，可直接移植 |

---

## 架构设计

```
调用方（框架层 / 组件层 / 应用层）
        │
        │  HI_LOGF / HI_LOGE / HI_LOGW / HI_LOGI / HI_LOGD
        │  HI_ASSERT / HI_CHECK_RET / HI_CHECK_NULL / ...
        ▼
   hi_log.h（宏封装层）
        │
        │  LOG_ENABLE=ON  → HI_LOG_PrintfInfo()
        │  LOG_ENABLE=OFF → ((void)0)，链接器完全消除
        ▼
   hi_log.c（后端实现层）
        ├── 终端模式（LOG_SAVE_TO_FILE=OFF，默认）
        │     fprintf(stderr) + isatty 检查 + ANSI 颜色输出
        │     线程安全由 libc flockfile 保证，无需 pthread
        └── 文件模式（LOG_SAVE_TO_FILE=ON）
              write() + pthread_mutex + 双文件自动轮转 + 多线程安全
```

运行时初始化流程：

```
HI_LOG_Init(filePath, level, fileSize)
        │
        ├── LOG_SAVE_TO_FILE=OFF → 始终终端模式，filePath/fileSize 被忽略
        └── LOG_SAVE_TO_FILE=ON
                ├── filePath=NULL 或空 → 文件模式，写入默认路径 logfile/system_log.log
                └── filePath 非空     → 文件模式，写入指定路径
                                            └── HI_LOG_OpenSaveFile()
                                                  └── 双文件轮转策略：
                                                      file1 满 → 切换写 file2
                                                      file2 满 → 清空 file1 重写
```

等级上限约束：

```
HI_LOG_Init(filePath, &level, fileSize)  ← 设定运行时等级上限 g_maxLevel = level
        │
        └── HI_LOG_SetEnabledLevel(newLevel)
                ├── newLevel ≤ g_maxLevel → 允许，收紧等级
                └── newLevel > g_maxLevel → 拒绝，返回 -1
```

---

## 快速开始

### 最小示例

```c
#include "hi_log.h"

#define TAG "my_module"

int main(void)
{
    /* 终端模式，默认 INFO 等级 */
    HI_LOG_Init(NULL, NULL, 0);

    HI_LOGI(TAG, "应用启动");

    HI_LOG_Deinit();
    return 0;
}
```

### 文件模式示例

```c
#include "hi_log.h"

#define TAG "my_module"

int main(void)
{
    /* 文件模式，DEBUG 等级，单文件最大 10 MB */
    /* 编译时需传入 -DLOG_SAVE_TO_FILE=ON */
    HI_LOG_LEVEL_E level = HI_LOG_LEVEL_DEBUG;
    HI_LOG_Init("/var/log/my_app.log", &level, 10u * 1024u * 1024u);

    HI_LOGI(TAG, "文件模式启动，路径=%s", HI_LOG_GetCurrentFilePath());

    HI_LOG_Deinit();
    return 0;
}
```

### 配置说明

**编译选项**（两个选项均有默认值，不传时以默认值生效）：

| 编译选项 | 合法值 | 默认值 | 说明 |
|---------|--------|--------|------|
| `LOG_ENABLE` | `ON YES TRUE 1` / `OFF NO FALSE 0` | `ON` | 是否编译日志代码 |
| `LOG_SAVE_TO_FILE` | `ON YES TRUE 1` / `OFF NO FALSE 0` | `OFF` | 是否启用文件输出后端 |

**运行时 `HI_LOG_Init` 参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| `filePath[in]` | `const char *` | 日志文件路径；`LOG_SAVE_TO_FILE=OFF` 时忽略；`LOG_SAVE_TO_FILE=ON` 时 `NULL`/空字符串使用默认路径 `logfile/system_log.log` |
| `level[in]` | `HI_LOG_LEVEL_E *` | 初始等级指针，同时设定运行时上限；`NULL` 使用默认等级 `INFO` |
| `fileSize[in]` | `unsigned int` | 单文件最大字节数阈值；`0` 使用默认值 `5 MB`；`LOG_SAVE_TO_FILE=OFF` 时忽略 |

### 构建启用

在应用或组件的 `CMakeLists.txt` 中链接日志组件：

```cmake
target_link_libraries(my_target PUBLIC hi_log)
```

编译时传入选项：

```bash
# 关闭日志
bash scripts/build.sh build --target <开发板目录> <案例目录> <案例名称> -DLOG_ENABLE=OFF

# 启用日志，终端输出（默认）
bash scripts/build.sh build --target <开发板目录> <案例目录> <案例名称> -DLOG_ENABLE=ON -DLOG_SAVE_TO_FILE=OFF

# 启用日志，文件输出
bash scripts/build.sh build --target <开发板目录> <案例目录> <案例名称> -DLOG_ENABLE=ON -DLOG_SAVE_TO_FILE=ON
```

---

# 附录

## API 参考

### 等级枚举

```c
typedef enum {
    HI_LOG_LEVEL_FATAL = 0, /* 致命：系统崩溃，最高优先级 */
    HI_LOG_LEVEL_ERROR,     /* 错误：不可恢复             */
    HI_LOG_LEVEL_WARN,      /* 警告：可恢复的异常         */
    HI_LOG_LEVEL_INFO,      /* 信息：关键流程节点（默认） */
    HI_LOG_LEVEL_DEBUG,     /* 调试：详细调试信息，最低优先级 */
    HI_LOG_LEVEL_BUTT       /* 无效等级，用于重置运行时上限 */
} HI_LOG_LEVEL_E;

/* 默认等级，Init 时 level=NULL 使用此值 */
#define HI_LOG_DEFAULT_LEVEL HI_LOG_LEVEL_INFO
```

### 初始化 / 反初始化

```c
/**
 * @brief 初始化日志模块（仅允许调用一次，重复调用返回 -1）
 * @param filePath[in]  日志文件路径（LOG_SAVE_TO_FILE=ON 时有效）
 *                      NULL 或空字符串 → 使用默认路径 logfile/system_log.log
 *                      非空路径 → 写入指定路径（不能以 '/' 结尾）
 *                      LOG_SAVE_TO_FILE=OFF 时此参数被忽略
 * @param level[in]     初始等级指针，同时设定运行时上限；NULL 使用默认等级 INFO
 * @param fileSize[in]  单文件最大字节数阈值（LOG_SAVE_TO_FILE=ON 有效），0 使用默认 5 MB
 * @return 0 成功，-1 失败（参数非法 / 已初始化 / 文件打开失败）
 * @warning 文件模式不支持多进程同时写入同一文件。若多进程共用同一文件，
 *          必须指定完全相同的 fileSize；各进程轮转计数独立，仍可能超限。
 *          推荐做法：每个进程使用独立文件路径。
 */
int HI_LOG_Init(const char *filePath, HI_LOG_LEVEL_E *level, unsigned int fileSize);

/**
 * @brief 反初始化日志模块，文件模式下刷盘并关闭文件，重置所有运行时状态
 * @return 0 成功，-1 未初始化
 */
int HI_LOG_Deinit(void);
```

### 日志打印

```c
HI_LOGF(tag, fmt, ...)   /* FATAL   级，系统崩溃错误*/
HI_LOGE(tag, fmt, ...)   /* ERROR   级，不可恢复错误 */
HI_LOGW(tag, fmt, ...)   /* WARNING 级，可恢复异常  */
HI_LOGI(tag, fmt, ...)   /* INFO    级，关键流程节点 */
HI_LOGD(tag, fmt, ...)   /* DEBUG   级，详细调试信息 */
```

`tag` 为模块标识字符串（建议不超过 32 字节），`fmt` 为 printf 格式串。输出格式示例：

```
2025/06/10 14:23:45 [ERROR][vi_dev] vi_open:42: 设备打开失败，ret=0xffffffff
2025/06/10 14:23:45 [INFO][sys] sys_init:67: 系统初始化完成
```

### 等级控制

```c
/**
 * @brief 运行时设置输出等级，只允许在 [FATAL, Init 时的初始等级] 范围内收紧
 * @param level[in]     目标等级
 * @return 0 成功，-1 参数非法或超过初始化时设定的等级上限
 */
int HI_LOG_SetEnabledLevel(HI_LOG_LEVEL_E level);

/**
 * @brief 获取当前运行时输出等级
 * @return 当前输出等级
 */
HI_LOG_LEVEL_E HI_LOG_GetEnabledLevel(void);
```

### 状态查询

```c
/**
 * @brief 获取当前日志文件路径（LOG_SAVE_TO_FILE=ON 且已打开时有效）
 * @return 文件路径字符串，或 NULL（终端模式 / 文件未打开）
 */
const char *HI_LOG_GetCurrentFilePath(void);

/**
 * @brief 判断是否处于文件输出模式
 * @return true 文件模式，false 终端模式
 */
bool HI_LOG_IsFileMode(void);
```

### 断言

```c
HI_ASSERT(expr)                /* expr 为假时打印文件名、行号并 abort() */
HI_ASSERT_MSG(expr, fmt, ...)  /* 同上，支持自定义消息 */
```

断言宏使用 `fprintf(stderr)` 直接输出，不依赖日志模块的其他功能，确保在 `LOG_ENABLE=OFF` 时行为一致。

### 返回值检查

```c
/* expr 返回值不为 0 时打印 ERROR 日志并 return 该值（expr 须与 int 兼容） */
HI_CHECK_RET(expr)
HI_CHECK_RET_MSG(expr, fmt, ...)

/* expr 返回值不等于 expectVal 时打印 ERROR 日志并 return 该值 */
HI_CHECK_RET_VAL(expr, expectVal)
HI_CHECK_RET_VAL_MSG(expr, expectVal, fmt, ...)

/* 指针为空时打印 ERROR 日志并 return errCode */
HI_CHECK_NULL(ptr, errCode)

/* 条件为假时打印 ERROR 日志并 return errCode */
HI_CHECK_TRUE(expr, errCode)
HI_CHECK_TRUE_MSG(expr, errCode, fmt, ...)

/* 失败时只打 WARNING 日志，不 return，适用于可忽略的操作 */
HI_LOG_RET(expr)
HI_LOG_RET_VAL(expr, expectVal)

/* 条件为假时执行 stmt 并跳转到 label，stmt 无内容时传 (void)0 */
HI_CHECK_GOTO(expr, label, stmt)
```

### 返回码

| 值 | 含义 |
|----|------|
| `0` | 成功 |
| `-1` | 参数非法 / 文件操作失败 / 重复初始化 / 未初始化（Deinit）/ 超过等级上限 |

---

## 相关案例与文档

| 案例 | 说明 |
|------|------|
| [ai_table_lamp](https://gitcode.com/HiSpark/hi_aiot_solution_cv610_ev_board_private/blob/master/references/ai_table_lamp/README.md) | 台灯应用，组件层调用示例 |
| [cloud_agent](https://gitcode.com/HiSpark/hi_aiot_solution_cv610_ev_board_private/blob/master/references/cloud_agent/README.md) | 云智能体应用，组件层调用示例 |
| [offline_voice_ac_control](https://gitcode.com/HiSpark/hi_aiot_solution_cv610_ev_board_private/blob/master/references/offline_voice_ac_control/README.md) | 离线语音控制应用，组件层调用示例 |
| [zeroclaw_base](https://gitcode.com/HiSpark/hi_aiot_solution_cv610_ev_board_private/blob/master/references/zeroclaw_base/README.md) | zeroclaw 基础应用，组件层调用示例 |

---

## 补充说明

**线程安全：** 终端模式依赖 libc `fprintf` 的 `flockfile` 内部锁，多线程并发安全，不链接 pthread。文件模式通过 `pthread_mutex_t` 保护共享文件状态和初始化过程，多线程并发安全，`CMakeLists.txt` 在 `LOG_SAVE_TO_FILE=ON` 时自动链接 `pthread`。静态变量 `g_isTty` 通过 `pthread_once`（即 `g_isTtyOnce`）保证多线程环境下首次初始化的原子性。

**等级上限约束：** `HI_LOG_SetEnabledLevel()` 只允许在 `[FATAL, Init 时的初始等级]` 范围内收紧，不能放宽超过初始化时设定的上限。例如 `Init` 时传入 `INFO`，运行时只能调整到 `FATAL`、`ERROR`、`WARN` 或 `INFO`，调用 `SetEnabledLevel(HI_LOG_LEVEL_DEBUG)` 会返回 `-1`。

**双文件轮转：** 文件模式采用双文件策略。`file1` 写满后切换写 `file2`，`file2` 写满后清空 `file1` 重新写入，每个进程始终保留最近约 `fileSize ~ 2 × fileSize` 字节的日志。`fileSize` 参数是触发轮转的阈值，不是单文件的精确大小上限。第二个文件命名规则：在原文件名基础上加 `_2` 后缀（如 `app.log` → `app_2.log`）。

**文件路径：** 默认日志文件路径 `filePath` 相对于进程运行时的**当前工作目录**，与可执行文件位置无关。嵌入式场景建议通过 `HI_LOG_Init` 传入绝对路径，例如 `HI_LOG_Init("/var/log/ai_table_lamp/app_vi.log", &level, 0)`。

**多进程限制：** 文件模式不支持多进程同时写入同一文件。`g_fileCurrentSize` 是进程私有计数，多进程共写同一文件时轮转判断失效，文件可能无限增长，极端情况下，下一个进程的轮转会清空另一个进程正在写入的文件导致数据丢失。强烈建议为每个进程指定独立文件路径，配合通配符统一查询：

```bash
grep -E "ERROR|WARN" /var/log/app_*.log | tail -20
```

**消息长度限制：** `hi_log.c` 内部使用两个固定大小的栈上缓冲区：

- `userBuf[384]`：存储格式化后的用户消息，有效内容最多 383 字节（含 `'\0'`），由 `logBuf[512]` 总容量约束
- `logBuf[512]`：存储完整日志行（时间戳约 22 字节 + 等级约 10 字节 + `tag` + 函数名 + 行号 + 用户消息），有效内容最多 511 字节

超出限制的部分会被截断，不会崩溃，但日志内容不完整。截断发生时会向 `stderr` 输出警告信息（如 `[hi_log] log message truncated (buffer size: 384)`）。`tag`（`mode`）建议不超过 32 字节，过长的 `tag` 会挤占用户消息的空间。若需更长的消息，修改 `hi_log.c` 中对应的缓冲区大小：

```c
/* hi_log.c — 按需调整，logBuf 须大于 userBuf + 约 80~128 字节前缀 */
char userBuf[384] = {0};
char logBuf[512]  = {0};
```

**重复初始化：** `HI_LOG_Init` 在已初始化状态下调用返回 `-1` 并打印提示，需先调用 `HI_LOG_Deinit` 再重新初始化。`HI_LOG_Deinit` 在未初始化状态下调用同样返回 `-1`。

**量产建议：** 量产镜像编译时传入 `-DLOG_ENABLE=OFF` 将所有日志代码从二进制中完全消除。若需保留关键错误日志，传入 `-DLOG_ENABLE=ON` 并在运行时通过 `HI_LOG_Init` 指定等级为 `HI_LOG_LEVEL_ERROR`。
