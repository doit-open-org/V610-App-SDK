/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_VPSS_INNER_H__
#define __MAPI_VPSS_INNER_H__

#include <pthread.h>
#include <limits.h>
#include "mapi_comm_inner.h"
#include "hi_mw_log.h"
#include "hi_mapi_vpss_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

#define MAPI_VPSS_DATA_PROC_TIMEOUTS_MS    5000
#define MAPI_VPSS_SEND_FRAME_TIMEOUTS_MS   500

#define VCAPPIPE_CHECK_HANDLE_RET(hdl)                                                                        \
    do {                                                                                                      \
        if ((hdl) >= HI_MAPI_VCAP_MAX_PIPE_NUM) {                                                             \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "VcapPipe handle(%d) is invalid, only suppwort [0, %d]\n", hdl, \
                           HI_MAPI_VCAP_MAX_PIPE_NUM - 1);                                                    \
            return HI_MAPI_VPSS_EILLEGAL_PARAM;                                                              \
        }                                                                                                     \
    } while (0)

#define VCAPCHN_CHECK_HANDLE_RET(hdl)                                                                       \
    do {                                                                                                    \
        if ((hdl) >= HI_MAPI_VCAP_PIPE_MAX_CHN_NUM) {                                                       \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "PipeChn handle(%d) is invalid, only support [0, %d]\n", hdl, \
                           HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1);                                              \
            return HI_MAPI_VPSS_EILLEGAL_PARAM;                                                            \
        }                                                                                                   \
    } while (0)

#define VPSS_CHECK_HANDLE_RET(hdl)                                                                       \
    do {                                                                                                 \
        if ((hdl) >= HI_MAPI_VPSS_MAX_NUM) {                                                       \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss handle(%d) is invalid, only support [0, %d]\n", hdl, \
                           HI_MAPI_VPSS_MAX_NUM - 1);                                              \
            return HI_MAPI_VPSS_EINVALID_DEVID;                                                         \
        }                                                                                                \
    } while (0)

#define CHN_CHECK_HANDLE_RET(hdl)                                                                       \
    do {                                                                                                  \
        if ((hdl) >= HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM) {                 \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Chn handle(%d) is invalid, only support [0, %d]\n", hdl, \
                           HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM - 1);        \
            return HI_MAPI_VPSS_EINVALID_CHNID;                                                          \
        }                                                                                                 \
    } while (0)

#define CHN_CHECK_PHY_HANDLE_RET(hdl)                                                                       \
    do {                                                                                                      \
        if ((hdl) >= HI_MAPI_VPSS_PHY_CHN_MAX_NUM) {                                                       \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Phy Chn handle(%d) is invalid, only support [0, %d]\n", hdl, \
                           HI_MAPI_VPSS_PHY_CHN_MAX_NUM - 1);                                              \
            return HI_MAPI_VPSS_EINVALID_CHNID;                                                              \
        }                                                                                                     \
    } while (0)

#define CHN_CHECK_EXT_HANDLE_RET(hdl)                                                                            \
    do {                                                                                                           \
        if (((hdl) >= HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM) ||                        \
            ((hdl) < HI_MAPI_VPSS_PHY_CHN_MAX_NUM)) {                                                           \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Extern Chn handle(%d) is invalid, only support [%d, %d]\n", hdl,  \
                           HI_MAPI_VPSS_PHY_CHN_MAX_NUM,                                                        \
                           HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM - 1);                 \
            return HI_MAPI_VPSS_EINVALID_CHNID;                                                                   \
        }                                                                                                          \
    } while (0)

#define VPSS_CHECK_NULL_PTR_RET(ptr)                             \
    do {                                                          \
        if ((ptr) == NULL) {                                      \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Null pointer!\n"); \
            return HI_MAPI_VPSS_ENULL_PTR;                       \
        }                                                         \
    } while (0)

#define VPSS_CHECK_RET(str, ret)                                          \
    do {                                                                   \
        if ((ret) != TD_SUCCESS) {                                         \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "%s,ret:[%#x]\n", str, ret); \
            return ret;                                                    \
        }                                                                  \
    } while (0)

#define VPSS_CHECK_RET_UNLOCK(str, ret, m_lock)                           \
    do {                                                                   \
        if ((ret) != TD_SUCCESS) {                                         \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "%s,ret:[%#x]\n", str, ret); \
            MAPI_MUTEX_UNLOCK(m_lock);                                     \
            return ret;                                                    \
        }                                                                  \
    } while (0)

#define VPSS_CHECK_PTHREAD_RET(ret, str)                                        \
	do {																		 \
		if ((ret) != TD_SUCCESS) {												 \
			MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "%s fail, ret:[%#x]\n", str, ret); \
			return (td_void *)TD_NULL;											 \
		}																		 \
	} while (0)

typedef struct {
    td_bool is_chn_start;
    td_bool support_buffer_share;
    hi_mapi_vpss_low_delay_info low_delay_info;
    hi_mapi_vpss_buf_wrap_attr buf_wrap_attr;   /* buffer wrap (卷绕); only 'enable' is user-set */
    td_u32 width;                               /* chn output width, cached for wrap buf_line calc */
    td_u32 height;                              /* chn output height, cached for wrap buf_line calc */
    td_u32 pool_id;
} mapi_vpss_phy_chn_attr;

typedef struct {
    td_bool is_phy_chn_start;
    td_bool is_ext_chn_start;
    hi_mapi_vpss_low_delay_info low_delay_info;
    td_u32 pool_id;
} mapi_vpss_ext_chn_attr;

typedef struct {
    td_bool is_vpss_start;
	td_u32 frm_time_ref;
    td_u32 max_width;
    td_u32 max_height;
    td_bool have_set_gdc_for_ldc_before;
    mapi_vpss_phy_chn_attr vpss_phy_chn_attr[HI_MAPI_VPSS_PHY_CHN_MAX_NUM];
    mapi_vpss_ext_chn_attr vpss_ext_chn_attr[HI_MAPI_VPSS_EXT_CHN_MAX_NUM];
} mapi_vpss_ctx;

#ifdef SUPPORT_IVE
#define MAPI_IVE_ALIGN 16
#define MAPI_IVE_GET_FRMAE_SLEEP_MS 30
#define MAPI_VPSS_SEND_FRMAE_TIMEOUT_MS 10

typedef struct {
    td_bool is_thread_start;
    td_handle vcap_pipe_hdl;
    td_handle vpss_hdl;
    hi_mapi_yuv_data_seq vi_yuv_seq;
    td_u32 vb_blk;
    pthread_t thread_id;
} mapi_vpss_ive_param;
#endif

td_s32 mapi_vpss_get_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    hi_mapi_frame_data *yuv_frame_data, td_s32 milli_sec);
td_s32 mapi_vpss_release_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    const hi_mapi_frame_data *yuv_frame_data);

td_s32 mapi_vpss_set_chn_depth(td_handle grp_hdl, td_handle chn_hdl, 
    const td_void *cmd_attr, td_u32 len);
td_s32 mapi_vpss_get_chn_depth(td_handle grp_hdl, td_handle chn_hdl, 
    td_void *cmd_attr, td_u32 len);

td_s32 mapi_vpss_set_grp_crop(td_handle grp_hdl, td_handle chn_hdl, 
    const td_void *cmd_attr, td_u32 len);
td_s32 mapi_vpss_get_grp_crop(td_handle grp_hdl, td_handle chn_hdl, 
    td_void *cmd_attr, td_u32 len);   

td_s32 mapi_vpss_init(td_void);
td_s32 mapi_vpss_deinit(td_void);

#ifdef SUPPORT_IVE
td_void mapi_vpss_init_ive(td_handle vpss_hdl);
td_s32 mapi_vpss_stop_recv_yuv(td_handle vpss_hdl);
td_s32 mapi_vpss_start_recv_yuv(td_handle vpss_hdl, td_handle vcap_pipe_hdl, hi_mapi_yuv_data_seq vi_yuv_seq);
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif
