/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_HDMI_INNER_H__
#define __MAPI_HDMI_INNER_H__

#include "hi_mapi_comm_define.h"
#include "hi_mapi_hdmi_define.h"
#include "hi_mw_log.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define HDMI_CHECK_HANDLE(Hdl) \
    do { \
        if ((Hdl) >= HI_MAPI_HDMI_ID_BUTT) { \
            MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Hdmi handle(%d) is invalid, only support [0, %d]\n", Hdl, \
                           HI_MAPI_HDMI_ID_BUTT - 1); \
            return HI_MAPI_HDMI_EINVALID_DEVID; \
        } \
    } while (0)

#define HDMI_CHECK_NULL_PTR(pstPtr)                                                                            \
    do {                                                                                                       \
        if ((pstPtr) == NULL) {                                                                                \
            MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Null pointer! FUNCTION %s, LINE %d!\n", __FUNCTION__, __LINE__); \
            return HI_MAPI_HDMI_ENULL_PTR;                                                                     \
        }                                                                                                      \
    } while (0)

#define HDMI_CHECK_INIT(state)                                              \
    do {                                                                    \
        if (!(state)) {                                                       \
            MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has not been inited\n"); \
            return HI_MAPI_HDMI_ENOTREADY;                                  \
        }                                                                   \
    } while (0)

typedef struct {
    td_bool hdmi_inited;
    td_bool hdmi_started;
    hi_mapi_hdmi_call_back_func hdmi_cb_func;
} mapi_hdmi_context;

td_void mapi_hdmi_get_call_back(hi_mapi_hdmi_call_back_func **hdmi_callback);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_HDMI_INNER_H__ */
