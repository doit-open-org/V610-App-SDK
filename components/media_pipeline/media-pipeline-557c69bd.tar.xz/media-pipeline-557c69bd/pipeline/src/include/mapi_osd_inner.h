/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_OSD_INNER_H__
#define __MAPI_OSD_INNER_H__

#include "hi_mapi_comm_adapt_define.h"
#include "hi_mapi_osd_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/* OSD Font Step In Lib, in bytes */
#define MAPI_OSD_RATIO_COORDINATE_MAX_VALUE 100

#define MAPI_ADEC_WAIT_TIME_CHANGE_USLEEP_TIME (10 * 1000)
#define MAPI_ADEC_WAIT_UPDATE_TIME_USLEEP_TIME (500 * 1000)
#define MAPI_OSD_CHAR_NUM 256

/* osd updated state */
typedef enum {
    MAPI_OSD_UPDATE_STATE_ATTACH = 0,
    MAPI_OSD_UPDATE_STATE_DISPLAY,
    MAPI_OSD_UPDATE_STATE_REBUILD,
    MAPI_OSD_UPDATE_STATE_BUTT
} mapi_osd_update_state;

typedef enum {
    MAPI_OSD_OVERLAY_RGN = 0, /* video overlay region */
    MAPI_OSD_COVER_RGN,
    MAPI_OSD_COVEREX_RGN,
    MAPI_OSD_OVERLAYEX_RGN,
    MAPI_OSD_MOSAIC_RGN,
    MAPI_OSD_MOSAICEX_RGN,
    MAPI_OSD_LINE_RGN,
    MAPI_OSD_LINEEX_RGN,
    MAPI_OSD_CORNER_RGN,
    MAPI_OSD_CORNEREX_RGN,
    MAPI_OSD_RGN_BUTT
} mapi_osd_rgn_type;

/* OSD Parameter */
typedef struct {
    hi_mapi_osd_attr old_osd_attr;
    hi_mapi_osd_attr osd_attr;
    hi_mapi_size max_size;
    pthread_mutex_t mutex_lock;
    td_bool is_init;    /* OSD Attribute Set or not, Canbe modified only hi_mapi_osd_set_attr */
    td_bool is_start;   /* OSD start/stop Flag, Canbe modified only by hi_mapi_osd_start/hi_mapi_osd_stop */
    mapi_osd_update_state update_state; /* OSD attr updated state */
    td_char str[HI_MAPI_MAX_STR_LEN];
    mapi_osd_rgn_type rgn_type;
} mapi_osd_param;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* __MAPI_OSD_INNER_H__ */
