/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_AO_INNER_H__
#define __MAPI_AO_INNER_H__

#include "hi_mapi_comm_define.h"
#include "hi_mw_log.h"
#include "hi_mapi_ao_arch.h"
#include "hi_mapi_ao_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define MAPI_AO_FRAME_CACHED_CNT 4

#define CHECK_MAPI_AO_NULL_PTR_RET(pointer)                                                                \
    do {                                                                                                   \
        if ((pointer) == NULL) {                                                                           \
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "Null pointer!FUNCTION %s,LINE %d!\n", __FUNCTION__, __LINE__); \
            return HI_MAPI_AO_ENULLPTR;                                                                    \
        }                                                                                                  \
    } while (0)

#define CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl)                                                                \
    do {                                                                                                      \
        if ((ao_hdl) >= HI_MAPI_AO_DEV_MAX_NUM) {                                                             \
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "Invalid Handle(%d)!FUNCTION %s,LINE %d!\n", ao_hdl, __FUNCTION__, \
               __LINE__);                                                                                     \
            return HI_MAPI_AO_EINVALIDHDL;                                                                    \
        }                                                                                                     \
    } while (0)

#define CHECK_MAPI_AO_CHN_HANDLE_RANGE_RET(ao_chn_hdl)                                                            \
    do {                                                                                                          \
        if ((ao_chn_hdl) >= (HI_MAPI_AO_CHN_MAX_NUM - 1)) {                                                       \
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "Invalid Handle(%d)!FUNCTION %s,LINE %d!\n", ao_chn_hdl, __FUNCTION__, \
                __LINE__);                                                                                        \
            return HI_MAPI_AO_EINVALIDHDL;                                                                        \
        }                                                                                                         \
    } while (0)

#define CHECK_MAPI_AO_ADECHANDLE_RANGE_RET(handle)                                                                \
    do {                                                                                                          \
        if ((handle) >= HI_MAPI_ADEC_CHN_MAX_NUM) {                                                               \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "ADEC handle out of range\n");                                       \
            return HI_MAPI_AO_EINVALIDHDL;                                                                        \
        }                                                                                                         \
    } while (0)

#define CHECK_MAPI_AO_INIT_RET(is_init)                                                                         \
    do {                                                                                                        \
        if ((is_init) == TD_FALSE) {                                                                            \
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited!FUNCTION %s,LINE %d!\n", __FUNCTION__, __LINE__); \
            return HI_MAPI_AO_ENOTINITED;                                                                       \
        }                                                                                                       \
    } while (0)

typedef enum {
    MAPI_AO_UNINITED = 0,
    MAPI_AO_STOPED,
    MAPI_AO_STARTED,
    MAPI_AO_BUTT
} mapi_ao_state;

typedef struct {
    hi_mapi_ao_attr            ao_attr;
    mapi_ao_state              ao_state;
    td_u32                     expand_flag;
    td_u32                     frm_num;
    td_u32                     chn_cnt;
    td_u32                     clk_sel;
    td_bool                    ao_chn_start[HI_MAPI_AO_CHN_MAX_NUM];
    hi_mapi_audio_ao_vqe_attr  ao_vqe_attr;
} mapi_ao_server_context;

td_s32  mapi_ao_init(td_void);
td_s32  mapi_ao_deinit(td_void);
td_void mapi_ao_init_vqe_cfg(const hi_mapi_audio_vqe_attr *audio_vqe_cfg);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_AO_INNER_H__ */
