/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VENC_INNER_H__
#define __HI_MAPI_VENC_INNER_H__

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#include "hi_mapi_comm_define.h"
#include "hi_mapi_venc_define.h"
#include "hi_mapi_venc.h"
#include "hi_mw_log.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define VENC_GET_FRAME_THREAD_USLEEP_TIME         (10 * 1000)
#define VENC_GET_FRAME_THREAD_SLEECT_TIMEOUT_USEC (10 * 1000)
#define VENC_PROCESS_STREAM_USLEEP_TIME           (10 * 1000)
#define VENC_FRAME_LOST_BPS_THRESHOLD             (8 * 8 * 1024 * 1024)
#define VENC_MSLEEP_TIME_UNIT                     1000

#define MAPI_VENC_MAX_PROFILE_H264  2
#define MAPI_VENC_MAX_PROFILE_H265  1
#define MAPI_VENC_MAX_PROFILE_JPEG  0
#define MAPI_VENC_MAX_PROFILE_MJPEG 0

#define MAPI_VENC_DATAFIFONODE_CNT    100

#define MAPI_VENC_THREAD_NAME_MAX_LEN 128

/* Fast-start version, maximum frame rate at high frame rate */
#define MAX_STREAM_CNT 800

#define MAPI_VENC_INTERVAL_MAX_TIME   2000
#define MAPI_ADAPT_VENC_MAX_TILE_NUM 1

#define ALIGN_NEXT(v, a)      ((((v) + ((a) - 1)) & (~((a) - 1))))
#define ALIGN_LENGTH_64BYTE(l) ALIGN_NEXT(l, 64)

#define CHECK_MAPI_VENC_NULL_PTR_RET(ptr)                            \
    do {                                                             \
        if ((ptr) == NULL) {                                         \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC NULL pointer\n"); \
            return HI_MAPI_VENC_ENULL_PTR;                           \
        }                                                            \
    } while (0)

#define CHECK_MAPI_VENC_CHECK_PREINIT_RET(state)                                       \
    do {                                                                               \
        if (!(state)) {                                                                \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "media not init yet,venc no pre init\n"); \
            return HI_MAPI_VENC_ENOT_INITED;                                           \
        }                                                                              \
    } while (0)

#define CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(state)                                \
    do {                                                                               \
        if (!(state)) {                                                                \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "media not init yet,venc no pre init\n"); \
            MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);                             \
            return HI_MAPI_VENC_ENOT_INITED;                                           \
        }                                                                              \
    } while (0)

#define CHECK_MAPI_VENC_CHECK_INIT_RET(state)                               \
    do {                                                                    \
        if (!(state)) {                                                     \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC has not been inited\n"); \
            return HI_MAPI_VENC_ENOT_INITED;                                \
        }                                                                   \
    } while (0)

#define CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(state)                        \
    do {                                                                    \
        if (!(state)) {                                                     \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC has not been inited\n"); \
            MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);                  \
            return HI_MAPI_VENC_ENOT_INITED;                                \
        }                                                                   \
    } while (0)

#define CHECK_MAPI_VCAPPIPE_HANDLE_RET(handle)                                                                 \
    do {                                                                                                       \
        if ((handle) >= HI_MAPI_VCAP_MAX_PIPE_NUM) {                                                           \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VcapPipe handle(%d) is invalid, only support [0, %d]\n", handle, \
                           HI_MAPI_VCAP_MAX_PIPE_NUM - 1);                                                     \
            return HI_MAPI_VENC_EHANDLE_ILLEGAL;                                                               \
        }                                                                                                      \
    } while (0)

#define CHECK_MAPI_PIPECHN_HANDLE_RET(handle)                                                                 \
    do {                                                                                                      \
        if ((handle) >= HI_MAPI_VCAP_PIPE_MAX_CHN_NUM) {                                                      \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "PipeChn handle(%d) is invalid, only support [0, %d]\n", handle, \
                           HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1);                                                \
            return HI_MAPI_VENC_EHANDLE_ILLEGAL;                                                              \
        }                                                                                                     \
    } while (0)

#define CHECK_MAPI_VPSS_HANDLE_RET(handle)                                                                 \
    do {                                                                                                   \
        if ((handle) >= HI_MAPI_VPSS_MAX_NUM) {                                                      \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "Vpss handle(%d) is invalid, only support [0, %d]\n", handle, \
                           HI_MAPI_VPSS_MAX_NUM - 1);                                                \
            return HI_MAPI_VENC_EHANDLE_ILLEGAL;                                                           \
        }                                                                                                  \
    } while (0)

#define CHECK_MAPI_VPORT_HANDLE_RET(handle)                                                                 \
    do {                                                                                                    \
        if ((handle) >= (HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM)) {              \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VPort handle(%d) is invalid, only support [0, %d]\n", handle, \
                           HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM - 1);          \
            return HI_MAPI_VENC_EHANDLE_ILLEGAL;                                                            \
        }                                                                                                   \
    } while (0)

#define CHECK_MAPI_STITCH_HANDLE_RET(handle)                                                                 \
    do {                                                                                                     \
        if ((handle) >= HI_MAPI_VPSS_STITCH_MAX_NUM) {                                                      \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "Stitch handle(%d) is invalid, only support [0, %d]\n", handle, \
                           HI_MAPI_VPSS_STITCH_MAX_NUM - 1);                                                \
            return HI_MAPI_VENC_EHANDLE_ILLEGAL;                                                             \
        }                                                                                                    \
    } while (0)

#define CHECK_MAPI_STITCHPORT_HANDLE_RET(handle)                                                                 \
    do {                                                                                                         \
        if ((handle) >= HI_MAPI_VPSS_STITCH_CHN_MAX_NUM) {                                                     \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "StitchPort handle(%d) is invalid, only support [0, %d]\n", handle, \
                           HI_MAPI_VPSS_STITCH_CHN_MAX_NUM - 1);                                               \
        return HI_MAPI_VENC_EHANDLE_ILLEGAL;                                                                     \
        }                                                                                                        \
    } while (0)

#define CHECK_MAPI_VENC_HANDLE_RANGE_RET(handle)                            \
    do {                                                                    \
        if ((handle) >= HI_MAPI_VENC_MAX_CHN_NUM) {                         \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC handle out of range\n"); \
            return HI_MAPI_VENC_EHANDLE_ILLEGAL;                            \
        }                                                                   \
    } while (0)

#define CHECK_MAPI_VENC_FRAMECNT_RANGE_RET(framecnt)                             \
    do {                                                                         \
        if ((framecnt) < HI_MAPI_VENC_LIMITLESS_FRAME_COUNT || (framecnt) == 0) { \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "frame count out of range\n");      \
            return HI_MAPI_VENC_EILLEGAL_PARAM;                                  \
        }                                                                        \
    } while (0)

#define CHECK_MAPI_VENC_OSD_HANDLE_RANGE_RET(handle)                            \
    do {                                                                        \
        if ((handle) >= HI_MAPI_VENC_OSD_MAX_NUM) {                             \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC OSD handle out of range\n"); \
            return HI_MAPI_VENC_EHANDLE_ILLEGAL;                                \
        }                                                                       \
    } while (0)

#define CHECK_MAPI_VENC_MAX_VAL_RET(paraname, atc, max)                                                     \
    do {                                                                                                    \
        if ((atc) > (max)) {                                                                                \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "%s:%d can not larger than max val %d\n", paraname, atc, max); \
            return HI_MAPI_VENC_EILLEGAL_PARAM;                                                             \
        }                                                                                                   \
    } while (0)

#define CHECK_MAPI_VENC_MIN_VAL_RET(paraname, atc, min)                                                   \
    do {                                                                                                  \
        if ((atc) < (min)) {                                                                              \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "%s:%d can not less than min val %d\n", paraname, atc, min); \
            return HI_MAPI_VENC_EILLEGAL_PARAM;                                                           \
        }                                                                                                 \
    } while (0)

#define CHECK_MEDIA_VENC_ALIGN_RET(value, align)                                          \
    do {                                                                                  \
        if (((value) % (align)) != 0) {                                                   \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "%d doesn't align with %d\n", value, align); \
            return HI_MAPI_VENC_EILLEGAL_PARAM;                                           \
        }                                                                                 \
    } while (0)

/* venc otlink stream struct */
typedef struct {
    td_handle handle;
    td_void *priv;
    hi_mapi_venc_data_attr venc_data;
} mapi_venc_otlink_stream;

typedef struct {
    td_bool enabled;
    td_u32 interval_time; /* unit: ms */
    td_u32 grp_frm_num; /* range: [1 - max framerate] */
} hi_mapi_venc_interval_get_frm_info;

/* venc chn information struct */
typedef struct {
    pthread_mutex_t venc_chn_lock;
    td_bool started;   /* Whether the stream has been started */
    td_bool inited;    /* whether the stream initialized */
    td_bool first_frame;
    td_handle venc_handle;
    hi_mapi_venc_attr venc_attr;
    /* Registered callback function ,each channel supports Registered callback function max number is:
         VENC_CHN_REGISTER_CALLBACK_MAX_COUNT */
    hi_mapi_venc_call_back venc_register_callbacks[HI_MAPI_VENC_CALLBACK_MAX_NUM];
    td_s32 start_frame_count;
    td_u32 time_ref; /* Image frame sequence number with send frame func */
    hi_mapi_venc_interval_get_frm_info interval_get_frm;
    td_bool rcn_ref_share_valid; /* <whether rcn_ref_share_en holds a valid value (0 = not configured) */
    td_bool rcn_ref_share_en;    /* <reconstruction and reference frame share buffer enable value */
} mapi_venc_chn_config;

/* data information about datafifo */
typedef struct {
    td_u32 link_frm_num;
    td_u32 last_frm_seq;
} mapi_venc_link_data_info;

/* otlink data process callback function pointer */
typedef td_s32 (*venc_otlink_proc_data)(td_handle venc_hdl,
    mapi_venc_otlink_stream *p_stream_link_data);

/* venc datafifo information struct */
typedef struct {
    td_u64 datafifo_hdl;
    td_u64 datafifo_share_phy_addr;
    td_u64 stream_buf_phy_addr[MAPI_ADAPT_VENC_MAX_TILE_NUM];
    td_u64 stream_buf_len[MAPI_ADAPT_VENC_MAX_TILE_NUM];
    td_void *data_virt_addr;
    td_bool used; /* TD_TRUE: clent and server datafifo has been install link */
    td_bool first_frame;
    td_bool started;
    mapi_venc_link_data_info link_data_info;
    venc_otlink_proc_data venc_otlink_data_proc;
    mapi_venc_otlink_stream unhandle_stream; /* the last unhandle venc frame */
    td_u32 grp_frm_index;
} mapi_venc_datafifo_attr;

/* thread information which use datafifo */
typedef struct {
    pthread_t proc_data_thread_id;
    pthread_mutex_t proc_data_thd_lock;
    pthread_cond_t proc_data_thd_cond;
    td_bool proc_data_thd_start_flg;
} mapi_venc_proc_data_thread;

/* context for venc */
typedef struct {
    td_bool venc_inited;
    td_u32 datafifo_node_num;
    mapi_venc_chn_config venc_chn_cfg[HI_MAPI_VENC_MAX_CHN_NUM];
    mapi_venc_datafifo_attr datafifo_attr[HI_MAPI_VENC_MAX_CHN_NUM];
    mapi_venc_proc_data_thread proc_data_thread[HI_MAPI_VENC_MAX_CHN_NUM];
} mapi_venc_context;

td_void mapi_venc_clear_datafifo_data(td_handle venc_hdl);
td_s32 mapi_venc_open_datafifo_writer(td_handle venc_hdl, td_u32 datafifo_node_num,
                                      mapi_venc_datafifo_attr *venc_datafifo);
td_s32 mapi_venc_close_datafifo_writer(td_handle venc_hdl);
td_void mapi_venc_open_datafifo_status(td_handle venc_hdl);
td_void mapi_venc_get_data_info(td_handle venc_hdl, mapi_venc_link_data_info *link_data_info);
td_bool mapi_venc_get_lite_boot_status(td_handle venc_hdl);
td_s32 mapi_venc_client_init(td_void);
td_s32 mapi_venc_client_deinit(td_void);
td_void mapi_venc_client_set_datafifo_node_num(td_u32 datafifo_node_num);
td_s32 mapi_venc_init(const hi_mapi_sys_venc_mode_param *venc_mod_para);
td_s32 mapi_venc_deinit(td_void);

td_s32 mapi_venc_get_start_frame_cnt(td_handle venc_hdl);

td_bool mapi_venc_is_register_callback(td_handle venc_hdl);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_VENC_INNER_H__ */
