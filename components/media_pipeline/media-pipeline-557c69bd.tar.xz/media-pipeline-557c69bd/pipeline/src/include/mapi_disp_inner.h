/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_DISP_INNER_H__
#define __MAPI_DISP_INNER_H__

#include <pthread.h>

#include "hi_mw_log.h"
#include "hi_mapi_disp_define.h"
#include "hi_mapi_disp_arch.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define DISP_DEFAULT_CANVASNUM     2
#define DISP_VIDEOLAYER_DISPRECT_X 0
#define DISP_VIDEOLAYER_DISPRECT_Y 0

#define DISP_CHECK_HANDLE_RET(Hdl)                                                                      \
    do {                                                                                                \
        if ((Hdl) >= HI_MAPI_DISP_MAX_NUM) {                                                              \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "disp dev(%d) is invalid, only support [0, %d]\n", Hdl,    \
                           HI_MAPI_DISP_MAX_NUM - 1);                                                   \
            return HI_MAPI_DISP_EINVALID_DEVID;                                                         \
        }                                                                                               \
    } while (0)

#define DISP_CHECK_WIN_ID_RET(HdW)                                                                      \
    do {                                                                                                \
        if ((HdW) >= HI_MAPI_DISP_WND_MAX_NUM) {                                                          \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "disp window(%d) is invalid, only support [0, %d]\n", HdW, \
                           HI_MAPI_DISP_WND_MAX_NUM - 1);                                               \
            return HI_MAPI_DISP_EINVALID_CHNID;                                                         \
        }                                                                                               \
    } while (0)

#define DISP_CHECK_OSD_HANDLE_RET(Hdl)                                                                      \
    do {                                                                                                    \
        if ((Hdl) >= HI_MAPI_DISP_OSD_MAX_NUM) {                                                              \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Disp osd handle(%d) is invalid, only support [0, %d]\n", Hdl, \
                           HI_MAPI_DISP_OSD_MAX_NUM - 1);                                                   \
            return HI_MAPI_DISP_EILLEGAL_PARAM;                                                             \
        }                                                                                                   \
    } while (0)

#define DISP_CHECK_VCAPPIPE_HANDLE_RET(Hdl)                                                                 \
    do {                                                                                                    \
        if ((Hdl) >= HI_MAPI_VCAP_MAX_PIPE_NUM) {                                                             \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "VcapPipe handle(%d) is invalid, only support [0, %d]\n", Hdl, \
                           HI_MAPI_VCAP_MAX_PIPE_NUM - 1);                                                  \
            return HI_MAPI_DISP_EILLEGAL_PARAM;                                                             \
        }                                                                                                   \
    } while (0)

#define DISP_CHECK_VCAPCHN_HANDLE_RET(Hdl)                                                                 \
    do {                                                                                                   \
        if ((Hdl) >= HI_MAPI_VCAP_PIPE_MAX_CHN_NUM) {                                                             \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "PipeChn handle(%d) is invalid, only support [0, %d]\n", Hdl, \
                           HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1);                                                  \
            return HI_MAPI_DISP_EILLEGAL_PARAM;                                                            \
        }                                                                                                  \
    } while (0)

#define DISP_CHECK_VPSSDVE_HANDLE_RET(Hdl)                                                              \
    do {                                                                                                \
        if ((Hdl) >= HI_MAPI_VPSS_MAX_NUM) {                                                              \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Vpss handle(%d) is invalid, only support [0, %d]\n", Hdl, \
                           HI_MAPI_VPSS_MAX_NUM - 1);                                                   \
            return HI_MAPI_DISP_EILLEGAL_PARAM;                                                         \
        }                                                                                               \
    } while (0)

#define DISP_CHECK_VPSSVPORT_HANDLE_RET(Hdl)                                                             \
    do {                                                                                                 \
        if ((Hdl) >= (HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM)) {                            \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "VPort handle(%d) is invalid, only support [0, %d]\n", Hdl, \
                           HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM - 1);                   \
            return HI_MAPI_DISP_EILLEGAL_PARAM;                                                          \
        }                                                                                                \
    } while (0)

#define DISP_CHECK_NULL_PTR_RET(pstPtr)                          \
    do {                                                         \
        if ((pstPtr) == NULL) {                                  \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Null pointer!\n"); \
            return HI_MAPI_DISP_ENULL_PTR;                       \
        }                                                        \
    } while (0)

#define DISP_CHECK_INIT_RET_UNLOCK(state, mLock)                            \
    do {                                                                    \
        if (!(state)) {                                                       \
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "DISP has not been inited\n"); \
            MAPI_MUTEX_UNLOCK(mLock);                                            \
            return HI_MAPI_DISP_ENOTREADY;                                  \
        }                                                                   \
    } while (0)

typedef struct {
    td_bool window_started;
} mapi_disp_window_attr;

typedef struct {
    td_bool disp_inited;
    td_bool disp_started;
    td_u32 vl_width;
    td_u32 vl_height;
    td_u32 vl_frame_rate;
    hi_mapi_disp_attr disp_attr;
    mapi_disp_window_attr wnd_attr[HI_MAPI_DISP_WND_MAX_NUM];
} mapi_disp_context;

td_s32 mapi_disp_init(td_void);
td_s32 mapi_disp_deinit(td_void);
td_s32 mapi_disp_send_frame(td_s32 dev_id, td_s32 chn_id,  hi_mapi_frame_data *data);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_DISP_INNER_H__ */
