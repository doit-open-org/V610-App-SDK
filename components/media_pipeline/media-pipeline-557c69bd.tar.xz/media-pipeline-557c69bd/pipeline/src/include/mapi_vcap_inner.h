/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_VCAP_INNER_H__
#define __MAPI_VCAP_INNER_H__

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <pthread.h>
#include "hi_mapi_comm_define.h"
#include "hi_mapi_errno.h"
#include "hi_mw_log.h"
#include "hi_mapi_vcap_define.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/* VCAP DEV ID */
#define VCAP_DEV_0 0
#define VCAP_DEV_1 1
#define VCAP_DEV_2 2
#define VCAP_DEV_3 3
#define VCAP_DEV_4 4

/* VCAP PIPE ID */
#define VCAP_PIPE_0 0
#define VCAP_PIPE_1 1
#define VCAP_PIPE_2 2
#define VCAP_PIPE_3 3
#define VCAP_PIPE_4 4
#define VCAP_PIPE_5 5

/* PIPE CHN ID */
#define PIPE_CHN_0 0
#define PIPE_CHN_1 1

/* clock and reset lins max */
#define SENSOR_MAX_CLOCK_DEV 3
#define SENSOR_MAX_RESET_DEV 3

#define MAPI_VCAP_GET_CHN_FRAME_TIMEOUT  5000

#if 0
/* dump raw info */
#define MAPI_VCAP_DUMP_RAW_TIMEOUT 60000  /* (1 min) */
#define MAPI_VCAP_DUMP_SCENE_NUM   2

/* raw info id */
#define MAPI_VCAP_NORMAL_RAW_INFO_ID 0 /* nomal raw id */
#define MAPI_VCAP_BNR_RAW_INFO_ID    1 /* bnr raw id */
#endif

/* VCAP PARAM CHECK */
#define CHECK_MAPI_VCAP_NULL_PTR_RET(ptr)                                   \
    do {                                                                    \
        if ((ptr) == NULL) {                                                \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "%s is NULL pointer\n", #ptr); \
            return HI_MAPI_VCAP_ENULL_PTR;                                  \
        }                                                                   \
    } while (0)

#define CHECK_MAPI_VCAP_ZERO_VAL_RET(paraname, value)                   \
    do {                                                                \
        if ((value) == 0) {                                             \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "%s is zero\n", paraname); \
            return HI_MAPI_VCAP_EILLEGAL_PARA;                          \
        }                                                               \
    } while (0)

#define CHECK_MAPI_VCAP_MAX_VAL_RET(paraname, value, max)                                                     \
    do {                                                                                                      \
        if ((value) > (max)) {                                                                                \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "%s:%d can not larger than max val %d\n", paraname, value, max); \
            return HI_MAPI_VCAP_EILLEGAL_PARA;                                                                \
        }                                                                                                     \
    } while (0)

#define CHECK_MAPI_VCAP_MIN_VAL_RET(paraname, value, min)                                                   \
    do {                                                                                                    \
        if ((value) < (min)) {                                                                              \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "%s:%d can not less than min val %d\n", paraname, value, min); \
            return HI_MAPI_VCAP_EILLEGAL_PARA;                                                              \
        }                                                                                                   \
    } while (0)

#define CHECK_MAPI_VCAP_HANDLE_RET(hdlname, value, max)                                         \
    do {                                                                                        \
        if ((td_handle)(value) > (max)) {                                                       \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "%s [%d][%d]out of range\n", hdlname, value, max); \
            return HI_MAPI_VCAP_EILLEGAL_HANDLE;                                                \
        }                                                                                       \
    } while (0)

#define CHECK_MAPI_VCAP_TRUE_RET(value, str, ret)                         \
    do {                                                                  \
        if ((value) != TD_TRUE) {                                         \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "%s,ret:[%#x]\n", str, ret); \
            return ret;                                                   \
        }                                                                 \
    } while (0)

#define CHECK_MAPI_VCAP_RET(ret, fmt...)                                      \
    do {                                                                      \
        if ((ret) != TD_SUCCESS) {                                            \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, fmt);                            \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "fail and return:[%#x]\n", ret); \
            return ret;                                                       \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_VCAP_RET_GOTO_FAIL(ret, fmt...)                                \
    do {                                                                          \
        if ((ret) != TD_SUCCESS) {                                                \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, fmt);                                \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "fail and return:[%#x]\n", ret);     \
            goto FAIL;                                                            \
        }                                                                         \
    } while (0)

#define CHECK_MEDIA_VCAP_ALIGN_RET(value, align)                                          \
    do {                                                                                  \
        if (((value) % (align)) != 0) {                                                   \
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "%d doesn't align with %d\n", value, align); \
            return HI_MAPI_VCAP_EILLEGAL_PARA;                                            \
        }                                                                                 \
    } while (0)

#define VCAP_ISP_QUERY_SWITCHSTATE_MAX_TIMES   5000  /* unit: ms */
#define VCAP_ISP_QUERY_SWITCHSTATE_SLEEP_TIMES 2000

/* VCAP global param */
typedef enum {
    VCAP_STATUS_NOTINIT,
    VCAP_STATUS_INIT,
    VCAP_STATUS_RUNNING,
    VCAP_STATUS_BUTT
} mapi_vcap_status;

typedef struct {
    td_bool is_isp_attr_init;
    hi_mapi_vcap_isp_init_attr isp_init_attr;
} mapi_vcap_isp_init_attr;

typedef struct {
    td_bool wdr_switch_finish;
    td_bool res_switch_finish;
} mapi_vcap_isp_inner_state;

typedef enum {
    MAPI_VCAP_ISP_FRMRATE_NOR_INTERVAL = 1,
    MAPI_VCAP_ISP_FRMRATE_120_INTERVAL = 2,
    MAPI_VCAP_ISP_FRMRATE_180_INTERVAL = 3,
    MAPI_VCAP_ISP_FRMRATE_240_INTERVAL = 4
} mapi_vcap_isp_state_interval;

typedef enum {
    MAPI_VCAP_DATA_BITWIDTH_8 = 0,
    MAPI_VCAP_DATA_BITWIDTH_10,
    MAPI_VCAP_DATA_BITWIDTH_12,
    MAPI_VCAP_DATA_BITWIDTH_14,
    MAPI_VCAP_DATA_BITWIDTH_16,

    MAPI_VCAP_DATA_BITWIDTH_BUTT
} mapi_vcap_data_bit_width;

typedef struct {
    hi_mapi_vcap_pipe_type pipe_type;                /* <static attribute,  PIPE attribute */
    hi_mapi_frame_rate_ctrl frame_rate_ctrl;         /* <dynamic attribute, PIPE attribute */
    hi_mapi_compress_mode compress_mode;             /* removed from public hdr; kept internal w/ default */
    td_bool isp_bypass;                              /* <static attribute, PIPE attribute */
    td_bool yuv_skip;
    mapi_vcap_data_bit_width bit_width;
    hi_mapi_pixel_format pix_fmt;                    /* <dynamic attribute, PIPE attribute */
    hi_mapi_vcap_pipe_bypass_mode pipe_bypass_mode;  /* <static attribute, PIPE attribute */
    hi_mapi_vcap_frame_interrupt_attr frame_int_attr; /* <static attribute, PIPE attribute */
    td_u32 vb_pool_blk_cnt;
} mapi_vcap_pipe_attr;


typedef struct {
    td_bool chn_enable;
    td_bool mirror;
    td_bool flip;
    hi_mapi_compress_mode compress_mode; 
    hi_mapi_video_format video_format;
    hi_mapi_vcap_pipe_chn_attr chn_attr; /* <attributes corresponding to PIPE channel */
    td_u32 vb_pool_blk_cnt;
} mapi_vcap_pipe_chn_attr;

typedef struct {
    td_bool is_pipe_create;
    td_bool is_pipe_start;
    td_bool is_isp_init;
    td_bool is_isp_run;
    td_bool is_isp_exited; /* ss_mpi_isp_exit already done since last init */
    pthread_t isp_run_thread;
    td_handle bind_dev_hdl;
    td_handle isp_hdl;

    td_u32 bind_vc_num;
    mapi_vcap_pipe_attr pipe_attr;
    mapi_vcap_pipe_chn_attr pipe_chn_attr[HI_MAPI_VCAP_PIPE_MAX_CHN_NUM];
    hi_mapi_vcap_pipe_isp_attr isp_pub_attr;
    mapi_vcap_isp_init_attr vcap_isp_init_attr;
    hi_mapi_vcap_wb_attr vcap_isp_wb_attr;

    td_u32 pipe_pool_id;
    td_u32 pipe_chn_pool_id[HI_MAPI_VCAP_PIPE_MAX_CHN_NUM];

    hi_mapi_vcap_buf_wrap_attr buf_wrap_attr;   /* pipe buffer wrap (卷绕); only 'enable' is user-set */
} mapi_vcap_glob_pipe_attr;

typedef struct {
    mapi_vcap_status dev_status;
    td_bool is_sns_init;
    td_bool sns_reset;
    hi_mapi_vcap_sensor_scene sns_scene;
    //td_u32 sns_cnt;
    //td_u32 sns_vaild_index;
    hi_mapi_vcap_sensor_attr sensor_attr;
    //mapi_vcap_switch_mode switch_mode;
    //hi_mapi_vcap_sensor_attr switch_sns_info;

    td_u32 pipe_bind_num;
    td_handle pipe_id_bind[HI_MAPI_VCAP_MAX_PIPE_NUM];
    td_handle master_isp_id;
    hi_mapi_vcap_dev_attr dev_attr;
    hi_mapi_vcap_wdr_attr wdr_attr; /* removed from public hdr; kept internal w/ defaults */
    td_u32 ob_height; /* sensor OB line count via set_config; default 0; added to MIPI RX height */
} mapi_vcap_glob_dev_attr;

typedef struct {
    td_bool vcap_inited;
    mapi_vcap_glob_dev_attr glob_dev_attr[HI_MAPI_VCAP_MAX_DEV_NUM];
    mapi_vcap_glob_pipe_attr glob_pipe_attr[HI_MAPI_VCAP_MAX_PIPE_NUM];
} mapi_vcap_glob_attr;

td_s32 mapi_vcap_init(td_void);
td_s32 mapi_vcap_deinit(td_void);
td_s32 mapi_isp_init_mode_param(const hi_mapi_isp_param_mode *isp_mod_param);

td_s32 mapi_vcap_get_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_frame_data *frame_data, td_s32 milli_sec);
td_s32 mapi_vcap_release_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_frame_data *frame_data);

td_s32 mapi_vcap_set_chn_depth(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_chn_depth *chn_depth);
td_s32 mapi_vcap_get_chn_depth(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_vcap_chn_depth *chn_depth);
#if 0
td_s32 mapi_vcap_get_raw_frame(td_handle vcap_pipe_hdl, hi_mapi_frame_data *frame_data, td_u32 array_len,
    td_u32 *frame_cnt, td_bool is_bnr_raw);
td_s32 mapi_vcap_release_raw_frame(td_handle vcap_pipe_hdl, const hi_mapi_frame_data *frame_data, td_u32 frame_cnt,
    td_bool is_bnr_raw);
#endif

mapi_vcap_glob_dev_attr *mapi_vcap_get_dev_attr(td_handle vcap_dev_hdl);
mapi_vcap_glob_attr *mapi_vcap_get_glob_attr(td_void);
hi_mapi_compress_mode mapi_vcap_get_default_pipe_compress_mode(td_void); 
hi_mapi_compress_mode mapi_vcap_get_default_chn_compress_mode(td_void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* __MAPI_VCAP_INNER_H__ */
