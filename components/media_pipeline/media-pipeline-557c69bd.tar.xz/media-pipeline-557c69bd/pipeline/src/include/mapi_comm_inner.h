/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_COMM_INNER_H__
#define __HI_MAPI_COMM_INNER_H__

#include <limits.h>
#include "pthread.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_sys.h"
#include "hi_mw_log.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

#define MAPI_SEC2NSEC_SCALE   (1 * 1000 * 1000 * 1000)
#define MAPI_USEC2NSEC_SCALE  (1 * 1000)
#define MAPI_MSEC2USEC_SCALE  (1 * 1000)
#define MAPI_SEC2MSEC_SCALE   (1 * 1000)
#define MAPI_SEC2USEC_SCALE   (1 * 1000 * 1000)

#define MAPI_FLOAT_EPSINON     0.00000001

#define MAPI_VIDEOFRAME_LUMINANCE_MAX 1000
#define MAPI_VIDEOFRAME_LUMINANCE_MIN 200
#define MAPI_SYS_VB_EXIT_MAX_CNT      10
#define MAPI_SYS_VB_EXIT_USLEEP_TIME  (10 * 1000)

#ifndef MIN
#define MIN(x, y) ((x) < (y) ? (x) : (y))
#endif

#include <stdio.h>

#ifdef MAPI_LOG_NONE
#define MAPI_DEBUG_TRACE(module, fmt...)
#define MAPI_INFO_TRACE(module, fmt...)
#define MAPI_WARN_TRACE(module, fmt...)
#define MAPI_ERR_TRACE(module, fmt...)
#define MAPI_FATAL_TRACE(module, fmt...)
#elif defined MAPI_LOG_ERR
#define MAPI_DEBUG_TRACE(module, fmt...)
#define MAPI_INFO_TRACE(module, fmt...)
#define MAPI_WARN_TRACE(module, fmt...)
#define MAPI_ERR_TRACE(module, fmt...) \
    do {                                                                                               \
        HI_LOG_ERR(mapi_comm_get_mode_name_by_id(module), fmt); \
    } while (0)

#define MAPI_FATAL_TRACE(module, fmt...)                                                                 \
    do {                                                                                                 \
        HI_LOG_FATAL(mapi_comm_get_mode_name_by_id(module), fmt); \
    } while (0)

#elif defined MAPI_LOG_ALL
#define MAPI_DEBUG_TRACE(module, fmt...)                                                                 \
    do {                                                                                                 \
        HI_LOG_DEBUG(mapi_comm_get_mode_name_by_id(module), fmt); \
    } while (0)

#define MAPI_INFO_TRACE(module, fmt...)                                                                 \
    do {                                                                                                \
        HI_LOG_INFO(mapi_comm_get_mode_name_by_id(module), fmt); \
    } while (0)

#define MAPI_WARN_TRACE(module, fmt...)                                                                 \
    do {                                                                                                \
        HI_LOG_WARN(mapi_comm_get_mode_name_by_id(module), fmt); \
    } while (0)

#define MAPI_ERR_TRACE(module, fmt...) \
    do {                                                                                               \
        HI_LOG_ERR(mapi_comm_get_mode_name_by_id(module), fmt); \
    } while (0)

#define MAPI_FATAL_TRACE(module, fmt...)                                                                 \
    do {                                                                                                 \
        HI_LOG_FATAL(mapi_comm_get_mode_name_by_id(module), fmt); \
    } while (0)
#endif

#define CHECK_MAPI_SYS_NULL_PTR_RET(paraname, ptr)                             \
    do {                                                                       \
        if ((ptr) == NULL) {                                                   \
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "%s is NULL pointer\n", paraname); \
            return HI_MAPI_SYS_ENULL_PTR;                                      \
        }                                                                      \
    } while (0)

#define CHECK_MAPI_PRINT(module, str, ret)                                    \
    do {                                                                      \
        if ((ret) != TD_SUCCESS) {                                            \
            MAPI_ERR_TRACE(module, "%s fail and return:[%#x]!!\n", str, ret); \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_NULL_PTR_RET(module, ptr, err_code)                        \
    do {                                                                      \
        if ((ptr) == NULL) {                                                  \
            MAPI_ERR_TRACE(module, "%s is NULL \n", #ptr);                    \
            return err_code;                                                  \
        }                                                                     \
    } while (0)


#define CHECK_MAPI_RET(module, str, ret)                                      \
    do {                                                                      \
        if ((ret) != TD_SUCCESS) {                                            \
            MAPI_ERR_TRACE(module, "%s fail and return:[%#x]!!\n", str, ret); \
            return ret;                                                       \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_RET_GOTO(module, str, ret, goto_label)                     \
    do {                                                                      \
        if ((ret) != TD_SUCCESS) {                                            \
            MAPI_ERR_TRACE(module, "%s fail and return:[%#x]!!\n", str, ret); \
            goto goto_label;                                                  \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_RET_UNLOCK(module, str, ret, m_lock)                       \
    do {                                                                      \
        if ((ret) != TD_SUCCESS) {                                            \
            MAPI_ERR_TRACE(module, "%s fail and return:[%#x]!!\n", str, ret); \
            MAPI_MUTEX_UNLOCK(m_lock);                                        \
            return ret;                                                       \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_BOOL_RET(module, ret, err_code)                            \
    do {                                                                      \
        if ((ret) != TD_TRUE) {                                               \
            MAPI_ERR_TRACE(module, "(%s) is false \n", #ret);                 \
            return err_code;                                                  \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_BOOL_RET_UNLOCK(module, ret, err_code, m_lock)             \
    do {                                                                      \
        if ((ret) != TD_TRUE) {                                               \
            MAPI_ERR_TRACE(module, "(%s) is false \n", #ret);                 \
            MAPI_MUTEX_UNLOCK(m_lock);                                        \
            return err_code;                                                  \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_SAFEFUNC_RET(module, str, ret)                             \
    do {                                                                      \
        if ((ret) != TD_SUCCESS) {                                            \
            MAPI_ERR_TRACE(module, "%s fail and return:[%#x]!!\n", str, ret); \
            return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;                        \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_SAFEFUNC_RET_UNLOCK(module, str, ret, m_lock)              \
    do {                                                                      \
        if ((ret) != TD_SUCCESS) {                                            \
            MAPI_ERR_TRACE(module, "%s fail and return:[%#x]!!\n", str, ret); \
            MAPI_MUTEX_UNLOCK(m_lock);                                        \
            return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;                        \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_UINT_MAX_VAL_RET(module, param)                                                       \
    do {                                                                                                 \
        if ((param) > UINT_MAX) {                                                                        \
            MAPI_ERR_TRACE(module, "%s:%llu can not larger than max val %u.\n", #param, param, UINT_MAX); \
            return HI_MAPI_SYS_VALUE_OVERFLOW;                                                           \
        }                                                                                                \
    } while (0)

#define CHECK_MAPI_UINT_PRODUCT_OVERFLOW_RET(module, value1, value2)                                    \
    do {                                                                                                \
        if (((value1) != 0) && (UINT_MAX / (td_u32)(value1) < (td_u32)(value2))) {                      \
            MAPI_ERR_TRACE(module, "\n%s * %s product owerflow!\n", #value1, #value2);                  \
            return HI_MAPI_SYS_VALUE_OVERFLOW;                                                          \
        }                                                                                               \
    } while (0)

#define CHECK_MAPI_FUNC_RUN_PRINT(module, str, ret, ret_err_flg)              \
    do {                                                                      \
        if ((ret) != TD_SUCCESS) {                                            \
            MAPI_ERR_TRACE(module, "%s fail and return:[%#x]!!\n", str, ret); \
            ret_err_flg = TD_TRUE;                                            \
        }                                                                     \
    } while (0)

#define CHECK_MAPI_STATE_RET(module, state, str, err_code)                    \
    do {                                                                      \
        if ((state) != TD_TRUE) {                                             \
            MAPI_ERR_TRACE(module, "%s!\n", str);                             \
            return err_code;                                                  \
        }                                                                     \
    } while (0)

#define MAPI_ALIGN(value, base) (((value) + (base) - 1) / (base) * (base))
#define MAPI_MAX(a, b) (((a) < (b)) ? (b) : (a))

#define IsASCII(a)              (((a) >= 0x00 && (a) <= 0x7F) ? 1 : 0)

#define MAPI_FONT_BYTE_BITS               8

/* OSD Fonts Lib */
typedef struct {
    /* OSD Lib Font Size, in pixel */
    td_bool is_init;  /* font_attr init flag */
    hi_mapi_sys_font_attr font_attr;
} mapi_comm_font_mod_attr;

typedef struct {
    td_u16 *bitmap_data;
    td_u32 stride;
    hi_mapi_size rgn_size;
    hi_mapi_size font_size;
    td_u32 bg_color;
    td_u32 font_color;
    td_char str[HI_MAPI_MAX_STR_LEN];
} mapi_comm_text_bitmap;

typedef struct {
    td_u32            width;
    td_u32            height;
    td_u32            bit_width;
    hi_mapi_pixel_format   pixel_format;
    hi_mapi_compress_mode  compress_mode;
    hi_mapi_video_format   video_format;
} mapi_pic_buf_attr;

typedef struct {
    hi_mapi_payload_type type;
    td_u32            width;
    td_u32            height;
    td_u32            bit_width;
    hi_mapi_pixel_format   pixel_format;
    hi_mapi_compress_mode  compress_mode;
    hi_mapi_video_format   video_format;
} mapi_vdec_pic_buf_attr;

typedef enum {
    MAPI_BUF_TYPE_PIC_COMMON_VB = 0,       /* struct: mapi_pic_buf_attr */
    MAPI_BUF_TYPE_VDEC_PIC_BUF,            /* struct: mapi_vdec_pic_buf_attr */
    MAPI_BUF_TYPE_VDEC_TMV_BUF,            /* struct: mapi_vdec_pic_buf_attr */
    MAPI_BUF_TYPE_PIC_BUTT
} mapi_buf_type;

/* Shared wrap (卷绕) config, set from base_attr. Per-VI-dev arrays; VPSS grp g uses dev g. */
typedef struct {
    td_u32  full_lines_std[HI_MAPI_VCAP_MAX_DEV_NUM]; /* sensor VTS; 0 => SDK default */
    td_u32  frame_rate[HI_MAPI_VCAP_MAX_DEV_NUM];     /* 0 => 30 */
    td_u32  vi_buf_line[HI_MAPI_VCAP_MAX_DEV_NUM];    /* VI wrap buf_line, precomputed at init */
    td_bool all_online;
} mapi_comm_wrap_cfg;

td_void mapi_comm_set_wrap_cfg(const mapi_comm_wrap_cfg *cfg);
td_void mapi_comm_get_wrap_cfg(mapi_comm_wrap_cfg *cfg);

td_char *mapi_comm_get_mode_name_by_id(hi_mapi_module_id mod_id);
td_bool mapi_get_media_init_status(td_void);
td_bool mapi_get_sys_init_status(td_void);
mapi_comm_font_mod_attr *mapi_sys_get_font_mod_attr(td_void);
td_s32 mapi_comm_config_text_bitmap(mapi_comm_text_bitmap *text, td_bool use_ascii_glyph);
td_void mapi_comm_cond_time_wait(pthread_cond_t *cond, pthread_mutex_t *mutex, td_u64 delay_us);

/* Internal: query the bind table by destination channel. Returns TD_SUCCESS and fills *src
 * with the first source currently bound to *dst; otherwise returns a non-zero error code and
 * leaves *src untouched. Pipeline-internal only. */
td_s32 mapi_sys_bind_get_src_by_dst(const hi_mapi_mpp_chn *dst, hi_mapi_mpp_chn *src);

/* Internal: unbind every entry whose destination matches *dst. Used by module destroy paths
 * as a safety net when the application forgot to unbind. Always returns TD_SUCCESS. */
td_s32 mapi_sys_bind_unbind_all_by_dst(const hi_mapi_mpp_chn *dst);

td_s32 mapi_sys_get_video_block(td_handle *pool_hdl, td_u64 *phy_addr, td_void **vir_addr, td_u64 blk_size,
    const td_char *mmz_name);
td_s32 mapi_sys_release_video_block(td_u64 phy_addr, td_void *vir_addr);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif
