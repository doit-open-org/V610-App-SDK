/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_ACAP_INNER_H__
#define __MAPI_ACAP_INNER_H__

#include <pthread.h>
#include "hi_mapi_acap_define.h"
#include "hi_mw_log.h"
#include "hi_mapi_acap_arch.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define MAPI_ACAP_FRAME_CACHED_CNT   5
#define MAPI_ACAP_FRAME_CACHED_DEPTH 5

#define MAPI_VQE_ANR_NOISE_DB_THR  45
#define MAPI_VQE_ANR_NR_INTENSITY  15

#define MAPI_ACAP_UP_RESAMPLE_MULTIPLE_MAX  6

#define MAPI_ACAP_TALKVQE_MASK_HPF     0x1
#define MAPI_ACAP_TALKVQE_MASK_AEC     0x2
#define MAPI_ACAP_TALKVQE_MASK_AGC     0x8
#define MAPI_ACAP_TALKVQE_MASK_EQ      0x10
#define MAPI_ACAP_TALKVQE_MASK_ANR     0x20

#define MAPI_ACAP_RESAMPLE_BUFF_SIZE \
    (HI_MAPI_AIO_MAX_POINT_PER_FRAME * HI_MAPI_ACAP_CHN_MAX_NUM * MAPI_ACAP_UP_RESAMPLE_MULTIPLE_MAX)

#define MAPI_ACAP_AFE_PROVIDER_NAME_LEN 16

#define CHECK_MAPI_ACAP_NULL_PTR_RET(ptr)                            \
    do {                                                             \
        if ((ptr) == NULL) {                                         \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "Acap NULL pointer\n"); \
            return HI_MAPI_ACAP_ENULLPTR;                            \
        }                                                            \
    } while (0)
#define CHECK_MAPI_ACAP_HANDLE_RANGE_RET(handle)                            \
    do {                                                                    \
        if ((handle) >= HI_MAPI_ACAP_DEV_MAX_NUM) {                         \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP handle out of range\n"); \
            return HI_MAPI_ACAP_EINVALIDHDL;                                \
        }                                                                   \
    } while (0)
#define CHECK_MAPI_ACAP_CHN_HANDLE_RANGE_RET(handle)                            \
    do {                                                                        \
        if ((handle) >= HI_MAPI_ACAP_CHN_MAX_NUM) {                             \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP Chn handle out of range\n"); \
            return HI_MAPI_ACAP_EINVALIDHDL;                                    \
        }                                                                       \
    } while (0)
#define CHECK_MAPI_ACAP_CHECK_INIT_RET(state)                                                                  \
    do {                                                                                                       \
        if (!(state)) {                                                                                        \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n"); \
            return HI_MAPI_ACAP_ENOINITED;                                                                     \
        }                                                                                                      \
    } while (0)

typedef enum {
    MAPI_ACAP_UNINITED = 0,
    MAPI_ACAP_STOPED,
    MAPI_ACAP_STARTED,
    MAPI_ACAP_BUTT
} mapi_acap_state;

typedef struct {
    td_void *acap_resampler;     /* resampler instance pointer */
    td_u32   saved_frm_len;       /* save origin frame len from mpi when resample process */
    td_u64   res_mmz_phy_addr;   /* mmz buffer phys address */
    td_void *res_mmz_vir_addr;   /* mmz buffer virtual address */
} mapi_acap_resample_info;

typedef struct {
    mapi_acap_state             acap_state;
    td_bool                     acap_chn_start[HI_MAPI_ACAP_CHN_MAX_NUM];
    hi_mapi_acap_attr           acap_attr;
    td_u32                      expand_flag;
    td_u32                      frm_num;
    td_u32                      chn_cnt;
    td_u32                      clk_sel;
    mapi_acap_resample_info     acap_resmp_info;
    hi_mapi_audio_talk_vqe_attr talk_vqe_attr;
    td_char                     afe_provider_name[MAPI_ACAP_AFE_PROVIDER_NAME_LEN];
    hi_mapi_acap_afe_attr_t     afe_attr;
} mapi_acap_server_context;

typedef struct {
    td_s16 *data_buf;
    td_s32  buf_len;
} mapi_acap_resample_data_attr;

td_void mapi_acap_init_vqe_cfg(const hi_mapi_audio_vqe_attr *audio_vqe_cfg);
td_s32  mapi_acap_init(td_void);
td_s32  mapi_acap_deinit(td_void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_ACAP_INNER_H__ */
