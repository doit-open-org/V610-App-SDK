/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_ADEC_INNER_H__
#define __MAPI_ADEC_INNER_H__

#include <pthread.h>
#include "hi_mapi_comm_define.h"
#include "hi_mw_log.h"
#include "hi_mapi_adec_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */


#define CHECK_MAPI_ADEC_NULL_PTR_RET(ptr)                            \
    do {                                                             \
        if ((ptr) == TD_NULL) {                                      \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "ADEC NULL pointer\n"); \
            return HI_MAPI_ADEC_ENULLPTR;                            \
        }                                                            \
    } while (0)

#define CHECK_MAPI_ADEC_CHECK_INIT_RET(state)                                     \
    do {                                                                          \
        if ((state) != TD_TRUE) {                                                 \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "MEDIA has not been pre inited \n"); \
            return HI_MAPI_ADEC_ENOTINITED;                                       \
        }                                                                         \
    } while (0)

#define CHECK_MAPI_ADEC_HANDLE_RANGE_RET(handle)                            \
    do {                                                                    \
        if ((handle) >= HI_MAPI_ADEC_CHN_MAX_NUM) {                         \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "ADEC handle out of range\n"); \
            return HI_MAPI_ADEC_EINVALIDHDL;                                \
        }                                                                   \
    } while (0)

typedef struct {
    td_bool                      chn_inited;
    hi_mapi_audio_format         adec_format;
    hi_mapi_audio_payload_format payload_format;    /* extension parameter (cmd-based); default HI_NATIVE */
    td_bool                      stream_started;   /* set on first hi_mapi_adec_send_stream; locks _CONFIG cmds */
} mapi_adec_chn_config;

/* context for adec */
typedef struct {
    td_bool              adec_inited;
    mapi_adec_chn_config adec_chn_cfg[HI_MAPI_ADEC_CHN_MAX_NUM];
} mapi_adec_server_context;


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_ADEC_INNER_H__ */
