/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_VDEC_INNER_H__
#define __MAPI_VDEC_INNER_H__

#include <pthread.h>
#include "hi_mw_type.h"
#include "ss_mpi_vdec.h"
#include "hi_mapi_vdec_define.h"
#include "hi_mapi_comm_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

#define VDEC_GET_FRAME_THREAD_USLEEP_TIME         (10 * 1000)
#define VDEC_GET_FRAME_THREAD_SLEECT_TIMEOUT_USEC (10 * 1000)
#define VDEC_PROCESS_STREAM_USLEEP_TIME           (10 * 1000)
#define VDEC_GET_FRAME_USLEEP_TIME                (10 * 1000)

#define MAPI_VDEC_THREAD_NAME_MAX_LEN 32

typedef struct {
    td_bool is_init;
    hi_mapi_vdec_get_frame_mode get_frame_mode;
    hi_mapi_payload_type type;
    td_bool is_start;
    ot_vdec_chn_pool vb_pool;
} mapi_vdec_chn_config;

/* thread information which use datafifo */
typedef struct {
    pthread_t proc_frame_thread;
    pthread_mutex_t proc_frame_thd_lock;
    pthread_cond_t proc_frame_thd_cond;
    td_bool is_proc_frame_thd_start;
} mapi_vdec_proc_frame_thread_info;

typedef struct {
    td_handle handle;
    hi_mapi_frame_data frame_data;
} mapi_vdec_ot_link_data;

/* otlink data process callback function pointer */
typedef td_s32 (*vdec_proc_ot_link_frame)(td_handle vdec_hdl, const mapi_vdec_ot_link_data *stream_link_data);

/* vdec datafifo information struct */
typedef struct {
    td_u64 data_fifo_hdl;
    td_bool is_start; /* TD_TRUE: clent and server datafifo has been install link */
    vdec_proc_ot_link_frame vdec_proc_frame_cb;
    mapi_vdec_ot_link_data unhandle_frame; /* the last unhandle vdec frame */
} mapi_vdec_data_fifo_config;

typedef struct {
    mapi_vdec_chn_config vdec_chn_cfg[HI_MAPI_VDEC_MAX_NUM];
    mapi_vdec_proc_frame_thread_info proc_frame_thread_info[HI_MAPI_VENC_MAX_CHN_NUM];
    mapi_vdec_data_fifo_config data_fifo_cfg[HI_MAPI_VENC_MAX_CHN_NUM];
} mapi_vdec_server_context;

typedef struct {
    mapi_vdec_chn_config vdec_chn_cfg[HI_MAPI_VDEC_MAX_NUM];
    mapi_vdec_data_fifo_config data_fifo_cfg[HI_MAPI_VENC_MAX_CHN_NUM];
    mapi_vdec_ot_link_data *ot_link_data[HI_MAPI_VENC_MAX_CHN_NUM];
} mapi_vdec_client_context;


td_s32 mapi_vdec_open_datafifo_writer(td_handle vdec_hdl, td_u64 *datafifo_phy_addr);
td_s32 mapi_vdec_close_datafifo_writer(td_handle vdec_hdl);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif
