/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_AENC_INNER_H__
#define __MAPI_AENC_INNER_H__

#include <pthread.h>
#include "hi_mapi_aenc.h"
#include "hi_mapi_acap_arch.h"
#include "hi_mw_log.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define AENCODE_GET_FRAME_THREAD_USLEEP_TIME         (10 * 1000)
#define AENCODE_GET_FRAME_THREAD_SLEECT_TIMEOUT_USEC (10 * 1000)
#define AENC_PROCESS_STREAM_USLEEP_TIME              (10 * 1000)

#define CHECK_MAPI_AENC_NULL_PTR_RET(ptr)                            \
    do {                                                             \
        if ((ptr) == TD_NULL) {                                      \
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC NULL pointer\n"); \
            return HI_MAPI_AENC_ENULLPTR;                            \
        }                                                            \
    } while (0)

#define CHECK_MAPI_AENC_CHECK_INIT_RET(state)                                                                    \
    do {                                                                                                         \
        if (!(state)) {                                                                                          \
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC has not been pre inited , mapi media has not been inited\n"); \
            return HI_MAPI_AENC_ENOTINITED;                                                                      \
        }                                                                                                        \
    } while (0)

#define CHECK_MAPI_AENC_ACAPHANDLE_RANGE_RET(handle)                                                                  \
    do {                                                                                                              \
        if ((handle) >= HI_MAPI_ACAP_DEV_MAX_NUM) {                                                                   \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP handle[%u] out of range[%u]\n", handle, HI_MAPI_ACAP_DEV_MAX_NUM); \
            return HI_MAPI_AENC_EINVALIDHDL;                                                                          \
        }                                                                                                             \
    } while (0)

#define CHECK_MAPI_AENC_ACAPCHNHANDLE_RANGE_RET(handle)                                        \
    do {                                                                                       \
        if ((handle) >= HI_MAPI_ACAP_CHN_MAX_NUM) {                                            \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP Chn handle[%u] out of range[%u]\n", handle, \
                           HI_MAPI_ACAP_CHN_MAX_NUM);                                          \
            return HI_MAPI_AENC_EINVALIDHDL;                                                   \
        }                                                                                      \
    } while (0)

#define CHECK_MAPI_AENC_HANDLE_RANGE_RET(handle)                                                                      \
    do {                                                                                                              \
        if ((handle) >= HI_MAPI_AENC_CHN_MAX_NUM) {                                                                   \
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC handle[%u] out of range[%u]\n", handle, HI_MAPI_AENC_CHN_MAX_NUM); \
            return HI_MAPI_AENC_EINVALIDHDL;                                                                          \
        }                                                                                                             \
    } while (0)

/* aenc chn state */
typedef enum {
    MAPI_AENC_CHN_UNINITED = 0,
    MAPI_AENC_CHN_STOPED, /* inited but not start */
    MAPI_AENC_CHN_STARTED,
    MAPI_AENC_CHN_BUTT
} mapi_aenc_chn_state;

/* aenc chn info struct */
typedef struct {
    td_handle                    aenc_chn_hdl;       /* chn handle */
    hi_mapi_aenc_attr            aenc_chn_attr;       /* aenc chn attr */
    mapi_aenc_chn_state          aenc_chn_state;     /* aenc chn current state */
    td_bool                      is_clear_buf;        /* whether to clear the buffer */
    pthread_mutex_t              aenc_chn_lock;
    hi_mapi_aenc_callback        aenc_reg_callbacks[HI_MAPI_AENC_CHN_CALLBACK_MAX_NUM];
    hi_mapi_audio_payload_format payload_format;     /* extension parameter (cmd-based); default HI_NATIVE */
} mapi_aenc_chn_config;

/* thread info which feeds aenc callback consumers */
typedef struct {
    pthread_t       proc_a_data_thread;
    pthread_mutex_t proc_a_data_thd_lock; /* lock for condition */
    pthread_cond_t  proc_a_data_thd_cond; /* condition for thread sleep */
    td_bool         proc_a_data_thd_start_flg; /* control thread start or stop */
} mapi_aenc_proc_data_thread_cfg;

/* context for aenc */
typedef struct {
    td_bool                        aenc_inited;
    mapi_aenc_chn_config           aenc_chn_cfg[HI_MAPI_AENC_CHN_MAX_NUM];
    mapi_aenc_proc_data_thread_cfg proc_a_data_thread[HI_MAPI_AENC_CHN_MAX_NUM];
} mapi_aenc_server_context;

td_s32 mapi_aenc_init(td_void);
td_s32 mapi_aenc_deinit(td_void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_AENC_INNER_H__ */
