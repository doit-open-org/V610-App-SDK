/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "hi_mapi_sys.h"
#include "hi_mapi_comm_define.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/prctl.h>
#include "mapi_vcap_inner.h"
#include "mapi_vpss_inner.h"
#include "mapi_venc_inner.h"
#include "mapi_disp_inner.h"
#include "mapi_acap_inner.h"
#include "mapi_aenc_inner.h"
#include "mapi_ao_inner.h"
#include "mapi_comm_inner.h"
#include "mapi_sys_arch.h"
#include "mapi_sys_os.h"
#include "mapi_sys_adapt.h"
#include "mapi_comm_adapt.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define MAPI_VENC_LOWPOWER_MODE_DEFAULT TD_TRUE
#define MAPI_SYS_BIND_MAX_NUM       64
#define MAPI_SYS_SOFT_BIND_MAX_NUM  2
#define MAPI_SYS_SOFT_BIND_POLL_US       10000
#define MAPI_SYS_SOFT_BIND_GET_FRAME_MS  100
#define MAPI_SYS_SRC_CHN_DEPTH           3
typedef struct mapi_sys_bind_node {
    hi_mapi_mpp_chn             src;
    hi_mapi_mpp_chn             dst;
    struct mapi_sys_bind_node  *next;
} mapi_sys_bind_node;

typedef struct {
    td_bool              inited;
    pthread_mutex_t      lock;
    td_u32               count;
    mapi_sys_bind_node  *head;
} mapi_sys_bind_ctx;

static mapi_sys_bind_ctx g_bind_ctx = {
    .inited = TD_FALSE,
    .count  = 0,
    .head   = TD_NULL,
};

/* VB 视频块记账表：get_video_block 时按 phy_addr 记录 {vir_addr, blk_size}，
 * release_video_block 时按 phy_addr 查回 blk_size 做 munmap（不再依赖调用方传入 size，
 * 避免错误 size 导致 munmap 长度错误引发板端异常）。生命周期随 init_media/deinit_media。 */
typedef struct mapi_sys_vb_node {
    td_u64                    phy_addr;
    td_void                  *vir_addr;
    td_u64                    blk_size;
    struct mapi_sys_vb_node  *next;
} mapi_sys_vb_node;

typedef struct {
    td_bool            inited;
    pthread_mutex_t    lock;
    td_u32             count;
    mapi_sys_vb_node  *head;
} mapi_sys_vb_ctx;

static mapi_sys_vb_ctx g_vb_ctx = {
    .inited = TD_FALSE,
    .count  = 0,
    .head   = TD_NULL,
};

typedef struct {
    hi_mapi_mpp_chn src;
    hi_mapi_mpp_chn dst;
} mapi_sys_soft_bind_item;

typedef struct {
    mapi_sys_soft_bind_item  items[MAPI_SYS_SOFT_BIND_MAX_NUM];
    volatile td_bool         running;
    pthread_t                tid;
    volatile td_u32          disp_cnt;
    pthread_mutex_t          lock;
} mapi_sys_soft_bind_ctx;

static mapi_sys_soft_bind_ctx g_soft_bind_ctx = {
    .running  = TD_FALSE,
    .tid      = (pthread_t)-1,
    .disp_cnt = 0,
};

static td_bool g_media_init = TD_FALSE;
static td_bool g_use_audio = TD_TRUE;
static td_bool g_need_set_vb = TD_TRUE;
static mapi_comm_font_mod_attr g_font_mod_attr = {TD_FALSE};

/* VQE module register state */
static td_bool g_register_vqe_module = TD_FALSE;

static td_char g_mode_names[HI_MAPI_MOD_BUTT][HI_MAPI_MODE_NAME_LEN] = {
    "SYS",
    "VCAP",
    "VPSS",
    "VENC",
    "ACAP",
    "AENC",
    "AO",
    "DISP",
    "HDMI",
    "ADEC",
    "VDEC",
    "OSD",
    "VGS",
};

static const hi_mapi_module_id g_bind_supported_mods[] = {
    HI_MAPI_MOD_VCAP,
    HI_MAPI_MOD_VPSS,
    HI_MAPI_MOD_VENC,
    HI_MAPI_MOD_VDEC,
    HI_MAPI_MOD_DISP,
    HI_MAPI_MOD_ACAP,
    HI_MAPI_MOD_AENC,
    HI_MAPI_MOD_ADEC,
    HI_MAPI_MOD_AO,
};

td_char *mapi_comm_get_mode_name_by_id(hi_mapi_module_id mod_id)
{
    return g_mode_names[mod_id];
}

static td_bool mapi_sys_bind_mod_supported(hi_mapi_module_id mod_id)
{
    td_u32 i;
    for (i = 0; i < sizeof(g_bind_supported_mods) / sizeof(g_bind_supported_mods[0]); i++) {
        if (g_bind_supported_mods[i] == mod_id) {
            return TD_TRUE;
        }
    }
    return TD_FALSE;
}

static td_s32 mapi_sys_bind_chn_check(const hi_mapi_mpp_chn *chn, const td_char *name)
{
    if (chn == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "%s is NULL pointer\n", name);
        return HI_MAPI_SYS_ENULL_PTR;
    }
    if (!mapi_sys_bind_mod_supported(chn->mod_id)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "%s mod_id %d not in bind whitelist\n", name, chn->mod_id);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }
    if (chn->dev_id < 0 || chn->chn_id < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "%s dev_id %d / chn_id %d invalid\n", name, chn->dev_id, chn->chn_id);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }
    return TD_SUCCESS;
}

static td_bool mapi_sys_bind_chn_equal(const hi_mapi_mpp_chn *a, const hi_mapi_mpp_chn *b)
{
    return (a->mod_id == b->mod_id) && (a->dev_id == b->dev_id) && (a->chn_id == b->chn_id);
}

static mapi_sys_bind_node *mapi_sys_bind_table_find(const hi_mapi_mpp_chn *src, const hi_mapi_mpp_chn *dst)
{
    mapi_sys_bind_node *cur;
    for (cur = g_bind_ctx.head; cur != TD_NULL; cur = cur->next) {
        if (mapi_sys_bind_chn_equal(&cur->src, src) && mapi_sys_bind_chn_equal(&cur->dst, dst)) {
            return cur;
        }
    }
    return TD_NULL;
}

static mapi_sys_bind_node *mapi_sys_bind_table_find_by_dst(const hi_mapi_mpp_chn *dst)
{
    mapi_sys_bind_node *cur;
    for (cur = g_bind_ctx.head; cur != TD_NULL; cur = cur->next) {
        if (mapi_sys_bind_chn_equal(&cur->dst, dst)) {
            return cur;
        }
    }
    return TD_NULL;
}

static td_s32 mapi_sys_bind_table_insert(const hi_mapi_mpp_chn *src, const hi_mapi_mpp_chn *dst)
{
    mapi_sys_bind_node *node;

    if (g_bind_ctx.count >= MAPI_SYS_BIND_MAX_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "bind table full (max %d)\n", MAPI_SYS_BIND_MAX_NUM);
        return HI_MAPI_SYS_ENOMEM;
    }

    node = (mapi_sys_bind_node *)malloc(sizeof(mapi_sys_bind_node));
    if (node == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "alloc bind node fail\n");
        return HI_MAPI_SYS_ENOMEM;
    }
    node->src  = *src;
    node->dst  = *dst;
    node->next = g_bind_ctx.head;
    g_bind_ctx.head = node;
    g_bind_ctx.count++;
    return TD_SUCCESS;
}

static td_void mapi_sys_bind_table_remove(mapi_sys_bind_node *node)
{
    mapi_sys_bind_node **link = &g_bind_ctx.head;
    while (*link != TD_NULL && *link != node) {
        link = &(*link)->next;
    }
    if (*link == TD_NULL) {
        return;
    }
    *link = node->next;
    free(node);
    g_bind_ctx.count--;
}

static td_void mapi_sys_soft_bind_item_remove(const hi_mapi_mpp_chn *src, const hi_mapi_mpp_chn *dst)
{
    td_u32 i;
    td_u32 j;
    for (i = 0; i < g_soft_bind_ctx.disp_cnt; i++) {
        if (!mapi_sys_bind_chn_equal(&g_soft_bind_ctx.items[i].src, src)) {
            continue;
        }
        if (!mapi_sys_bind_chn_equal(&g_soft_bind_ctx.items[i].dst, dst)) {
            continue;
        }
        for (j = i; j + 1 < g_soft_bind_ctx.disp_cnt; j++) {
            g_soft_bind_ctx.items[j] = g_soft_bind_ctx.items[j + 1];
        }
        return;
    }
}

static td_s32 mapi_sys_soft_bind_item_add(const hi_mapi_mpp_chn *src, const hi_mapi_mpp_chn *dst)
{
    (td_void)pthread_mutex_lock(&g_soft_bind_ctx.lock);
    if (g_soft_bind_ctx.disp_cnt >= MAPI_SYS_SOFT_BIND_MAX_NUM) {
        (td_void)pthread_mutex_unlock(&g_soft_bind_ctx.lock);
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "soft bind items full (max %d)\n",
            MAPI_SYS_SOFT_BIND_MAX_NUM);
        return HI_MAPI_SYS_EBUSY;
    }
    switch (src->mod_id) {
        case HI_MAPI_MOD_VCAP: {
            hi_mapi_vcap_chn_depth chn_depth;
            (td_void)mapi_vcap_get_chn_depth((td_handle)src->dev_id,
                (td_handle)src->chn_id, &chn_depth);
            chn_depth.depth = MAPI_SYS_SRC_CHN_DEPTH;
            (td_void)mapi_vcap_set_chn_depth((td_handle)src->dev_id,
                (td_handle)src->chn_id, &chn_depth);
            break;
        }
        case HI_MAPI_MOD_VPSS: {
            hi_mapi_vpss_depth_attr depth_attr;
            (td_void)mapi_vpss_get_chn_depth((td_handle)src->dev_id,
                (td_handle)src->chn_id, &depth_attr, sizeof(depth_attr));
            depth_attr.depth = MAPI_SYS_SRC_CHN_DEPTH;
            (td_void)mapi_vpss_set_chn_depth((td_handle)src->dev_id,
                (td_handle)src->chn_id, &depth_attr, sizeof(depth_attr));
            break;
        }
        default:
            break;
    }
    g_soft_bind_ctx.items[g_soft_bind_ctx.disp_cnt].src = *src;
    g_soft_bind_ctx.items[g_soft_bind_ctx.disp_cnt].dst = *dst;
    g_soft_bind_ctx.disp_cnt++;
    (td_void)pthread_mutex_unlock(&g_soft_bind_ctx.lock);
    return TD_SUCCESS;
}

static td_void *mapi_sys_soft_bind_thread(td_void *arg)
{
    td_u32 i;
    td_u32 cnt;
    td_s32 ret;
    hi_mapi_frame_data frame_data;

    (td_void)arg;
    prctl(PR_SET_NAME, "soft_bind_poll", 0, 0, 0);

    while (g_soft_bind_ctx.running == TD_TRUE) {
        
        (td_void)pthread_mutex_lock(&g_soft_bind_ctx.lock);
        cnt = g_soft_bind_ctx.disp_cnt;
        (td_void)pthread_mutex_unlock(&g_soft_bind_ctx.lock);
        if (cnt == 0) {
            usleep(MAPI_SYS_SOFT_BIND_POLL_US);
            continue;
        }

        for (i = 0; i < cnt; i++) {
            (td_void)pthread_mutex_lock(&g_soft_bind_ctx.lock);
            hi_mapi_mpp_chn src = g_soft_bind_ctx.items[i].src;
            hi_mapi_mpp_chn dst = g_soft_bind_ctx.items[i].dst;
            (td_void)pthread_mutex_unlock(&g_soft_bind_ctx.lock);
            switch (src.mod_id) {
                case HI_MAPI_MOD_VCAP:
                    ret = mapi_vcap_get_chn_frame((td_handle)src.dev_id,
                        (td_handle)src.chn_id, &frame_data, MAPI_SYS_SOFT_BIND_GET_FRAME_MS);
                    if (ret != TD_SUCCESS) {
                        break;
                    }
                    ret = mapi_disp_send_frame(dst.dev_id, dst.chn_id, &frame_data);
                    if (ret != TD_SUCCESS) {
                        MAPI_WARN_TRACE(HI_MAPI_MOD_SYS,
                            "soft_bind send_frame fail grp=%d port=%d ret=%#x\n",
                            src.dev_id, src.chn_id, ret);
                    }
                    (td_void)mapi_vcap_release_chn_frame((td_handle)src.dev_id,
                        (td_handle)src.chn_id, &frame_data);
                    break;
                case HI_MAPI_MOD_VPSS:
                    ret = mapi_vpss_get_chn_frame((td_handle)src.dev_id,
                        (td_handle)src.chn_id, &frame_data, MAPI_SYS_SOFT_BIND_GET_FRAME_MS);
                    if (ret != TD_SUCCESS) {
                        break;
                    }
                    ret = mapi_disp_send_frame(dst.dev_id, dst.chn_id, &frame_data);
                    if (ret != TD_SUCCESS) {
                        MAPI_WARN_TRACE(HI_MAPI_MOD_SYS,
                            "soft_bind send_frame fail grp=%d port=%d ret=%#x\n",
                            src.dev_id, src.chn_id, ret);
                    }
                    (td_void)mapi_vpss_release_chn_frame((td_handle)src.dev_id,
                        (td_handle)src.chn_id, &frame_data);
                    break;
                default:
                    break;
            }
        }
    }

    return TD_NULL;
}

static td_void mapi_sys_bind_table_flush(td_void)
{
    mapi_sys_bind_node *cur = g_bind_ctx.head;
    while (cur != TD_NULL) {
        mapi_sys_bind_node *next = cur->next;
        /* Best-effort: try to unbind in SDK before freeing the node. Failures are logged but ignored
         * because deinit must not get stuck on dangling SDK state. */
        (td_void)mapi_adapt_sys_unbind(&cur->src, &cur->dst);
        free(cur);
        cur = next;
    }
    g_bind_ctx.head  = TD_NULL;
    g_bind_ctx.count = 0;
}

static td_s32 mapi_sys_bind_ctx_init(td_void)
{
    if (g_bind_ctx.inited) {
        return TD_SUCCESS;
    }
    if (pthread_mutex_init(&g_bind_ctx.lock, TD_NULL) != 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "init bind ctx mutex fail\n");
        return HI_MAPI_SYS_ENOTREADY;
    }
    g_bind_ctx.head   = TD_NULL;
    g_bind_ctx.count  = 0;
    g_bind_ctx.inited = TD_TRUE;
    return TD_SUCCESS;
}

static td_void mapi_sys_bind_ctx_deinit(td_void)
{
    if (!g_bind_ctx.inited) {
        return;
    }
    (td_void)pthread_mutex_lock(&g_bind_ctx.lock);
    mapi_sys_bind_table_flush();
    (td_void)pthread_mutex_unlock(&g_bind_ctx.lock);
    (td_void)pthread_mutex_destroy(&g_bind_ctx.lock);
    g_bind_ctx.inited = TD_FALSE;
}

/* ---- VB 视频块记账表（按 phy_addr 索引；调用方需自行持 g_vb_ctx.lock）---- */
static mapi_sys_vb_node *mapi_sys_vb_table_find(td_u64 phy_addr)
{
    mapi_sys_vb_node *cur = g_vb_ctx.head;
    while (cur != TD_NULL) {
        if (cur->phy_addr == phy_addr) {
            return cur;
        }
        cur = cur->next;
    }
    return TD_NULL;
}

static td_void mapi_sys_vb_table_remove(mapi_sys_vb_node *node)
{
    mapi_sys_vb_node **link = &g_vb_ctx.head;
    while (*link != TD_NULL && *link != node) {
        link = &(*link)->next;
    }
    if (*link == TD_NULL) {
        return;
    }
    *link = node->next;
    free(node);
    g_vb_ctx.count--;
}

static td_s32 mapi_sys_vb_table_insert(td_u64 phy_addr, td_void *vir_addr, td_u64 blk_size)
{
    mapi_sys_vb_node *node;

    /* 同 phy 已有脏记录（理论上不应出现）则先移除，避免重复 */
    node = mapi_sys_vb_table_find(phy_addr);
    if (node != TD_NULL) {
        mapi_sys_vb_table_remove(node);
    }

    node = (mapi_sys_vb_node *)malloc(sizeof(mapi_sys_vb_node));
    if (node == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "alloc vb node fail\n");
        return HI_MAPI_SYS_ENOMEM;
    }
    node->phy_addr = phy_addr;
    node->vir_addr = vir_addr;
    node->blk_size = blk_size;
    node->next     = g_vb_ctx.head;
    g_vb_ctx.head  = node;
    g_vb_ctx.count++;
    return TD_SUCCESS;
}

static td_void mapi_sys_vb_table_flush(td_void)
{
    mapi_sys_vb_node *cur = g_vb_ctx.head;
    if (cur != TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vb table still has %u block(s) at deinit, releasing them\n",
            g_vb_ctx.count);
    }
    while (cur != TD_NULL) {
        mapi_sys_vb_node *next = cur->next;
        /* 残留块兜底回收：用记录的 size 做 munmap + 释放 VB 块（best-effort，失败仅打印不中断）。 */
        td_s32 ret = mapi_adapt_comm_munmap(cur->vir_addr, (td_u32)cur->blk_size);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "flush munmap fail phy=0x%llx ret:%#x\n",
                (unsigned long long)cur->phy_addr, ret);
        }
        ret = mapi_adapt_sys_release_video_block(cur->phy_addr);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "flush release_video_block fail phy=0x%llx ret:%#x\n",
                (unsigned long long)cur->phy_addr, ret);
        }
        free(cur);
        cur = next;
    }
    g_vb_ctx.head  = TD_NULL;
    g_vb_ctx.count = 0;
}

static td_s32 mapi_sys_vb_ctx_init(td_void)
{
    if (g_vb_ctx.inited) {
        return TD_SUCCESS;
    }
    if (pthread_mutex_init(&g_vb_ctx.lock, TD_NULL) != 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "init vb ctx mutex fail\n");
        return HI_MAPI_SYS_ENOTREADY;
    }
    g_vb_ctx.head   = TD_NULL;
    g_vb_ctx.count  = 0;
    g_vb_ctx.inited = TD_TRUE;
    return TD_SUCCESS;
}

static td_void mapi_sys_vb_ctx_deinit(td_void)
{
    if (!g_vb_ctx.inited) {
        return;
    }
    (td_void)pthread_mutex_lock(&g_vb_ctx.lock);
    mapi_sys_vb_table_flush();
    (td_void)pthread_mutex_unlock(&g_vb_ctx.lock);
    (td_void)pthread_mutex_destroy(&g_vb_ctx.lock);
    g_vb_ctx.inited = TD_FALSE;
}

mapi_comm_font_mod_attr *mapi_sys_get_font_mod_attr(td_void)
{
    return &g_font_mod_attr;
}

td_s32 hi_mapi_sys_init(td_void)
{
    td_s32 ret;

    ret = hal_mapi_sys_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "hal_mapi_sys_init fail,ret:%x\n", ret);
        return ret;
    }

    ret = mapi_sys_bind_ctx_init();
    if (ret != TD_SUCCESS) {
        (td_void)hal_mapi_sys_deinit();
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_sys_deinit(td_void)
{
    td_s32 ret;

    mapi_sys_bind_ctx_deinit();

    ret = hal_mapi_sys_deinit();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "hal_mapi_sys_deinit fail,ret:%x\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_sys_bind(const hi_mapi_mpp_chn *src_chn, const hi_mapi_mpp_chn *dst_chn)
{
    td_s32 ret;

    if (!g_bind_ctx.inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "bind ctx not inited, call hi_mapi_sys_init first\n");
        return HI_MAPI_SYS_ENOTREADY;
    }

    ret = mapi_sys_bind_chn_check(src_chn, "src_chn");
    if (ret != TD_SUCCESS) {
        return ret;
    }
    ret = mapi_sys_bind_chn_check(dst_chn, "dst_chn");
    if (ret != TD_SUCCESS) {
        return ret;
    }
    if (mapi_sys_bind_chn_equal(src_chn, dst_chn)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "bind src equals dst (mod=%d,dev=%d,chn=%d)\n",
            src_chn->mod_id, src_chn->dev_id, src_chn->chn_id);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    (td_void)pthread_mutex_lock(&g_bind_ctx.lock);

    /* Duplicate bind on the same (src,dst): treat as success without dispatching to SDK. */
    if (mapi_sys_bind_table_find(src_chn, dst_chn) != TD_NULL) {
        ret = TD_SUCCESS;
        goto out;
    }

    /* A bind destination accepts a single source. The same (dev,chn) is unique even for VENC
     * multi-instance mode (SDK requires distinct dev for each VENC instance), so all modules
     * including VENC share the same one-source-per-dst rule; a second source is rejected. */
    if (mapi_sys_bind_table_find_by_dst(dst_chn) != TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS,
            "dst (mod=%d,dev=%d,chn=%d) already has a source bound\n",
            dst_chn->mod_id, dst_chn->dev_id, dst_chn->chn_id);
        ret = HI_MAPI_SYS_EBUSY;
        goto out;
    }

    if (dst_chn->mod_id == HI_MAPI_MOD_DISP) {
        ret = mapi_sys_soft_bind_item_add(src_chn, dst_chn);
        if (ret != TD_SUCCESS) {
            goto out;
        }
        ret = mapi_sys_bind_table_insert(src_chn, dst_chn);
        if (ret != TD_SUCCESS) {
            (td_void)pthread_mutex_lock(&g_soft_bind_ctx.lock);
            mapi_sys_soft_bind_item_remove(src_chn, dst_chn);
            if (g_soft_bind_ctx.disp_cnt > 0) {
                g_soft_bind_ctx.disp_cnt--;
            }
            (td_void)pthread_mutex_unlock(&g_soft_bind_ctx.lock);
        }
        goto out;
    }

    ret = mapi_adapt_sys_bind(src_chn, dst_chn);
    if (ret != TD_SUCCESS) {
        goto out;
    }

    ret = mapi_sys_bind_table_insert(src_chn, dst_chn);
    if (ret != TD_SUCCESS) {
        /* Keep table/SDK consistent on bookkeeping failure. */
        (td_void)mapi_adapt_sys_unbind(src_chn, dst_chn);
    }

out:
    (td_void)pthread_mutex_unlock(&g_bind_ctx.lock);
    return ret;
}

td_s32 hi_mapi_sys_unbind(const hi_mapi_mpp_chn *src_chn, const hi_mapi_mpp_chn *dst_chn)
{
    td_s32 ret;
    mapi_sys_bind_node *node;

    if (!g_bind_ctx.inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "bind ctx not inited, call hi_mapi_sys_init first\n");
        return HI_MAPI_SYS_ENOTREADY;
    }

    ret = mapi_sys_bind_chn_check(src_chn, "src_chn");
    if (ret != TD_SUCCESS) {
        return ret;
    }
    ret = mapi_sys_bind_chn_check(dst_chn, "dst_chn");
    if (ret != TD_SUCCESS) {
        return ret;
    }

    (td_void)pthread_mutex_lock(&g_bind_ctx.lock);

    /* Not bound: treat as success without dispatching to SDK. */
    node = mapi_sys_bind_table_find(src_chn, dst_chn);
    if (node == TD_NULL) {
        ret = TD_SUCCESS;
        goto out;
    }

    if (node->dst.mod_id == HI_MAPI_MOD_DISP) {
        (td_void)pthread_mutex_lock(&g_soft_bind_ctx.lock);
        mapi_sys_soft_bind_item_remove(&node->src, &node->dst);
        if (g_soft_bind_ctx.disp_cnt > 0) {
            g_soft_bind_ctx.disp_cnt--;
        }
        (td_void)pthread_mutex_unlock(&g_soft_bind_ctx.lock);
        mapi_sys_bind_table_remove(node);
        (td_void)pthread_mutex_unlock(&g_bind_ctx.lock);
        return TD_SUCCESS;
    }

    ret = mapi_adapt_sys_unbind(src_chn, dst_chn);
    if (ret != TD_SUCCESS) {
        goto out;
    }

    mapi_sys_bind_table_remove(node);

out:
    (td_void)pthread_mutex_unlock(&g_bind_ctx.lock);
    return ret;
}

td_s32 mapi_sys_bind_get_src_by_dst(const hi_mapi_mpp_chn *dst, hi_mapi_mpp_chn *src)
{
    td_s32 ret;
    mapi_sys_bind_node *cur;

    if (!g_bind_ctx.inited) {
        return HI_MAPI_SYS_ENOTREADY;
    }

    ret = mapi_sys_bind_chn_check(dst, "dst");
    if (ret != TD_SUCCESS) {
        return ret;
    }
    if (src == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "src is NULL pointer\n");
        return HI_MAPI_SYS_ENULL_PTR;
    }

    (td_void)pthread_mutex_lock(&g_bind_ctx.lock);

    ret = HI_MAPI_SYS_ENO_REG_MSG;
    for (cur = g_bind_ctx.head; cur != TD_NULL; cur = cur->next) {
        if (mapi_sys_bind_chn_equal(&cur->dst, dst)) {
            *src = cur->src;
            ret = TD_SUCCESS;
            break;
        }
    }

    (td_void)pthread_mutex_unlock(&g_bind_ctx.lock);
    return ret;
}

td_s32 mapi_sys_bind_unbind_all_by_dst(const hi_mapi_mpp_chn *dst)
{
    mapi_sys_bind_node *cur;

    if (!g_bind_ctx.inited) {
        return HI_MAPI_SYS_ENOTREADY;
    }

    if (mapi_sys_bind_chn_check(dst, "dst") != TD_SUCCESS) {
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    (td_void)pthread_mutex_lock(&g_bind_ctx.lock);

    td_u32 iter = 0;
    cur = mapi_sys_bind_table_find_by_dst(dst);
    while (cur != TD_NULL) {
        if (iter >= MAPI_SYS_BIND_MAX_NUM) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS,
                "unbind_all_by_dst exceeded %d iterations, abort to avoid dead loop\n",
                MAPI_SYS_BIND_MAX_NUM);
            break;
        }
        if (cur->dst.mod_id == HI_MAPI_MOD_DISP) {
            (td_void)pthread_mutex_lock(&g_soft_bind_ctx.lock);
            mapi_sys_soft_bind_item_remove(&cur->src, &cur->dst);
            if (g_soft_bind_ctx.disp_cnt > 0) {
                g_soft_bind_ctx.disp_cnt--;
            }
            (td_void)pthread_mutex_unlock(&g_soft_bind_ctx.lock);
            mapi_sys_bind_table_remove(cur);
        } else {
            /* SDK unbind failure here is best-effort: log and keep going so the table doesn't get stuck. */
            (td_void)mapi_adapt_sys_unbind(&cur->src, &cur->dst);
            mapi_sys_bind_table_remove(cur);
        }
        cur = mapi_sys_bind_table_find_by_dst(dst);
        iter++;
    }

    (td_void)pthread_mutex_unlock(&g_bind_ctx.lock);
    return TD_SUCCESS;
}

td_s32 mapi_sys_get_video_block(td_handle *pool_hdl, td_u64 *phy_addr, td_void **vir_addr, td_u64 blk_size,
    const td_char *mmz_name)
{
    CHECK_MAPI_SYS_NULL_PTR_RET("pool_hdl", pool_hdl);
    CHECK_MAPI_SYS_NULL_PTR_RET("phy_addr", phy_addr);
    CHECK_MAPI_SYS_NULL_PTR_RET("vir_addr", vir_addr);

    if (g_media_init == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "media not init yet\n");
        return HI_MAPI_SYS_ENOTREADY;
    }

    CHECK_MAPI_UINT_MAX_VAL_RET(HI_MAPI_MOD_SYS, blk_size);
    td_s32 ret = mapi_adapt_sys_get_video_block(pool_hdl, phy_addr, blk_size, mmz_name);
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "mapi_adapt_sys_get_video_block", ret);

    td_u32 mmap_size = (td_u32)blk_size;
    td_void *get_vir_addr = mapi_adapt_comm_mmap(*phy_addr, mmap_size);
    if (get_vir_addr == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "HI_MAPI_VB_GetBlock mmap error\n");
        mapi_adapt_sys_release_video_block(*phy_addr);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    /* 记账：按 phy_addr 记录 {vir_addr, blk_size}，供 release 反查 size 做 munmap */
    (td_void)pthread_mutex_lock(&g_vb_ctx.lock);
    ret = mapi_sys_vb_table_insert(*phy_addr, get_vir_addr, blk_size);
    (td_void)pthread_mutex_unlock(&g_vb_ctx.lock);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vb table insert fail, ret:%#x\n", ret);
        (td_void)mapi_adapt_comm_munmap(get_vir_addr, mmap_size);
        mapi_adapt_sys_release_video_block(*phy_addr);
        return ret;
    }

    *vir_addr = get_vir_addr;

    return TD_SUCCESS;
}

td_s32 mapi_sys_release_video_block(td_u64 phy_addr, td_void *vir_addr)
{
    td_s32 ret;
    mapi_sys_vb_node *node;
    td_u32 mmap_size;

    if (g_media_init == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "media not init yet\n");
        return HI_MAPI_SYS_ENOTREADY;
    }

    CHECK_MAPI_SYS_NULL_PTR_RET("vir_addr", vir_addr);
    if (phy_addr == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "phy_addr is invalid\n");
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    /* 按 phy_addr 查记账表：未 get / 重复 release / 伪造 phy 均查不到 -> 拒绝 */
    (td_void)pthread_mutex_lock(&g_vb_ctx.lock);
    node = mapi_sys_vb_table_find(phy_addr);
    if (node == TD_NULL) {
        (td_void)pthread_mutex_unlock(&g_vb_ctx.lock);
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "phy_addr 0x%llx not in vb table (not got / already released)\n",
            (unsigned long long)phy_addr);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }
    if (node->vir_addr != vir_addr) {
        (td_void)pthread_mutex_unlock(&g_vb_ctx.lock);
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vir_addr mismatch for phy_addr 0x%llx\n",
            (unsigned long long)phy_addr);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }
    /* 用记录的 size 做 munmap，杜绝调用方传错 size 导致的 munmap 长度错误 */
    mmap_size = (td_u32)node->blk_size;
    (td_void)pthread_mutex_unlock(&g_vb_ctx.lock);

    ret = mapi_adapt_comm_munmap(vir_addr, mmap_size);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "munmap fail, ret:%#x\n", ret);
    }

    ret = mapi_adapt_sys_release_video_block(phy_addr);
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "mapi_adapt_sys_release_video_block", ret);

    /* 释放成功后移除记账节点 */
    (td_void)pthread_mutex_lock(&g_vb_ctx.lock);
    node = mapi_sys_vb_table_find(phy_addr);
    if (node != TD_NULL) {
        mapi_sys_vb_table_remove(node);
    }
    (td_void)pthread_mutex_unlock(&g_vb_ctx.lock);

    return TD_SUCCESS;
}


static td_s32 mapi_sys_register_vqe_module(const hi_mapi_audio_vqe_attr *audio_vqe_attr)
{
    td_s32 ret;

    if (audio_vqe_attr == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "audio_vqe_attr is Null pointer!\n");
        return HI_MAPI_SYS_ENULL_PTR;
    }

    /* system start only need register VQE once */
    if (g_register_vqe_module == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_SYS, "VQE module is registered!\n");
        return TD_SUCCESS;
    }

    ret = hal_mapi_sys_register_vqe_module(audio_vqe_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "hal_mapi_sys_register_vqe_module error, ret:%#x!!\n", ret);
        return ret;
    }

    mapi_acap_init_vqe_cfg(audio_vqe_attr);
    mapi_ao_init_vqe_cfg(audio_vqe_attr);

    g_register_vqe_module = TD_TRUE;

    return TD_SUCCESS;
}

static td_s32 mapi_sys_init_audio_module(const hi_mapi_audio_param_mode *audio_param)
{
    td_s32 goto_ret;
    td_s32 ret;
    if (audio_param->audio_bypass == TD_TRUE) {
        return TD_SUCCESS;
    }

    ret = mapi_sys_register_vqe_module(&audio_param->vqe_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "sys register_vqe_module fail, ret:%x\n", ret);
        return ret;
    }

    ret = mapi_acap_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_acap_init fail, ret:%x\n", ret);
        return ret;
    }

    ret = mapi_aenc_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_aenc_init err, ret:%x\n", ret);
        goto ACAP_DEINIT;
    }

    ret = mapi_ao_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_ao_init err, ret:%x\n", ret);
        goto AENC_DEINIT;
    }

    return TD_SUCCESS;

AENC_DEINIT:
    goto_ret = mapi_aenc_deinit();
    if (goto_ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_aenc_deinit err.\n");
    }

ACAP_DEINIT:
    goto_ret = mapi_acap_deinit();
    if (goto_ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_acap_deinit fail.\n");
    }

    return ret;
}

static td_s32 mapi_sys_init_video_module(const hi_mapi_sys_media_attr *media_attr)
{
    td_s32 goto_ret;

    td_s32 ret = mapi_vcap_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_vcap_init fail,ret:%x\n", ret);
        return ret;
    }

    ret = mapi_isp_init_mode_param(&media_attr->isp_mod_para);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_isp_init_mode_param fail,ret:%x\n", ret);
        goto VCAP_DEINIT;
    }

    ret = mapi_vpss_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_vpss_init fail,ret:%x\n", ret);
        goto VCAP_DEINIT;
    }
    ret = mapi_venc_init(&media_attr->venc_mod_para);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_venc_init err, ret:%x\n", ret);
        goto VPSS_DEINIT;
    }
#ifdef SUPPORT_DISP
    ret = MAPI_DISP_Init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "MAPI_DISP_Init fail,ret:%x\n", ret);
        goto VPSS_DEINIT;
    }
#endif
    return TD_SUCCESS;

VPSS_DEINIT:
    goto_ret = mapi_vpss_deinit();
    if (goto_ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_vpss_deinit fail.\n");
    }

VCAP_DEINIT:
    goto_ret = mapi_vcap_deinit();
    if (goto_ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_vcap_deinit fail.\n");
    }

    return ret;
}

static td_s32 mapi_sys_deinit_video_module(td_void)
{
    td_s32 ret;
#ifdef SUPPORT_DISP
    ret = MAPI_DISP_Deinit();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "MAPI_DISP_Deinit fail.\n");
    }
#endif
    ret = mapi_vpss_deinit();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_vpss_deinit fail.\n");
    }

    ret = mapi_vcap_deinit();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_vcap_deinit fail.\n");
    }

    return TD_SUCCESS;
}

static td_s32 mapi_sys_check_work_mode(const hi_mapi_sys_base_attr *base_attr, td_bool *vcap_online, td_bool *vpss_online)
{
    td_s32 i;
    *vcap_online = TD_FALSE;
    *vpss_online = TD_FALSE;

    if (base_attr->vcap_dev_num > HI_MAPI_VCAP_MAX_DEV_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vcap_dev_num is invalid, vcap_dev_num:%d (max:%d)\n",
            base_attr->vcap_dev_num, HI_MAPI_VCAP_MAX_DEV_NUM);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    if (base_attr->vpss_grp_num > HI_MAPI_VPSS_MAX_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vpss_grp_num is invalid, vpss_grp_num:%d (max:%d)\n",
            base_attr->vpss_grp_num, HI_MAPI_VPSS_MAX_NUM);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    if (base_attr->vcap_dev_num > 1) {
        /* multi pipe vcap must be offline */
        for (i = 0; i < base_attr->vcap_dev_num; i++) {
            if (base_attr->vcap_online[i] == TD_TRUE) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vcap online not support multi pipe,vcap_dev_num:%d (must be %d)\n",
                    base_attr->vcap_dev_num, 1);
                return HI_MAPI_SYS_EILLEGAL_PARAM;
            }
        }
    }

    *vcap_online = base_attr->vcap_online[0];

    for (i = 0; i < base_attr->vpss_grp_num; i++) {
        if (base_attr->vpss_online[i] == TD_TRUE) {
            *vpss_online = TD_TRUE;
            break;
        }
    }

    if (*vpss_online == TD_TRUE) {
        if (*vcap_online == TD_TRUE && base_attr->vpss_grp_num != 1) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vcap online vpss online just support one grp,vpss_grp_num:%d (must be %d)\n",
                base_attr->vpss_grp_num, 1);
            return HI_MAPI_SYS_EILLEGAL_PARAM;
        }

        for (i = 0; i < base_attr->vpss_grp_num; i++) {
            if (base_attr->vpss_online[i] == TD_FALSE) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vpss online must all grp online! vpss_online[%d] = %d (must be %d)\n",
                    i, base_attr->vpss_online[i], TD_TRUE);
                return HI_MAPI_SYS_EILLEGAL_PARAM;
            }
        }
    }

    return TD_SUCCESS;
}

static td_void mapi_sys_get_default_work_mode(td_bool vcap_online, td_bool vpss_online, hi_mapi_sys_vi_vpss_mode *work_mode)
{
    if (vcap_online && vpss_online) {
        work_mode->mode[0] = HI_MAPI_VI_ONLINE_VPSS_ONLINE;
        work_mode->mode[1] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
        work_mode->mode[2] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
        work_mode->mode[3] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
    } else if (vcap_online) {
        work_mode->mode[0] = HI_MAPI_VI_ONLINE_VPSS_OFFLINE;
        work_mode->mode[1] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
        work_mode->mode[2] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
        work_mode->mode[3] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
    } else if (vpss_online) {
        work_mode->mode[0] = HI_MAPI_VI_OFFLINE_VPSS_ONLINE;
        work_mode->mode[1] = HI_MAPI_VI_OFFLINE_VPSS_ONLINE;
        work_mode->mode[2] = HI_MAPI_VI_OFFLINE_VPSS_ONLINE;
        work_mode->mode[3] = HI_MAPI_VI_OFFLINE_VPSS_ONLINE;
    } else {
        work_mode->mode[0] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
        work_mode->mode[1] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
        work_mode->mode[2] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
        work_mode->mode[3] = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
    }
    return;
}

static hi_mapi_pixel_format get_raw_pixel_format_from_bit_width(td_u32 bit_width)
{
	hi_mapi_pixel_format pixel_format = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP;

	if (bit_width == 8) {   /* 8 : bit width */
		pixel_format = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_8BPP;
    } else if (bit_width == 10) {   /* 10 : bit width */
    	pixel_format = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_10BPP;
    } else if (bit_width == 12) {   /* 12 : bit width */
    	pixel_format = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_12BPP;
    } else if (bit_width == 14) {   /* 14 : bit width */
    	pixel_format = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_14BPP;
    } else if (bit_width == 16) {   /* 16 : bit width */
    	pixel_format = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP;
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "bit_width %d not support force set to %d!\n", bit_width, 16); /* 16: max bit width */
	}

	return pixel_format;
}

/* Publish per-sensor wrap (卷绕) timing + precompute VI buf_line for all sensors in one call. */
static td_void mapi_sys_publish_wrap_cfg(const hi_mapi_sys_base_attr *base_attr,
    td_bool vcap_online, td_bool vpss_online)
{
    mapi_comm_wrap_cfg cfg = {0};
    hi_mapi_size vi_pipe_size[HI_MAPI_VCAP_MAX_DEV_NUM] = {0};
    td_bool any_vi_wrap = TD_FALSE;
    td_u32 d;

    cfg.all_online = (vcap_online && vpss_online) ? TD_TRUE : TD_FALSE;

    for (d = 0; d < base_attr->vcap_dev_num && d < HI_MAPI_VCAP_MAX_DEV_NUM; d++) {
        cfg.full_lines_std[d] = base_attr->sensor_full_lines_std[d];
        cfg.frame_rate[d] = base_attr->frame_rate[d];
        vi_pipe_size[d] = base_attr->vcap_reso_size[d];
        if (base_attr->vi_wrap_en[d]) {
            any_vi_wrap = TD_TRUE;
        }
    }

    if (any_vi_wrap && mapi_adapt_comm_get_vi_wrap_buf_lines(vi_pipe_size, cfg.full_lines_std,
        cfg.frame_rate, base_attr->vcap_dev_num, cfg.vi_buf_line) != TD_SUCCESS) {
        /* vi_buf_line stays 0 -> VI wrap apply will report ENOT_PERM at start_dev */
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "get vi wrap buf lines failed, vi wrap disabled\n");
    }

    mapi_comm_set_wrap_cfg(&cfg);
}

/* VPSS grp g is fed by VI dev g (1:1 for dual sensor); pick that sensor's timing, clamped. */
static td_u32 mapi_sys_wrap_dev_of_grp(td_u32 grp)
{
    if (grp >= HI_MAPI_VCAP_MAX_DEV_NUM) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_SYS, "vpss grp %u >= max dev, fallback to sensor 0 timing\n", grp);
        return 0;
    }
    return grp;
}

/* Fill chn0's VB block as a small wrap ring buffer (blk_cnt=1) instead of a full frame. */
static td_s32 mapi_sys_add_vpss_wrap_vb(const hi_mapi_sys_base_attr *base_attr, td_u32 grp,
    hi_mapi_sys_vb_config *vb_config, td_u32 *cnt)
{
    mapi_pic_buf_attr large_attr = {0};
    mapi_comm_wrap_cfg wrap_cfg;
    mapi_vpss_wrap_calc_param param = {0};
    td_u32 wrap_size = 0;
    td_u32 d = mapi_sys_wrap_dev_of_grp(grp);

    if (*cnt >= HI_MAPI_VB_MAX_COMMON_POOLS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vb pool count %u exceeds max\n", *cnt);
        return TD_FAILURE;
    }

    mapi_comm_get_wrap_cfg(&wrap_cfg);
    mapi_adapt_comm_set_vpss_wrap_buf_attr(&large_attr, base_attr->vpss_reso_size[grp][0].width,
        base_attr->vpss_reso_size[grp][0].height);

    param.large_attr = &large_attr;
    param.small_size = base_attr->vpss_reso_size[grp][1];
    param.full_lines_std = wrap_cfg.full_lines_std[d];
    param.frame_rate = wrap_cfg.frame_rate[d];
    param.all_online = wrap_cfg.all_online;
    if (mapi_adapt_comm_get_vpss_wrap_buf(&param, TD_NULL, &wrap_size) != TD_SUCCESS || wrap_size == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "calc vpss wrap vb size failed, grp:%u\n", grp);
        return TD_FAILURE;
    }

    vb_config->comm_pool[*cnt].blk_size = wrap_size;
    vb_config->comm_pool[*cnt].blk_cnt = 1; /* 1: wrap ring buffer is a single block */
    vb_config->comm_pool[*cnt].remap_mode = HI_MAPI_VB_REMAP_MODE_NONE;
    (*cnt)++;
    return TD_SUCCESS;
}

/* Build VB blocks for one VPSS grp's channels (chn0 -> small wrap block when enabled). */
static td_s32 mapi_sys_calc_vpss_grp_vb(const hi_mapi_sys_base_attr *base_attr, td_u32 grp,
    td_bool all_online, hi_mapi_sys_vb_config *vb_config, td_u32 *cnt)
{
    mapi_pic_buf_attr attr = {0};
    td_u32 j;

    for (j = 0; j < base_attr->vpss_chn_num; j++) {
        /* VPSS wrap (卷绕): chn0 uses a small wrap block instead of a full-frame pool (省内存) */
        if (base_attr->vpss_wrap_en[grp] && j == 0) {
            if (mapi_sys_add_vpss_wrap_vb(base_attr, grp, vb_config, cnt) != TD_SUCCESS) {
                return TD_FAILURE;
            }
            continue;
        }
        if (*cnt >= HI_MAPI_VB_MAX_COMMON_POOLS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "vb pool count %u exceeds max\n", *cnt);
            return TD_FAILURE;
        }
        attr.width = base_attr->vpss_reso_size[grp][j].width;
        attr.height = base_attr->vpss_reso_size[grp][j].height;
        attr.bit_width = 8; /* 8: bit width */
        attr.pixel_format = HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
        attr.compress_mode = HI_MAPI_COMPRESS_MODE_NONE;
        attr.video_format = HI_MAPI_VIDEO_FORMAT_LINEAR;
        vb_config->comm_pool[*cnt].blk_size =
            mapi_adapt_comm_vb_get_buffer_size(MAPI_BUF_TYPE_PIC_COMMON_VB, &attr, sizeof(attr));
        vb_config->comm_pool[*cnt].blk_cnt =
            (all_online == TD_TRUE) ? 3 : 2; /* 3: all online needs an extra buffer; 2: normal offline */
        vb_config->comm_pool[*cnt].remap_mode = HI_MAPI_VB_REMAP_MODE_NONE;
        if (vb_config->comm_pool[*cnt].blk_size == 0) {
            return TD_FAILURE;
        }
        (*cnt)++;
    }
    return TD_SUCCESS;
}

static td_s32 mapi_sys_calc_vb_config(const hi_mapi_sys_base_attr *base_attr, hi_mapi_sys_vb_config *vb_config)
{
    td_u32 i;
    td_u32 cnt = 0;
    td_bool err_flag = TD_FALSE;
    td_bool all_online;
    mapi_pic_buf_attr mapi_buf_attr = {0};

    (td_void)memset_s(vb_config, sizeof(hi_mapi_sys_vb_config), 0, sizeof(hi_mapi_sys_vb_config));

    all_online = ((base_attr->vcap_online[0] == TD_TRUE) && (base_attr->vpss_online[0] == TD_TRUE)) ?
        TD_TRUE : TD_FALSE;

    for (i = 0; i < base_attr->vcap_dev_num; i++) {
        /* VI wrap (卷绕): skip the raw block; the VI driver uses its own private wrap buffer (省内存) */
        if (base_attr->vcap_online[i] == TD_FALSE && base_attr->vi_wrap_en[i] == TD_FALSE) {
            if (cnt >= HI_MAPI_VB_MAX_COMMON_POOLS) {
                err_flag = TD_TRUE;
                goto EXIT;
            }
            mapi_buf_attr.width = base_attr->vcap_reso_size[i].width;
            mapi_buf_attr.height = base_attr->vcap_reso_size[i].height;
            mapi_buf_attr.bit_width = base_attr->raw_bit_width;
            mapi_buf_attr.pixel_format = get_raw_pixel_format_from_bit_width(base_attr->raw_bit_width);
            mapi_buf_attr.compress_mode = mapi_vcap_get_default_pipe_compress_mode();
            mapi_buf_attr.video_format = HI_MAPI_VIDEO_FORMAT_LINEAR;
            vb_config->comm_pool[cnt].blk_size =
                mapi_adapt_comm_vb_get_buffer_size(MAPI_BUF_TYPE_PIC_COMMON_VB, &mapi_buf_attr, sizeof(mapi_buf_attr));
            vb_config->comm_pool[cnt].blk_cnt = 3;   /* 3: offline raw buffer num */
            vb_config->comm_pool[cnt].remap_mode = HI_MAPI_VB_REMAP_MODE_NONE;
            if (vb_config->comm_pool[cnt].blk_size == 0) {
                err_flag = TD_TRUE;
                goto EXIT;
            }
            cnt++;
        }

        if (base_attr->vpss_online[0] == TD_FALSE) {
            if (cnt >= HI_MAPI_VB_MAX_COMMON_POOLS) {
                err_flag = TD_TRUE;
                goto EXIT;
            }
            mapi_buf_attr.width = base_attr->vcap_reso_size[i].width;
            mapi_buf_attr.height = base_attr->vcap_reso_size[i].height;
            mapi_buf_attr.bit_width = 8; /* 8: bit width */
            mapi_buf_attr.pixel_format = HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
            mapi_buf_attr.compress_mode = mapi_vcap_get_default_chn_compress_mode();
            mapi_buf_attr.video_format = HI_MAPI_VIDEO_FORMAT_LINEAR;
            vb_config->comm_pool[cnt].blk_size =
                mapi_adapt_comm_vb_get_buffer_size(MAPI_BUF_TYPE_PIC_COMMON_VB, &mapi_buf_attr, sizeof(mapi_buf_attr));
            vb_config->comm_pool[cnt].blk_cnt = 2;   /* 2: offline yuv buffer num */
            vb_config->comm_pool[cnt].remap_mode = HI_MAPI_VB_REMAP_MODE_NONE;
            if (vb_config->comm_pool[cnt].blk_size == 0) {
                err_flag = TD_TRUE;
                goto EXIT;
            }
            cnt++;
        }
    }

    for (i = 0; i < base_attr->vpss_grp_num; i++) {
        if (mapi_sys_calc_vpss_grp_vb(base_attr, i, all_online, vb_config, &cnt) != TD_SUCCESS) {
            err_flag = TD_TRUE;
            goto EXIT;
        }
    }

    vb_config->max_pool_cnt = cnt;

EXIT:
    return (err_flag == TD_FALSE) ? TD_SUCCESS : TD_FAILURE;
}

td_s32 hi_mapi_sys_get_default_media_attr(const hi_mapi_sys_base_attr *base_attr, hi_mapi_sys_media_attr *media_attr)
{
    td_s32 ret;
    td_bool vcap_online = TD_FALSE;
    td_bool vpss_online = TD_FALSE;

    CHECK_MAPI_SYS_NULL_PTR_RET("base_attr", base_attr);
    CHECK_MAPI_SYS_NULL_PTR_RET("media_attr", media_attr);

    if (mapi_sys_check_work_mode(base_attr, &vcap_online, &vpss_online) != TD_SUCCESS) {
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    /* SDK: with dual input, VI pipe wrap can't be on for one dev and off for another. */
    if (base_attr->vcap_dev_num > 1) {
        td_u32 i;
        for (i = 1; i < base_attr->vcap_dev_num && i < HI_MAPI_VCAP_MAX_DEV_NUM; i++) {
            if (base_attr->vi_wrap_en[i] != base_attr->vi_wrap_en[0]) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_SYS,
                    "dual input: vi_wrap_en must be same for all devs (dev0=%d dev%u=%d)\n",
                    base_attr->vi_wrap_en[0], i, base_attr->vi_wrap_en[i]);
                return HI_MAPI_SYS_EILLEGAL_PARAM;
            }
        }
    }

    mapi_sys_get_default_work_mode(vcap_online, vpss_online, &media_attr->media_config.vi_vpss_mode);

    /* publish buffer wrap (卷绕) cfg before VB sizing so both use the same values */
    mapi_sys_publish_wrap_cfg(base_attr, vcap_online, vpss_online);

    /* default vb config */
    ret = mapi_sys_calc_vb_config(base_attr, &media_attr->media_config.vb_config);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_sys_calc_vb_config err, ret:%x\n", ret);
        return ret;
    }

    /* config default venc mode param */
    media_attr->venc_mod_para.h264e_low_power_mode = MAPI_VENC_LOWPOWER_MODE_DEFAULT;
    media_attr->venc_mod_para.h265e_low_power_mode = MAPI_VENC_LOWPOWER_MODE_DEFAULT;
    media_attr->venc_mod_para.svac3e_low_power_mode = MAPI_VENC_LOWPOWER_MODE_DEFAULT;

    /* config default isp mode param */
    media_attr->isp_mod_para.param_valid = TD_FALSE;
    media_attr->isp_mod_para.quick_start = TD_FALSE;
    media_attr->isp_mod_para.int_bottom_half = TD_FALSE;

    /* config default audio mode param */
    media_attr->audio_mod_para.audio_bypass = TD_FALSE;
    media_attr->audio_mod_para.vqe_attr.talk_vqe_attr.open_mask =
        HI_MAPI_AI_TALKVQE_MASK_HPF | HI_MAPI_AI_TALKVQE_MASK_AEC | HI_MAPI_AI_TALKVQE_MASK_AGC | HI_MAPI_AI_TALKVQE_MASK_ANR;
    media_attr->audio_mod_para.vqe_attr.ao_vqe_attr.open_mask =
        HI_MAPI_AO_VQE_MASK_HPF | HI_MAPI_AO_VQE_MASK_AGC;

    return TD_SUCCESS;
}


td_s32 hi_mapi_sys_init_media(const hi_mapi_sys_media_attr *media_attr)
{
    td_s32 ret;
    CHECK_MAPI_SYS_NULL_PTR_RET("media_attr", media_attr);

    if (g_media_init == TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "media has already been inited\n");
        return TD_SUCCESS;
    }

    if (media_attr->media_config.vb_config.max_pool_cnt != 0) {
        td_u32 supplement_config;
        hal_mapi_vb_set_supplement_config(&supplement_config);
        ret = mapi_adapt_sys_init_media(&media_attr->media_config, supplement_config);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "MAPI_MEDIA_SYS_Init fail,ret:%x\n", ret);
            goto DEINIT;
        }
    }

    ret = mapi_sys_init_video_module(media_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_sys_init_video_module err, ret:%x\n", ret);
        goto SYS_DEINIT;
    }

    ret = mapi_sys_init_audio_module(&media_attr->audio_mod_para);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_sys_init_audio_module err, ret:%x\n", ret);
        goto VIDEO_DEINIT;
    }

    /* 进入 media_inited 态之前开启 VB 记账表；失败则回滚已 init 的 audio/video/sys-media */
    ret = mapi_sys_vb_ctx_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_sys_vb_ctx_init fail, ret:%x\n", ret);
        goto AUDIO_DEINIT;
    }


    if (pthread_mutex_init(&g_soft_bind_ctx.lock, TD_NULL) != 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "init soft bind ctx mutex fail\n");
        ret = HI_MAPI_SYS_ENOTREADY;
        goto VB_CTX_DEINIT;
    }
    g_soft_bind_ctx.running  = TD_TRUE;
    g_soft_bind_ctx.disp_cnt = 0;
    ret = pthread_create(&g_soft_bind_ctx.tid, TD_NULL, mapi_sys_soft_bind_thread, TD_NULL);
    if (ret != 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "soft_bind poll thread create fail\n");
        g_soft_bind_ctx.running = TD_FALSE;
        g_soft_bind_ctx.tid = (pthread_t)-1;
        (td_void)pthread_mutex_destroy(&g_soft_bind_ctx.lock);
        ret = HI_MAPI_SYS_EBUSY;
        goto VB_CTX_DEINIT;
    }

    g_media_init = TD_TRUE;
    g_need_set_vb = (media_attr->media_config.vb_config.max_pool_cnt == 0) ? TD_FALSE : TD_TRUE;
    g_use_audio = (media_attr->audio_mod_para.audio_bypass == TD_TRUE) ? TD_FALSE : TD_TRUE;

    return TD_SUCCESS;

VB_CTX_DEINIT:
    mapi_sys_vb_ctx_deinit();
AUDIO_DEINIT:
    if (media_attr->audio_mod_para.audio_bypass != TD_TRUE) {
        (td_void)mapi_aenc_deinit();
        (td_void)mapi_acap_deinit();
        (td_void)mapi_ao_deinit();
    }

VIDEO_DEINIT:
    {
        td_s32 deinit_ret = mapi_sys_deinit_video_module();
        if (deinit_ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_sys_deinit_video_module fail.\n");
        }
    }

SYS_DEINIT:
    if (media_attr->media_config.vb_config.max_pool_cnt != 0) {
        td_s32 deinit_ret = mapi_adapt_sys_deinit_media();
        if (deinit_ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_adapt_sys_deinit_media fail.\n");
        }
    }
DEINIT:
    g_media_init = TD_FALSE;

    return ret;
}

td_s32 hi_mapi_sys_deinit_media(td_void)
{
    td_bool func_ret_err = TD_FALSE;

    if (g_media_init == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "Media has already been deinited\n");
        return TD_SUCCESS;
    }

    if (g_soft_bind_ctx.running == TD_TRUE) {
        g_soft_bind_ctx.running = TD_FALSE;
        if (g_soft_bind_ctx.tid != (pthread_t)-1) {
            pthread_join(g_soft_bind_ctx.tid, TD_NULL);
            g_soft_bind_ctx.tid = (pthread_t)-1;
        }
    }
    g_soft_bind_ctx.disp_cnt = 0;
    (td_void)pthread_mutex_destroy(&g_soft_bind_ctx.lock);

    /* add other deinit fun here */
    td_s32 ret = mapi_venc_deinit();
    CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_SYS, "mapi_venc_deinit", ret, func_ret_err);

    if (g_use_audio == TD_TRUE) {
        ret = mapi_aenc_deinit();
        CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_SYS, "mapi_aenc_deinit", ret, func_ret_err);

        ret = mapi_acap_deinit();
        CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_SYS, "mapi_acap_deinit", ret, func_ret_err);

        ret = mapi_ao_deinit();
        CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_SYS, "mapi_ao_deinit", ret, func_ret_err);
    }

    ret = mapi_vpss_deinit();
    CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_SYS, "mapi_vpss_deinit", ret, func_ret_err);
#ifdef SUPPORT_DISP
    ret = MAPI_DISP_Deinit();
    CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_SYS, "MAPI_DISP_Deinit", ret, func_ret_err);
#endif
    ret = mapi_vcap_deinit();
    CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_SYS, "mapi_vcap_deinit", ret, func_ret_err);

    mapi_sys_vb_ctx_deinit();

    if (g_need_set_vb == TD_TRUE) {
        ret = mapi_adapt_sys_deinit_media();
        CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_SYS, "mapi_adapt_sys_deinit_media", ret, func_ret_err);
    }

    g_media_init = TD_FALSE;

    if (func_ret_err) {
        return HI_MAPI_SYS_EBUSY;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_sys_alloc_buffer(td_u64 *phy_addr, td_void **virt_addr, td_u32 buf_len, const td_char *buf_name,
    td_bool is_cache)
{
    CHECK_MAPI_SYS_NULL_PTR_RET("phy_addr", phy_addr);
    CHECK_MAPI_SYS_NULL_PTR_RET("virt_addr", virt_addr);
    CHECK_MAPI_SYS_NULL_PTR_RET("buf_name", buf_name);

    if (g_media_init == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "media not init yet\n");
        return HI_MAPI_SYS_ENOTREADY;
    }

    if (buf_len == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "Buffer len can not be zero\n");
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    td_s32 ret = mapi_adapt_sys_alloc_mmz_buffer(phy_addr, virt_addr, buf_len, buf_name, is_cache);
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "mapi_adapt_sys_alloc_mmz_buffer", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_sys_free_buffer(td_u64 phy_addr, td_void *virt_addr, td_u32 buf_len)
{
    td_s32 ret;
    CHECK_MAPI_SYS_NULL_PTR_RET("virt_addr", virt_addr);
    MAPI_UNUSED(buf_len);

    if (g_media_init == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "media not init yet\n");
        return HI_MAPI_SYS_ENOTREADY;
    }

    ret = mapi_adapt_sys_free_mmz_buffer(phy_addr, virt_addr);
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "mapi_adapt_sys_free_mmz_buffer", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_sys_flush_cache(td_u64 phy_addr, td_void *virt_addr, td_u32 buf_len)
{
    td_s32 ret;
    CHECK_MAPI_SYS_NULL_PTR_RET("virt_addr", virt_addr);

    if (g_media_init == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "media not init yet\n");
        return HI_MAPI_SYS_ENOTREADY;
    }

    ret = mapi_adapt_sys_flush_cache(phy_addr, virt_addr, buf_len);
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "mapi_adapt_sys_flush_cache", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_sys_get_video_block(td_handle *pool_hdl, td_u64 *phy_addr, td_void **vir_addr, td_u64 blk_size,
    const td_char *mmz_name)
{
    return mapi_sys_get_video_block(pool_hdl, phy_addr, vir_addr, blk_size, mmz_name);
}

td_s32 hi_mapi_sys_release_video_block(td_u64 phy_addr, td_void *vir_addr)
{
    return mapi_sys_release_video_block(phy_addr, vir_addr);
}

td_s32 hi_mapi_sys_register_font_attr(const hi_mapi_sys_font_attr *font_attr)
{
    CHECK_MAPI_SYS_NULL_PTR_RET("font_attr", font_attr);
    CHECK_MAPI_SYS_NULL_PTR_RET("font_attr->get_font_mod_cb", font_attr->get_font_mod_cb);

    if (font_attr->font_width == 0 || font_attr->font_height == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "font_width or font_height must > 0.\n");
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    if ((font_attr->font_width % MAPI_FONT_BYTE_BITS) != 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "font_width must be a multiple of %d.\n", MAPI_FONT_BYTE_BITS);
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    if (g_font_mod_attr.is_init) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "the FontMod is registered repeated!\n");
        return HI_MAPI_SYS_ENOT_PERM;
    }

    td_s32 ret = memcpy_s(&g_font_mod_attr.font_attr, sizeof(g_font_mod_attr.font_attr), font_attr,
        sizeof(hi_mapi_sys_font_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memcpy_s", ret);

    g_font_mod_attr.is_init = TD_TRUE;

    return TD_SUCCESS;
}

td_bool mapi_get_media_init_status(td_void)
{
    td_bool b_flag = g_media_init;
    return b_flag;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
