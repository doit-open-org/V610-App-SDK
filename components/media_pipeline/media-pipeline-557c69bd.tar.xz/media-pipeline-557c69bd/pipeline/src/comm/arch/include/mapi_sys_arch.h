/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_SYS_ARCH_H__
#define __MAPI_SYS_ARCH_H__

#include "hi_mapi_sys.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 hal_mapi_sys_register_vqe_module(const hi_mapi_audio_vqe_attr *audio_vqe_attr);
td_void hal_mapi_vb_set_supplement_config(td_u32 *supplement_config);
td_s32 hal_mapi_sys_calc_vb_config(const hi_mapi_sys_base_attr *base_attr, hi_mapi_sys_vb_config *vb_config);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_SYS_ARCH_H__ */
