/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "hi_mapi_sys.h"
#include "mapi_comm_inner.h"
#include "hi_mw_log.h"
#include "mapi_sys_adapt.h"
#include "mapi_sys_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 hal_mapi_sys_register_vqe_module(const hi_mapi_audio_vqe_attr *audio_vqe_attr)
{
    td_s32 ret = mapi_adapt_sys_register_vqe_module(audio_vqe_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "register vqe module fail with ret = %d!\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_void hal_mapi_vb_set_supplement_config(td_u32 *supplement_config)
{
    if (supplement_config == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "input is null.\n");
        return;
    }
    *supplement_config = MAPI_VB_SUPPLEMENT_JPEG_MASK | MAPI_VB_SUPPLEMENT_DNG_MASK | MAPI_VB_SUPPLEMENT_BNR_MOT_MASK;
#ifdef SUPPORT_GYRO
    *supplement_config |= MAPI_VB_SUPPLEMENT_MOTION_DATA_MASK;
#endif
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
