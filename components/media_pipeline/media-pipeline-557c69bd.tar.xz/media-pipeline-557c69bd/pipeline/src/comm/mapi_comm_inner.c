/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_comm_inner.h"
#include <string.h>
#include <sys/time.h>
#include <limits.h>
#include "hi_mapi_sys.h"
#include "securec.h"
#include "hi_mw_log.h"

#define BYTES 2

static mapi_comm_wrap_cfg g_mapi_wrap_cfg = {0};
static pthread_mutex_t g_mapi_wrap_cfg_lock = PTHREAD_MUTEX_INITIALIZER;

td_void mapi_comm_set_wrap_cfg(const mapi_comm_wrap_cfg *cfg)
{
    if (cfg == TD_NULL) {
        return;
    }
    (td_void)pthread_mutex_lock(&g_mapi_wrap_cfg_lock);
    g_mapi_wrap_cfg = *cfg;
    (td_void)pthread_mutex_unlock(&g_mapi_wrap_cfg_lock);
}

td_void mapi_comm_get_wrap_cfg(mapi_comm_wrap_cfg *cfg)
{
    if (cfg == TD_NULL) {
        return;
    }
    (td_void)pthread_mutex_lock(&g_mapi_wrap_cfg_lock);
    *cfg = g_mapi_wrap_cfg;
    (td_void)pthread_mutex_unlock(&g_mapi_wrap_cfg_lock);
}

static void mapi_comm_get_font_mod2(td_u16 *glyph_buffer, char c, mapi_comm_text_bitmap *text)
{
    mapi_comm_font_mod_attr *font_mod_attr = mapi_sys_get_font_mod_attr();
    td_u8 *font_mod = NULL;
    td_s32 font_mod_len = 0;
    if (font_mod_attr->font_attr.get_font_mod_cb(&c, &font_mod, &font_mod_len) != TD_SUCCESS || font_mod == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get_font_mod_cb failed\n");
        return;
    }

    td_u32 offset;
    td_u32 row;
    td_u32 col;
    for (td_u32 i = 0; i < text->font_size.height; i++) {
        for (td_u32 j = 0; j < text->font_size.width; j++) {
            row = i * font_mod_attr->font_attr.font_height / text->font_size.height;
            col = j * font_mod_attr->font_attr.font_width / text->font_size.width;
            offset = row * font_mod_attr->font_attr.font_width / MAPI_FONT_BYTE_BITS + col / MAPI_FONT_BYTE_BITS;
            if (offset > (td_u32)font_mod_len) {
                return;
            }
            if (((font_mod[offset] >> (MAPI_FONT_BYTE_BITS - 1 - (col % MAPI_FONT_BYTE_BITS))) & 0x1) == 1) {
                glyph_buffer[i * text->font_size.width + j] = (td_u16)text->font_color;
            } else {
                glyph_buffer[i * text->font_size.width + j] = (td_u16)text->bg_color;
            }
        }
    }
}

static td_s32 mapi_comm_get_font_mod(td_u32 idx, mapi_comm_text_bitmap *text)
{
    mapi_comm_font_mod_attr *font_mod_attr = mapi_sys_get_font_mod_attr();
    td_u8 *font_mod = NULL;
    td_s32 font_mod_len = 0;
    if (font_mod_attr->font_attr.get_font_mod_cb(&text->str[idx], &font_mod, &font_mod_len) != TD_SUCCESS ||
        font_mod == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get_font_mod_cb failed\n");
        return TD_FAILURE;
    }

    td_u16 *tmp_bitmap_data = text->bitmap_data;

    td_u32 offset;
    td_u32 bitmap_offset;
    td_u32 row;
    td_u32 col;
    for (td_u32 i = 0; i < text->font_size.height; i++) {
        for (td_u32 j = 0; j < text->font_size.width; j++) {
            if ((i * text->font_size.width + j) > (text->stride * text->rgn_size.height)) {
                break;
            }
            row = i * font_mod_attr->font_attr.font_height / text->font_size.height;
            col = j * font_mod_attr->font_attr.font_width / text->font_size.width;
            offset = row * font_mod_attr->font_attr.font_width / MAPI_FONT_BYTE_BITS + col / MAPI_FONT_BYTE_BITS;
            if (offset > (td_u32)font_mod_len) {
                return TD_FAILURE;
            }
            bitmap_offset = i * text->stride / BYTES + j + (idx * text->font_size.width);
            if (((font_mod[offset] >> (MAPI_FONT_BYTE_BITS - 1 - (col % MAPI_FONT_BYTE_BITS))) & 0x1) == 1) {
                tmp_bitmap_data[bitmap_offset] = (td_u16)text->font_color;
            } else {
                tmp_bitmap_data[bitmap_offset] = (td_u16)text->bg_color;
            }
        }
    }
    return TD_SUCCESS;
}

static td_s32 mapi_comm_get_glyph(td_u32 idx, mapi_comm_text_bitmap *text)
{
    td_s32 ret;
    td_u32 size = text->font_size.width * text->font_size.height;
    if (size == 0) {
        return TD_FAILURE;
    }
    td_u16 *ascii_glyph = (td_u16 *)malloc(sizeof(td_u16) * size);
    if (ascii_glyph == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "ascii_glyph malloc failed\n");
        return TD_FAILURE;
    }

    unsigned char c = text->str[idx];
    mapi_comm_get_font_mod2(ascii_glyph, c, text);

    td_u32 offset = idx * text->font_size.width;
    td_u32 width = text->stride / BYTES;
    for (td_u32 j = 0; j < text->font_size.height; j++) {
        ret = memcpy_s(&text->bitmap_data[offset + j * (width)], sizeof(td_u16) * text->font_size.width,
            ascii_glyph + j * text->font_size.width, sizeof(td_u16) * text->font_size.width);
        CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_OSD, "memcpy_s", ret, fail);
    }

    if (ascii_glyph != TD_NULL) {
        free(ascii_glyph);
        ascii_glyph = TD_NULL;
    }
    return TD_SUCCESS;

fail:
    if (ascii_glyph != TD_NULL) {
        free(ascii_glyph);
        ascii_glyph = TD_NULL;
    }
    return ret;
}

td_s32 mapi_comm_config_text_bitmap(mapi_comm_text_bitmap *text, td_bool use_ascii_glyph)
{
    CHECK_MAPI_SYS_NULL_PTR_RET("text", text);
    CHECK_MAPI_SYS_NULL_PTR_RET("text->bitmap_data", text->bitmap_data);

    /* generate bitmap */
    td_s32 ret;
    td_u32 str_len = (td_u32)strnlen(text->str, HI_MAPI_MAX_STR_LEN);
    td_u32 canvas_height = text->font_size.height;
    td_u32 width = text->stride / BYTES;

    for (td_u32 i = 0; i < str_len; i++) {
        /* Check if the current character exceeds the canvas width */
        if (text->font_size.width * (i + 1) > text->rgn_size.width) {
            break;
        }

        if (use_ascii_glyph == TD_TRUE) {
            ret = mapi_comm_get_glyph(i, text);
            CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "mapi_comm_get_glyph", ret);
        } else {
            ret = mapi_comm_get_font_mod(i, text);
            CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "mapi_comm_get_font_mod", ret);
        }
    }

    /* Fill background color for the remaining area */
    td_u32 start_col = str_len * text->font_size.width;
    if (start_col < text->rgn_size.width) {
        for (td_u32 bitmap_row = 0; bitmap_row < canvas_height; ++bitmap_row) {
            for (td_u32 bitmap_col = start_col; bitmap_col < text->rgn_size.width; ++bitmap_col) {
                text->bitmap_data[bitmap_row * width + bitmap_col] = (td_u16)text->bg_color;
            }
        }
    }

    /* Fill background color for the remaining rows */
    for (td_u32 bitmap_row = canvas_height; bitmap_row < text->rgn_size.height; ++bitmap_row) {
        for (td_u32 bitmap_col = 0; bitmap_col < text->rgn_size.width; ++bitmap_col) {
            text->bitmap_data[bitmap_row * width + bitmap_col] = (td_u16)text->bg_color;
        }
    }

    return TD_SUCCESS;
}

td_void mapi_comm_cond_time_wait(pthread_cond_t *cond, pthread_mutex_t *mutex, td_u64 delay_us)
{
    struct timespec ts;
    (td_void)clock_gettime(CLOCK_MONOTONIC, &ts);
    if (ts.tv_sec < 0 || ts.tv_nsec < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "Negative time values detected\n");
        return;
    }
    td_u64 tv_sec = (td_u64)ts.tv_sec;
    td_u64 tv_nsec = (td_u64)ts.tv_nsec;

    td_u64 delay_ns = delay_us * MAPI_USEC2NSEC_SCALE;
    td_u64 sec_add = delay_ns / MAPI_SEC2NSEC_SCALE;
    td_u64 nsec_add = delay_ns % MAPI_SEC2NSEC_SCALE;

    if (sec_add > UINT64_MAX - tv_sec) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "tv_sec + sec_add > UINT64_MAX\n");
        return;
    }
    if (nsec_add > UINT64_MAX - tv_nsec) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "tv_nsec + nsec_add > UINT64_MAX\n");
        return;
    }

    tv_sec += sec_add;
    tv_nsec += nsec_add;

    if (tv_nsec >= MAPI_SEC2NSEC_SCALE) {
        tv_sec += tv_nsec / MAPI_SEC2NSEC_SCALE;
        tv_nsec %= MAPI_SEC2NSEC_SCALE;
    }

    if (tv_sec > (td_u64)LLONG_MAX || tv_nsec > (td_u64)LONG_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "Time values exceed signed type limits\n");
        return;
    }
    ts.tv_sec = (time_t)tv_sec;
    ts.tv_nsec = (long)tv_nsec;

    pthread_cond_timedwait(cond, mutex, &ts);
}
