/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef MAPI_LINUX_LIST_H
#define MAPI_LINUX_LIST_H

#ifndef _LINUX_LIST_H

#ifndef MAPI_INLINE
#define MAPI_INLINE __inline
#endif

struct CbbListHead {
    struct CbbListHead *next, *prev;
};

#define MAPI_LIST_HEAD_INIT(name) \
    {                        \
        &(name), &(name)     \
    }

#define MAPI_LIST_HEAD(name) \
    struct CbbListHead name = MAPI_LIST_HEAD_INIT(name)
#define MAPI_INIT_LIST_HEAD(ptr)  \
    do {                     \
        (ptr)->next = (ptr); \
        (ptr)->prev = (ptr); \
    } while (0)

static MAPI_INLINE void CbbListAdd(struct CbbListHead *newHead, struct CbbListHead *prev,
    struct CbbListHead *next)
{
    if (newHead == NULL || prev == NULL || next == NULL) {
        return;
    }

    next->prev = newHead;
    newHead->next = next;
    newHead->prev = prev;
    prev->next = newHead;
}

static MAPI_INLINE void LIST_CbbListAdd(struct CbbListHead *newHead, struct CbbListHead *head)
{
    CbbListAdd(newHead, head, head->next);
}

static MAPI_INLINE void LIST_CbbListAddTail(struct CbbListHead *newHead, struct CbbListHead *head)
{
    if (head == NULL) {
        return;
    }

    CbbListAdd(newHead, head->prev, head);
}

static MAPI_INLINE void CbbListDel(struct CbbListHead *prev, struct CbbListHead *next)
{
    next->prev = prev;
    prev->next = next;
}

static MAPI_INLINE void LIST_CbbListDel(struct CbbListHead *entry)
{
    CbbListDel(entry->prev, entry->next);
}

static MAPI_INLINE void LIST_CbbListDelInit(struct CbbListHead *entry)
{
    CbbListDel(entry->prev, entry->next);
    MAPI_INIT_LIST_HEAD(entry);
}

static MAPI_INLINE int CbbListEmpty(const struct CbbListHead *head)
{
    return head->next == head;
}

static MAPI_INLINE void CbbListSplice(struct CbbListHead *list,
    struct CbbListHead *head)
{
    struct CbbListHead *first = list->next;
    struct CbbListHead *last = list->prev;
    struct CbbListHead *at = head->next;

    first->prev = head;
    head->next = first;

    last->next = at;
    at->prev = last;
}

static MAPI_INLINE void LIST_CbbListSplice(struct CbbListHead *list, struct CbbListHead *head)
{
    if (CbbListEmpty(list) == 0) {
        CbbListSplice(list, head);
    }
}

static MAPI_INLINE void LIST_CbbListSpliceInit(struct CbbListHead *list, struct CbbListHead *head)
{
    if (CbbListEmpty(list) == 0) {
        CbbListSplice(list, head);
        MAPI_INIT_LIST_HEAD(list);
    }
}

#define CBB_LIST_ENTRY(ptr, type, member) \
    ((type *)((unsigned long)(uintptr_t)(ptr) - ((unsigned long)(&((type *)1)->member) - 1)))

#define CBB_LIST_FOR_EACH(pos, head)                                    \
    for ((pos) = (head)->next; (((pos) != (head)) && ((pos) != TD_NULL_PTR)); \
         (pos) = (pos)->next)

#define CBB_LIST_FOR_EACH_ENTRY(pos, head, member)                 \
    for ((pos) = CBB_LIST_ENTRY((head)->next, typeof(*(pos)), member); \
         &(pos)->member != (head);                                   \
         (pos) = CBB_LIST_ENTRY((pos)->member.next, typeof(*(pos)), member))

#define CBB_LIST_FOR_EACH_SAFE(pos, n, head)               \
    for ((pos) = (head)->next, (n) = (pos)->next; (pos) != (head); \
         (pos) = (n), (n) = (pos)->next)

#define CBB_GET_FIRST_ITEM(attached, type, member) \
    ((type *)((char *)((attached)->next) - (unsigned long)(&((type *)0)->member)))

#endif

#define CBB_LIST_FOR_EACH_ENTRY_SAFE(pos, n, head, member)          \
    for ((pos) = CBB_LIST_ENTRY((head)->next, typeof(*(pos)), member),  \
        (n) = CBB_LIST_ENTRY((pos)->member.next, typeof(*(pos)), member); \
         &(pos)->member != (head);                                    \
         (pos) = (n), (n) = CBB_LIST_ENTRY((n)->member.next, typeof(*(n)), member))

#endif
