/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <pthread.h>
#include <string.h>
#include <sys/prctl.h>
#include <unistd.h>

#include "hi_mapi_comm_define.h"
#include "hi_mw_log.h"
#include "hi_mapi_vpss_adapt_define.h"
#include "hi_mapi_vpss_define.h"
#include "mapi_comm_adapt.h"
#include "mapi_comm_inner.h"
#include "mapi_vpss_adapt.h"
#include "mapi_vpss_inner.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

typedef struct {
    hi_mapi_vpss_cmd id;
    td_s32 (*process)(td_handle grp_hdl, td_handle chn_hdl, const td_void *cmd_attr, td_u32 len);
} set_cmd_ex_map;

typedef struct {
    hi_mapi_vpss_cmd id;
    td_s32 (*process)(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len);
} get_cmd_ex_map;

static mapi_vpss_ctx g_vpss_ctx[HI_MAPI_VPSS_MAX_NUM];
static pthread_mutex_t g_vpss_lock = PTHREAD_MUTEX_INITIALIZER;

static td_s32 mapi_vpss_calc_buf_wrap(td_handle grp_hdl, mapi_vpss_buf_wrap_info *info);

static td_void mapi_vpss_reset(td_bool deinit)
{
    td_u32 i;
    td_u32 j;

    MAPI_MUTEX_LOCK(g_vpss_lock);

    for (i = 0; i < HI_MAPI_VPSS_MAX_NUM; i++) {
        g_vpss_ctx[i].is_vpss_start = TD_FALSE;
        g_vpss_ctx[i].frm_time_ref = 0;

        for (j = 0; j < HI_MAPI_VPSS_PHY_CHN_MAX_NUM; j++) {
            g_vpss_ctx[i].vpss_phy_chn_attr[j].is_chn_start = TD_FALSE;
            g_vpss_ctx[i].vpss_phy_chn_attr[j].support_buffer_share = TD_FALSE;

            if (deinit == TD_TRUE) {
                (td_void)mapi_adapt_comm_destroy_vb_pool(g_vpss_ctx[i].vpss_phy_chn_attr[j].pool_id);
            }
            g_vpss_ctx[i].vpss_phy_chn_attr[j].pool_id = OT_VB_INVALID_POOL_ID;
        }

        for (j = 0; j < HI_MAPI_VPSS_EXT_CHN_MAX_NUM; j++) {
            g_vpss_ctx[i].vpss_ext_chn_attr[j].is_phy_chn_start = TD_FALSE;
            g_vpss_ctx[i].vpss_ext_chn_attr[j].is_ext_chn_start = TD_FALSE;
            if (deinit == TD_TRUE) {
                (td_void)mapi_adapt_comm_destroy_vb_pool(g_vpss_ctx[i].vpss_ext_chn_attr[j].pool_id);
            }
            g_vpss_ctx[i].vpss_ext_chn_attr[j].pool_id = OT_VB_INVALID_POOL_ID;
        }
    }

    MAPI_MUTEX_UNLOCK(g_vpss_lock);
}

/* ndk inner */
td_s32 mapi_vpss_init(td_void)
{
    MAPI_MUTEX_INIT_LOCK(g_vpss_lock);
    mapi_vpss_reset(TD_FALSE);
    return TD_SUCCESS;
}

td_s32 mapi_vpss_deinit(td_void)
{
    mapi_vpss_reset(TD_TRUE);
    MAPI_MUTEX_DESTROY(g_vpss_lock);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_init(td_handle grp_hdl, const hi_mapi_vpss_grp_attr *grp_attr)
{
    td_s32 ret;
    td_s32 destroy_ret;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    VPSS_CHECK_NULL_PTR_RET(grp_attr);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VPSS, "Vpss group %d has been initialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return TD_SUCCESS;
    }

    ret = mapi_adapt_vpss_create_grp(grp_hdl, grp_attr);
    VPSS_CHECK_RET_UNLOCK("create vpss failed", ret, g_vpss_lock);

    g_vpss_ctx[grp_hdl].max_width  = grp_attr->max_width;
    g_vpss_ctx[grp_hdl].max_height = grp_attr->max_height;
    g_vpss_ctx[grp_hdl].have_set_gdc_for_ldc_before = TD_FALSE;

    ret = mapi_adapt_vpss_start_grp(grp_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "start vpss[%u] failed,ret:[%#x]\n", grp_hdl, ret);
        destroy_ret = mapi_adapt_vpss_destroy_grp(grp_hdl);
        if (destroy_ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "destroy vpss[%u] failed,ret:[%#x]\n", grp_hdl, destroy_ret);
        }
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return ret;
    }

#ifdef SUPPORT_IVE
    mapi_vpss_init_ive(grp_hdl);
#endif

    g_vpss_ctx[grp_hdl].is_vpss_start = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_vpss_lock);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_deinit(td_handle grp_hdl)
{
    td_s32 ret;

    VPSS_CHECK_HANDLE_RET(grp_hdl);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start == TD_FALSE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VPSS, "Vpss group %d has been deinit.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return TD_SUCCESS;
    }

    ret = mapi_adapt_vpss_stop_grp(grp_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "stop vpss[%u] failed,ret:[%#x]\n", grp_hdl, ret);
    }

    ret = mapi_adapt_vpss_destroy_grp(grp_hdl);
    VPSS_CHECK_RET_UNLOCK("destroy vpss group failed", ret, g_vpss_lock);

    g_vpss_ctx[grp_hdl].is_vpss_start = TD_FALSE;
    MAPI_MUTEX_UNLOCK(g_vpss_lock);
    return TD_SUCCESS;
}

#ifdef SUPPORT_IVE
td_s32 HI_MAPI_VPSS_StartRecvVcapYuv(td_handle vpssHdl, td_handle vcapPipeHdl, hi_mapi_yuv_data_seq yuvSeq)
{
    VCAPPIPE_CHECK_HANDLE_RET(vcapPipeHdl);
    VPSS_CHECK_HANDLE_RET(vpssHdl);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[vpssHdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized, can not start recv vcap yuv \n", vpssHdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }

    td_s32 ret = mapi_vpss_start_recv_yuv(vpssHdl, vcapPipeHdl, yuvSeq);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d start recv vcap yuv failed \n", vpssHdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return ret;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    return TD_SUCCESS;
}

td_s32 HI_MAPI_VPSS_StopRecvVcapYuv(td_handle vpssHdl)
{
    VPSS_CHECK_HANDLE_RET(vpssHdl);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[vpssHdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized, can not stop recv vcap yuv \n", vpssHdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }

    td_s32 ret = mapi_vpss_stop_recv_yuv(vpssHdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d stop recv vcap yuv failed \n", vpssHdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return ret;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    return TD_SUCCESS;
}
#endif

static td_s32 mapi_vpss_check_chn_attr(const hi_mapi_vpss_chn_attr *chn_attr)
{
    VPSS_CHECK_NULL_PTR_RET(chn_attr);
    if ((chn_attr->width == 0) || (chn_attr->height == 0)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "width[%u] or height[%u] is illegal.\n",
            chn_attr->width, chn_attr->height);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_set_chn_attr(td_handle grp_hdl, td_handle chn_hdl, const hi_mapi_vpss_chn_attr *chn_attr)
{
    td_s32 ret;
    td_u32 scale_w;
    td_u32 scale_h;
    td_u32 scale = 1;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_PHY_HANDLE_RET(chn_hdl);
    ret = mapi_vpss_check_chn_attr(chn_attr);
    VPSS_CHECK_RET("check chn attr failed", ret);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].support_buffer_share = chn_attr->support_buffer_share;
    g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].low_delay_info.enable   = chn_attr->low_delay_info.enable;
    g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].low_delay_info.line_cnt = chn_attr->low_delay_info.line_cnt;
    /* cache chn resolution for buffer wrap (卷绕) buf_line derivation */
    g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].width  = chn_attr->width;
    g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].height = chn_attr->height;
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    if (chn_attr->width != 0 && chn_attr->height != 0) {
        scale_w = g_vpss_ctx[grp_hdl].max_width / chn_attr->width;
        scale_h = g_vpss_ctx[grp_hdl].max_height / chn_attr->height;
        if (scale_w >= OT_VPSS_MAX_ZOOMOUT || scale_h >= OT_VPSS_MAX_ZOOMOUT) {
            scale += 1;
        }
    }

    ret = mapi_adapt_vpss_set_chn_attr(grp_hdl, chn_hdl, chn_attr,
        &g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].pool_id, scale);
    VPSS_CHECK_RET("set chn attr failed", ret);

#ifdef SUPPORT_PHOTO_POST_PROCESS
    ret = MAPI_ADAPT_VPSS_SetChnAlign(vpssHdl, chnHdl, PHOTO_ALIGN_LEN);
    VPSS_CHECK_RET("set chn align failed", ret);
#endif

    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_get_chn_attr(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_chn_attr *chn_attr)
{
    td_s32 ret;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_PHY_HANDLE_RET(chn_hdl);
    VPSS_CHECK_NULL_PTR_RET(chn_attr);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    chn_attr->support_buffer_share = g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].support_buffer_share;
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    ret = mapi_adapt_vpss_get_low_delay_attr(grp_hdl, chn_hdl, &chn_attr->low_delay_info);
    VPSS_CHECK_RET("get low delay attr failed", ret);

    ret = mapi_adapt_vpss_get_chn_attr(grp_hdl, chn_hdl, chn_attr);
    VPSS_CHECK_RET("get chn attr failed", ret);
    return TD_SUCCESS;
}

static td_s32 mapi_vpss_check_ext_chn_attr(const hi_mapi_vpss_ext_chn_attr *ext_chn_attr)
{
    VPSS_CHECK_NULL_PTR_RET(ext_chn_attr);
    CHN_CHECK_PHY_HANDLE_RET(ext_chn_attr->bind_chn_hdl);
    if ((ext_chn_attr->width == 0) || (ext_chn_attr->height == 0)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "width[%u] or height[%u] is illegal.\n",
            ext_chn_attr->width, ext_chn_attr->height);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_set_ext_chn_attr(td_handle grp_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_ext_chn_attr *ext_chn_attr)
{
    td_s32 ret;
    td_u32 scale_w;
    td_u32 scale_h;
    td_u32 scale = 1;
    const td_handle ext_chn_hdl = chn_hdl - HI_MAPI_VPSS_PHY_CHN_MAX_NUM;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_EXT_HANDLE_RET(chn_hdl);
    ret = mapi_vpss_check_ext_chn_attr(ext_chn_attr);
    VPSS_CHECK_RET("check ext chn attr failed", ret);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].low_delay_info.enable
        = ext_chn_attr->low_delay_info.enable;
    g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].low_delay_info.line_cnt
        = ext_chn_attr->low_delay_info.line_cnt;
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    if (ext_chn_attr->width != 0 && ext_chn_attr->height != 0) {
        scale_w = g_vpss_ctx[grp_hdl].max_width / ext_chn_attr->width;
        scale_h = g_vpss_ctx[grp_hdl].max_height / ext_chn_attr->height;
        if (scale_w >= OT_VPSS_MAX_ZOOMOUT || scale_h >= OT_VPSS_MAX_ZOOMOUT) {
            scale += 1;
        }
    }

    ret = mapi_adapt_vpss_set_ext_chn_attr(grp_hdl, chn_hdl, ext_chn_attr,
        &g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].pool_id, scale);
    VPSS_CHECK_RET("set ext chn attr failed", ret);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].is_ext_chn_start = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_vpss_lock);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_get_ext_chn_attr(td_handle grp_hdl, td_handle chn_hdl,
    hi_mapi_vpss_ext_chn_attr *ext_chn_attr)
{
    td_s32 ret;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_EXT_HANDLE_RET(chn_hdl);
    VPSS_CHECK_NULL_PTR_RET(ext_chn_attr);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    ret = mapi_adapt_vpss_get_low_delay_attr(grp_hdl, chn_hdl, &ext_chn_attr->low_delay_info);
    VPSS_CHECK_RET("get low delay attr failed", ret);

    ret = mapi_adapt_vpss_get_ext_chn_attr(grp_hdl, chn_hdl, ext_chn_attr);
    VPSS_CHECK_RET("get ext chn attr failed", ret);
    return TD_SUCCESS;
}

static td_s32 mapi_vpss_start_phy_chn(td_handle grp_hdl, td_handle chn_hdl)
{
    td_s32 ret;
    if (g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].is_chn_start == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Chn %d has been start.\n", grp_hdl, chn_hdl);
        return TD_SUCCESS;
    }

    if (g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].low_delay_info.enable) {
        ret = mapi_adapt_vpss_set_low_delay_attr(grp_hdl, chn_hdl,
            &g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].low_delay_info);
        VPSS_CHECK_RET("set low delay attr failed", ret);
    }

    /* buffer wrap (卷绕): apply before enable_chn */
    if (g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].buf_wrap_attr.enable) {
        mapi_vpss_buf_wrap_info info = { .enable = TD_TRUE };
        mapi_comm_wrap_cfg wrap_cfg;

        ret = mapi_vpss_calc_buf_wrap(grp_hdl, &info);
        VPSS_CHECK_RET("calc buf wrap failed", ret);

        /* online: EARLY_END grp frame interrupt at grp_height/2 */
        mapi_comm_get_wrap_cfg(&wrap_cfg);
        if (wrap_cfg.all_online) {
            ret = mapi_adapt_vpss_set_wrap_grp_frame_interrupt(grp_hdl, g_vpss_ctx[grp_hdl].max_height);
            VPSS_CHECK_RET("set wrap grp frame interrupt failed", ret);
        }

        ret = mapi_adapt_vpss_set_chn_buf_wrap(grp_hdl, chn_hdl, &info);
        VPSS_CHECK_RET("set chn buf wrap failed", ret);
        MAPI_INFO_TRACE(HI_MAPI_MOD_VPSS, "chn0 wrap applied: buf_line=%u buf_size=%u\n",
            info.buf_line, info.buf_size);
    }

#if (defined __SS928V100__)
    if (g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].support_buffer_share == TD_TRUE) {
        ret = mapi_adapt_vpss_enable_buffer_share(grp_hdl, chn_hdl);
        VPSS_CHECK_RET("enable buffer share failed", ret);
    }
#endif

    ret = mapi_adapt_vpss_enable_chn(grp_hdl, chn_hdl);
    VPSS_CHECK_RET("enable chn failed", ret);
    g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].is_chn_start = TD_TRUE;
    return TD_SUCCESS;
}

static td_s32 mapi_vpss_start_ext_chn(td_handle grp_hdl, td_handle chn_hdl)
{
    td_s32 ret;
    const td_handle ext_chn_hdl = chn_hdl - HI_MAPI_VPSS_PHY_CHN_MAX_NUM;

    if (g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].is_phy_chn_start == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Chn %d has been start.\n", grp_hdl, chn_hdl);
        return TD_SUCCESS;
    }

    if (g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].low_delay_info.enable) {
        ret = mapi_adapt_vpss_set_low_delay_attr(grp_hdl, chn_hdl,
            &g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].low_delay_info);
        VPSS_CHECK_RET("set low delay attr failed", ret);
    }

    ret = mapi_adapt_vpss_enable_chn(grp_hdl, chn_hdl);
    VPSS_CHECK_RET("enable chn failed", ret);
    g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].is_phy_chn_start = TD_TRUE;
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_start_chn(td_handle grp_hdl, td_handle chn_hdl)
{
    td_s32 ret;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_HANDLE_RET(chn_hdl);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d uninitialized,Can not start Chn.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }

    if (chn_hdl < HI_MAPI_VPSS_PHY_CHN_MAX_NUM) {
        ret = mapi_vpss_start_phy_chn(grp_hdl, chn_hdl);
    } else {
        ret = mapi_vpss_start_ext_chn(grp_hdl, chn_hdl);
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);
    return ret;
}

td_s32 hi_mapi_vpss_stop_chn(td_handle grp_hdl, td_handle chn_hdl)
{
    td_s32 ret;
    td_handle ext_chn_hdl;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_HANDLE_RET(chn_hdl);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }

    if (chn_hdl < HI_MAPI_VPSS_PHY_CHN_MAX_NUM) {
        if (g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].is_chn_start == TD_FALSE) {
            MAPI_WARN_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Chn %d has been stop.\n", grp_hdl, chn_hdl);
            MAPI_MUTEX_UNLOCK(g_vpss_lock);
            return TD_SUCCESS;
        }
#if (defined __SS928V100__)
        if (g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].support_buffer_share == TD_TRUE) {
            ret = mapi_adapt_vpss_disable_buffer_share(grp_hdl, chn_hdl);
            VPSS_CHECK_RET_UNLOCK("disable buffer share failed", ret, g_vpss_lock);
        }
#endif
        ret = mapi_adapt_vpss_disable_chn(grp_hdl, chn_hdl,
            g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].pool_id);
        VPSS_CHECK_RET_UNLOCK("disable chn failed", ret, g_vpss_lock);
        g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].is_chn_start = TD_FALSE;

        ret = mapi_adapt_comm_destroy_vb_pool(g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].pool_id);
        VPSS_CHECK_RET_UNLOCK("destroy vb pool failed", ret, g_vpss_lock);
        g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].pool_id = OT_VB_INVALID_POOL_ID;
    } else {
        ext_chn_hdl = chn_hdl - HI_MAPI_VPSS_PHY_CHN_MAX_NUM;
        if (g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].is_phy_chn_start == TD_FALSE) {
            MAPI_WARN_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Chn %d has been stop.\n", grp_hdl, chn_hdl);
            MAPI_MUTEX_UNLOCK(g_vpss_lock);
            return TD_SUCCESS;
        }
        ret = mapi_adapt_vpss_disable_chn(grp_hdl, chn_hdl,
            g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].pool_id);
        VPSS_CHECK_RET_UNLOCK("disable chn failed", ret, g_vpss_lock);
        g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].is_phy_chn_start = TD_FALSE;

        ret = mapi_adapt_comm_destroy_vb_pool(g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].pool_id);
        VPSS_CHECK_RET_UNLOCK("destroy vb pool failed", ret, g_vpss_lock);
        g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[ext_chn_hdl].pool_id = OT_VB_INVALID_POOL_ID;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);
    return TD_SUCCESS;
}

td_s32 mapi_vpss_set_chn_crop(td_handle grp_hdl, td_handle chn_hdl, const td_void *cmd_attr, td_u32 len)
{
    td_s32 ret;
	
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_crop_info)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn crop cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    const hi_mapi_vpss_crop_info *crop_info = (const hi_mapi_vpss_crop_info *)cmd_attr;

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (chn_hdl < HI_MAPI_VPSS_PHY_CHN_MAX_NUM) {
        /* 1. vpss must be started */
        if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
            MAPI_MUTEX_UNLOCK(g_vpss_lock);
            return HI_MAPI_VPSS_EUNEXIST;
        }
    } else {
        const td_handle extChnHdl = chn_hdl - HI_MAPI_VPSS_PHY_CHN_MAX_NUM;
        if (g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[extChnHdl].is_ext_chn_start == TD_FALSE) {
            MAPI_WARN_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Chn %d extvport has been stop.\n", grp_hdl, chn_hdl);
            MAPI_MUTEX_UNLOCK(g_vpss_lock);
            return HI_MAPI_VPSS_EUNEXIST;
        }
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    ret = mapi_adapt_vpss_set_chn_crop(grp_hdl, chn_hdl, crop_info);
    VPSS_CHECK_RET("set vpss crop failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_vpss_get_chn_crop(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    td_s32 ret;

    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_crop_info)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn crop cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    hi_mapi_vpss_crop_info *crop_info = (hi_mapi_vpss_crop_info *)cmd_attr;

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (chn_hdl < HI_MAPI_VPSS_PHY_CHN_MAX_NUM) {
        /* 1. vpss must be started */
        if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
            MAPI_MUTEX_UNLOCK(g_vpss_lock);
            return HI_MAPI_VPSS_EUNEXIST;
        }
    } else {
        const td_handle extChnHdl = chn_hdl - HI_MAPI_VPSS_PHY_CHN_MAX_NUM;
        if (g_vpss_ctx[grp_hdl].vpss_ext_chn_attr[extChnHdl].is_ext_chn_start == TD_FALSE) {
            MAPI_WARN_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Chn %d extvport has been stop.\n", grp_hdl, chn_hdl);
            MAPI_MUTEX_UNLOCK(g_vpss_lock);
            return HI_MAPI_VPSS_EUNEXIST;
        }
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    ret = mapi_adapt_vpss_get_chn_crop(grp_hdl, chn_hdl, crop_info);
    VPSS_CHECK_RET("get vpss crop failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_vpss_set_grp_crop(td_handle grp_hdl, td_handle chn_hdl, const td_void *cmd_attr, td_u32 len)
{
    td_s32 ret;
    (td_void)chn_hdl;

    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_crop_info)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn grp crop cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    const hi_mapi_vpss_crop_info *crop_info = (const hi_mapi_vpss_crop_info *)cmd_attr;

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    ret = mapi_adapt_vpss_set_grp_crop(grp_hdl, crop_info);
    VPSS_CHECK_RET("set vpss grp crop failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_vpss_get_grp_crop(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    td_s32 ret;
    (td_void)chn_hdl;

    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_crop_info)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn grp crop cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    hi_mapi_vpss_crop_info *crop_info = (hi_mapi_vpss_crop_info *)cmd_attr;

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    ret = mapi_adapt_vpss_get_grp_crop(grp_hdl, crop_info);
    VPSS_CHECK_RET("get vpss grp crop failed", ret);

    return TD_SUCCESS;
}

static td_s32 mapi_vpss_set_chn_mirror(td_handle grp_hdl, td_handle chn_hdl, const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_mirror_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn mirror cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    const hi_mapi_vpss_mirror_attr *mirror_attr = (const hi_mapi_vpss_mirror_attr *)cmd_attr;
    return mapi_adapt_vpss_set_chn_mirror(grp_hdl, chn_hdl, mirror_attr->enable);
}

static td_s32 mapi_vpss_set_chn_flip(td_handle grp_hdl, td_handle chn_hdl, const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_flip_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn flip cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    const hi_mapi_vpss_flip_attr *flip_attr = (const hi_mapi_vpss_flip_attr *)cmd_attr;
    return mapi_adapt_vpss_set_chn_flip(grp_hdl, chn_hdl, flip_attr->enable);
}

static td_s32 mapi_vpss_set_chn_rotation(td_handle grp_hdl, td_handle chn_hdl,
    const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_rotation)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn rotation cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    const hi_mapi_rotation *rotation = (const hi_mapi_rotation *)cmd_attr;
    return mapi_adapt_vpss_set_chn_rotation(grp_hdl, chn_hdl, rotation);
}

static td_s32 mapi_vpss_set_chn_ldc(td_handle grp_hdl, td_handle chn_hdl,
    const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_ldc_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn ldc cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    if (g_vpss_ctx[grp_hdl].have_set_gdc_for_ldc_before == TD_FALSE) {
        hi_mapi_vpss_gdc_param param = {0};
        param.cell_size = HI_MAPI_VPSS_LUT_CELL_SIZE_16;
        param.in_width  = g_vpss_ctx[grp_hdl].max_width;
        param.in_height = g_vpss_ctx[grp_hdl].max_height;
        if (mapi_adapt_vpss_set_gdc(grp_hdl, chn_hdl, &param) == TD_SUCCESS) {
            g_vpss_ctx[grp_hdl].have_set_gdc_for_ldc_before = TD_TRUE;
        }
    }
    const hi_mapi_vpss_ldc_attr *ldc_attr = (const hi_mapi_vpss_ldc_attr *)cmd_attr;
    return mapi_adapt_vpss_set_chn_ldc(grp_hdl, chn_hdl, ldc_attr);
}

static td_s32 mapi_vpss_set_chn_ldcv2(td_handle grp_hdl, td_handle chn_hdl,
    const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_ldc_v2_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn ldcv2 cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return mapi_adapt_vpss_set_chn_ldcv2(grp_hdl, chn_hdl, (const hi_mapi_vpss_ldc_v2_attr *)cmd_attr);
}

static td_s32 mapi_vpss_set_chn_ldcv3(td_handle grp_hdl, td_handle chn_hdl,
    const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_ldc_v3_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn ldcv3 cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    if (g_vpss_ctx[grp_hdl].have_set_gdc_for_ldc_before == TD_FALSE) {
        hi_mapi_vpss_gdc_param param = {0};
        param.cell_size = HI_MAPI_VPSS_LUT_CELL_SIZE_16;
        param.in_width  = g_vpss_ctx[grp_hdl].max_width;
        param.in_height = g_vpss_ctx[grp_hdl].max_height;
        if (mapi_adapt_vpss_set_gdc(grp_hdl, chn_hdl, &param) == TD_SUCCESS) {
            g_vpss_ctx[grp_hdl].have_set_gdc_for_ldc_before = TD_TRUE;
        }
    }
    return mapi_adapt_vpss_set_chn_ldcv3(grp_hdl, chn_hdl, (const hi_mapi_vpss_ldc_v3_attr *)cmd_attr);
}

static td_s32 mapi_vpss_set_chn_ldcv4(td_handle grp_hdl, td_handle chn_hdl,
    const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_ldc_v4_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn ldcv4 cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return mapi_adapt_vpss_set_chn_ldcv4(grp_hdl, chn_hdl, (const hi_mapi_vpss_ldc_v4_attr *)cmd_attr);
}

static td_s32 mapi_vpss_set_chn_gdc(td_handle grp_hdl, td_handle chn_hdl,
    const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_gdc_param)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn gdc cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }

    td_s32 ret = mapi_adapt_vpss_set_gdc(grp_hdl, chn_hdl, (const hi_mapi_vpss_gdc_param *)cmd_attr);
    VPSS_CHECK_RET("set chn gdc failed", ret);
    g_vpss_ctx[grp_hdl].have_set_gdc_for_ldc_before = TD_TRUE;
    return ret;
}

td_s32 mapi_vpss_set_chn_depth(td_handle grp_hdl, td_handle chn_hdl, const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_depth_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn depth cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    const hi_mapi_vpss_depth_attr *depth_attr = (const hi_mapi_vpss_depth_attr *)cmd_attr;
    return mapi_adapt_vpss_set_chn_depth(grp_hdl, chn_hdl, depth_attr->depth);
}

/* Derive chn0 wrap buf_line/buf_size into info (internal), matches VB sizing. */
static td_s32 mapi_vpss_calc_buf_wrap(td_handle grp_hdl, mapi_vpss_buf_wrap_info *info)
{
    mapi_comm_wrap_cfg wrap_cfg;
    mapi_pic_buf_attr large_attr = {0};
    mapi_vpss_wrap_calc_param param = {0};
    const mapi_vpss_phy_chn_attr *chn0 = &g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[0];
    /* chn1 (small stream) may be unconfigured -> width/height 0, which the SDK accepts */
    const mapi_vpss_phy_chn_attr *chn1 =
        (HI_MAPI_VPSS_PHY_CHN_MAX_NUM > 1) ? &g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[1] : chn0;
    /* grp g is fed by VI dev g (1:1 for dual sensor); use that sensor's timing */
    td_u32 d = (grp_hdl < HI_MAPI_VCAP_MAX_DEV_NUM) ? (td_u32)grp_hdl : 0;

    mapi_comm_get_wrap_cfg(&wrap_cfg);
    mapi_adapt_comm_set_vpss_wrap_buf_attr(&large_attr, chn0->width, chn0->height);

    param.large_attr = &large_attr;
    param.small_size.width = chn1->width;
    param.small_size.height = chn1->height;
    param.full_lines_std = wrap_cfg.full_lines_std[d];
    param.frame_rate = wrap_cfg.frame_rate[d];
    param.all_online = wrap_cfg.all_online;
    return mapi_adapt_comm_get_vpss_wrap_buf(&param, &info->buf_line, &info->buf_size);
}

static td_s32 mapi_vpss_set_chn_buf_wrap(td_handle grp_hdl, td_handle chn_hdl, const td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_buf_wrap_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn buf wrap cmd_attr null or len:%u small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    const hi_mapi_vpss_buf_wrap_attr *wrap = (const hi_mapi_vpss_buf_wrap_attr *)cmd_attr;

    if (chn_hdl != 0) { /* phy chn0 only */
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "buf wrap only support phy chn0, chn:%d\n", chn_hdl);
        return HI_MAPI_VPSS_ENOT_SUPPORT;
    }
    if (wrap->enable && (g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].low_delay_info.enable ||
        g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].support_buffer_share)) { /* mutually exclusive */
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "buf wrap conflicts with low_delay/buffer_share on chn0\n");
        return HI_MAPI_VPSS_ENOT_SUPPORT;
    }
    if (g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].is_chn_start) { /* static: no runtime change */
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "buf wrap is a static attr, chn0 already started\n");
        return HI_MAPI_VPSS_ENOT_PERM;
    }

    /* only 'enable' is honored; sizes computed at apply time */
    g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl].buf_wrap_attr.enable = wrap->enable;
    return TD_SUCCESS;
}

static td_s32 mapi_vpss_get_chn_buf_wrap(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_buf_wrap_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn buf wrap len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    if (chn_hdl != 0) {
        return HI_MAPI_VPSS_ENOT_SUPPORT;
    }
    hi_mapi_vpss_buf_wrap_attr *wrap = (hi_mapi_vpss_buf_wrap_attr *)cmd_attr;
    const mapi_vpss_phy_chn_attr *ctx = &g_vpss_ctx[grp_hdl].vpss_phy_chn_attr[chn_hdl];

    /* after start, read the authoritative applied state from the SDK (only 'enable' is exposed) */
    if (ctx->is_chn_start && ctx->buf_wrap_attr.enable) {
        mapi_vpss_buf_wrap_info info = {0};
        /* SDK read is authoritative; if it fails, fall back to the intended (ctx) state */
        if (mapi_adapt_vpss_get_chn_buf_wrap(grp_hdl, chn_hdl, &info) == TD_SUCCESS) {
            wrap->enable = info.enable;
            return TD_SUCCESS;
        }
    }

    wrap->enable = ctx->buf_wrap_attr.enable;
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_set_param(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_cmd command,
    const td_void *cmd_attr, td_u32 len)
{
    td_s32 ret = HI_MAPI_VPSS_ENOT_SUPPORT;
    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_PHY_HANDLE_RET(chn_hdl);
    VPSS_CHECK_NULL_PTR_RET(cmd_attr);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    const set_cmd_ex_map cmd_map[] = {
        {HI_MAPI_VPSS_CMD_GRP_CROP, mapi_vpss_set_grp_crop},
        {HI_MAPI_VPSS_CMD_CHN_MIRROR, mapi_vpss_set_chn_mirror},
        {HI_MAPI_VPSS_CMD_CHN_FLIP, mapi_vpss_set_chn_flip},
        {HI_MAPI_VPSS_CMD_CHN_ROTATE, mapi_vpss_set_chn_rotation},
        {HI_MAPI_VPSS_CMD_CHN_LDC, mapi_vpss_set_chn_ldc},
        {HI_MAPI_VPSS_CMD_CHN_LDCV2, mapi_vpss_set_chn_ldcv2},
        {HI_MAPI_VPSS_CMD_CHN_LDCV3, mapi_vpss_set_chn_ldcv3},
        {HI_MAPI_VPSS_CMD_CHN_LDCV4, mapi_vpss_set_chn_ldcv4},
        {HI_MAPI_VPSS_CMD_CHN_GDC, mapi_vpss_set_chn_gdc},
        {HI_MAPI_VPSS_CMD_CHN_CROP, mapi_vpss_set_chn_crop},
        {HI_MAPI_VPSS_CMD_CHN_DEPTH, mapi_vpss_set_chn_depth}
    };
    td_u32 size = (td_u32)(sizeof(cmd_map) / sizeof(cmd_map[0]));
    for (td_u32 i = 0; i < size; i++) {
        if (command == cmd_map[i].id && cmd_map[i].process != NULL) {
            ret = cmd_map[i].process(grp_hdl, chn_hdl, cmd_attr, len);
            break;
        }
    }
    if (ret == HI_MAPI_VPSS_ENOT_SUPPORT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Do not support cmd %d.\n", command);
    }
    return ret;
}

static td_s32 mapi_vpss_get_chn_mirror(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_mirror_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn mirror len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    hi_mapi_vpss_mirror_attr *mirror_attr = (hi_mapi_vpss_mirror_attr *)cmd_attr;
    return mapi_adapt_vpss_get_chn_mirror(grp_hdl, chn_hdl, &mirror_attr->enable);
}

static td_s32 mapi_vpss_get_chn_flip(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_flip_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn flip len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    hi_mapi_vpss_flip_attr *flip_attr = (hi_mapi_vpss_flip_attr *)cmd_attr;
    return mapi_adapt_vpss_get_chn_flip(grp_hdl, chn_hdl, &flip_attr->enable);
}

static td_s32 mapi_vpss_get_chn_rotation(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_rotation)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn rotation len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return mapi_adapt_vpss_get_chn_rotation(grp_hdl, chn_hdl, (hi_mapi_rotation *)cmd_attr);
}

static td_s32 mapi_vpss_get_chn_ldc(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_ldc_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn ldc len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return mapi_adapt_vpss_get_chn_ldc(grp_hdl, chn_hdl, (hi_mapi_vpss_ldc_attr *)cmd_attr);
}

static td_s32 mapi_vpss_get_chn_ldcv2(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_ldc_v2_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn ldcv2 len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return mapi_adapt_vpss_get_chn_ldcv2(grp_hdl, chn_hdl, (hi_mapi_vpss_ldc_v2_attr *)cmd_attr);
}

static td_s32 mapi_vpss_get_chn_ldcv3(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_ldc_v3_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn ldcv3 len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return mapi_adapt_vpss_get_chn_ldcv3(grp_hdl, chn_hdl, (hi_mapi_vpss_ldc_v3_attr *)cmd_attr);
}

static td_s32 mapi_vpss_get_chn_ldcv4(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_ldc_v4_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn ldcv4 len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return mapi_adapt_vpss_get_chn_ldcv4(grp_hdl, chn_hdl, (hi_mapi_vpss_ldc_v4_attr *)cmd_attr);
}

static td_s32 mapi_vpss_get_chn_gdc(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_gdc_param)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn gdc len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    return mapi_adapt_vpss_get_gdc(grp_hdl, chn_hdl, (hi_mapi_vpss_gdc_param *)cmd_attr);
}

td_s32 mapi_vpss_get_chn_depth(td_handle grp_hdl, td_handle chn_hdl, td_void *cmd_attr, td_u32 len)
{
    if (cmd_attr == TD_NULL || len < sizeof(hi_mapi_vpss_depth_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "chn depth len:%x is small\n", len);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }
    hi_mapi_vpss_depth_attr *depth_attr = (hi_mapi_vpss_depth_attr *)cmd_attr;
    return mapi_adapt_vpss_get_chn_depth(grp_hdl, chn_hdl, &depth_attr->depth);
}

td_s32 hi_mapi_vpss_get_param(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_cmd command,
    td_void *cmd_attr, td_u32 len)
{
    td_s32 ret = HI_MAPI_VPSS_ENOT_SUPPORT;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_PHY_HANDLE_RET(chn_hdl);
    VPSS_CHECK_NULL_PTR_RET(cmd_attr);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    const get_cmd_ex_map cmd_map[] = {
        {HI_MAPI_VPSS_CMD_GRP_CROP, mapi_vpss_get_grp_crop},
        {HI_MAPI_VPSS_CMD_CHN_MIRROR, mapi_vpss_get_chn_mirror},
        {HI_MAPI_VPSS_CMD_CHN_FLIP, mapi_vpss_get_chn_flip},
        {HI_MAPI_VPSS_CMD_CHN_ROTATE, mapi_vpss_get_chn_rotation},
        {HI_MAPI_VPSS_CMD_CHN_LDC, mapi_vpss_get_chn_ldc},
        {HI_MAPI_VPSS_CMD_CHN_LDCV2, mapi_vpss_get_chn_ldcv2},
        {HI_MAPI_VPSS_CMD_CHN_LDCV3, mapi_vpss_get_chn_ldcv3},
        {HI_MAPI_VPSS_CMD_CHN_LDCV4, mapi_vpss_get_chn_ldcv4},
        {HI_MAPI_VPSS_CMD_CHN_GDC, mapi_vpss_get_chn_gdc},
        {HI_MAPI_VPSS_CMD_CHN_CROP, mapi_vpss_get_chn_crop},
        {HI_MAPI_VPSS_CMD_CHN_DEPTH, mapi_vpss_get_chn_depth}
    };
    td_u32 size = (td_u32)(sizeof(cmd_map) / sizeof(cmd_map[0]));
    for (td_u32 i = 0; i < size; i++) {
        if (command == cmd_map[i].id && cmd_map[i].process != NULL) {
            ret = cmd_map[i].process(grp_hdl, chn_hdl, cmd_attr, len);
            break;
        }
    }
    if (ret == HI_MAPI_VPSS_ENOT_SUPPORT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Do not support cmd %d.\n", command);
    }
    return ret;
}

td_s32 hi_mapi_vpss_set_config(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_config_cmd command,
    const td_void *cmd_attr, td_u32 len)
{
    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_PHY_HANDLE_RET(chn_hdl);
    VPSS_CHECK_NULL_PTR_RET(cmd_attr);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    switch (command) {
        case HI_MAPI_VPSS_CONFIG_CMD_CHN_BUF_WRAP:
            return mapi_vpss_set_chn_buf_wrap(grp_hdl, chn_hdl, cmd_attr, len);
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Do not support config cmd %d.\n", command);
            return HI_MAPI_VPSS_ENOT_SUPPORT;
    }
}

td_s32 hi_mapi_vpss_get_config(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_config_cmd command,
    td_void *cmd_attr, td_u32 len)
{
    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_PHY_HANDLE_RET(chn_hdl);
    VPSS_CHECK_NULL_PTR_RET(cmd_attr);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    switch (command) {
        case HI_MAPI_VPSS_CONFIG_CMD_CHN_BUF_WRAP:
            return mapi_vpss_get_chn_buf_wrap(grp_hdl, chn_hdl, cmd_attr, len);
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Do not support config cmd %d.\n", command);
            return HI_MAPI_VPSS_ENOT_SUPPORT;
    }
}

td_s32 mapi_vpss_get_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    hi_mapi_frame_data *yuv_frame_data, td_s32 milli_sec)
{
    td_s32 ret;

    VPSS_CHECK_NULL_PTR_RET(yuv_frame_data);

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_HANDLE_RET(chn_hdl);

    ret = mapi_adapt_vpss_get_chn_frame(grp_hdl, chn_hdl, yuv_frame_data, milli_sec);
    VPSS_CHECK_RET("get chn frame failed", ret);
    return TD_SUCCESS;
}

td_s32 mapi_vpss_release_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    const hi_mapi_frame_data *yuv_frame_data)
{
    td_s32 ret;

    VPSS_CHECK_NULL_PTR_RET(yuv_frame_data);

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    CHN_CHECK_HANDLE_RET(chn_hdl);

    ret = mapi_adapt_vpss_release_chn_frame(grp_hdl, chn_hdl, yuv_frame_data);
    VPSS_CHECK_RET("release chn frame failed", ret);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_get_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    hi_mapi_frame_data *yuv_frame_data)
{
    td_s32 ret;

    ret = mapi_vpss_get_chn_frame(grp_hdl, chn_hdl, yuv_frame_data, MAPI_VPSS_DATA_PROC_TIMEOUTS_MS);
    VPSS_CHECK_RET("get chn frame failed", ret);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_release_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    const hi_mapi_frame_data *yuv_frame_data)
{
    td_s32 ret;

    ret = mapi_vpss_release_chn_frame(grp_hdl, chn_hdl, yuv_frame_data);
    VPSS_CHECK_RET("release chn frame failed", ret);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vpss_send_frame(td_handle grp_hdl, const hi_mapi_frame_data *framedata)
{
    td_s32 ret;

    VPSS_CHECK_HANDLE_RET(grp_hdl);
    VPSS_CHECK_NULL_PTR_RET(framedata);

    MAPI_MUTEX_LOCK(g_vpss_lock);
    if (g_vpss_ctx[grp_hdl].is_vpss_start != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Vpss %d Uninitialized.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EUNEXIST;
    }

    if (framedata->frame_data_type != HI_MAPI_FRAME_DATA_TYPE_YUV) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "vpss(%d) sendFrame is not YUV.\n", grp_hdl);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return HI_MAPI_VPSS_EILLEGAL_PARAM;
    }

    td_u32 time_ref = g_vpss_ctx[grp_hdl].frm_time_ref;
    ret = mapi_adapt_vpss_send_frame(grp_hdl, framedata, time_ref);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "send frame error ret:%x\n", ret);
        MAPI_MUTEX_UNLOCK(g_vpss_lock);
        return ret;
    }
    g_vpss_ctx[grp_hdl].frm_time_ref =
        g_vpss_ctx[grp_hdl].frm_time_ref + 2; /* 2: Image frame sequence number, Add 2 each time */
    MAPI_MUTEX_UNLOCK(g_vpss_lock);

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
