/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/prctl.h>
#include "hi_mapi_comm_define.h"
#include "hi_mw_log.h"
#include "mapi_comm_inner.h"
#include "mapi_vpss_inner.h"
#include "mapi_vcap_adapt.h"
#include "mapi_vpss_adapt.h"
#include "hi_mapi_vpss_define.h"
#include "hi_mapi_vcap_adapt_define.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#ifdef SUPPORT_IVE
static mapi_vpss_ive_param g_ive_param[HI_MAPI_VPSS_MAX_NUM] = {0};

static td_s32 mapi_ive_deal_yvyu_frame(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, hi_mapi_yuv_data_seq vi_yuv_seq)
{
    td_handle ive_hdl;
    td_s32 ret;

    /*
      ive dma only support 1920*1080 byte one time at most, so we need to separate it into two parts.
      we deal with left part for y pixel first
    */
    ret = mapi_adapt_vpss_proc_ive_left_y_pixel(src_frame, dst_frame, &ive_hdl, vi_yuv_seq);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "proc ive left y pixel failed, ret:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }

    /* deal with right part for y pixel */
    ret = mapi_adapt_vpss_proc_ive_right_y_pixel(src_frame, dst_frame, &ive_hdl, vi_yuv_seq);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "proc ive right y pixel failed, ret:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }

    /* deal with left part for vu pixel */
    ret = mapi_adapt_vpss_proc_ive_left_vu_pixel(src_frame, dst_frame, &ive_hdl, vi_yuv_seq);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "proc ive left vu pixel failed, ret:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }

     /*
       deal with right part for vu pixel
       caution: be sure the address of w+1 must be valid , or it will ocuur access exception
     */
    ret = mapi_adapt_vpss_proc_ive_right_vu_pixel(src_frame, dst_frame, &ive_hdl, vi_yuv_seq);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "proc ive right vu pixel failed, ret:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }

    ret = mapi_adapt_vpss_query_ive_status(ive_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "proc ive right vu pixel failed, ret:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }

    return ret;
}

static td_s32 mapi_ive_deal_frame_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, hi_mapi_yuv_data_seq vi_yuv_seq)
{
    if ((src_frame->v_frame.width > 1920) ||  /* 1920: video frame width */
        (src_frame->v_frame.height > 1080)) { /* 1080: video frame height */
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "not support this resolution, width:%d, height:%d \n",
            src_frame->v_frame.width, src_frame->v_frame.height);
        return TD_FAILURE;
    }

    if (vi_yuv_seq == HI_MAPI_DATA_SEQ_YVYU || vi_yuv_seq == HI_MAPI_DATA_SEQ_VYUY ||
        vi_yuv_seq == HI_MAPI_DATA_SEQ_UYVY) {
        return mapi_ive_deal_yvyu_frame(src_frame, dst_frame, vi_yuv_seq);
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "not support this seq:%d ", vi_yuv_seq);
        return TD_FAILURE;
    }
}

/* it is using ive module to transform yuv422 package to yuv422 semi-planar */
static td_void *mapi_ive_data_proc_thread(td_void *param)
{
    mapi_vpss_ive_param *ive_param = (mapi_vpss_ive_param *)param;
    td_char thread_name[HI_MAPI_PTHREAD_NAME_LEN] = {0};

    td_s32 ret = snprintf_s(thread_name, HI_MAPI_PTHREAD_NAME_LEN, HI_MAPI_PTHREAD_NAME_LEN - 1,
        "IveData_%u", ive_param->vpss_hdl);
    if (ret == TD_FAILURE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "snprintf_s fail and return:[%#x]!!\n", ret);
        return TD_NULL;
    }
    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)thread_name, 0, 0, 0);

    hi_mapi_dump_attr dump_attr = { .enable = TD_TRUE, .depth = 2, .dump_type = HI_MAPI_VCAP_DUMP_TYPE_RAW };
    ret = mapi_adapt_vcap_set_pipe_dump_attr(ive_param->vcap_pipe_hdl, &dump_attr);
    VPSS_CHECK_PTHREAD_RET(ret, "set dump attr fail vb failed");

    mapi_adapt_video_frame_info dst_frame_data;
    ret = mapi_adapt_vpss_get_ive_vb(ive_param, &dst_frame_data);
    VPSS_CHECK_PTHREAD_RET(ret, "create vb failed");

    while (ive_param->is_thread_start) {
        mapi_adapt_video_frame_info src_frame_data = {0};

        ret = mapi_adapt_vpss_get_ive_pipe_raw(ive_param, &src_frame_data);
        if (ret != TD_SUCCESS) {
            if (ret == OT_ERR_VI_BUF_EMPTY) {
                continue;
            } else {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "get ive frame fail,ret:[%#x]!!\n", ret);
                return TD_NULL;
            }
        }
        dst_frame_data.mod_id = src_frame_data.mod_id;
        dst_frame_data.v_frame.field = src_frame_data.v_frame.field;
        dst_frame_data.v_frame.time_ref = src_frame_data.v_frame.time_ref;
        dst_frame_data.v_frame.pts = src_frame_data.v_frame.pts;
        dst_frame_data.v_frame.frame_flag = src_frame_data.v_frame.frame_flag;
        dst_frame_data.v_frame.width = src_frame_data.v_frame.width;
        dst_frame_data.v_frame.height = src_frame_data.v_frame.height;
        dst_frame_data.v_frame.pixel_format = (ive_param->vi_yuv_seq == HI_MAPI_DATA_SEQ_UYVY) ?
            HI_MAPI_PIXEL_FORMAT_YUV_SEMIPLANAR_422 : HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_422;
        dst_frame_data.v_frame.video_format = src_frame_data.v_frame.video_format;

        ret = mapi_ive_deal_frame_pixel(&src_frame_data, &dst_frame_data, ive_param->vi_yuv_seq);
        CHECK_MAPI_PRINT(HI_MAPI_MOD_VPSS, "deal ive frame", ret);

        if (ret == TD_SUCCESS) {
            ret = mapi_adapt_vpss_send_ive_frame(ive_param->vpss_hdl, 0, &dst_frame_data); /* default to chn 0 */
            CHECK_MAPI_PRINT(HI_MAPI_MOD_VPSS, "send ive frame", ret);
        }

        ret = mapi_adapt_vpss_release_ive_pipe_raw(ive_param, &src_frame_data);
        VPSS_CHECK_PTHREAD_RET(ret, "release ive frame");
    }

    return TD_NULL;
}

td_void mapi_vpss_init_ive(td_handle vpss_hdl)
{
    g_ive_param[vpss_hdl].is_thread_start = TD_FALSE;
    return;
}

td_s32 mapi_vpss_start_recv_yuv(td_handle vpss_hdl, td_handle vcap_pipe_hdl, hi_mapi_yuv_data_seq vi_yuv_seq)
{
    td_s32 ret;
    if (vi_yuv_seq != HI_MAPI_DATA_SEQ_VYUY && vi_yuv_seq != HI_MAPI_DATA_SEQ_YVYU &&
        vi_yuv_seq != HI_MAPI_DATA_SEQ_UYVY) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "ive not support this yuv seq:%d.\n", vi_yuv_seq);
        return HI_MAPI_VPSS_ENOT_SUPPORT;
    }

    if (g_ive_param[vpss_hdl].is_thread_start == TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "ive handling thread has been started\n");
        return TD_SUCCESS;
    }

    g_ive_param[vpss_hdl].is_thread_start = TD_TRUE;
    g_ive_param[vpss_hdl].vcap_pipe_hdl = vcap_pipe_hdl;
    g_ive_param[vpss_hdl].vpss_hdl = vpss_hdl;
    g_ive_param[vpss_hdl].vi_yuv_seq = vi_yuv_seq;

    ret = pthread_create(&g_ive_param[vpss_hdl].thread_id, 0, mapi_ive_data_proc_thread,
        (td_void *)&g_ive_param[vpss_hdl]);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "create ive handling thread failed!\n");
        g_ive_param[vpss_hdl].is_thread_start = TD_FALSE;
        return HI_MAPI_VPSS_ENOT_PERM;
    }

    return TD_SUCCESS;
}

td_s32 mapi_vpss_stop_recv_yuv(td_handle vpss_hdl)
{
    if (g_ive_param[vpss_hdl].is_thread_start == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, " ive handling thread has stoped\n");
        return TD_SUCCESS;
    }

    g_ive_param[vpss_hdl].is_thread_start = TD_FALSE;
    td_s32 ret = TD_SUCCESS;
    if (pthread_join(g_ive_param[vpss_hdl].thread_id, TD_NULL) != TD_SUCCESS) {
        ret = TD_FAILURE;
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "ive handling thread join failed!\n");
    }

    if (mapi_adapt_vpss_release_ive_vb(&g_ive_param[vpss_hdl]) != TD_SUCCESS) {
        ret = TD_FAILURE;
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "release ive vb failed!");
    }

    hi_mapi_dump_attr dump_attr;
    dump_attr.enable = TD_FALSE;
    dump_attr.depth = 0;
    dump_attr.dump_type = HI_MAPI_VCAP_DUMP_TYPE_RAW;
    td_handle vcap_pipe_hdl = g_ive_param[vpss_hdl].vcap_pipe_hdl;
    if (mapi_adapt_vcap_set_pipe_dump_attr(vcap_pipe_hdl, &dump_attr) != TD_SUCCESS) {
        ret = TD_FAILURE;
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "set dump attr fail !!\n");
    }

    return ret;
}

#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
