/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_VENC_ARCH_H__
#define __MAPI_VENC_ARCH_H__

#include "hi_mapi_comm_define.h"
#include "hi_mapi_venc_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 hal_mapi_venc_config_h265_car_trans(td_handle venc_hdl, hi_mapi_payload_type payload_type,
    hi_mapi_venc_scene_mode scene_mode);
td_bool hal_mapi_venc_get_rcn_ref_share_buf_mode(td_void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_VENC_ARCH_H__ */
