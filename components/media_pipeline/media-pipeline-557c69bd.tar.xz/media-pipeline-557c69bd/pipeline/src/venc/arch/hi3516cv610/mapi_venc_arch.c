/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_venc_arch.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_venc_define.h"
#include "mapi_venc_inner.h"
#include "mapi_venc_adapt.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

td_s32 hal_mapi_venc_config_h265_car_trans(td_handle venc_hdl, hi_mapi_payload_type payload_type,
    hi_mapi_venc_scene_mode scene_mode)
{
    if ((payload_type == HI_MAPI_PAYLOAD_TYPE_H265) && (scene_mode == HI_MAPI_VENC_SCENE_MODE_CAR)) {
        return mapi_adapt_venc_set_h265_trans(venc_hdl);
    }

    return TD_SUCCESS;
}

td_bool hal_mapi_venc_get_rcn_ref_share_buf_mode(td_void)
{
    return TD_FALSE;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
