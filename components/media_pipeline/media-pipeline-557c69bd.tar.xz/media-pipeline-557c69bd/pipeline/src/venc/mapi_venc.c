/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <sys/time.h>
#include <pthread.h>

#include "hi_mapi_comm_define.h"
#include "hi_mapi_venc_define.h"
#include "hi_mapi_venc.h"
#include "mapi_venc_inner.h"
#include "mapi_comm_inner.h"
#include "mapi_venc_os.h"
#include "mapi_venc_arch.h"
#include "mapi_venc_adapt.h"
#include "securec.h"
#include "ot_osal_user.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

static mapi_venc_context g_venc_ctx;
td_bool g_liteBootStarted[HI_MAPI_VENC_MAX_CHN_NUM] = {
    [0 ... (HI_MAPI_VENC_MAX_CHN_NUM - 1)] = TD_FALSE
};

static pthread_mutex_t g_venc_func_lock[HI_MAPI_VENC_MAX_CHN_NUM] = {
    [0 ... (HI_MAPI_VENC_MAX_CHN_NUM - 1)] = PTHREAD_MUTEX_INITIALIZER
};


td_bool mapi_venc_get_lite_boot_status(td_handle venc_hdl)
{
    td_bool isStatus;
    isStatus = g_liteBootStarted[venc_hdl];
    return isStatus;
}

td_s32 mapi_venc_get_start_frame_cnt(td_handle venc_hdl)
{
    return g_venc_ctx.venc_chn_cfg[venc_hdl].start_frame_count;
}

td_bool mapi_venc_is_register_callback(td_handle venc_hdl)
{
    td_u32 i;

    for (i = 0; i < HI_MAPI_VENC_CALLBACK_MAX_NUM; i++) {
        if (g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].proc_data_cb != TD_NULL) {
            return TD_TRUE;
        }
    }

    return TD_FALSE;
}


static td_s32 mapi_venc_config_thd_name(td_handle venc_hdl)
{
    td_char threadName[MAPI_VENC_THREAD_NAME_MAX_LEN] = {0};

    td_s32 ret = snprintf_s(threadName, MAPI_VENC_THREAD_NAME_MAX_LEN,
        MAPI_VENC_THREAD_NAME_MAX_LEN - 1, "pTVData_Chn%u", venc_hdl);
    if (ret == TD_FAILURE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "snprintf_s fail and return:[%#x]!!\n", ret);
        return TD_FAILURE;
    }
    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)threadName, 0, 0, 0);

    return TD_SUCCESS;
}

static td_void mapi_venc_proc_video_stream(td_handle venc_hdl, struct timeval *timeoutVal)
{
    OSAL_DEV_FD_SET readFds;
    mapi_venc_chn_config *gobalVencChnCfg = &g_venc_ctx.venc_chn_cfg[venc_hdl];
    mapi_venc_proc_data_thread *gobal_prc_thd = &g_venc_ctx.proc_data_thread[venc_hdl];

    MAPI_MUTEX_LOCK(gobalVencChnCfg->venc_chn_lock);
    OSAL_FD_ZERO(&readFds);
    td_s32 vencFd = mapi_adapt_venc_get_fd(gobalVencChnCfg->venc_handle);
    OSAL_FD_SET(vencFd, &readFds);
    MAPI_MUTEX_UNLOCK(gobalVencChnCfg->venc_chn_lock);
    timeoutVal->tv_sec = 0;
    timeoutVal->tv_usec = VENC_GET_FRAME_THREAD_SLEECT_TIMEOUT_USEC;

    td_s32 ret = OSAL_SELECT(vencFd + 1, &readFds, NULL, NULL, timeoutVal);
    MAPI_MUTEX_LOCK(gobalVencChnCfg->venc_chn_lock);
    if (ret < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "OSAL_SELECT fail,Ret:%x\n", ret);
        MAPI_MUTEX_UNLOCK(gobalVencChnCfg->venc_chn_lock);
        /* Low power mode, Let out the cpu, scheduling the other threads. */
        mapi_comm_cond_time_wait(&gobal_prc_thd->proc_data_thd_cond, &gobal_prc_thd->proc_data_thd_lock,
            VENC_GET_FRAME_THREAD_USLEEP_TIME);
    } else if (ret == 0) {
        /* if no new data, update the activated channel and release memory */
        mapi_venc_clear_datafifo_data(venc_hdl);
    } else {
        if ((gobalVencChnCfg->started) && (OSAL_FD_ISSET(vencFd, &readFds))) {
            ret = mapi_venc_get_stream(gobalVencChnCfg->venc_handle, gobalVencChnCfg);
            if (ret != TD_SUCCESS) {
                MAPI_INFO_TRACE(HI_MAPI_MOD_VENC, "get vsteam venc_hdl[%d] fail\n", venc_hdl);
                MAPI_MUTEX_UNLOCK(gobalVencChnCfg->venc_chn_lock);
                /* Low power mode, Let out the cpu, scheduling the other threads. */
                mapi_comm_cond_time_wait(&gobal_prc_thd->proc_data_thd_cond, &gobal_prc_thd->proc_data_thd_lock,
                    VENC_GET_FRAME_THREAD_USLEEP_TIME);
                return;
            }
        } else {
            /* Low power mode, Let out the cpu, scheduling the other threads. */
            MAPI_MUTEX_UNLOCK(gobalVencChnCfg->venc_chn_lock);
            mapi_comm_cond_time_wait(&gobal_prc_thd->proc_data_thd_cond, &gobal_prc_thd->proc_data_thd_lock,
                VENC_GET_FRAME_THREAD_USLEEP_TIME);
            return;
        }
    }
    MAPI_MUTEX_UNLOCK(gobalVencChnCfg->venc_chn_lock);

    return;
}

static td_void *ProcVDataThread(td_void *arg)
{
    td_handle venc_hdl = *(td_handle *)arg;
    struct timeval timeoutVal;
    timeoutVal.tv_sec = 0;
    timeoutVal.tv_usec = VENC_GET_FRAME_THREAD_SLEECT_TIMEOUT_USEC;

    if (mapi_venc_config_thd_name(venc_hdl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "set thread name fail\n");
        return TD_NULL;
    }

    MAPI_MUTEX_LOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);
    while (g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_start_flg == TD_TRUE) {
        MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
        mapi_venc_chn_config *gobalVencChnCfg = &g_venc_ctx.venc_chn_cfg[venc_hdl];
        td_bool isVencChnStart = gobalVencChnCfg->started;
        MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
        if (isVencChnStart == TD_TRUE) {
            mapi_venc_proc_video_stream(venc_hdl, &timeoutVal);
        } else {
            mapi_venc_proc_data_thread *gobal_prc_thd = &g_venc_ctx.proc_data_thread[venc_hdl];
            /* Low power mode, Let out the cpu, scheduling the other threads. */
            mapi_comm_cond_time_wait(&gobal_prc_thd->proc_data_thd_cond, &gobal_prc_thd->proc_data_thd_lock,
                VENC_GET_FRAME_THREAD_USLEEP_TIME);
        }
    }
    MAPI_MUTEX_UNLOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);

    return TD_NULL;
}

static td_s32 mapi_venc_init_data_thread(td_handle venc_hdl)
{
    td_s32 ret;

    /* create server stream processing thread */
    MAPI_MUTEX_INIT_LOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);
    pthread_condattr_t condAttr;
    (td_void)pthread_condattr_init(&condAttr);
    (td_void)pthread_condattr_setclock(&condAttr, CLOCK_MONOTONIC);
    (td_void)pthread_cond_init(&g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_cond, &condAttr);
    (td_void)pthread_condattr_destroy(&condAttr);

    g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thread_id = (pthread_t)-1;
    g_venc_ctx.venc_chn_cfg[venc_hdl].venc_handle = venc_hdl;

    /* start thread and set chn state */
    MAPI_MUTEX_LOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);
    g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_start_flg = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);

    ret = pthread_create(&g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thread_id, TD_NULL, ProcVDataThread,
        &g_venc_ctx.venc_chn_cfg[venc_hdl].venc_handle);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "create ProcVDataThread fail,ret:%x\n", ret);

        MAPI_MUTEX_LOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);
        g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_start_flg = TD_FALSE;
        MAPI_MUTEX_UNLOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);

        MAPI_MUTEX_DESTROY(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);
        pthread_cond_destroy(&g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_cond);
        return ret;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_venc_deinit_data_thread(td_handle venc_hdl)
{
    td_s32 ret;

    MAPI_MUTEX_LOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);
    g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_start_flg = TD_FALSE;
    pthread_cond_signal(&g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_cond);
    MAPI_MUTEX_UNLOCK(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);

    if (g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thread_id != (pthread_t)-1) {
        ret = pthread_join(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thread_id, TD_NULL);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "pthread_join fail,ret:%x\n", ret);
            pthread_cancel(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thread_id);
            ret = pthread_join(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thread_id, TD_NULL);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "pthread_cancel and join fail, ret:%x\n", ret);
                MAPI_MUTEX_DESTROY(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);
                pthread_cond_destroy(&g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_cond);
                return ret;
            }
        }
    }

    g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thread_id = (pthread_t)-1;
    MAPI_MUTEX_DESTROY(g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_lock);
    pthread_cond_destroy(&g_venc_ctx.proc_data_thread[venc_hdl].proc_data_thd_cond);

    return TD_SUCCESS;
}

static td_s32 mapi_venc_check_attr(const hi_mapi_venc_attr *venc_attr)
{
    switch (venc_attr->payload_type_attr.type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            if (venc_attr->payload_type_attr.profile > MAPI_VENC_MAX_PROFILE_H264) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr profile:%d error\n", venc_attr->payload_type_attr.profile);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }
            break;

        case HI_MAPI_PAYLOAD_TYPE_H265:
            if (venc_attr->payload_type_attr.profile > MAPI_VENC_MAX_PROFILE_H265) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr profile:%d error\n", venc_attr->payload_type_attr.profile);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }
            break;

#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            break;
#endif

        case HI_MAPI_PAYLOAD_TYPE_MJPEG:
            if (venc_attr->payload_type_attr.profile > MAPI_VENC_MAX_PROFILE_MJPEG) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr profile:%d error\n", venc_attr->payload_type_attr.profile);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }
            break;

        case HI_MAPI_PAYLOAD_TYPE_JPEG:
            if (venc_attr->payload_type_attr.jpeg_attr.mpf_attr.large_thumb_nail_num > HI_MAPI_VENC_MPF_MAX_CNT) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr large_thumb_nail_num:%d error\n",
                    venc_attr->payload_type_attr.jpeg_attr.mpf_attr.large_thumb_nail_num);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            if (venc_attr->payload_type_attr.profile > MAPI_VENC_MAX_PROFILE_JPEG) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr profile:%d error\n", venc_attr->payload_type_attr.profile);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }
            break;

        default: {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr type:%d unsupport\n", venc_attr->payload_type_attr.type);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
        }
    }

    return TD_SUCCESS;
}

td_s32 mapi_venc_init(const hi_mapi_sys_venc_mode_param *venc_mod_para)
{
    td_u32 i;
    td_s32 ret;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_mod_para);

    if (g_venc_ctx.venc_inited == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VENC, "VENC has been pre inited\n");
        return TD_SUCCESS;
    }

    ret = memset_s(&g_venc_ctx, sizeof(mapi_venc_context), 0, sizeof(mapi_venc_context));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    for (i = 0; i < HI_MAPI_VENC_MAX_CHN_NUM; i++) {
        /* Initialize the channel lock */
        MAPI_MUTEX_INIT_LOCK(g_venc_ctx.venc_chn_cfg[i].venc_chn_lock);

        MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[i].venc_chn_lock);
        g_venc_ctx.venc_chn_cfg[i].venc_handle = i;
        g_venc_ctx.venc_chn_cfg[i].start_frame_count = HI_MAPI_VENC_LIMITLESS_FRAME_COUNT;
        MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[i].venc_chn_lock);
    }

    mapi_venc_os_init();

    /* 各协议先 get 取回全量 mod_param，仅覆盖 init 关心的字段后 set，避免改动 SDK 其它默认值 */
    mapi_adapt_venc_mod_param mod_param;

#ifdef SUPPORT_H264
    ret = mapi_adapt_venc_get_h264_mod_param(&mod_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_get_h264_mod_param", ret);
    mod_param.one_stream_buf = 1;
    mod_param.low_power_mode = venc_mod_para->h264e_low_power_mode;
    ret = mapi_adapt_venc_set_h264_mod_param(&mod_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_h264_mod_param", ret);
#endif

#ifdef SUPPORT_H265
    ret = mapi_adapt_venc_get_h265_mod_param(&mod_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_get_h265_mod_param", ret);
    mod_param.one_stream_buf = 1;
    mod_param.low_power_mode = venc_mod_para->h265e_low_power_mode;
    ret = mapi_adapt_venc_set_h265_mod_param(&mod_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_h265_mod_param", ret);
#endif

    ret = mapi_adapt_venc_get_jpeg_mod_param(&mod_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_get_jpeg_mod_param", ret);
    mod_param.mini_buf_mode = 1;  /* 1：jpeg 默认使用最小码流buffer模式，省内存 */
    ret = mapi_adapt_venc_set_jpeg_mod_param(&mod_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_jpeg_mod_param", ret);

#if !defined (SUPPORT_H265) && !defined (SUPPORT_H264)
    MAPI_UNUSED(venc_mod_para);
#endif

    g_venc_ctx.venc_inited = TD_TRUE;
    return TD_SUCCESS;
}

td_s32 mapi_venc_deinit(td_void)
{
    td_u32 i;
    td_s32 ret;

    if (g_venc_ctx.venc_inited != TD_TRUE) {
        return TD_SUCCESS;
    }

    for (i = 0; i < HI_MAPI_VENC_MAX_CHN_NUM; i++) {
        if (g_venc_ctx.venc_chn_cfg[i].inited == TD_TRUE) {
            MAPI_INFO_TRACE(HI_MAPI_MOD_VENC, "venc is not deinit,channel:%d\n", i);
            ret = hi_mapi_venc_deinit(i);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "venc deinit handle:%d failed! ret:%x\n", i, ret);
            }
        }
    }

    for (i = 0; i < HI_MAPI_VENC_MAX_CHN_NUM; i++) {
        MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[i].venc_chn_lock);
        g_venc_ctx.venc_chn_cfg[i].started = TD_FALSE;
        g_venc_ctx.venc_chn_cfg[i].inited = TD_FALSE;
        g_venc_ctx.venc_chn_cfg[i].first_frame = TD_FALSE;
        g_venc_ctx.venc_chn_cfg[i].venc_handle = OT_INVALID_HANDLE;
        g_venc_ctx.venc_chn_cfg[i].start_frame_count = HI_MAPI_VENC_LIMITLESS_FRAME_COUNT;
        ret = memset_s(g_venc_ctx.venc_chn_cfg[i].venc_register_callbacks,
            sizeof(hi_mapi_venc_call_back) * HI_MAPI_VENC_CALLBACK_MAX_NUM, 0,
            sizeof(hi_mapi_venc_call_back) * HI_MAPI_VENC_CALLBACK_MAX_NUM);
        CHECK_MAPI_PRINT(HI_MAPI_MOD_VENC, "memset_s", ret);
        MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[i].venc_chn_lock);

        /* destroy the channel lock */
        MAPI_MUTEX_DESTROY(g_venc_ctx.venc_chn_cfg[i].venc_chn_lock);
    }

    g_venc_ctx.datafifo_node_num = 0;
    ret = memset_s(g_venc_ctx.proc_data_thread,
        sizeof(mapi_venc_proc_data_thread) * HI_MAPI_VENC_MAX_CHN_NUM, 0,
        sizeof(mapi_venc_proc_data_thread) * HI_MAPI_VENC_MAX_CHN_NUM);
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    mapi_venc_os_de_init();

    g_venc_ctx.venc_inited = TD_FALSE;
    return TD_SUCCESS;
}

static td_s32 mapi_venc_create_chn(td_handle venc_hdl, const hi_mapi_venc_attr *venc_attr)
{
    td_s32 ret = mapi_venc_check_attr(venc_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_venc_check_attr", ret);

    td_bool rcnRefShareBuf;
    if (g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_valid == TD_TRUE) {
        /* use the value configured by hi_mapi_venc_set_config */
        rcnRefShareBuf = g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_en;
    } else {
        /* not configured: fall back to hal default and back-fill so valid stays TRUE after init */
        rcnRefShareBuf = hal_mapi_venc_get_rcn_ref_share_buf_mode();
        g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_en = rcnRefShareBuf;
        g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_valid = TD_TRUE;
    }
    ret = mapi_adapt_venc_create_chn(venc_hdl, venc_attr, rcnRefShareBuf);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_create_chn", ret);

    return TD_SUCCESS;
}

static td_s32 mapi_venc_deinit_chn_global_cfg(td_handle venc_hdl)
{
    td_s32 ret;

    MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
    ret = memset_s(&g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr, sizeof(hi_mapi_venc_attr), 0,
        sizeof(hi_mapi_venc_attr));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "memset_s fail and return:[%#x]\n", ret);
        MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    for (td_s32 i = 0; i < HI_MAPI_VENC_CALLBACK_MAX_NUM; i++) {
        g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].proc_data_cb = TD_NULL;
        g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].private_data = TD_NULL;
    }

    g_venc_ctx.venc_chn_cfg[venc_hdl].time_ref = 0;
    g_venc_ctx.venc_chn_cfg[venc_hdl].inited = TD_FALSE;
    g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_valid = TD_FALSE;
    g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_en = TD_FALSE;
    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    return TD_SUCCESS;
}

static td_s32 mapi_venc_init_attr(td_handle venc_hdl, const hi_mapi_venc_attr *venc_attr)
{
    td_s32 ret = mapi_adapt_venc_close_reencode(venc_hdl, venc_attr->payload_type_attr.type, venc_attr->rc_attr.rc_mode);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_close_reencode", ret);

#ifdef SUPPORT_SVAC3
    if (venc_attr->payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_SVAC3) {
        ret = mapi_adapt_venc_set_scene_mode(venc_hdl, venc_attr->payload_type_attr.scene_mode);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_scene_mode", ret);

        ret = hal_mapi_venc_config_h265_car_trans(venc_hdl, venc_attr->payload_type_attr.type,
            venc_attr->payload_type_attr.scene_mode);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "hal_mapi_venc_config_h265_car_trans", ret);
    }
#endif

    if (venc_attr->payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_H264 ||
        venc_attr->payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_H265) {
        ret = mapi_adapt_venc_set_scene_mode(venc_hdl, venc_attr->payload_type_attr.scene_mode);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_scene_mode", ret);

        ret = hal_mapi_venc_config_h265_car_trans(venc_hdl, venc_attr->payload_type_attr.type,
            venc_attr->payload_type_attr.scene_mode);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "hal_mapi_venc_config_h265_car_trans", ret);
    } else if (venc_attr->payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_JPEG) {
        ret = mapi_adapt_venc_set_jpeg_param(venc_hdl, &venc_attr->payload_type_attr.jpeg_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_jpeg_param", ret);
    }

    ret = mapi_adapt_venc_set_stream_max_cnt(venc_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_stream_max_cnt", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_init(td_handle venc_hdl, const hi_mapi_venc_attr *venc_attr)
{
    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_attr);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);

    if (g_venc_ctx.venc_chn_cfg[venc_hdl].inited == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VENC, "chn %d has been inited\n", venc_hdl);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return HI_MAPI_VENC_EEXIST;
    }

    td_s32 ret = mapi_venc_create_chn(venc_hdl, venc_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VENC, "mapi_venc_create_chn", ret, g_venc_func_lock[venc_hdl]);

    ret = mapi_venc_init_attr(venc_hdl, venc_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "mapi_venc_sett_payload_type_attr error,ret:%x\n", ret);
        (td_void)mapi_adapt_venc_destroy_chn(venc_hdl);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return ret;
    }

    ret = mapi_venc_init_data_thread(venc_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "mapi_venc_init_data_thread error,ret:%x\n", ret);
        (td_void)mapi_adapt_venc_destroy_chn(venc_hdl);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return ret;
    }

    MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    mapi_venc_chn_config *cfg = &g_venc_ctx.venc_chn_cfg[venc_hdl];
    if (memcpy_s(&cfg->venc_attr, sizeof(cfg->venc_attr), venc_attr, sizeof(hi_mapi_venc_attr)) != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "memcpy_s fail and return:[%#x]\n", ret);
        MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
        (td_void)mapi_adapt_venc_destroy_chn(venc_hdl);
        (td_void)mapi_venc_deinit_data_thread(venc_hdl);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    if ((venc_attr->payload_type_attr.type != HI_MAPI_PAYLOAD_TYPE_JPEG) &&
        (venc_attr->rc_attr.rc_mode >= HI_MAPI_VENC_RC_MODE_BUTT)) {
        /* default rc_mode is  HI_MAPI_VENC_RC_MODE_CBR */
        g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.rc_attr.rc_mode = HI_MAPI_VENC_RC_MODE_CBR;
    }

    for (td_u32 i = 0; i < HI_MAPI_VENC_CALLBACK_MAX_NUM; i++) {
        g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].proc_data_cb = TD_NULL;
        g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].private_data = TD_NULL;
    }

    g_venc_ctx.venc_chn_cfg[venc_hdl].time_ref = 0;
    g_venc_ctx.venc_chn_cfg[venc_hdl].inited = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_deinit(td_handle venc_hdl)
{
    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_CHECK_PREINIT_RET(g_venc_ctx.venc_inited);

    td_bool funcRetErr = TD_FALSE;
    td_s32 ret;

    if (g_venc_ctx.venc_chn_cfg[venc_hdl].started == TD_TRUE) {
        ret = hi_mapi_venc_stop(venc_hdl);
        CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_VENC, "hi_mapi_venc_stop", ret, funcRetErr);
    }

    if (g_venc_ctx.venc_chn_cfg[venc_hdl].inited != TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VENC, "chn %d has been deinited\n", venc_hdl);
        return TD_SUCCESS;
    }

    {
        /* Safety net: drop any leftover (src -> this VENC) bindings if the app forgot to unbind. */
        hi_mapi_mpp_chn venc_dst = { .mod_id = HI_MAPI_MOD_VENC, .dev_id = 0, .chn_id = (td_s32)venc_hdl };
        (td_void)mapi_sys_bind_unbind_all_by_dst(&venc_dst);
    }
    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    ret = mapi_adapt_venc_destroy_chn(venc_hdl);
    CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_VENC, "mapi_adapt_venc_destroy_chn", ret, funcRetErr);

    ret = mapi_venc_deinit_data_thread(venc_hdl);
    CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_VENC, "mapi_venc_deinit_data_thread", ret, funcRetErr);

    if (funcRetErr) {
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return HI_MAPI_VENC_EBUSY;
    }

    ret = mapi_venc_deinit_chn_global_cfg(venc_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return ret;
    }
    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_register_callback(td_handle venc_hdl, const hi_mapi_venc_call_back *venc_cb)
{
    td_u32 i;
    td_s32 recordIdx = -1;
    td_s32 ret = TD_SUCCESS;

    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_cb);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);

    for (i = 0; i < HI_MAPI_VENC_CALLBACK_MAX_NUM; i++) {
        /* Check if the same callback has been registered */
        if (venc_cb->proc_data_cb == g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].proc_data_cb &&
            venc_cb->private_data == g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].private_data) {
            MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
            return TD_SUCCESS;
        }

        /* Record the first available free index */
        if ((recordIdx == -1) &&
            (g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].proc_data_cb == TD_NULL)) {
            recordIdx = (td_s32)i;
        }
    }

    if (recordIdx == -1) {
        ret = HI_MAPI_VENC_ENOT_PERM;
        goto EXIT;
    }
    MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
    g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[recordIdx].proc_data_cb = venc_cb->proc_data_cb;
    g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[recordIdx].private_data = venc_cb->private_data;
    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

EXIT:
    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
    return ret;
}

td_s32 hi_mapi_venc_un_register_callback(td_handle venc_hdl, const hi_mapi_venc_call_back *venc_cb)
{
    td_u32 i;
    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_cb);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);

    for (i = 0; i < HI_MAPI_VENC_CALLBACK_MAX_NUM; i++) {
        if (venc_cb->proc_data_cb == g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].proc_data_cb &&
            venc_cb->private_data == g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].private_data) {
            MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
            g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].proc_data_cb = TD_NULL;
            g_venc_ctx.venc_chn_cfg[venc_hdl].venc_register_callbacks[i].private_data = TD_NULL;
            MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
            MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
            return TD_SUCCESS;
        }
    }

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return HI_MAPI_VENC_ENOT_PERM;
}

td_s32 hi_mapi_venc_start(td_handle venc_hdl, td_s32 frame_cnt)
{
    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_FRAMECNT_RANGE_RET(frame_cnt);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);

    if (g_venc_ctx.venc_chn_cfg[venc_hdl].started == TD_TRUE && frame_cnt == HI_MAPI_VENC_LIMITLESS_FRAME_COUNT) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VENC, "chn %d has been started\n", venc_hdl);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return TD_SUCCESS;
    }

    td_s32 ret = mapi_adapt_venc_start_recv_frame(venc_hdl, frame_cnt);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VENC, "mapi_adapt_venc_start_recv_frame", ret, g_venc_func_lock[venc_hdl]);

    MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
    g_venc_ctx.venc_chn_cfg[venc_hdl].start_frame_count = frame_cnt;
    g_venc_ctx.venc_chn_cfg[venc_hdl].started = TD_TRUE;
    g_liteBootStarted[venc_hdl] = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_stop(td_handle venc_hdl)
{
    td_s32 ret;
    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);

    MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
    if (g_venc_ctx.venc_chn_cfg[venc_hdl].started == TD_FALSE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VENC, "chn %d has been stopped\n", venc_hdl);
        MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return TD_SUCCESS;
    }

    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    ret = mapi_adapt_venc_stop_recv_frame(venc_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VENC, "mapi_adapt_venc_stop_recv_frame", ret, g_venc_func_lock[venc_hdl]);
    g_venc_ctx.venc_chn_cfg[venc_hdl].started = TD_FALSE;

    ret = mapi_adapt_venc_reset_chn(venc_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VENC, "mapi_adapt_venc_reset_chn", ret, g_venc_func_lock[venc_hdl]);

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_set_attr(td_handle venc_hdl, const hi_mapi_venc_attr *venc_attr)
{
    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_attr);

    td_s32 ret = mapi_venc_check_attr(venc_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_venc_check_attr", ret);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);

    ret = mapi_adapt_venc_set_attr(venc_hdl, g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.rc_attr.rc_mode, venc_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_attr fail,venc_hdl:%d,ret:%x\n", venc_hdl, ret);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return ret;
    }

    MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
    ret = memcpy_s(&g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr, sizeof(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr),
        venc_attr, sizeof(hi_mapi_venc_attr));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "memcpy_s fail and return:[%#x]\n", ret);
        MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    if ((venc_attr->payload_type_attr.type != HI_MAPI_PAYLOAD_TYPE_JPEG) &&
        (venc_attr->rc_attr.rc_mode >= HI_MAPI_VENC_RC_MODE_BUTT)) {
        /* default rc_mode is  HI_MAPI_VENC_RC_MODE_CBR */
        g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.rc_attr.rc_mode = HI_MAPI_VENC_RC_MODE_CBR;
    }

    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_get_attr(td_handle venc_hdl, hi_mapi_venc_attr *venc_attr)
{
    td_s32 ret;

    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_attr);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);
    ret = memcpy_s(venc_attr, sizeof(hi_mapi_venc_attr), &g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr,
        sizeof(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr));
    CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_VENC, "memcpy_s", ret, g_venc_func_lock[venc_hdl]);

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_request_idr(td_handle venc_hdl)
{
    td_s32 ret;

    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);

    if (g_venc_ctx.venc_chn_cfg[venc_hdl].started != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC,
                       "venc_hdl:%d is not started, request IDR is not permit\n", venc_hdl);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return HI_MAPI_VENC_ENOT_PERM;
    }

    ret = mapi_adapt_venc_request_idr(venc_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC,
                       "mapi_adapt_venc_request_idr fail,venc_hdl:%d,ret:%x\n", venc_hdl, ret);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return ret;
    }

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_get_param(td_handle venc_hdl, hi_mapi_venc_cmd cmd, td_void *attr, td_u32 attr_len)
{
    td_s32 ret;

    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);
    MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    switch (cmd) {
        case HI_MAPI_VENC_CMD_H264_RC_ATTR_EX:
        case HI_MAPI_VENC_CMD_H265_RC_ATTR_EX:
        case HI_MAPI_VENC_CMD_MJPEG_RC_ATTR_EX:
            if (attr_len < sizeof(hi_mapi_venc_rc_param)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_rc_param *rcParam = (hi_mapi_venc_rc_param *)attr;
            ret = mapi_adapt_venc_get_rc_param(venc_hdl, g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.rc_attr.rc_mode,
                g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.payload_type_attr.type, rcParam);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC_GetRcParam fail,venc_hdl:%d,ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }

            break;

        case HI_MAPI_VENC_CMD_GOP_MODE:
            if (attr_len < sizeof(hi_mapi_venc_gop_attr)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_gop_attr *venc_gop_attr = (hi_mapi_venc_gop_attr *)attr;
            ret = mapi_adapt_venc_get_gop_attr(venc_hdl, venc_gop_attr);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "mapi_adapt_venc_get_gop_attr fail,venc_hdl:%d,ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }

            break;

        case HI_MAPI_VENC_CMD_INTRA_REFRESH:
            if (attr_len < sizeof(hi_mapi_venc_intra_refresh)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_intra_refresh *intraRefresh = (hi_mapi_venc_intra_refresh *)attr;
            ret = mapi_adapt_venc_get_intra_refresh(venc_hdl, intraRefresh);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "GetIntraRefresh fail, venc_hdl:%d, ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }

            break;

        case HI_MAPI_VENC_CMD_FRAME_RATE:
            if (attr_len < sizeof(hi_mapi_frame_rate_ctrl)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_frame_rate_ctrl *vencFrameRate = (hi_mapi_frame_rate_ctrl *)attr;
            ret = mapi_adapt_venc_get_frame_rate(venc_hdl, vencFrameRate);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "GetFrameRate fail,venc_hdl:%d, ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }

            break;

        case HI_MAPI_VENC_CMD_HIERARCHICAL_QP:
            if (attr_len < sizeof(hi_mapi_venc_hierarchical_qp)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_hierarchical_qp *vencHierarchicalQp = (hi_mapi_venc_hierarchical_qp *)attr;
            ret = mapi_adapt_venc_get_hierarchical_qp(venc_hdl, vencHierarchicalQp);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "GetHierarchicalQp fail, venc_hdl:%d, ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }

            break;

        case HI_MAPI_VENC_CMD_FRAMELOST_STRATEGY:
            if (attr_len < sizeof(td_bool)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC pAttr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_payload_type type = g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.payload_type_attr.type;
            if ((type == HI_MAPI_PAYLOAD_TYPE_H264) || (type == HI_MAPI_PAYLOAD_TYPE_H265) ||
                (type == HI_MAPI_PAYLOAD_TYPE_MJPEG)) {
                ret = mapi_adapt_venc_get_frame_lost_strategy(venc_hdl, (td_bool *)attr);
                if (ret != TD_SUCCESS) {
                    MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "GetFrameLostStrategy failed:0x%x\n", ret);
                    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                    return ret;
                }
            } else {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC payload type(%d) err\n",
                               g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.payload_type_attr.type);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }
            break;

        default:
            break;
    }

    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

/* mini_buf_mode 三个 cmd 是模块级（按协议）SDK 设置，与 venc_hdl 无关 */
static td_bool mapi_venc_is_mini_buf_cmd(hi_mapi_venc_cfg_cmd cmd)
{
    return (cmd == HI_MAPI_VENC_CFG_H264_MINI_BUF_MODE) ||
           (cmd == HI_MAPI_VENC_CFG_H265_MINI_BUF_MODE) ||
           (cmd == HI_MAPI_VENC_CFG_JPEG_MINI_BUF_MODE);
}

/* 按 cmd 取回对应协议全量 mod_param。jpeg cmd 覆盖 JPEG/MJPEG（SDK 共用 mod_type）。 */
static td_s32 mapi_venc_get_mod_param_by_cmd(hi_mapi_venc_cfg_cmd cmd, mapi_adapt_venc_mod_param *mod_param)
{
    switch (cmd) {
        case HI_MAPI_VENC_CFG_H264_MINI_BUF_MODE:
            return mapi_adapt_venc_get_h264_mod_param(mod_param);
        case HI_MAPI_VENC_CFG_H265_MINI_BUF_MODE:
            return mapi_adapt_venc_get_h265_mod_param(mod_param);
        case HI_MAPI_VENC_CFG_JPEG_MINI_BUF_MODE:
            return mapi_adapt_venc_get_jpeg_mod_param(mod_param);
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC mini_buf cfg cmd:%d unsupport\n", cmd);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }
}

static td_s32 mapi_venc_set_mod_param_by_cmd(hi_mapi_venc_cfg_cmd cmd, const mapi_adapt_venc_mod_param *mod_param)
{
    switch (cmd) {
        case HI_MAPI_VENC_CFG_H264_MINI_BUF_MODE:
            return mapi_adapt_venc_set_h264_mod_param(mod_param);
        case HI_MAPI_VENC_CFG_H265_MINI_BUF_MODE:
            return mapi_adapt_venc_set_h265_mod_param(mod_param);
        case HI_MAPI_VENC_CFG_JPEG_MINI_BUF_MODE:
            return mapi_adapt_venc_set_jpeg_mod_param(mod_param);
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC mini_buf cfg cmd:%d unsupport\n", cmd);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }
}

/* mini_buf_mode 配置：模块全局、按协议立刻 set_mod_param 生效。忽略 venc_hdl（接受任意值），
 * 仅校验 attr/attr_len 与模块已 init；用 g_venc_func_lock[0] 串行化（设置本身是模块级）。 */
static td_s32 mapi_venc_set_mini_buf_config(hi_mapi_venc_cfg_cmd cmd, const td_void *attr, td_u32 attr_len)
{
    if (attr_len != sizeof(hi_mapi_venc_mini_buf_mode_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr_len:%x mismatch\n", attr_len);
        return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    MAPI_MUTEX_LOCK(g_venc_func_lock[0]);
    if (!g_venc_ctx.venc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "media not init yet,venc no pre init\n");
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[0]);
        return HI_MAPI_VENC_ENOT_INITED;
    }

    /* 先 get 取回该协议全量 mod_param（避免覆盖 one_stream_buf/low_power_mode 等其它字段），
     * 仅改 mini_buf_mode 后按协议 set，立刻生效。 */
    const hi_mapi_venc_mini_buf_mode_attr *miniAttr = (const hi_mapi_venc_mini_buf_mode_attr *)attr;
    mapi_adapt_venc_mod_param mod_param;
    td_s32 ret = mapi_venc_get_mod_param_by_cmd(cmd, &mod_param);
    if (ret == TD_SUCCESS) {
        mod_param.mini_buf_mode = miniAttr->mini_buf_mode;
        ret = mapi_venc_set_mod_param_by_cmd(cmd, &mod_param);
    }
    MAPI_MUTEX_UNLOCK(g_venc_func_lock[0]);
    return ret;
}

static td_s32 mapi_venc_get_mini_buf_config(hi_mapi_venc_cfg_cmd cmd, td_void *attr, td_u32 attr_len)
{
    if (attr_len != sizeof(hi_mapi_venc_mini_buf_mode_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr_len:%x mismatch\n", attr_len);
        return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    MAPI_MUTEX_LOCK(g_venc_func_lock[0]);
    if (!g_venc_ctx.venc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "media not init yet,venc no pre init\n");
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[0]);
        return HI_MAPI_VENC_ENOT_INITED;
    }

    hi_mapi_venc_mini_buf_mode_attr *miniAttr = (hi_mapi_venc_mini_buf_mode_attr *)attr;
    mapi_adapt_venc_mod_param mod_param;
    td_s32 ret = mapi_venc_get_mod_param_by_cmd(cmd, &mod_param);
    if (ret == TD_SUCCESS) {
        miniAttr->mini_buf_mode = mod_param.mini_buf_mode;
    }
    MAPI_MUTEX_UNLOCK(g_venc_func_lock[0]);
    return ret;
}

td_s32 hi_mapi_venc_set_config(td_handle venc_hdl, hi_mapi_venc_cfg_cmd cmd, const td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_VENC_NULL_PTR_RET(attr);

    if (cmd >= HI_MAPI_VENC_CFG_CMD_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC cfg cmd:%d is invalid\n", cmd);
        return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    /* mini_buf_mode 三 cmd 模块全局生效，忽略 venc_hdl，走独立路径（不取 per-channel 锁/不查通道状态） */
    if (mapi_venc_is_mini_buf_cmd(cmd)) {
        return mapi_venc_set_mini_buf_config(cmd, attr, attr_len);
    }

    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);

    /* static config must be set before channel init */
    if (g_venc_ctx.venc_chn_cfg[venc_hdl].inited == TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "chn %d already inited, set_config is not permit\n", venc_hdl);
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return HI_MAPI_VENC_ENOT_PERM;
    }

    switch (cmd) {
        case HI_MAPI_VENC_CFG_RCN_REF_SHARE:
            if (attr_len != sizeof(hi_mapi_venc_rcn_ref_share_attr)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr_len:%x mismatch\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            const hi_mapi_venc_rcn_ref_share_attr *rcnAttr = (const hi_mapi_venc_rcn_ref_share_attr *)attr;
            MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
            g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_en = rcnAttr->ref_rcn_share_en;
            g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_valid = TD_TRUE;
            MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC cfg cmd:%d unsupport\n", cmd);
            MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_get_config(td_handle venc_hdl, hi_mapi_venc_cfg_cmd cmd, td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_VENC_NULL_PTR_RET(attr);

    if (cmd >= HI_MAPI_VENC_CFG_CMD_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC cfg cmd:%d is invalid\n", cmd);
        return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    /* mini_buf_mode 三 cmd 模块全局生效，忽略 venc_hdl，走独立路径回读 SDK mod_param */
    if (mapi_venc_is_mini_buf_cmd(cmd)) {
        return mapi_venc_get_mini_buf_config(cmd, attr, attr_len);
    }

    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    /* readable before and after channel init, module init is enough */
    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);

    switch (cmd) {
        case HI_MAPI_VENC_CFG_RCN_REF_SHARE:
            if (attr_len != sizeof(hi_mapi_venc_rcn_ref_share_attr)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC attr_len:%x mismatch\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_rcn_ref_share_attr *rcnAttr = (hi_mapi_venc_rcn_ref_share_attr *)attr;
            MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
            if (g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_valid == TD_TRUE) {
                rcnAttr->ref_rcn_share_en = g_venc_ctx.venc_chn_cfg[venc_hdl].rcn_ref_share_en;
            } else {
                rcnAttr->ref_rcn_share_en = hal_mapi_venc_get_rcn_ref_share_buf_mode();
            }
            MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC cfg cmd:%d unsupport\n", cmd);
            MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_set_param(td_handle venc_hdl, hi_mapi_venc_cmd cmd, const td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);

    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);
    td_s32 ret;
    MAPI_MUTEX_LOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    switch (cmd) {
        case HI_MAPI_VENC_CMD_H264_RC_ATTR_EX:
        case HI_MAPI_VENC_CMD_H265_RC_ATTR_EX:
        case HI_MAPI_VENC_CMD_MJPEG_RC_ATTR_EX:
            if (attr_len < sizeof(hi_mapi_venc_rc_param)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC pAttr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_rc_param *rcParam = (hi_mapi_venc_rc_param *)attr;
            ret = mapi_adapt_venc_set_rc_param(venc_hdl, g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.rc_attr.rc_mode,
                g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.payload_type_attr.type, rcParam);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC_SetRcParam fail,venc_hdl:%d,ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }
            break;

        case HI_MAPI_VENC_CMD_GOP_MODE:
            if (attr_len < sizeof(hi_mapi_venc_gop_attr)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC pAttr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_gop_attr *venc_gop_attr = (hi_mapi_venc_gop_attr *)attr;
            ret = mapi_adapt_venc_set_gop_attr(venc_hdl, venc_gop_attr);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_gop_attr err 0x%x\n", ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }

            break;

        case HI_MAPI_VENC_CMD_INTRA_REFRESH:
            if (attr_len < sizeof(hi_mapi_venc_intra_refresh)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC pAttr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_intra_refresh *intraRefresh = (hi_mapi_venc_intra_refresh *)attr;
            ret = mapi_adapt_venc_set_intra_refresh(venc_hdl, intraRefresh);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "SetIntraRefresh fail, venc_hdl:%d, ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }
            break;

        case HI_MAPI_VENC_CMD_FRAME_RATE:
            if (attr_len < sizeof(hi_mapi_frame_rate_ctrl)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC pAttr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_frame_rate_ctrl *vencFrameRate = (hi_mapi_frame_rate_ctrl *)attr;
            ret = mapi_adapt_venc_set_frame_rate(venc_hdl, vencFrameRate);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "SetFrameRate fail, venc_hdl:%d, ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }

            break;

        case HI_MAPI_VENC_CMD_HIERARCHICAL_QP:
            if (attr_len < sizeof(hi_mapi_venc_hierarchical_qp)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC pAttr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            hi_mapi_venc_hierarchical_qp *vencHierarchicalQp = (hi_mapi_venc_hierarchical_qp *)attr;
            ret = mapi_adapt_venc_set_hierarchical_qp(venc_hdl, vencHierarchicalQp);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "HierarchicalQp fail, venc_hdl:%d, ret:%x\n", venc_hdl, ret);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return ret;
            }
            break;

        case HI_MAPI_VENC_CMD_FRAMELOST_STRATEGY:
            if (attr_len < sizeof(td_bool)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC pAttr attr_len:%x is small\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }

            if (g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_H264 ||
                g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_H265 ||
                g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_MJPEG) {
                td_bool *frmLostOpen = (td_bool *)attr;
                ret = mapi_adapt_venc_set_frame_lost_strategy(venc_hdl, frmLostOpen);
                if (ret != TD_SUCCESS) {
                    MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "SetFrameLostStrategy failed:0x%x\n", ret);
                    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                    return ret;
                }
            } else {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC payload type(%d) err\n",
                               g_venc_ctx.venc_chn_cfg[venc_hdl].venc_attr.payload_type_attr.type);
                MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);
                MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
                return HI_MAPI_VENC_EILLEGAL_PARAM;
            }
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "not support yet\n");
            ret = HI_MAPI_VENC_EILLEGAL_PARAM;
            break;
    }

    MAPI_MUTEX_UNLOCK(g_venc_ctx.venc_chn_cfg[venc_hdl].venc_chn_lock);

    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    return ret;
}

td_s32 hi_mapi_venc_send_frame(td_handle venc_hdl, const hi_mapi_frame_data *framedata, td_s32 timeout)
{
    CHECK_MAPI_VENC_HANDLE_RANGE_RET(venc_hdl);
    CHECK_MAPI_VENC_NULL_PTR_RET(framedata);

    MAPI_MUTEX_LOCK(g_venc_func_lock[venc_hdl]);
    CHECK_MAPI_VENC_CHECK_PREINIT_UNLOCK_RET(g_venc_ctx.venc_inited);
    CHECK_MAPI_VENC_CHECK_INIT_UNLOCK_RET(g_venc_ctx.venc_chn_cfg[venc_hdl].inited);
    if (!g_venc_ctx.venc_chn_cfg[venc_hdl].started) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC has not been started\n");
        MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);
        return HI_MAPI_VENC_ENOT_PERM;
    }
    MAPI_MUTEX_UNLOCK(g_venc_func_lock[venc_hdl]);

    td_u32 time_ref = g_venc_ctx.venc_chn_cfg[venc_hdl].time_ref;
    td_s32 ret = mapi_adapt_venc_send_frame(venc_hdl, framedata, time_ref, timeout);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "VENC_SendFrame", ret);

    g_venc_ctx.venc_chn_cfg[venc_hdl].time_ref += 2; /* 2: Image frame sequence number, Add 2 each time */

    return TD_SUCCESS;
}

td_s32 hi_mapi_venc_get_default_attr(const hi_mapi_venc_base_attr *base_attr, hi_mapi_venc_attr *venc_attr)
{
    CHECK_MAPI_VENC_NULL_PTR_RET(base_attr);
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_attr);

    (td_void)memset_s(venc_attr, sizeof(hi_mapi_venc_attr), 0, sizeof(hi_mapi_venc_attr));

    /* get playload attr */
    venc_attr->payload_type_attr.type = base_attr->type;
    venc_attr->payload_type_attr.width = base_attr->width;
    venc_attr->payload_type_attr.height = base_attr->height;
    venc_attr->payload_type_attr.buf_size = base_attr->width  * base_attr->height * 3 / 4; /* 3, 4: value */
    if (venc_attr->payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_H264) {
        venc_attr->payload_type_attr.profile = 1; /* H.264:   0: baseline; 1:MP; 2:HP */
    } else {
        venc_attr->payload_type_attr.profile = 0; /* H.265:   0: Main profile; JPEG: baseline */
    }

    venc_attr->payload_type_attr.scene_mode = HI_MAPI_VENC_SCENE_MODE_NORMAL;
    venc_attr->payload_type_attr.by_frame = TD_TRUE; /* frame mode: required by callback-based stream consumers */

    if (venc_attr->payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_JPEG) {
        venc_attr->payload_type_attr.jpeg_attr.qfactor = base_attr->qfactor;
    } else {
        venc_attr->rc_attr.rc_mode = HI_MAPI_VENC_RC_MODE_CBR;
        venc_attr->rc_attr.cbr_attr.gop = base_attr->dst_frame_rate * 5;
        venc_attr->rc_attr.cbr_attr.stat_time = 1;
        venc_attr->rc_attr.cbr_attr.src_frame_rate = base_attr->src_frame_rate;
        venc_attr->rc_attr.cbr_attr.dst_frame_rate = base_attr->dst_frame_rate;
        venc_attr->rc_attr.cbr_attr.bit_rate = base_attr->bit_rate;
    }

    return TD_SUCCESS;
}


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
