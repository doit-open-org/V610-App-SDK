/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_venc_os.h"
#include "mapi_venc_inner.h"
#include "mapi_comm_inner.h"
#include "mapi_venc_adapt.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static td_s32 mapi_venc_stream_process(hi_mapi_venc_data_attr *venc_data, const mapi_venc_chn_config *venc_chn_cfg)
{
    td_s32 ret;
    td_u32 i;

    for (i = 0; i < HI_MAPI_VENC_CALLBACK_MAX_NUM; i++) {
        if (venc_chn_cfg->venc_register_callbacks[i].proc_data_cb != TD_NULL) {
            ret = venc_chn_cfg->venc_register_callbacks[i].proc_data_cb(venc_chn_cfg->venc_handle, venc_data,
                venc_chn_cfg->venc_register_callbacks[i].private_data);
            if (ret != TD_SUCCESS) {
                MAPI_INFO_TRACE(HI_MAPI_MOD_VENC, "venc_register_callbacks[%u].proc_data_cb fail,ret:%x\n", i, ret);
            }
        }
    }

    return TD_SUCCESS;
}

static td_void mapi_venc_check_end_of_stream(td_handle venc_hdl, const mapi_adapt_venc_status *status,
    hi_mapi_venc_data_attr *outVStream)
{
    if (((status->left_pics == 0 && status->left_stream_frames == 1 && status->leftEncPics == 0 &&
          status->jpegSnapEnd == TD_TRUE) || /* for snap, jpegSnapEnd come from vi. */
          (status->left_pics == 0 && status->left_stream_frames == 1 &&
          status->leftEncPics == 0 && status->leftRecvPics == 0)) && /* for video THM */
          mapi_venc_get_start_frame_cnt(venc_hdl) != HI_MAPI_VENC_LIMITLESS_FRAME_COUNT) {
        outVStream->end_of_stream = TD_TRUE;

        td_s32 ret = mapi_adapt_venc_stop_recv_frame(venc_hdl);
        CHECK_MAPI_PRINT(HI_MAPI_MOD_VENC, "StopRecvFrame", ret);
    } else {
        outVStream->end_of_stream = TD_FALSE;
    }
}

td_s32 mapi_venc_get_stream(td_handle venc_hdl, const mapi_venc_chn_config *venc_chn_cfg)
{
    mapi_adapt_venc_stream stream;
    hi_mapi_venc_data_attr outVStream;
    mapi_adapt_venc_pack streamPack[HI_MAPI_VENC_MAX_FRAME_PACKCOUNT];
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_chn_cfg);

    td_s32 ret = memset_s(streamPack, sizeof(mapi_adapt_venc_pack) * HI_MAPI_VENC_MAX_FRAME_PACKCOUNT, 0,
        sizeof(mapi_adapt_venc_pack) * HI_MAPI_VENC_MAX_FRAME_PACKCOUNT);
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = memset_s(&outVStream, sizeof(hi_mapi_venc_data_attr), 0, sizeof(hi_mapi_venc_data_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = memset_s(&stream, sizeof(mapi_adapt_venc_stream), 0, sizeof(mapi_adapt_venc_stream));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    if (mapi_venc_is_register_callback(venc_hdl) != TD_TRUE) {
        return TD_SUCCESS;
    }

    mapi_adapt_venc_status status;
    ret = mapi_adapt_venc_query_status(venc_hdl, &status);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_query_status\n", ret);

    if (status.curPacks == 0) {
        return TD_SUCCESS;
    }

    if (status.curPacks > HI_MAPI_VENC_MAX_FRAME_PACKCOUNT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "status.curPacks > HI_MAPI_VENC_MAX_FRAME_PACKCOUNT\n");
        return TD_FAILURE;
    }

    ret = mapi_adapt_venc_get_stream(venc_hdl, streamPack, status.curPacks, &stream);
    if (ret != TD_SUCCESS) {
        return ret;
    }

    mapi_venc_check_end_of_stream(venc_hdl, &status, &outVStream);
    ret = mapi_adapt_venc_config_out_stream_data(status.type, TD_NULL, &stream, &outVStream);
    if (ret != TD_SUCCESS) {
        (td_void)mapi_adapt_venc_release_stream(venc_hdl, &stream);
        return ret;
    }

    ret = mapi_venc_stream_process(&outVStream, venc_chn_cfg);
    CHECK_MAPI_PRINT(HI_MAPI_MOD_VENC, "getting video stream error\n", ret);

    ret = mapi_adapt_venc_release_stream(venc_hdl, &stream);
    CHECK_MAPI_PRINT(HI_MAPI_MOD_VENC, "mapi_adapt_venc_release_stream fail.\n", ret);

    return TD_SUCCESS;
}

td_void mapi_venc_clear_datafifo_data(td_handle venc_hdl)
{
    MAPI_UNUSED(venc_hdl);

    return;
}

td_void mapi_venc_os_init(td_void)
{
    return;
}

td_void mapi_venc_os_de_init(td_void)
{
    return;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
