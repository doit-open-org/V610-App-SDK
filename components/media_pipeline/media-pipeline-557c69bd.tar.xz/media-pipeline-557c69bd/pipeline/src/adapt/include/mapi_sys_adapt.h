/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_SYS_ADAPT_H__
#define __HI_MAPI_SYS_ADAPT_H__

#include "hi_mapi_comm_define.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 mapi_adapt_sys_register_vqe_module(const hi_mapi_audio_vqe_attr *audio_vqe_attr);
td_s32 mapi_adapt_sys_init_media(const hi_mapi_sys_media_config *media_config, td_u32 supplement_config);
td_s32 mapi_adapt_sys_deinit_media(td_void);
td_s32 mapi_adapt_sys_alloc_mmz_buffer(td_u64 *phy_addr, td_void **virt_addr, td_u32 buf_len, const td_char *buf_name,
    td_bool is_cache);
td_s32 mapi_adapt_sys_free_mmz_buffer(td_u64 phy_addr, td_void *virt_addr);
td_s32 mapi_adapt_sys_flush_cache(td_u64 phy_addr, td_void *virt_addr, td_u32 buf_len);
td_s32 mapi_adapt_sys_get_video_block(td_handle *pool_hdl, td_u64 *phy_addr, td_u64 blk_size,
    const td_char *mmz_name);
td_s32 mapi_adapt_sys_release_video_block(td_u64 phy_addr);
td_s32 mapi_adapt_sys_bind(const hi_mapi_mpp_chn *src_chn, const hi_mapi_mpp_chn *dst_chn);
td_s32 mapi_adapt_sys_unbind(const hi_mapi_mpp_chn *src_chn, const hi_mapi_mpp_chn *dst_chn);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_SYS_ADAPT_H__ */
