/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AUDIO_COMP_ACODEC_H
#define AUDIO_COMP_ACODEC_H

#include "hi_mw_type.h"
#include "hi_mapi_audio_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/* Public API dispatched to the active provider. */
td_s32 audio_comp_acodec_open(td_void);
td_s32 audio_comp_acodec_close(td_void);
td_s32 audio_comp_acodec_config_attr(hi_mapi_audio_sample_rate sample_rate, hi_mapi_aio_acodec_mixer mixer_mic_mode);
td_s32 audio_comp_acodec_set_ai_vol(td_s32 input_vol);
td_s32 audio_comp_acodec_get_ai_vol(td_s32 *input_vol);
td_s32 audio_comp_acodec_set_ao_vol(td_s32 output_vol);
td_s32 audio_comp_acodec_get_ao_vol(td_s32 *output_vol);
td_s32 audio_comp_acodec_mute_ai(td_void);
td_s32 audio_comp_acodec_unmute_ai(td_void);

/* Provider ops table. */
typedef struct {
    td_s32 (*open)(td_void);
    td_s32 (*close)(td_void);
    td_s32 (*config_attr)(hi_mapi_audio_sample_rate sample_rate, hi_mapi_aio_acodec_mixer mixer_mic_mode);
    td_s32 (*set_ai_vol)(td_s32 input_vol);
    td_s32 (*get_ai_vol)(td_s32 *input_vol);
    td_s32 (*set_ao_vol)(td_s32 output_vol);
    td_s32 (*get_ao_vol)(td_s32 *output_vol);
    td_s32 (*mute_ai)(td_void);
    td_s32 (*unmute_ai)(td_void);
} audio_comp_acodec_ops_t;

/* Platform provider bootstrap. */
/* Explicit registration entry for the HiSilicon inner acodec provider.
 * Must be called once before audio_comp_acodec_open(); idempotent.
 * inner_acodec.c is always compiled in; the constructor is a fallback for
 * shared-library builds. Explicit call in hi_mapi_acap_init ensures the
 * linker keeps inner_acodec.o in static-link scenarios. */
td_void inner_acodec_register(td_void);

/* Provider registry. */

/* Register a provider implementation. The first registration becomes active.
 * Name pointer must remain valid for the process lifetime (typically a string
 * literal); ops table likewise must be static.  Returns 0 on success,
 * -1 on duplicate name or table full. */
td_s32 audio_comp_acodec_register(const char *name, const audio_comp_acodec_ops_t *ops);

/* Look up a registered provider by name; returns NULL if absent. */
const audio_comp_acodec_ops_t *audio_comp_acodec_get_ops(const char *name);

/* Switch the active provider by name. Caller is responsible for invoking
 * close() on the previous provider before switching if the device was open.
 * Returns 0 on success, -1 if the name is not registered. */
td_s32 audio_comp_acodec_set_active(const char *name);

/* Return the active provider ops table, or NULL if none registered. */
const audio_comp_acodec_ops_t *audio_comp_acodec_get_active(void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef AUDIO_COMP_ACODEC_H */
