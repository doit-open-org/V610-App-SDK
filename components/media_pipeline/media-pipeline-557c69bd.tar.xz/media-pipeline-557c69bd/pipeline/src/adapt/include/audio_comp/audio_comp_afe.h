/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AUDIO_COMP_AFE_H
#define AUDIO_COMP_AFE_H

#include "hi_mw_type.h"
#include <stdint.h>

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

/* Init attributes. */

/* SDK-style providers only: describes which VQE preset to apply. Ignored by
 * software providers. */
typedef enum {
    AUDIO_COMP_AFE_VQE_NONE   = 0,
    AUDIO_COMP_AFE_VQE_RECORD,   /* RECORD VQE (NR+AGC+HPF+EQ) */
    AUDIO_COMP_AFE_VQE_TALK,     /* TALK VQE   (AEC+NR+AGC) */
    AUDIO_COMP_AFE_VQE_TALKV2,   /* TALK VQE v2 (AEC+NR+AGC+WNR, stereo) */
    AUDIO_COMP_AFE_VQE_BUTT
} audio_comp_afe_vqe_mode_t;

typedef struct {
    /* Software providers (e.g. Unisound) only; ignored by SDK providers.
     * NULL = no model needed. */
    const char *model_path;

    /* SDK providers only; ignored by software providers. */
    audio_comp_afe_vqe_mode_t vqe_mode;
    td_handle ai_dev_id;
    td_handle ai_chn_id;
    td_handle ref_ao_dev_id;
    td_handle ref_ao_chn_id;
    td_u32 talk_open_mask;

    /* PCM format hints, populated by the caller (typically copied from the
     * upstream acap attr). */
    uint32_t sample_rate;   /* Hz, e.g. 16000 / 48000 */
    uint16_t channels;      /* 1 = mono, 2 = stereo */
    uint16_t samples_per_frame;
} audio_comp_afe_attr_t;

/* PCM view: zero-copy contract for process(). */

/* A read-only view onto a PCM frame.  Bytes layout is interleaved int16_t.
 * For software providers needing an AEC reference channel, ref_data points
 * at the parallel reference PCM; NULL when not applicable. */
typedef struct {
    const int16_t *data;
    const int16_t *data_ch1;
    const int16_t *ref_data;
    uint32_t       samples;       /* int16_t samples per channel */
    uint32_t       channels;
    uint32_t       sample_rate;
} audio_comp_pcm_view_in_t;

/* Output view returned by process().  For pass-through (SDK) providers the
 * implementation just writes the input PCM pointer back; for software
 * providers the buffer is owned by the algorithm engine. */
typedef struct {
    const int16_t *data;
    uint32_t       samples;
    uint32_t       channels;
    uint32_t       sample_rate;
} audio_comp_pcm_view_out_t;

/* Provider ops table. */

typedef struct {
    /* Initialise the provider with shared and provider-specific attributes.
     * Called once before the first process().  Returns 0 on success. */
    int (*init)(const audio_comp_afe_attr_t *attr);

    /* Process one PCM frame through the AFE engine.
     * For SDK in-band providers this is a no-op (out = in shape passthrough).
     * For software providers this is the real algorithm call.
     * Returns 0 on success. */
    int (*process)(const audio_comp_pcm_view_in_t *in, audio_comp_pcm_view_out_t *out);

    /* Release any resources allocated by init(). */
    void (*deinit)(void);

    /* Whether this provider requires raw mic + ref frames from the SDK.
     * - FALSE (hisi_native and other SDK in-band providers): SDK VQE
     *   processed PCM is fine; ACAP create_chn leaves SDK chn_attr.raw_frame_enable=FALSE.
     * - TRUE (unisound and other software AEC/NR providers): need raw
     *   mic+ref; ACAP create_chn sets chn_attr.raw_frame_enable=TRUE and
     *   hi_mapi_acap_enable_vqe is automatically rejected (mutex).
     * Self-declared at provider registration time; consumed by audio_comp_acap. */
    int needs_raw_frame;
    int software_process;
} audio_comp_afe_ops_t;

/* Provider registry. */

/* Register a provider implementation.  First registration becomes active.
 * `name` must remain valid for the process lifetime; `ops` must be static.
 * Returns 0 on success, -1 on duplicate name or table full. */
int audio_comp_afe_register(const char *name, const audio_comp_afe_ops_t *ops);

/* Look up a registered provider by name; NULL if absent. */
const audio_comp_afe_ops_t *audio_comp_afe_get_ops(const char *name);

/* Switch the active provider by name.  Caller is responsible for tearing
 * down the previous provider (deinit + open device close) if appropriate.
 * Returns 0 on success, -1 if name is not registered. */
int audio_comp_afe_set_active(const char *name);

/* Return the active provider ops, or NULL if none registered. */
const audio_comp_afe_ops_t *audio_comp_afe_get_active(void);

/* Lifecycle fence.
 * The active provider must be chosen before audio_comp_acap_create_chn
 * commits the SDK chn_attr.raw_frame_enable.  After lock, set_active
 * returns -1 until unlock is called (typically by acap_destroy_chn).
 * Called by audio_comp_acap internally, not by business code. */
void audio_comp_afe_lock_active(void);
void audio_comp_afe_unlock_active(void);
int  audio_comp_afe_is_active_locked(void);

/* Built-in provider bootstrap. Explicit call keeps constructor-only objects
 * reachable when the pipeline is linked from a static archive. */
void hisi_afe_provider_register(void);
void external_afe_provider_register(void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif /* AUDIO_COMP_AFE_H */
