/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_VPSS_ADAPT_DEFINE_H__
#define __MAPI_VPSS_ADAPT_DEFINE_H__

#include "hi_mapi_venc_adapt_define.h"
#include "mapi_vpss_inner.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

#define MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN OT_MAX_COLOR_COMPONENT

typedef enum {
    MAPI_VIDEO_FIELD_TOP         = 0x1, /* even field */
    MAPI_VIDEO_FIELD_BOTTOM      = 0x2, /* odd field */
    MAPI_VIDEO_FIELD_INTERLACED  = 0x3, /* two interlaced fields */
    MAPI_VIDEO_FIELD_FRAME       = 0x4, /* frame */

    MAPI_VIDEO_FIELD_BUTT
} mapi_adapt_video_field;

typedef enum {
    MAPI_DYNAMIC_RANGE_SDR8 = 0,
    MAPI_DYNAMIC_RANGE_SDR10,
    MAPI_DYNAMIC_RANGE_HDR10,
    MAPI_DYNAMIC_RANGE_HLG,
    MAPI_DYNAMIC_RANGE_SLF,
    MAPI_DYNAMIC_RANGE_XDR,
    MAPI_DYNAMIC_RANGE_BUTT
} mapi_adapt_dynamic_range;

typedef enum {
    MAPI_COLOR_GAMUT_BT601 = 0,
    MAPI_COLOR_GAMUT_BT709,
    MAPI_COLOR_GAMUT_BT2020, /* Only used for 3559AV100 */
    MAPI_COLOR_GAMUT_USER,
    MAPI_COLOR_GAMUT_BUTT
} mapi_adapt_color_gamut;

#define MAPI_ADAPT_MAX_USER_DATA_NUM OT_MAX_USER_DATA_NUM

typedef struct {
    td_u32              width;
    td_u32              height;
    mapi_adapt_video_field     field;
    hi_mapi_pixel_format pixel_format;
    hi_mapi_video_format video_format;
    hi_mapi_compress_mode compress_mode;
    mapi_adapt_dynamic_range    dynamic_range;
    mapi_adapt_color_gamut      color_gamut;
    td_u32              header_stride[MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN];
    td_u32              stride[MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN];

    td_u64              header_phy_addr[MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN];
    td_u64              phy_addr[MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN];
    td_u64              header_vir_addr[MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN];
    td_u64              vir_addr[MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN];

    td_u32              time_ref;
    td_u64              pts;

    td_u64              private_data[MAPI_ADAPT_MAX_USER_DATA_NUM];
    td_u32              frame_flag; /* FRAME_FLAG_E, can be OR operation. */
    hi_mapi_video_supplement supplement;
} mapi_adapt_frame_info;

#if (defined SUPPORT_PHOTO_POST_PROCESS) || (defined SUPPORT_IVE)
typedef struct {
    mapi_adapt_frame_info v_frame;
    td_u32        pool_id;
    ot_mod_id     mod_id;
} mapi_adapt_video_frame_info;
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif /* __MAPI_VPSS_ADAPT_DEFINE_H__ */
