/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_DISP_ADAPT_H__
#define __HI_MAPI_DISP_ADAPT_H__

#include "hi_mapi_disp_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 mapi_adapt_disp_set_vo_pub_attr(td_handle disp_hdl, const hi_mapi_disp_pub_attr *pub_attr);
td_s32 mapi_adapt_disp_set_user_intf_sync_info(td_handle disp_hdl,
    const hi_mapi_disp_user_info_attr *user_info_attr);
td_s32 mapi_adapt_disp_enable_vo(td_handle disp_hdl);
td_s32 mapi_adapt_disp_disable_vo(td_handle disp_hdl);
td_s32 mapi_adapt_disp_set_video_layer_csc(td_handle disp_hdl, const hi_mapi_disp_csc_attr_ex *csc_attr);
td_s32 mapi_adapt_disp_get_video_layer_csc(td_handle disp_hdl, hi_mapi_disp_csc_attr_ex *csc_attr);
td_s32 mapi_adapt_disp_set_graphic_layer_csc(td_handle disp_hdl, const hi_mapi_disp_csc_attr_ex *csc_attr);
td_s32 mapi_adapt_disp_get_graphic_layer_csc(td_handle disp_hdl, hi_mapi_disp_csc_attr_ex *csc_attr);
td_s32 mapi_adapt_disp_set_chn_rotation(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_rotate *disp_rotate);
td_s32 mapi_adapt_disp_get_chn_rotation(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_rotate *disp_rotate);
td_s32 mapi_adapt_disp_set_video_layer_param(td_handle disp_hdl,
    const hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr);
td_s32 mapi_adapt_disp_get_video_layer_param(td_handle disp_hdl,
    hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr);
td_s32 mapi_adapt_disp_set_chn_param(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr);
td_s32 mapi_adapt_disp_get_chn_param(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr);
td_s32 mapi_adapt_disp_start(td_handle disp_hdl, const hi_mapi_disp_video_layer_attr *video_layer_attr,
    const hi_mapi_rect *disp_rect);
td_s32 mapi_adapt_disp_stop(td_handle disp_hdl);
td_s32 mapi_adapt_disp_set_vo_chn_attr(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_attr *wnd_attr);
td_s32 mapi_adapt_disp_get_vo_chn_attr(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_attr *wnd_attr);
td_s32 mapi_adapt_disp_enable_vo_chn(td_handle disp_hdl, td_handle wnd_hdl);
td_s32 mapi_adapt_disp_disable_vo_chn(td_handle disp_hdl, td_handle wnd_hdl);
td_s32 mapi_adapt_disp_clear_vo_chn_buf(td_handle disp_hdl, td_handle wnd_hdl);
td_s32 mapi_adapt_disp_send_frame(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_frame_data *frame_data);
td_s32 mapi_adapt_disp_nv12_to_rgb888_ive(const hi_mapi_frame_data *yuv_frame,
    td_phys_addr_t out_phys_addr, td_void *out_virt_addr);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_DISP_ADAPT_H__ */
