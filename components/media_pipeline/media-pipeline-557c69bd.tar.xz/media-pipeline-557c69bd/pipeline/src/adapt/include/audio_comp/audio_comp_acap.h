/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_ACAP_ADAPT_H__
#define __MAPI_ACAP_ADAPT_H__

#include "mapi_acap_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32  mapi_acap_audio_init(td_void);
td_void mapi_acap_audio_deinit(td_void);

td_s32  mapi_acap_dlopen(td_void **lib_handle, td_char *lib_name);
td_s32  mapi_acap_dlsym(td_void **func_handle, td_void *lib_handle, td_char *func_name);
td_void mapi_acap_dlclose(td_void *lib_handle);

td_s32 audio_comp_acap_set_ai_pub_attr(td_handle acap_hdl, const mapi_acap_server_context *acap_context,
                                       const hi_mapi_acap_attr *acap_attr);
td_s32 audio_comp_acap_enable_ai(td_handle acap_hdl);
td_s32 audio_comp_acap_disable_ai(td_handle acap_hdl);
td_s32 audio_comp_acap_enable_ai_chn(td_handle acap_hdl, td_handle acap_chn_hdl);
td_s32 audio_comp_acap_disable_ai_chn(td_handle acap_hdl, td_handle acap_chn_hdl);
td_s32 audio_comp_acap_start(td_handle acap_hdl, td_handle acap_chn_hdl, const hi_mapi_acap_attr *acap_attr);
#ifdef SUPPORT_RECORDVQE
td_s32 audio_comp_acap_enable_record_vqe(td_handle acap_hdl, td_handle acap_chn_hdl,
                                         const hi_mapi_acap_attr *acap_attr);
#endif
#ifdef SUPPORT_TALKVQE
td_s32 audio_comp_acap_enable_talk_vqe(td_handle acap_hdl, td_handle acap_chn_hdl, td_handle talk_ao_hdl,
                                       td_u32 open_mask, const hi_mapi_acap_attr *acap_attr);
#endif
#if defined(SUPPORT_TALKVQE) || defined(SUPPORT_RECORDVQE)
td_s32 audio_comp_acap_disable_vqe(td_handle acap_hdl, td_handle acap_chn_hdl);
#endif
td_s32 audio_comp_acap_get_frame(td_handle acap_hdl, td_handle acap_chn_hdl,
                                 const hi_mapi_acap_attr *acap_attr,
                                 hi_mapi_audio_frame *audio_frm, hi_mapi_aec_frame *aec_frm);
td_s32 audio_comp_acap_release_frame(td_handle acap_hdl, td_handle acap_chn_hdl,
                                     const hi_mapi_audio_frame *audio_frm, const hi_mapi_aec_frame *aec_frm);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_ACAP_ADAPT_H__ */
