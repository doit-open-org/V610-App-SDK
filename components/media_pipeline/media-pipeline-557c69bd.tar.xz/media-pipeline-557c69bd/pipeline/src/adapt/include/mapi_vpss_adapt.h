/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VPSS_ADAPT_H__
#define __HI_MAPI_VPSS_ADAPT_H__

#include "mapi_vpss_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

td_s32 mapi_adapt_vpss_get_chn_frame(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_frame_data *yuv_frame_data,
    td_s32 milli_sec);
td_s32 mapi_adapt_vpss_release_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    const hi_mapi_frame_data *yuv_frame_data);

td_s32 mapi_adapt_vpss_create_grp(td_handle vpss_hdl, const hi_mapi_vpss_grp_attr *vpss_attr);
td_s32 mapi_adapt_vpss_destroy_grp(td_handle vpss_hdl);
td_s32 mapi_adapt_vpss_start_grp(td_handle vpss_hdl);
td_s32 mapi_adapt_vpss_stop_grp(td_handle vpss_hdl);
td_s32 mapi_adapt_vpss_set_chn_attr(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_chn_attr *chn_attr, td_u32 *pool_id, td_u32 scale);
td_s32 mapi_adapt_vpss_get_chn_attr(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_chn_attr *chn_attr);
td_s32 mapi_adapt_vpss_set_chn_align(td_handle vpss_hdl, td_handle chn_hdl, td_u32 align);
td_s32 mapi_adapt_vpss_set_ext_chn_attr(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_ext_chn_attr *ext_chn_attr, td_u32 *pool_id, td_u32 scale);
td_s32 mapi_adapt_vpss_get_ext_chn_attr(td_handle vpss_hdl, td_handle chn_hdl,
    hi_mapi_vpss_ext_chn_attr *ext_chn_attr);
td_s32 mapi_adapt_vpss_set_low_delay_attr(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_low_delay_info *low_delay);
td_s32 mapi_adapt_vpss_get_low_delay_attr(td_handle vpss_hdl, td_handle chn_hdl,
    hi_mapi_vpss_low_delay_info *low_delay);
/* internal buffer wrap (卷绕) info: buf_line/buf_size are computed internally, not exposed */
typedef struct {
    td_bool enable;
    td_u32  buf_line;
    td_u32  buf_size;
} mapi_vpss_buf_wrap_info;

td_s32 mapi_adapt_vpss_set_chn_buf_wrap(td_handle vpss_hdl, td_handle chn_hdl,
    const mapi_vpss_buf_wrap_info *info);
td_s32 mapi_adapt_vpss_get_chn_buf_wrap(td_handle vpss_hdl, td_handle chn_hdl,
    mapi_vpss_buf_wrap_info *info);
td_s32 mapi_adapt_vpss_set_wrap_grp_frame_interrupt(td_handle vpss_hdl, td_u32 max_height);
td_s32 mapi_adapt_vpss_enable_buffer_share(td_handle vpss_hdl, td_handle chn_hdl);
td_s32 mapi_adapt_vpss_disable_buffer_share(td_handle vpss_hdl, td_handle chn_hdl);
td_s32 mapi_adapt_vpss_enable_chn(td_handle vpss_hdl, td_handle chn_hdl);
td_s32 mapi_adapt_vpss_disable_chn(td_handle vpss_hdl, td_handle chn_hdl, td_u32 pool_id);
td_s32 mapi_adapt_vpss_set_grp_crop(td_handle vpss_hdl, const hi_mapi_vpss_crop_info *crop_info);
td_s32 mapi_adapt_vpss_set_chn_crop(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_crop_info *crop_info);
td_s32 mapi_adapt_vpss_get_grp_crop(td_handle vpss_hdl, hi_mapi_vpss_crop_info *crop_info);
td_s32 mapi_adapt_vpss_get_chn_crop(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_crop_info *crop_info);
td_s32 mapi_adapt_vpss_set_chn_mirror(td_handle vpss_hdl, td_handle chn_hdl, td_bool is_mirror);
td_s32 mapi_adapt_vpss_get_chn_mirror(td_handle vpss_hdl, td_handle chn_hdl, td_bool *is_mirror);
td_s32 mapi_adapt_vpss_set_chn_flip(td_handle vpss_hdl, td_handle chn_hdl, td_bool is_flip);
td_s32 mapi_adapt_vpss_get_chn_flip(td_handle vpss_hdl, td_handle chn_hdl, td_bool *is_flip);
td_s32 mapi_adapt_vpss_set_chn_rotation(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_rotation *vpss_rotation);
td_s32 mapi_adapt_vpss_get_chn_rotation(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_rotation *vpss_rotation);

td_s32 mapi_adapt_vpss_get_chn_ldc(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_ldc_attr *attr);
td_s32 mapi_adapt_vpss_set_chn_ldc(td_handle vpss_hdl, td_handle chn_hdl, const hi_mapi_vpss_ldc_attr *attr);
td_s32 mapi_adapt_vpss_get_chn_ldcv2(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_ldc_v2_attr *attr);
td_s32 mapi_adapt_vpss_set_chn_ldcv2(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_ldc_v2_attr *attr);
td_s32 mapi_adapt_vpss_get_chn_ldcv3(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_ldc_v3_attr *attr);
td_s32 mapi_adapt_vpss_set_chn_ldcv3(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_ldc_v3_attr *attr);

td_s32 mapi_adapt_vpss_get_chn_ldcv4(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_ldc_v4_attr *attr);
td_s32 mapi_adapt_vpss_set_chn_ldcv4(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_ldc_v4_attr *attr);
td_s32 mapi_adapt_vpss_set_chn_depth(td_handle vpss_hdl, td_handle chn_hdl, td_u32 depth);
td_s32 mapi_adapt_vpss_get_chn_depth(td_handle vpss_hdl, td_handle chn_hdl, td_u32 *depth);
td_s32 mapi_adapt_vpss_set_ext_chn_depth(td_handle vpss_hdl, td_handle chn_hdl, td_u32 depth);
td_s32 mapi_adapt_vpss_get_ext_chn_depth(td_handle vpss_hdl, td_handle chn_hdl, td_u32 *depth);
td_s32 mapi_adapt_vpss_send_frame(td_handle vpss_hdl, const hi_mapi_frame_data *frame_data, td_u32 time_ref);
td_u64 mapi_adapt_vpss_get_photo_virt_addr(td_u64 phy_addr, td_u32 size);
td_s32 mapi_adapt_vpss_release_photo_virt_addr(td_u64 vir_addr, td_u32 size);

#ifdef SUPPORT_IVE
td_s32 mapi_adapt_vpss_get_ive_vb(mapi_vpss_ive_param *ive_param, mapi_adapt_video_frame_info *frame_info);
td_s32 mapi_adapt_vpss_release_ive_vb(const mapi_vpss_ive_param *ive_param);
td_s32 mapi_adapt_vpss_get_ive_pipe_raw(const mapi_vpss_ive_param *ive_param,
    mapi_adapt_video_frame_info *frame_info);
td_s32 mapi_adapt_vpss_release_ive_pipe_raw(const mapi_vpss_ive_param *ive_param,
    const mapi_adapt_video_frame_info *frame_info);
td_s32 mapi_adapt_vpss_proc_ive_left_y_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, td_handle *ive_hdl, hi_mapi_yuv_data_seq vi_yuv_seq);
td_s32 mapi_adapt_vpss_proc_ive_right_y_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, td_handle *ive_hdl, hi_mapi_yuv_data_seq vi_yuv_seq);
td_s32 mapi_adapt_vpss_proc_ive_left_vu_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, td_handle *ive_hdl, hi_mapi_yuv_data_seq vi_yuv_seq);
td_s32 mapi_adapt_vpss_proc_ive_right_vu_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, td_handle *ive_hdl, hi_mapi_yuv_data_seq vi_yuv_seq);
td_s32 mapi_adapt_vpss_query_ive_status(td_handle ive_hdl);
td_s32 mapi_adapt_vpss_send_ive_frame(td_handle vpss_hdl, td_handle chn_hdl,
    const mapi_adapt_video_frame_info *frame_info);
#endif
td_s32 mapi_adapt_vpss_get_gdc(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_gdc_param *param);
td_s32 mapi_adapt_vpss_set_gdc(td_handle vpss_hdl, td_handle chn_hdl, const hi_mapi_vpss_gdc_param *param);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif /* __HI_MAPI_VPSS_ADAPT_H__ */
