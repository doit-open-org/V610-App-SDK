/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AUDIO_COMP_CODEC_H
#define AUDIO_COMP_CODEC_H

#include "hi_mw_type.h"
#include "hi_mapi_comm_define.h"    /* hi_mapi_audio_format */

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

/* Provider ops table.
 *
 * `aenc_register` is invoked when a pipeline AENC channel is initialised with
 * this provider's format and the provider has been selected as active for
 * that (format, direction) pair.  Mirror semantics for `adec_register`.
 * Either pointer may be NULL when the provider is one-directional (e.g. a
 * pure decoder library would leave aenc_register NULL).
 *
 * The exact signature passed to encoder/decoder registration is captured in
 * the SDK adp headers (ot_aenc_encoder / ot_adec_decoder); for the P1
 * skeleton step we keep the callbacks opaque `void *` so providers can be
 * stubbed in without committing to the final wrapper rewrite shape.  The
 * T10.2 migration will type-strengthen these once the existing
 * adpt_aenc_aac / adpt_aenc_mp3 / adpt_adec_aac / adpt_adec_mp3 wrappers
 * move under audio_comp/codec/.
 */
typedef struct {
    hi_mapi_audio_format format;
    const char *backend_name;        /* e.g. "sdk", "fdk", "lame" */

    int (*aenc_register)(void *out_encoder);     /* NULL = decode-only */
    int (*adec_register)(void);                   /* NULL = encode-only */
    int (*aenc_unregister)(void);                 /* NULL = decode-only */
    int (*adec_unregister)(void);                 /* NULL = encode-only */
} audio_comp_codec_ops_t;

/* Provider registry. */

int audio_comp_codec_register(const char *name, const audio_comp_codec_ops_t *ops);
const audio_comp_codec_ops_t *audio_comp_codec_get_ops(const char *name);
int audio_comp_codec_set_active(const char *name);
const audio_comp_codec_ops_t *audio_comp_codec_get_active(void);

/* Convenience: find the active provider that matches a given format.
 * Returns NULL if no registered provider matches. */
const audio_comp_codec_ops_t *audio_comp_codec_find_by_format(hi_mapi_audio_format format);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif /* AUDIO_COMP_CODEC_H */
