/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_OSD_ADAPT_H__
#define __HI_MAPI_OSD_ADAPT_H__

#include "mapi_osd_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

td_s32 mapi_adapt_osd_detach_rgn(td_u32 osd_idx, const hi_mapi_osd_disp_attr *disp_attr);
td_s32 mapi_adapt_osd_destroy_rgn(td_u32 osd_idx);
td_s32 mapi_adapt_osd_create_rgn(td_u32 osd_idx, const mapi_adapt_osd_rgn_attr *rgn_attr);
td_s32 mapi_adapt_osd_set_rgn_bitmap(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr);
td_s32 mapi_adapt_osd_get_canvas_info(td_u32 osd_idx, mapi_comm_text_bitmap *osd_text);
td_s32 mapi_adapt_osd_update_canvas(td_u32 osd_idx);
td_s32 mapi_adapt_osd_get_image_size(const mapi_adapt_osd_chn_bind_info *chn_info, hi_mapi_size *img_size);
td_s32 mapi_adapt_osd_attach_rgn_to_chn(td_u32 osd_idx, const mapi_adapt_osd_rgn_chn_attr *rgn_chn_attr,
    const hi_mapi_osd_disp_attr *disp_attr);
td_s32 mapi_adapt_osd_set_display_attr(td_u32 osd_idx, const mapi_adapt_osd_rgn_chn_attr *rgn_chn_attr,
    const hi_mapi_osd_disp_attr *disp_attr);
#ifdef SUPPORT_AVS
td_s32 mapi_adapt_osd_get_stitch_mode(td_handle stitch_hdl, hi_mapi_vpss_stitch_mode *stitch_mode);
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* __HI_MAPI_OSD_ADAPT_H__ */
