/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VCAP_ADAPT_H__
#define __HI_MAPI_VCAP_ADAPT_H__

#include "mapi_vcap_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/* vcap modlule interface */
td_s32 mapi_adapt_vcap_set_isp_mode_param(const hi_mapi_isp_param_mode *isp_mod_param);
td_s32 mapi_adapt_vcap_get_vi_vpss_mode(td_handle vcap_pipe_hdl, hi_mapi_vi_vpss_mode *work_mode);
td_bool mapi_adapt_vcap_is_bt656_mode(input_mode_t input_mode);
td_s32 mapi_adapt_vcap_set_frame_rate(td_handle vcap_pipe_hdl, td_float frame_rate);
td_s32 mapi_adapt_vcap_set_dev_static_attr(td_handle vcap_dev_hdl, const hi_mapi_vcap_attr *vcap_attr,
    const combo_dev_attr_t *combo_dev_attr);
td_s32 mapi_adapt_vcap_set_pipe_dynamic_attr(td_handle vcap_pipe_hdl, const hi_mapi_vcap_pipe_attr *vcap_pipe_attr);
td_s32 mapi_adapt_vcap_set_frame_int_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_frame_interrupt_attr *frame_int_attr);
td_s32 mapi_adapt_vcap_set_isp_pub_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_pub_attr *vcap_isp_pub_attr);
td_s32 mapi_adapt_vcap_get_isp_pub_attr(td_handle vcap_pipe_hdl, hi_mapi_vcap_isp_pub_attr *vcap_isp_pub_attr);
td_s32 mapi_adapt_vcap_query_isp_state(td_handle vcap_pipe_hdl, mapi_vcap_isp_inner_state *isp_inner_state);
td_s32 mapi_adapt_vcap_set_isp_interval(td_handle vcap_pipe_hdl, td_u32 isp_stat_intvl);
td_s32 mapi_adapt_vcap_set_chn_dynamic_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_pipe_chn_attr *vcap_chn_attr);
td_s32 mapi_adapt_vcap_set_chn_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl);
td_s32 mapi_adapt_vcap_get_chn_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    mapi_vcap_pipe_chn_attr *vcap_chn_attr);
td_s32 mapi_adapt_vcap_start_dev(td_handle vcap_dev_hdl);
td_s32 mapi_adapt_vcap_stop_dev(td_handle vcap_dev_hdl);
td_s32 mapi_adapt_vcap_set_dev_bind_pipe(td_handle vcap_dev_hdl, td_u32 pipe_bind_num, const td_handle pipe_id_bind[],
    td_u32 array_len);
td_s32 mapi_adapt_vcap_set_pipe_vc_number(td_handle vcap_pipe_hdl, td_u32 bind_vc_num);
td_s32 mapi_adapt_vcap_get_pipe_vc_number(td_handle vcap_pipe_hdl, td_u32 *bind_vc_num);
td_s32 mapi_adapt_vcap_create_pipe(td_handle vcap_pipe_hdl,
    const mapi_vcap_pipe_attr *vcap_pipe_attr);
td_s32 mapi_adapt_vcap_destroy_pipe(td_handle vcap_dev_hdl, td_handle vcap_pipe_hdl);
td_s32 mapi_adapt_vcap_start_pipe(td_handle vcap_pipe_hdl, td_u32 pool_id);
td_s32 mapi_adapt_vcap_stop_pipe(td_handle vcap_pipe_hdl, td_u32 pool_id);
td_s32 mapi_adapt_vcap_start_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, td_u32 pool_id);
td_s32 mapi_adapt_vcap_stop_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, td_u32 pool_id);
td_s32 mapi_adapt_vcap_get_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_frame_data *frame_data, td_s32 milli_sec);
td_s32 mapi_adapt_vcap_release_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_frame_data *frame_data);
td_s32 mapi_adapt_vcap_set_chn_depth(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, td_u32 depth);
td_s32 mapi_adapt_vcap_get_chn_depth(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, td_u32 *depth);
td_s32 mapi_adapt_vcap_set_pipe_low_delay(td_handle vcap_pipe_hdl, const hi_mapi_vcap_low_delay_info *info);
td_s32 mapi_adapt_vcap_get_pipe_low_delay(td_handle vcap_pipe_hdl, hi_mapi_vcap_low_delay_info *info);
td_s32 mapi_adapt_vcap_set_chn_low_delay(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_low_delay_info *info);
td_s32 mapi_adapt_vcap_get_chn_low_delay(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_vcap_low_delay_info *info);
/* internal buffer wrap (卷绕) info: buf_line is computed internally, not exposed */
typedef struct {
    td_bool enable;
    td_u32  buf_line;
} mapi_vcap_buf_wrap_info;

td_s32 mapi_adapt_vcap_set_pipe_buf_wrap(td_handle vcap_pipe_hdl, const mapi_vcap_buf_wrap_info *info);
td_s32 mapi_adapt_vcap_get_pipe_buf_wrap(td_handle vcap_pipe_hdl, mapi_vcap_buf_wrap_info *info);

td_s32 mapi_adapt_vcap_set_isp_sns_init(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_sensor_attr *sensor_attr);
td_s32 mapi_adapt_vcap_reg_isp_sns_callback(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_sensor_attr *sensor_attr);
td_s32 mapi_adapt_vcap_unreg_isp_sns_callback(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_sensor_attr *sensor_attr);
td_void mapi_adapt_vcap_set_sns_bus_info(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_sensor_comm_bus_type sns_comm_bus_type, td_s32 sns_bus_id);

td_void mapi_adapt_vcap_set_sns_mirror_flip(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_sns_mirror_flip_type sns_mirror_flip, const hi_mapi_vcap_sensor_attr *sensor_attr);
td_s32 mapi_adapt_vcap_init_isp_mem(td_handle vcap_pipe_hdl);
td_s32 mapi_adapt_vcap_register_isp_3a(td_handle vcap_pipe_hdl);
td_s32 mapi_adapt_vcap_unregister_isp_3a(td_handle vcap_pipe_hdl);
td_s32 mapi_adapt_vcap_init_isp(td_handle vcap_pipe_hdl);
td_s32 mapi_adapt_vcap_start_isp(td_handle vcap_pipe_hdl);
td_s32 mapi_adapt_vcap_stop_isp(td_handle vcap_pipe_hdl);

td_s32 mapi_adapt_vcap_set_stitch_attr(td_handle vcap_stitch_hdl, const hi_mapi_vcap_stitch_grp_attr *vcap_stitch_attr);
td_s32 mapi_adapt_vcap_get_stitch_attr(td_handle vcap_stitch_hdl, hi_mapi_vcap_stitch_grp_attr *vcap_stitch_attr);
td_s32 mapi_adapt_vcap_set_contrast(td_handle vcap_pipe_hdl, const hi_mapi_vcap_contrast *vcap_contrast);
td_s32 mapi_adapt_vcap_get_contrast(td_handle vcap_pipe_hdl, hi_mapi_vcap_contrast *vcap_contrast);
td_s32 mapi_adapt_vcap_set_gps_info(const hi_mapi_vcap_gps_info *vcap_gps_info);
td_s32 mapi_adapt_vcap_get_gps_info(hi_mapi_vcap_gps_info *vcap_gps_info);
td_s32 mapi_adapt_vcap_set_exposure(td_handle vcap_pipe_hdl, const hi_mapi_vcap_exposure_attr *vcap_exposure);
td_s32 mapi_adapt_vcap_get_exposure(td_handle vcap_pipe_hdl, hi_mapi_vcap_exposure_attr *vcap_exposure);
td_s32 mapi_adapt_vcap_get_exposure_info(td_handle vcap_pipe_hdl, hi_mapi_vcap_exposure_info *exposure_info);
td_s32 mapi_adapt_vcap_set_wb(td_handle vcap_pipe_hdl, const hi_mapi_vcap_wb_attr *vcap_wb_attr);
td_s32 mapi_adapt_vcap_get_wb_info(td_handle vcap_pipe_hdl, hi_mapi_vcap_isp_wb_info *vcap_wb_info);
td_s32 mapi_adapt_vcap_set_rotation(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_rotation *vcap_rotation);
td_s32 mapi_adapt_vcap_get_rotation(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_rotation *vcap_rotation);
td_s32 mapi_adapt_vcap_set_mirror_flip(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_mirror_flip_attr *mirror_flip_attr);
td_s32 mapi_adapt_vcap_set_ldc_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_ldc_attr *vcap_ldc_attr);
td_s32 mapi_adapt_vcap_get_ldc_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_vcap_ldc_attr *vcap_ldc_attr);

td_s32 mapi_adapt_vcap_set_isp_dng_color_param(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_dng_color_param *vcap_dng_color_param);
td_s32 mapi_adapt_vcap_get_isp_dng_color_param(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_dng_color_param *vcap_dng_color_param);
td_s32 mapi_adapt_vcap_set_isp_debug(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_cmd command, const hi_mapi_vcap_isp_debug_info *vcap_isp_debug_info);
td_s32 mapi_adapt_vcap_set_saturation(td_handle vcap_pipe_hdl, const hi_mapi_vcap_saturation *vcap_saturation);
td_s32 mapi_adapt_vcap_get_saturation(td_handle vcap_pipe_hdl, hi_mapi_vcap_saturation *vcap_saturation);
td_s32 mapi_adapt_vcap_set_luma(td_handle vcap_pipe_hdl, const hi_mapi_vcap_luma *vcap_luma);
td_s32 mapi_adapt_vcap_get_luma(td_handle vcap_pipe_hdl, hi_mapi_vcap_luma *vcap_luma);
td_s32 mapi_adapt_vcap_set_sharpen(td_handle vcap_pipe_hdl, const hi_mapi_vcap_sharpen *vcap_sharpen);
td_s32 mapi_adapt_vcap_get_sharpen(td_handle vcap_pipe_hdl, hi_mapi_vcap_sharpen *vcap_sharpen);
td_s32 mapi_adapt_vcap_set_metering_mode(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_metering_mode *vcap_metering_mode);
td_s32 mapi_adapt_vcap_get_metering_mode(td_handle vcap_pipe_hdl, hi_mapi_vcap_metering_mode *vcap_metering_mode);
td_s32 mapi_adapt_vcap_set_isp_wdr_fs_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_wdr_fs_attr *vcap_wdr_fs_attr);
td_s32 mapi_adapt_vcap_get_isp_wdr_fs_attr(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_wdr_fs_attr *vcap_wdr_fs_attr);
td_s32 mapi_adapt_vcap_set_isp_pipe_diff_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_pipe_diff_attr *vcap_pipe_diff_attr);
td_s32 mapi_adapt_vcap_get_isp_pipe_diff_attr(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_pipe_diff_attr *vcap_pipe_diff_attr);
td_s32 mapi_adapt_vcap_set_isp_local_cac_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_local_cac_attr *vcap_local_cac_attr);
td_s32 mapi_adapt_vcap_get_isp_local_cac_attr(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_local_cac_attr *vcap_local_cac_attr);
td_void mapi_adapt_vcap_enter_standby(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_sensor_attr *sensor_attr);
td_void mapi_adapt_vcap_restart_sensor(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_sensor_attr *sensor_attr);
td_s32 mapi_adapt_vcap_get_dng_image_static_info(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_dng_image_static_info *vcap_dng_info);
td_s32 mapi_adapt_vcap_get_cmp_param(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_cmp_param *vcap_cmp_param);
td_s32 mapi_adapt_vcap_set_chn_crop_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_crop_info *vcap_crop_info);
td_s32 mapi_adapt_vcap_get_chn_crop_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_vcap_crop_info *vcap_crop_info);

td_s32 mapi_adapt_vcap_set_pipe_dump_attr(td_handle vcap_pipe_hdl, const hi_mapi_dump_attr *vcap_dump_info);

#if 0
/* RAW dump-related adapt APIs - external 6 APIs deleted, kept under #if 0 for future restore */
td_s32 mapi_adapt_vcap_set_pipe_dump_attr(td_handle vcap_pipe_hdl, const hi_mapi_dump_attr *vcap_dump_info);
td_s32 mapi_adapt_vcap_set_pipe_bnr_raw_dump_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_bnr_dump_attr *vcap_dump_bnr_attr);
td_s32 mapi_adapt_vcap_get_pipe_raw(td_handle vcap_pipe_hdl, td_bool is_bnr_raw,
    td_u32 frame_timeout, hi_mapi_frame_data *frame_data);
td_s32 mapi_adapt_vcap_release_pipe_raw(td_handle vcap_pipe_hdl, td_bool is_bnr_raw,
    const hi_mapi_frame_data *frame_data);
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_VCAP_ADAPT_H__ */
