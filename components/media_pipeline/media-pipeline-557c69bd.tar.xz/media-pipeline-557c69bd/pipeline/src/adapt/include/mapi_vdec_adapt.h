/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VDEC_ADAPT_H__
#define __HI_MAPI_VDEC_ADAPT_H__

#include "hi_mapi_vdec_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

td_s32 mapi_adapt_vdec_set_mod_param(td_void);
td_s32 mapi_adapt_vdec_create_chn(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr);
td_s32 mapi_adapt_vdec_destroy_chn(td_handle vdec_hdl);
td_s32 mapi_adapt_vdec_reset_chn(td_handle vdec_hdl);
td_s32 mapi_adapt_vdec_start(td_handle vdec_hdl);
td_s32 mapi_adapt_vdec_stop(td_handle vdec_hdl);
td_s32 mapi_adapt_vdec_get_fd(td_handle vdec_hdl);
td_s32 mapi_adapt_vdec_query_status(td_handle vdec_hdl, hi_mapi_vdec_status *status);
td_s32 mapi_adapt_vdec_set_attr(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr);
td_s32 mapi_adapt_vdec_get_attr(td_handle vdec_hdl, hi_mapi_vdec_attr *vdec_attr);
td_s32 mapi_adapt_vdec_set_param(td_handle vdec_hdl, const hi_mapi_vdec_param *vdec_param);
td_s32 mapi_adapt_vdec_get_param(td_handle vdec_hdl, hi_mapi_vdec_param *vdec_param);
td_s32 mapi_adapt_vdec_send_stream(td_handle vdec_hdl, const hi_mapi_vdec_stream *stream, td_s32 timeout);
td_s32 mapi_adapt_vdec_get_frame(td_handle vdec_hdl, hi_mapi_frame_data *frame_data, td_u32 timeout);
td_s32 mapi_adapt_vdec_release_frame(td_handle vdec_hdl, const hi_mapi_frame_data *frame_data);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* __HI_MAPI_VDEC_ADAPT_H__ */
