/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AEC_REF_BUS_H
#define AEC_REF_BUS_H

#include "hi_mw_type.h"
#include <stdint.h>

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

/*
 * AEC 参考总线（AO 播放 -> ACAP 软件 AFE 的回声参考旁路）
 *
 * 单声道 / 16kHz / int16 的 FIFO，在 AO 播放路径（生产者，audio_comp_ao_send_frame）
 * 与 ACAP 软件 AFE 路径（消费者，audio_comp_acap_get_software_frame）之间传递
 * "正在播放的远端 PCM"。当内置 CODEC + 外部软件 AFE（如云知声 SSP）场景下，
 * SDK raw 帧不携带 AEC 参考、内置又无物理回采通道时，软件 AEC 用它作为回声参考。
 *
 * 说明：
 * - 本总线只做生产/消费的速率匹配（AO 与 AI 同为 16kHz，长期速率一致）；
 *   回声路径的精确延时由 AFE 引擎自身的延时估计负责（见 unisound SSP 的
 *   SSP_ID_RES_SET_DELAY_FRANES），本总线不做样本级对齐。
 * - 单生产者(AO线程) / 单消费者(ACAP线程)，内部用互斥量保护。
 * - 由消费者在识别到"内置 + 外部软件 AFE"路径时惰性使能；其余场景（hisi /
 *   ES7210 物理回采）总线保持关闭，生产者零开销。
 */

/* 使能/关闭总线；关闭同时清空缓冲。 */
void aec_ref_bus_set_enabled(td_bool enable);
td_bool aec_ref_bus_enabled(void);

/* 生产者：追加 samples 个 mono int16 样本（16kHz）。未使能时为空操作。
 * 缓冲满时丢弃最旧样本（保持参考"新鲜"）。 */
void aec_ref_bus_write(const int16_t *pcm, uint32_t samples);

/* 消费者：弹出恰好 samples 个 mono int16 样本到 out。
 * 数据充足返回 0；欠帧返回 -1（out 不改动，调用方应补零）。 */
int aec_ref_bus_read(int16_t *out, uint32_t samples);

/* 清空缓冲（起停时使用）。 */
void aec_ref_bus_reset(void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif /* AEC_REF_BUS_H */
