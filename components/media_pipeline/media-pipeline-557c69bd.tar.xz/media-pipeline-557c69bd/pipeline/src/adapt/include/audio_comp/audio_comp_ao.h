/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_AO_ADAPT_H__
#define __MAPI_AO_ADAPT_H__

#include "hi_mapi_ao_define.h"
#include "mapi_ao_inner.h"
#include "hi_mapi_audio_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 audio_comp_ao_set_pub_attr(td_handle ao_hdl, const mapi_ao_server_context *ao_context,
                                  const hi_mapi_ao_attr *ao_attr);
td_s32 audio_comp_ao_enable(td_handle ao_hdl);
td_s32 audio_comp_ao_disable(td_handle ao_hdl);
td_s32 audio_comp_ao_enable_chn(td_handle ao_hdl, td_handle ao_chn_hdl);
td_s32 audio_comp_ao_disable_chn(td_handle ao_hdl, td_handle ao_chn_hdl);
td_s32 audio_comp_ao_enable_resmp(td_handle ao_hdl, td_handle ao_chn_hdl, hi_mapi_audio_sample_rate sample_rate);
td_s32 audio_comp_ao_disable_resmp(td_handle ao_hdl, td_handle ao_chn_hdl);
td_s32 audio_comp_ao_start(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_ao_attr *ao_attr);
td_s32 audio_comp_ao_stop(td_handle ao_hdl);
#ifdef SUPPORT_TALKVQE
td_s32 audio_comp_ao_enable_vqe(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_ao_vqe_attr *ao_vqe_attr,
                                const hi_mapi_ao_attr *ao_attr, td_u32 open_mask);
td_s32 audio_comp_ao_disable_vqe(td_handle ao_hdl, td_handle ao_chn_hdl);
#endif
td_s32 audio_comp_ao_set_mute(td_handle ao_hdl, td_bool enable);
td_s32 audio_comp_ao_send_frame(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_audio_frame *audio_frame,
                                td_u32 timeout);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_AO_ADAPT_H__ */
