/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_COMM_ADAPT_H__
#define __HI_MAPI_COMM_ADAPT_H__

#include "ot_buffer.h"
#include "hi_mapi_comm_define.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 mapi_adapt_comm_dlopen(td_void **lib_handle, td_char *lib_name);
td_s32 mapi_adapt_comm_dlsym(td_void **func_handle, td_void *lib_handle, td_char *func_name);
td_s32 mapi_adapt_comm_dlclose(td_void *lib_handle);
td_void mapi_adapt_comm_frame_info_to_mpi(const hi_mapi_frame_data *frame_data, ot_video_frame_info *frame_info);
td_void mapi_adapt_comm_frame_info_to_mapi(const ot_video_frame_info *frame_info, hi_mapi_frame_data *frame_data);

td_void *mapi_adapt_comm_mmap(td_u64 phy_addr, td_u32 size);
td_void *mapi_adapt_comm_mmap_cached(td_u64 phy_addr, td_u32 size);
td_s32 mapi_adapt_comm_munmap(td_void *vir_addr, td_u32 size);

td_u32 mapi_adapt_comm_create_vb_pool(ot_pic_buf_attr *frame_attr, td_u32 blk_cnt);
td_s32 mapi_adapt_comm_destroy_vb_pool(ot_vb_pool pool_id);

ot_pixel_format mapi_adapt_comm_pixel_format_convert(hi_mapi_pixel_format mapi_pixel_format);
ot_video_format mapi_adapt_comm_video_format_convert(hi_mapi_video_format mapi_video_format);
ot_compress_mode mapi_adapt_comm_compress_mode_convert(hi_mapi_compress_mode mapi_compress_mode);

td_u32 mapi_adapt_comm_vb_get_buffer_size(mapi_buf_type type, const td_void *attr, td_u32 attr_len);

/* Buffer wrap (卷绕) helpers, shared by media-init VB sizing and start-time apply. */
typedef struct {
    const mapi_pic_buf_attr *large_attr; /* chn0 */
    hi_mapi_size small_size;             /* chn1 */
    td_u32  full_lines_std;
    td_u32  frame_rate;
    td_bool all_online;
} mapi_vpss_wrap_calc_param;

td_void mapi_adapt_comm_set_vpss_wrap_buf_attr(mapi_pic_buf_attr *attr, td_u32 width, td_u32 height);
td_s32 mapi_adapt_comm_get_vpss_wrap_buf(const mapi_vpss_wrap_calc_param *param,
    td_u32 *buf_line, td_u32 *buf_size);
td_s32 mapi_adapt_comm_get_vi_wrap_buf_lines(const hi_mapi_size *pipe_size, const td_u32 *full_lines_std,
    const td_u32 *frame_rate, td_u32 dev_num, td_u32 *buf_line_out);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_COMM_ADAPT_H__ */
