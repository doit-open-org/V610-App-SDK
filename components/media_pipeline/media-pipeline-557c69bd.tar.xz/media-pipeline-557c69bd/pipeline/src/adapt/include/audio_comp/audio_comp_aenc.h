/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_AENC_ADAPT_H__
#define __MAPI_AENC_ADAPT_H__

#include "hi_mapi_aenc_define.h"
#include "hi_mapi_audio_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 audio_comp_aenc_create_chn(td_handle aenc_hdl, const hi_mapi_aenc_attr *aenc_attr);
td_s32 audio_comp_aenc_destroy_chn(td_handle aenc_hdl);
td_s32 audio_comp_aenc_register_audio_encoder(td_s32 *encoder_hdl, hi_mapi_audio_format audio_format);
td_s32 audio_comp_aenc_unregister_audio_encoder(td_s32 encoder_hdl);
td_s32 audio_comp_aenc_send_frame(td_handle aenc_hdl, const hi_mapi_audio_frame *audio_frm);
td_s32 audio_comp_aenc_get_fd(td_handle aenc_hdl);
/*
 * payload_format selects HI_NATIVE (default, raw SDK packing with the
 * Hisi-private 8-byte big-endian length header on each OPUS frame) or STANDARD
 * (bare RFC 7587 OPUS RTP payload, header stripped on egress and restored
 * before SDK release).
 * Non-OPUS aenc_format MUST pass HI_NATIVE; checked at the public API entry
 * (hi_mapi_aenc_set_param).
 */
td_s32 audio_comp_aenc_get_stream(td_handle aenc_hdl, hi_mapi_audio_stream *stream,
                                   hi_mapi_audio_payload_format payload_format);
td_s32 audio_comp_aenc_release_stream(td_handle aenc_hdl, const hi_mapi_audio_stream *stream,
                                       hi_mapi_audio_payload_format payload_format);
td_s32 audio_comp_aenc_get_stream_buf_info(td_handle aenc_hdl, td_u64 *phys_addr, td_u32 *size);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_AENC_ADAPT_H__ */
