/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VGS_ADAPT_H__
#define __HI_MAPI_VGS_ADAPT_H__

#include "hi_mapi_vgs_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

td_s32 mapi_adapt_vgs_begin_job(td_handle *vgs_hdl);
td_s32 mapi_adapt_vgs_add_scale_task(td_handle vgs_hdl, const hi_mapi_vgs_scale_task_attr *scale_task_attr);
td_s32 mapi_adapt_vgs_add_draw_line_task(td_handle vgs_hdl, const hi_mapi_vgs_draw_line_task_attr *draw_line_task_attr);
td_s32 mapi_adapt_vgs_add_cover_task(td_handle vgs_hdl, const hi_mapi_vgs_cover_task_attr *cover_task_attr);
td_s32 mapi_adapt_vgs_create_rgn(td_handle rgn_hdl, const hi_mapi_vgs_rgn_attr *vgs_rgn_attr);
td_s32 mapi_adapt_vgs_destroy_rgn(td_handle rgn_hdl);
td_s32 mapi_adapt_vgs_add_osd_task(td_handle vgs_hdl, const hi_mapi_vgs_osd_task_attr *osd_task_attr);
td_s32 mapi_adapt_vgs_end_job(td_handle vgs_hdl);
td_s32 mapi_adapt_vgs_cancel_job(td_handle vgs_hdl);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* __HI_MAPI_VGS_ADAPT_H__ */
