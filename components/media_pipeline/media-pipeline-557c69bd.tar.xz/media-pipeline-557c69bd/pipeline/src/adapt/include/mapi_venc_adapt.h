/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef mapi_venc_adapt_h
#define mapi_venc_adapt_h

#include "mapi_venc_inner.h"
#include "mapi_venc_adapt_define.h"

/* 按协议即时配置/回读 SDK mod_param（jpeg 含 mjpeg）。入参为 adapt 层统一封装结构，协议由接口区分。
 * set 内部先 get 全量再改受管理字段，避免覆盖 vb_src/qp_hist_en/clear_stream_buf 等其它字段。
 * 上层可「先 get 再改单个字段再 set」。jpeg 接口忽略 low_power_mode（SDK jpeg mod_param 无此字段）。 */
td_s32 mapi_adapt_venc_set_h264_mod_param(const mapi_adapt_venc_mod_param *venc_mod_para);
td_s32 mapi_adapt_venc_set_h265_mod_param(const mapi_adapt_venc_mod_param *venc_mod_para);
td_s32 mapi_adapt_venc_set_jpeg_mod_param(const mapi_adapt_venc_mod_param *venc_mod_para);
td_s32 mapi_adapt_venc_get_h264_mod_param(mapi_adapt_venc_mod_param *venc_mod_para);
td_s32 mapi_adapt_venc_get_h265_mod_param(mapi_adapt_venc_mod_param *venc_mod_para);
td_s32 mapi_adapt_venc_get_jpeg_mod_param(mapi_adapt_venc_mod_param *venc_mod_para);
td_s32 mapi_adapt_venc_config_attr(const hi_mapi_venc_attr *venc_attr, mapi_adapt_venc_chn_attr *vencChnAttr,
    td_bool rcnRefShareBuf);
td_s32 mapi_adapt_venc_create_chn(td_handle vencHdl, const hi_mapi_venc_attr *venc_attr,
    td_bool rcnRefShareBuf);
td_s32 mapi_adapt_venc_destroy_chn(td_handle vencHdl);
td_s32 mapi_adapt_venc_close_reencode(td_handle vencHdl, hi_mapi_payload_type payload_type,
    hi_mapi_venc_rc_mode rc_mode);
td_s32 mapi_adapt_venc_set_scene_mode(td_handle vencHdl, hi_mapi_venc_scene_mode scene_mode);
td_s32 mapi_adapt_venc_set_h265_trans(td_handle vencHdl);
td_s32 mapi_adapt_venc_set_jpeg_param(td_handle vencHdl, const hi_mapi_venc_jpeg_attr *jpeg_attr);
td_s32 mapi_adapt_venc_set_stream_max_cnt(td_handle vencHdl);
td_s32 mapi_adapt_venc_start_recv_frame(td_handle vencHdl, td_s32 frame_cnt);
td_s32 mapi_adapt_venc_stop_recv_frame(td_handle vencHdl);
td_s32 mapi_adapt_venc_reset_chn(td_handle vencHdl);
td_s32 mapi_adapt_venc_set_attr(td_handle vencHdl, hi_mapi_venc_rc_mode originalRcMode,
    const hi_mapi_venc_attr *venc_attr);
td_s32 mapi_adapt_venc_request_idr(td_handle vencHdl);
td_s32 mapi_adapt_venc_get_rc_param(td_handle vencHdl, hi_mapi_venc_rc_mode rc_mode,
    hi_mapi_payload_type type, hi_mapi_venc_rc_param *rcParam);
td_s32 mapi_adapt_venc_set_rc_param(td_handle vencHdl, hi_mapi_venc_rc_mode rc_mode,
    hi_mapi_payload_type type, const hi_mapi_venc_rc_param *rcParam);
td_s32 mapi_adapt_venc_set_gop_attr(td_handle vencHdl, const hi_mapi_venc_gop_attr *vencGopAttr);
td_s32 mapi_adapt_venc_get_gop_attr(td_handle vencHdl, hi_mapi_venc_gop_attr *vencGopAttr);
td_s32 mapi_adapt_venc_set_intra_refresh(td_handle vencHdl, const hi_mapi_venc_intra_refresh *intraRefresh);
td_s32 mapi_adapt_venc_get_intra_refresh(td_handle vencHdl, hi_mapi_venc_intra_refresh *intraRefresh);
td_s32 mapi_adapt_venc_set_frame_rate(td_handle vencHdl, const hi_mapi_frame_rate_ctrl *vencFrameRate);
td_s32 mapi_adapt_venc_get_frame_rate(td_handle vencHdl, hi_mapi_frame_rate_ctrl *vencFrameRate);
td_s32 mapi_adapt_venc_set_hierarchical_qp(td_handle vencHdl, const hi_mapi_venc_hierarchical_qp *hierarchicalQp);
td_s32 mapi_adapt_venc_get_hierarchical_qp(td_handle vencHdl, hi_mapi_venc_hierarchical_qp *hierarchicalQp);
td_s32 mapi_adapt_venc_set_frame_lost_strategy(td_handle vencHdl, const td_bool *isOpenFrmLost);
td_s32 mapi_adapt_venc_get_frame_lost_strategy(td_handle vencHdl, td_bool *isOpenFrmLost);
td_s32 mapi_adapt_venc_send_frame(td_handle vencHdl, const hi_mapi_frame_data *frameData,
    td_u32 time_ref, td_s32 timeout);
td_s32 mapi_adapt_venc_get_stream_buf_info(td_handle vencHdl, mapi_adapt_venc_stream_buf_info *streamBufInfo);
td_s32 mapi_adapt_venc_query_status(td_handle vencHdl, mapi_adapt_venc_status *status);
td_s32 mapi_adapt_venc_get_fd(td_handle venchdl);
td_s32 mapi_adapt_venc_get_stream(td_handle vencHdl, mapi_adapt_venc_pack *streamPack, td_u32 pack_count,
    mapi_adapt_venc_stream *stream);
td_s32 mapi_adapt_venc_release_stream(td_handle vencHdl, mapi_adapt_venc_stream *stream);
td_s32 mapi_adapt_venc_config_out_stream_data(hi_mapi_payload_type type,
    const mapi_adapt_venc_stream_buf_info *streamBufInfo, const mapi_adapt_venc_stream *stream,
    hi_mapi_venc_data_attr *outVStream);

#endif
