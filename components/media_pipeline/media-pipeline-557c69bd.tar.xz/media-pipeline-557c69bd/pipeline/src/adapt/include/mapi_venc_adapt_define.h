/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef MAPI_VENC_ADAPT_DEFINE_H
#define MAPI_VENC_ADAPT_DEFINE_H

#include "ss_mpi_venc.h"
#include "ot_common_venc.h"
#include "mapi_venc_inner.h"

#define VENC_SCENEMODE_TO_MPI(scenemode) (((scenemode) - HI_MAPI_VENC_SCENE_MODE_NORMAL) + OT_VENC_SCENE_0)

/* the information of the stream */
typedef struct {
    /* Start physical address for a stream buffer */
    td_u64  phy_addr[MAPI_ADAPT_VENC_MAX_TILE_NUM];
    /* Start virtual address for a stream buffer */
    td_void MAPI_ALIGN_ATTRIBUTE* userAddr[MAPI_ADAPT_VENC_MAX_TILE_NUM];
    /* Stream buffer size */
    td_u64  MAPI_ALIGN_ATTRIBUTE buf_size[MAPI_ADAPT_VENC_MAX_TILE_NUM];
} mapi_adapt_venc_stream_buf_info;

typedef ot_venc_stream mapi_adapt_venc_stream;
typedef ot_venc_pack mapi_adapt_venc_pack;
typedef ot_venc_chn_attr mapi_adapt_venc_chn_attr;

/* adapt 层 venc mod 参数封装：合并各协议公共字段 + 罗列差异字段。
 * 协议不在结构中标识，由调用的 set/get_{h264,h265,jpeg}_mod_param 接口决定。 */
typedef struct {
    td_u32 one_stream_buf;  /* 单码流 buffer 模式 */
    td_u32 mini_buf_mode;   /* 最小码流 buffer 模式: 0 disable, 1 enable */
    td_u32 low_power_mode;  /* H264/H265 低功耗模式 Range:[0,2] */
} mapi_adapt_venc_mod_param;

/* the status of the venc chnl */
typedef struct {
    hi_mapi_payload_type type;                  /* video stream type */
    td_u32 left_pics;                           /* left picture number */
    td_u32 left_stream_frames;                   /* left stream frames */
    td_u32 curPacks;                           /* pack number of current frame */
    td_u32 leftRecvPics;                       /* Number of frames to be received. */
    td_u32 leftEncPics;                        /* Number of frames to be encoded.  */
    td_bool jpegSnapEnd;                       /* the end of Snap. */
} mapi_adapt_venc_status;

#endif
