/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __AUDIO_COMP_OPUS_H__
#define __AUDIO_COMP_OPUS_H__

#include "hi_mapi_comm_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/* Size of the Hisi-private big-endian length header preceding each OPUS frame
 * in HI_NATIVE payload format. */
#define AUDIO_COMP_OPUS_HEADER_SIZE 8U

/* Per-channel temp buffer ceiling used on the ADEC ingress path when STANDARD
 * payload arrives and needs the header prepended before being forwarded to the
 * SDK decoder.  Sized as a conservative upper bound on an OPUS frame at
 * 48 kHz / stereo / 120 ms (~3 KB observed) plus margin.  Adjust if SDK
 * documentation pins a tighter or larger figure. */
#define AUDIO_COMP_OPUS_MAX_PACKET_SIZE 4096U

/* Hisi private OPUS frame header: byte[0..3] = big-endian packet length, byte[4..7] = 0x00. */
static inline void audio_comp_opus_encode_be64(unsigned char out_hdr[AUDIO_COMP_OPUS_HEADER_SIZE],
                                                unsigned long long value)
{
    out_hdr[0] = (unsigned char)((value >> 24) & 0xFFU);
    out_hdr[1] = (unsigned char)((value >> 16) & 0xFFU);
    out_hdr[2] = (unsigned char)((value >>  8) & 0xFFU);
    out_hdr[3] = (unsigned char)( value        & 0xFFU);
    out_hdr[4] = 0x00;
    out_hdr[5] = 0x00;
    out_hdr[6] = 0x00;
    out_hdr[7] = 0x00;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __AUDIO_COMP_OPUS_H__ */
