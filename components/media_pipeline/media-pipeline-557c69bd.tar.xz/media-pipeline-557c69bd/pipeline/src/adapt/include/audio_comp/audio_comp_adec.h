/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_ADEC_ADAPT_H__
#define __MAPI_ADEC_ADAPT_H__

#include "hi_mapi_adec_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define MAPI_ADEC_DEFAULT_BUF_SIZE 50

td_s32 audio_comp_adec_create_chn(td_handle adec_hdl, const hi_mapi_adec_attr *adec_attr);
td_s32 audio_comp_adec_destroy_chn(td_handle adec_hdl);
/*
 * payload_format selects HI_NATIVE (default, caller already prepends the
 * Hisi-private 8-byte big-endian length header on each OPUS packet) or
 * STANDARD (caller provides bare RFC 7587 OPUS RTP payload; adapt layer
 * prepends the header into a per-channel temporary buffer before forwarding
 * to the SDK).
 * Non-OPUS adec_format MUST pass HI_NATIVE; checked at the public API entry
 * (hi_mapi_adec_set_param).
 */
td_s32 audio_comp_adec_send_stream(td_handle adec_hdl, const hi_mapi_audio_stream *adec_stream, td_bool block,
                                    hi_mapi_audio_payload_format payload_format);
td_s32 audio_comp_adec_get_frame(td_handle adec_hdl, hi_mapi_audio_frame_info *audio_frame_info, td_bool block);
td_s32 audio_comp_adec_release_frame(td_handle adec_hdl, const hi_mapi_audio_frame_info *audio_frame_info);
td_s32 audio_comp_adec_send_end_of_stream(td_handle adec_hdl);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_ADEC_ADAPT_H__ */
