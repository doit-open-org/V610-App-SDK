/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ADPT_AENC_MP3_H
#define ADPT_AENC_MP3_H

#include "hi_mapi_aenc_adpt.h"
#include "ot_mp3dec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     AENC ADPT */
/** @{ */ /** <!-- [AENC ADPT] */

typedef td_void *(*InitDecoderCallback)(td_void);
typedef td_void (*FreeDecoderCallback)(ot_mp3dec_handle mp3Decoder);
typedef td_s32 (*FindSyncHeaderCallback)(ot_mp3dec_handle mp3Decoder, td_u8 **inbufPtr,
    td_s32 *bytesLeft);
typedef td_s32 (*DecodeCallback)(ot_mp3dec_handle mp3Decoder, td_u8 **inbufPtr,
    td_s32 *bytesLeft, td_s16 *outPcm, td_s32 reserved);
typedef td_void (*GetLastFrameInfoCallback)(ot_mp3dec_handle mp3Decoder,
    ot_mp3dec_frame_info *mp3decFrameInfo);

typedef struct {
    td_void *libHandle;
    InitDecoderCallback initDecoder;
    FreeDecoderCallback freeDecoder;
    FindSyncHeaderCallback findSyncHeader;
    DecodeCallback decode;
    GetLastFrameInfoCallback getLastFrameInfo;
} MAPI_ADEC_Mp3FunAttr;

typedef struct {
    td_s32 bit_rate;
    td_s32 chans;                /* 1 or 2 */
    td_s32 sample_rate;
    td_s32 bits_per_sample;      /* only support 16 bits */
    td_s32 outputSample;         /* nChans * SamplePerFrame */
    td_s32 layer;                /* layer, the infomation of stream's encode profile */
    td_s32 version;              /* version, the infomation of stream's encode profile */
} MAPI_ADEC_Mp3FrameInfo;

typedef struct {
    td_u32 resv;
} MAPI_ADEC_Mp3Attr;

typedef struct {
    MAPI_ADEC_Mp3Attr mp3Attr;
    ot_mp3dec_handle decoderHandle;
} MAPI_ADEC_Mp3Decoder;

td_s32 MAPI_ADEC_RegisterMp3(td_void);
td_s32 MAPI_ADEC_UnRegisterMp3(td_void);

/** @} */ /** <!-- ==== AENC ADPT End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
