/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "adpt_aenc_aac.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mapi_acap_inner.h"
#include "mapi_aenc_inner.h"
#include "mapi_comm_inner.h"
#include "securec.h"

#define OT_AENC_AACENC_MAX_TRANSTYPE     2
#define OT_AENC_AACENC_MIN_BANDWIDTH     1000

static td_s32 AACTypeConvert(hi_mapi_aenc_aac_type aac_type, ot_aacenc_format *encoderFormat)
{
    switch (aac_type) {
        case HI_MAPI_AAC_TYPE_AACLC:
            *encoderFormat = OT_AACLC;
            break;

        case HI_MAPI_AAC_TYPE_EAAC:
            *encoderFormat = OT_EAAC;
            break;

        case HI_MAPI_AAC_TYPE_EAACPLUS:
            *encoderFormat = OT_EAACPLUS;
            break;

        case HI_MAPI_AAC_TYPE_AACLD:
            *encoderFormat = OT_AACLD;
            break;

        case HI_MAPI_AAC_TYPE_AACELD:
            *encoderFormat = OT_AACELD;
            break;

        default:
            return OT_ERR_AENC_ILLEGAL_PARAM;
    }
    return TD_SUCCESS;
}

static td_s32 AencCheckAACAttr(const hi_mapi_aenc_aac_attr *aacAttr)
{
    if (aacAttr->bit_width != HI_MAPI_AUDIO_BIT_WIDTH_16) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid bitwidth for AAC encoder\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (aacAttr->sound_mode >= HI_MAPI_AUDIO_SOUND_MODE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid sound mode for AAC encoder\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if ((aacAttr->aac_type == HI_MAPI_AAC_TYPE_EAACPLUS) && (aacAttr->sound_mode != HI_MAPI_AUDIO_SOUND_MODE_STEREO)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid sound mode for AAC encoder\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (aacAttr->aac_type >= HI_MAPI_AAC_TYPE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid AACType for AAC encoder\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (aacAttr->trans_type >= HI_MAPI_AAC_TRANS_TYPE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid trans_type for AAC encoder\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (aacAttr->trans_type == HI_MAPI_AAC_TRANS_TYPE_ADTS) {
        if ((aacAttr->aac_type == HI_MAPI_AAC_TYPE_AACLD)
            || (aacAttr->aac_type == HI_MAPI_AAC_TYPE_AACELD)) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACLD or AACELD not support HI_MAPI_AAC_TRANS_TYPE_ADTS\n");
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }
    }

    return TD_SUCCESS;
}

static td_s32 AencCheckAACLCSampleRate(const ot_aacenc_config *config, td_s32 *minBitRate, td_s32 *max_bit_rate)
{
    if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_32000) {
        *minBitRate = MAPI_AACENC_BITRATE_32000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_192000 : MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_44100) {
        *minBitRate = MAPI_AACENC_BITRATE_48000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_265000 : MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_48000) {
        *minBitRate = MAPI_AACENC_BITRATE_48000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_288000 : MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_16000) {
        *minBitRate = MAPI_AACENC_BITRATE_24000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_96000 : MAPI_AACENC_BITRATE_192000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_8000) {
        *minBitRate = MAPI_AACENC_BITRATE_16000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_48000 : MAPI_AACENC_BITRATE_96000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_24000) {
        *minBitRate = MAPI_AACENC_BITRATE_32000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_144000 : MAPI_AACENC_BITRATE_288000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_22050) {
        *minBitRate = MAPI_AACENC_BITRATE_32000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_132000 : MAPI_AACENC_BITRATE_265000;
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACLC invalid sample_rate(%d)\n", config->sample_rate);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 AencCheckAACLCConfig(const ot_aacenc_config *config)
{
    td_s32 minBitRate = 0;
    td_s32 max_bit_rate = 0;

    if (config->coder_format == OT_AACLC) {
        if (config->num_channels_out != config->num_channels_in) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACLC num_channels_out(%d) in not equal to num_channels_in(%d)\n",
                           config->num_channels_out, config->num_channels_in);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }

        td_s32 ret = AencCheckAACLCSampleRate(config, &minBitRate, &max_bit_rate);
        if (ret != TD_SUCCESS) {
            return ret;
        }

        if (config->bit_rate < minBitRate || config->bit_rate > max_bit_rate) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACLC %d Hz bit_rate(%d) should be %d ~ %d\n",
                config->sample_rate, config->bit_rate, minBitRate, max_bit_rate);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }
    } else {
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 AencCheckEAACConfig(const ot_aacenc_config *config)
{
    td_s32 minBitRate = 0;
    td_s32 max_bit_rate = 0;

    if (config->coder_format == OT_EAAC) {
        if (config->num_channels_out != config->num_channels_in) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "EAAC num_channels_out(%d) is not equal to num_channels_in(%d)\n",
                           config->num_channels_out, config->num_channels_in);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }

        if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_32000) {
            minBitRate = MAPI_AACENC_BITRATE_32000;
            max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_64000 : MAPI_AACENC_BITRATE_128000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_44100) {
            minBitRate = MAPI_AACENC_BITRATE_32000;
            max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_64000 : MAPI_AACENC_BITRATE_128000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_48000) {
            minBitRate = MAPI_AACENC_BITRATE_32000;
            max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_64000 : MAPI_AACENC_BITRATE_128000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_16000) {
            minBitRate = MAPI_AACENC_BITRATE_24000;
            max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_48000 : MAPI_AACENC_BITRATE_96000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_22050) {
            minBitRate = MAPI_AACENC_BITRATE_32000;
            max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_64000 : MAPI_AACENC_BITRATE_128000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_24000) {
            minBitRate = MAPI_AACENC_BITRATE_32000;
            max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_64000 : MAPI_AACENC_BITRATE_128000;
        } else {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "EAAC invalid sample_rate(%d)\n", config->sample_rate);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }

        if (config->bit_rate < minBitRate || config->bit_rate > max_bit_rate) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "EAAC %d Hz bit_rate(%d) should be %d ~ %d\n",
                config->sample_rate, config->bit_rate, minBitRate, max_bit_rate);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }
    } else {
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 AencCheckEAACPLUSConfig(const ot_aacenc_config *config)
{
    td_s32 minBitRate = 0;
    td_s32 max_bit_rate = 0;

    if (config->coder_format == OT_EAACPLUS) {
        /* 2: Channel number */
        if (config->num_channels_out != HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT ||
            config->num_channels_in != HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "EAACPLUS num_channels_out(%d) and num_channels_in(%d) should be 2\n",
                           config->num_channels_out, config->num_channels_in);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }

        if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_32000) {
            minBitRate = MAPI_AACENC_BITRATE_16000;
            max_bit_rate =  MAPI_AACENC_BITRATE_64000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_44100) {
            minBitRate = MAPI_AACENC_BITRATE_16000;
            max_bit_rate =  MAPI_AACENC_BITRATE_64000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_48000) {
            minBitRate = MAPI_AACENC_BITRATE_16000;
            max_bit_rate =  MAPI_AACENC_BITRATE_64000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_16000) {
            minBitRate = MAPI_AACENC_BITRATE_16000;
            max_bit_rate = MAPI_AACENC_BITRATE_48000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_22050) {
            minBitRate = MAPI_AACENC_BITRATE_16000;
            max_bit_rate =  MAPI_AACENC_BITRATE_64000;
        } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_24000) {
            minBitRate = MAPI_AACENC_BITRATE_16000;
            max_bit_rate =  MAPI_AACENC_BITRATE_64000;
        } else {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "EAACPLUS invalid sample_rate(%d)\n", config->sample_rate);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }

        if (config->bit_rate < minBitRate || config->bit_rate > max_bit_rate) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "EAACPLUS %d Hz bit_rate(%d) should be %d ~ %d\n",
                config->sample_rate, config->bit_rate, minBitRate, max_bit_rate);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }
    } else {
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 AencCheckAACLDSampleRate(const ot_aacenc_config *config, td_s32 *minBitRate, td_s32 *max_bit_rate)
{
    if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_32000) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_48000 : MAPI_AACENC_BITRATE_64000;
        *max_bit_rate =  MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_44100) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_64000 : MAPI_AACENC_BITRATE_44000;
        *max_bit_rate =  MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_48000) {
        *minBitRate = MAPI_AACENC_BITRATE_64000;
        *max_bit_rate =  MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_16000) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_24000 : MAPI_AACENC_BITRATE_32000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_192000 : MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_8000) {
        *minBitRate = MAPI_AACENC_BITRATE_16000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_96000 : MAPI_AACENC_BITRATE_192000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_24000) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_32000 : MAPI_AACENC_BITRATE_48000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_256000 : MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_22050) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_32000 : MAPI_AACENC_BITRATE_48000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_256000 : MAPI_AACENC_BITRATE_320000;
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACLD invalid sample_rate(%d)\n", config->sample_rate);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 AencCheckAACLDConfig(const ot_aacenc_config *config)
{
    td_s32 minBitRate = 0;
    td_s32 max_bit_rate = 0;

    if (config->coder_format == OT_AACLD) {
        if (config->num_channels_out != config->num_channels_in) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACLD num_channels_out(%d) in not equal to num_channels_in(%d)\n",
                           config->num_channels_out, config->num_channels_in);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }

        td_s32 ret = AencCheckAACLDSampleRate(config, &minBitRate, &max_bit_rate);
        if (ret != TD_SUCCESS) {
            return ret;
        }

        if (config->bit_rate < minBitRate || config->bit_rate > max_bit_rate) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACLD %d Hz bit_rate(%d) should be %d ~ %d\n",
                config->sample_rate, config->bit_rate,  minBitRate, max_bit_rate);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }
    } else {
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 AencCheckAACELDSampleRate(const ot_aacenc_config *config, td_s32 *minBitRate, td_s32 *max_bit_rate)
{
    if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_32000) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_32000 : MAPI_AACENC_BITRATE_64000;
        *max_bit_rate =  MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_44100) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_96000 : MAPI_AACENC_BITRATE_192000;
        *max_bit_rate =  MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_48000) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_96000 : MAPI_AACENC_BITRATE_192000;
        *max_bit_rate =  MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_16000) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_16000 : MAPI_AACENC_BITRATE_32000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_256000 : MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_8000) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_32000 : MAPI_AACENC_BITRATE_64000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_96000 : MAPI_AACENC_BITRATE_192000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_24000) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_24000 : MAPI_AACENC_BITRATE_32000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_256000 : MAPI_AACENC_BITRATE_320000;
    } else if (config->sample_rate == OT_AUDIO_SAMPLE_RATE_22050) {
        *minBitRate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_24000 : MAPI_AACENC_BITRATE_32000;
        *max_bit_rate = (config->num_channels_in == 1) ? MAPI_AACENC_BITRATE_256000 : MAPI_AACENC_BITRATE_320000;
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACELD invalid sample_rate(%d)\n", config->sample_rate);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 AencCheckAACELDConfig(const ot_aacenc_config *config)
{
    td_s32 minBitRate = 0;
    td_s32 max_bit_rate = 0;

    if (config->coder_format == OT_AACELD) {
        if (config->num_channels_out != config->num_channels_in) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACELD num_channels_out(%d) in not equal to num_channels_in(%d)\n",
                           config->num_channels_out, config->num_channels_in);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }

        td_s32 ret = AencCheckAACELDSampleRate(config, &minBitRate, &max_bit_rate);
        if (ret != TD_SUCCESS) {
            return ret;
        }

        if (config->bit_rate < minBitRate || config->bit_rate > max_bit_rate) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACELD %d Hz bit_rate(%d) should be %d ~ %d\n",
                config->sample_rate, config->bit_rate, minBitRate, max_bit_rate);
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }
    } else {
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

td_s32 AencAACCheckConfig(const ot_aacenc_config *config)
{
    td_s32 ret = TD_SUCCESS;

    if (config == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "config is null\n");
        return OT_ERR_AENC_NULL_PTR;
    }

    if (config->coder_format != OT_AACLC && config->coder_format != OT_EAAC && config->coder_format != OT_EAACPLUS &&
        config->coder_format != OT_AACLD && config->coder_format != OT_AACELD) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aacenc coder_format(%d) invalid\n", config->coder_format);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (config->quality != OT_AACENC_QUALITY_EXCELLENT && config->quality != OT_AACENC_QUALITY_HIGH &&
        config->quality != OT_AACENC_QUALITY_MEDIUM && config->quality != OT_AACENC_QUALITY_LOW) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aacenc quality(%d) invalid\n", config->quality);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (config->bits_per_sample != 16) { /* 16: per sample bits */
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aacenc bits_per_sample(%d) should be 16\n", config->bits_per_sample);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (config->trans_type > OT_AENC_AACENC_MAX_TRANSTYPE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid transtype(%d), not in [0, 2]\n", config->trans_type);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (config->band_width != 0 && (config->band_width < OT_AENC_AACENC_MIN_BANDWIDTH ||
        config->band_width > config->sample_rate / 2)) { /* 2: max band_width is half of sample_rate */
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AAC band_width(%d) should be 0, or 1000 ~ %d\n", config->band_width,
                       config->sample_rate / 2); /* 2: max band_width is half of sample_rate */
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (config->coder_format == OT_AACLC) {
        ret = AencCheckAACLCConfig(config);
    } else if (config->coder_format == OT_EAAC) {
        ret = AencCheckEAACConfig(config);
    } else if (config->coder_format == OT_EAACPLUS) {
        ret = AencCheckEAACPLUSConfig(config);
    } else if (config->coder_format == OT_AACLD) {
        ret = AencCheckAACLDConfig(config);
    } else if (config->coder_format == OT_AACELD) {
        ret = AencCheckAACELDConfig(config);
    }

    return ret;
}

static td_s32  AencGetAACEncoderConfig(ot_aacenc_config *config, const hi_mapi_aenc_aac_attr *aacAttr)
{
    td_s32 ret = ot_aacenc_init_default_config(config);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "ret:0x%x.#########\n", ret);
        return ret;
    }

    ret = AACTypeConvert(aacAttr->aac_type, &config->coder_format);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AACTypeConvert error ret:0x%x.#########\n", ret);
        return ret;
    }

    config->bit_rate = aacAttr->bit_rate;
    config->bits_per_sample = 8 * (1 << (td_u32)(aacAttr->bit_width)); /* 8 : bit_width align at 8 bit */
    config->sample_rate = aacAttr->sample_rate;
    config->band_width = aacAttr->band_width;  /* half of config.sample_rate; */

    switch (aacAttr->trans_type) {
        case HI_MAPI_AAC_TRANS_TYPE_ADTS:
            config->trans_type = OT_AACENC_ADTS;
            break;

        case HI_MAPI_AAC_TRANS_TYPE_LOAS:
            config->trans_type = OT_AACENC_LOAS;
            break;

        case HI_MAPI_AAC_TRANS_TYPE_LATM_MCP1:
            config->trans_type = OT_AACENC_LATM_MCP1;
            break;

        default:
            break;
    }

    if (aacAttr->sound_mode == HI_MAPI_AUDIO_SOUND_MODE_MONO && aacAttr->aac_type != HI_MAPI_AAC_TYPE_EAACPLUS) {
        config->num_channels_in = HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT;
        config->num_channels_out = HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT;
    } else {
        config->num_channels_in = HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT;
        config->num_channels_out = HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT;
    }

    config->quality = OT_AACENC_QUALITY_HIGH;

    ret = AencAACCheckConfig(config);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "ret:0x%x.#########\n", ret);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}


td_s32 OpenAACEncoder(td_void *encoderAttr, td_void **encoder)
{
    MAPI_AENC_AacEncoder *aacEncoder = NULL;
    hi_mapi_aenc_aac_attr *aacAttr = NULL;
    td_s32 ret;
    ot_aacenc_config config;

    CHECK_MAPI_AENC_NULL_PTR_RET(encoderAttr);
    CHECK_MAPI_AENC_NULL_PTR_RET(encoder);

    /* check attribute of encoder */
    aacAttr = (hi_mapi_aenc_aac_attr *)encoderAttr;
    ret = AencCheckAACAttr(aacAttr);
    CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "AencCheckAACAttr", ret);

    /* allocate memory for encoder */
    aacEncoder = (MAPI_AENC_AacEncoder *)malloc(sizeof(MAPI_AENC_AacEncoder));
    if (aacEncoder == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "no memory\n");
        return OT_ERR_AENC_NO_MEM;
    }
    ret = memset_s(aacEncoder, sizeof(MAPI_AENC_AacEncoder), 0, sizeof(MAPI_AENC_AacEncoder));
    if (ret != EOK) {
        free(aacEncoder);
        aacEncoder = NULL;
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "memset_s error:0x%x.#########\n", ret);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    /* set default config to encoder */
    ret = AencGetAACEncoderConfig(&config, aacAttr);
    if (ret != TD_SUCCESS) {
        free(aacEncoder);
        aacEncoder = NULL;
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AencSetAACEncoderConfig ret:0x%x.#########\n", ret);
        return ret;
    }

    /* create encoder */
    ret = ot_aacenc_open(&aacEncoder->aacEncoderHdl, &config);
    if (ret != TD_SUCCESS) {
        free(aacEncoder);
        aacEncoder = NULL;
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "ret:0x%x.#########\n", ret);
        return ret;
    }

    ret = memcpy_s(&aacEncoder->aacAttr, sizeof(aacEncoder->aacAttr), aacAttr,
        sizeof(hi_mapi_aenc_aac_attr));
    if (ret != EOK) {
        ot_aacenc_close(aacEncoder->aacEncoderHdl);
        free(aacEncoder);
        aacEncoder = NULL;
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "memcpy_s error:0x%x.#########\n", ret);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }
    *encoder = (td_void *)aacEncoder;

    return TD_SUCCESS;
}

static td_s32 AencCheckAACEncoderConfig(const MAPI_AENC_AacEncoder *aacEncoder,
    const ot_audio_frame *frame_data, td_u32 *waterLine)
{
    if (aacEncoder->aacAttr.sound_mode == HI_MAPI_AUDIO_SOUND_MODE_STEREO) {
        /* whether the sound mode of frame and channel is match  */
        if (frame_data->snd_mode != OT_AUDIO_SOUND_MODE_STEREO) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AAC encode receive a frame which not match its Soundmode\n");
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }
    }

    /* WaterLine, equals to the frame sample frame of protocol */
    if (aacEncoder->aacAttr.aac_type == HI_MAPI_AAC_TYPE_AACLC) {
        *waterLine = HI_MAPI_AENC_AACLC_SAMPLES_PER_FRAME;
    } else if (aacEncoder->aacAttr.aac_type == HI_MAPI_AAC_TYPE_EAAC
               || aacEncoder->aacAttr.aac_type == HI_MAPI_AAC_TYPE_EAACPLUS) {
        *waterLine = HI_MAPI_AENC_AACPLUS_SAMPLES_PER_FRAME;
    } else if (aacEncoder->aacAttr.aac_type == HI_MAPI_AAC_TYPE_AACLD
               || aacEncoder->aacAttr.aac_type == HI_MAPI_AAC_TYPE_AACELD) {
        *waterLine = HI_MAPI_AENC_AACLD_SAMPLES_PER_FRAME;
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid AAC coder type\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }
    /* calculate point number */
    td_u32 pointNums = frame_data->len / (frame_data->bit_width + 1);

    /* if frame sample larger than protocol sample, reject to receive, or buffer will be overflow */
    if (pointNums != *waterLine) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid pointNums%d for AACType:%d\n", pointNums,
                       aacEncoder->aacAttr.aac_type);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

td_s32 EncodeAACFrm(td_void *encoder, const ot_audio_frame *frame_data, ot_aenc_buf_info *buf_info)
{
    MAPI_AENC_AacEncoder *aacEncoder = NULL;
    td_s32 i;
    td_s16 data[OT_AACENC_BLOCK_SIZE * HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT * OT_AACENC_MAX_CHANNELS];
    td_s16 len;
    td_u32 waterLine = 0;

    CHECK_MAPI_AENC_NULL_PTR_RET(encoder);
    CHECK_MAPI_AENC_NULL_PTR_RET(frame_data);
    CHECK_MAPI_AENC_NULL_PTR_RET(buf_info);

    aacEncoder = (MAPI_AENC_AacEncoder *)encoder;
    td_s32 ret = AencCheckAACEncoderConfig(aacEncoder, frame_data, &waterLine);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AencCheckAACEncoderConfig error and ret:%#x\n", ret);
        return ret;
    }

    /* AAC encoder need interleaved data,here change LLLRRR to LRLRLR.
       AACLC will encode 1024*2 point, and AACplus encode 2048*2 point */
    if (aacEncoder->aacAttr.sound_mode == HI_MAPI_AUDIO_SOUND_MODE_STEREO) {
        len = waterLine;
        for (i = len - 1; i >= 0; i--) {
            data[HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT * i] = *((td_s16 *)frame_data->virt_addr[0] + i);
            data[HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT * i + 1] = *((td_s16 *)frame_data->virt_addr[1] + i);
        }
    } else { /* if inbuf is momo, copy left to right */
        td_s16 *temp = (td_s16 *)frame_data->virt_addr[0];
        len = waterLine;
        for (i = len - 1; i >= 0; i--) {
            data[i] = *(temp + i);
        }
    }

    CHECK_MAPI_AENC_NULL_PTR_RET(aacEncoder->aacEncoderHdl);
    ret = ot_aacenc_frame(aacEncoder->aacEncoderHdl, data, buf_info->out_buf, (td_s32*)buf_info->out_valid_len);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AAC encode failed\n");
    }

    return ret;
}

td_s32 CloseAACEncoder(td_void *encoder)
{
    MAPI_AENC_AacEncoder *aacEncoder = NULL;

    CHECK_MAPI_AENC_NULL_PTR_RET(encoder);
    aacEncoder = (MAPI_AENC_AacEncoder *)encoder;

    if (aacEncoder->aacEncoderHdl != NULL) {
        ot_aacenc_close(aacEncoder->aacEncoderHdl);
    }

    free(aacEncoder);
    aacEncoder = NULL;
    return TD_SUCCESS;
}

td_s32 ADPT_AENC_GetAacEncoder(ot_aenc_encoder *aacEncoder)
{
    td_s32 ret;
    CHECK_MAPI_AENC_NULL_PTR_RET(aacEncoder);

    aacEncoder->type = OT_PT_AAC;
    ret = snprintf_s(aacEncoder->name, sizeof(aacEncoder->name),
        sizeof(aacEncoder->name) - 1, "Aac");
    if (ret == TD_FAILURE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "snprintf_s fail.\n");
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    aacEncoder->max_frame_len = HI_MAPI_AENC_MAX_AAC_MAINBUF_SIZE;
    aacEncoder->func_open_encoder = OpenAACEncoder;
    aacEncoder->func_enc_frame = EncodeAACFrm;
    aacEncoder->func_close_encoder = CloseAACEncoder;

    return TD_SUCCESS;
}
