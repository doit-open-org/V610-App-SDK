/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ADPT_AENC_MP3_H
#define ADPT_AENC_MP3_H

#include "hi_mapi_aenc_adpt.h"
#include "ot_mp3enc.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     AENC ADPT */
/** @{ */ /** <!-- [AENC ADPT] */

#define MAPI_AENC_MP3_ENCODER_QUALITY_MAX_NUM 9

typedef td_void *(*createCallback)(ot_mp3enc_attr *mp3encAttr);
typedef td_s32 (*processFrameCallback)(td_void *mp3Encoder, td_s16 *pcmBuf, td_u8 *outBuf,
    td_s32 *outBytesNum);
typedef td_void (*destroyCallback)(td_void *mp3Encoder);

typedef struct {
    td_void *libHandle;
    createCallback create;
    processFrameCallback processFrame;
    destroyCallback destroy;
} MAPI_AENC_Mp3FunAttr;

typedef struct {
    td_void *encoderHandle;
    hi_mapi_aenc_mp3_attr mp3Attr;
} MAPI_AENC_Mp3Encoder;

td_s32 MP3ENC_DeinitFun(td_void);
td_s32 ADPT_AENC_ConfigMp3Encoder(ot_aenc_encoder *mp3Encoder);

/** @} */ /** <!-- ==== AENC ADPT End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
