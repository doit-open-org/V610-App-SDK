/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "adpt_adec_mp3.h"
#include <dlfcn.h>
#include "securec.h"
#include "ot_common.h"
#include "ss_mpi_audio.h"
#include "mapi_comm_adapt.h"
#include "hi_mapi_comm_define.h"
#include "mapi_comm_inner.h"
#include "mapi_adec_inner.h"

#define MP3DEC_LIB_NAME "libmp3_dec.so"

#define NO_ENOUGH_MAIN_DATA_ERROR 11

static MAPI_ADEC_Mp3FunAttr g_mp3decFun = {0};
static td_s32 g_mp3DecHandle = OT_INVALID_HANDLE;

static td_s32 MP3DEC_DeinitFun(td_void)
{
    if (g_mp3decFun.libHandle != TD_NULL) {
        mapi_adapt_comm_dlclose(g_mp3decFun.libHandle);
        td_s32 ret = memset_s(&g_mp3decFun, sizeof(MAPI_ADEC_Mp3FunAttr), 0, sizeof(MAPI_ADEC_Mp3FunAttr));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ADEC, "memset_s", ret);
    }

    return TD_SUCCESS;
}

static td_s32 MP3DEC_Dlsym(MAPI_ADEC_Mp3FunAttr *mp3DecFun)
{
    td_s32 ret = mapi_adapt_comm_dlsym((td_void **)&(mp3DecFun->freeDecoder), mp3DecFun->libHandle,
        "ot_mp3dec_free_decoder");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "find symbol fail:%#x \n", ret);
        return TD_FAILURE;
    }

    ret = mapi_adapt_comm_dlsym((td_void **)&(mp3DecFun->findSyncHeader), mp3DecFun->libHandle,
        "ot_mp3dec_find_sync_header");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "find symbol fail:%#x \n", ret);
        return TD_FAILURE;
    }

    ret = mapi_adapt_comm_dlsym((td_void **)&(mp3DecFun->decode), mp3DecFun->libHandle, "ot_mp3dec_frame");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "find symbol fail:%#x \n", ret);
        return TD_FAILURE;
    }

    ret = mapi_adapt_comm_dlsym((td_void **)&(mp3DecFun->getLastFrameInfo), mp3DecFun->libHandle,
        "ot_mp3dec_get_last_frame_info");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "find symbol fail:%#x \n", ret);
        return TD_FAILURE;
    }

    ret = mapi_adapt_comm_dlsym((td_void **)&(mp3DecFun->initDecoder), mp3DecFun->libHandle,
        "ot_mp3dec_init_decoder");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "find symbol fail:%#x \n", ret);
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

static td_s32 MP3DEC_InitFun(td_void)
{
    MAPI_ADEC_Mp3FunAttr mp3DecFun;
    td_s32 ret = MP3DEC_DeinitFun();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "Unload mp3dec lib fail:%#x \n", ret);
        return TD_FAILURE;
    }

    ret = memset_s(&mp3DecFun, sizeof(MAPI_ADEC_Mp3FunAttr), 0, sizeof(MAPI_ADEC_Mp3FunAttr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ADEC, "memset_s", ret);

    ret = mapi_adapt_comm_dlopen(&(mp3DecFun.libHandle), MP3DEC_LIB_NAME);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "load mp3enc lib fail:%#x \n", ret);
        return TD_FAILURE;
    }

    ret = MP3DEC_Dlsym(&mp3DecFun);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "find mp3enc symbol fail:%#x \n", ret);
        mapi_adapt_comm_dlclose(mp3DecFun.libHandle);
        return TD_FAILURE;
    }

    ret = memcpy_s(&g_mp3decFun, sizeof(g_mp3decFun), &mp3DecFun, sizeof(mp3DecFun));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "memcpy_s error:%#x \n", ret);
        mapi_adapt_comm_dlclose(mp3DecFun.libHandle);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    return TD_SUCCESS;
}

td_s32 OpenMp3Decoder(td_void *decoderAttr, td_void **decoder)
{
    MAPI_ADEC_Mp3Decoder *mp3Decoder = NULL;
    MAPI_ADEC_Mp3Attr *attr = NULL;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoderAttr);
    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);

    attr = (MAPI_ADEC_Mp3Attr *)decoderAttr;
    CHECK_MAPI_ADEC_NULL_PTR_RET(g_mp3decFun.initDecoder);
    /* allocate memory for decoder */
    mp3Decoder = (MAPI_ADEC_Mp3Decoder *)malloc(sizeof(MAPI_ADEC_Mp3Decoder));
    if (mp3Decoder == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "malloc MP3 decoder context failed!");
        return OT_ERR_ADEC_NO_MEM;
    }

    td_s32 ret = memset_s(mp3Decoder, sizeof(MAPI_ADEC_Mp3Decoder), 0, sizeof(MAPI_ADEC_Mp3Decoder));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "memset_s error:%#x!", ret);
        free(mp3Decoder);
        mp3Decoder = NULL;
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    /* create decoder */
    mp3Decoder->decoderHandle = g_mp3decFun.initDecoder();
    if (!mp3Decoder->decoderHandle) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "MP3 decoder is not ready!");
        free(mp3Decoder);
        mp3Decoder = NULL;
        return OT_ERR_ADEC_DECODER_ERR;
    }

    mp3Decoder->mp3Attr.resv = attr->resv;
    *decoder = (td_void *)mp3Decoder;

    return TD_SUCCESS;
}

td_s32 DecodeMp3Frame(td_void *decoder, ot_adec_buf_info *bufInfo, td_u32 *chns)
{
    MAPI_ADEC_Mp3Decoder *mp3Decoder = NULL;
    ot_mp3dec_frame_info frameInfo;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);
    CHECK_MAPI_ADEC_NULL_PTR_RET(bufInfo);
    CHECK_MAPI_ADEC_NULL_PTR_RET(bufInfo->in_buf);
    CHECK_MAPI_ADEC_NULL_PTR_RET(bufInfo->in_left_byte);
    CHECK_MAPI_ADEC_NULL_PTR_RET(bufInfo->out_buf);
    CHECK_MAPI_ADEC_NULL_PTR_RET(bufInfo->out_valid_len);
    CHECK_MAPI_ADEC_NULL_PTR_RET(chns);
    CHECK_MAPI_ADEC_NULL_PTR_RET(g_mp3decFun.findSyncHeader);
    CHECK_MAPI_ADEC_NULL_PTR_RET(g_mp3decFun.decode);
    CHECK_MAPI_ADEC_NULL_PTR_RET(g_mp3decFun.getLastFrameInfo);
    *chns = 1; /* voice encoder only one channle */

    mp3Decoder = (MAPI_ADEC_Mp3Decoder *)decoder;

    td_s32 frameLen = g_mp3decFun.findSyncHeader(mp3Decoder->decoderHandle, bufInfo->in_buf, bufInfo->in_left_byte);
    if (frameLen < 0) {
        return OT_ERR_ADEC_BUF_LACK;
    }
    td_s32 ret = g_mp3decFun.decode(mp3Decoder->decoderHandle,
        bufInfo->in_buf, bufInfo->in_left_byte, (td_s16 *)bufInfo->out_buf, 0);
    if (ret) {
        if (ret == NO_ENOUGH_MAIN_DATA_ERROR) {
            return OT_ERR_ADEC_BUF_LACK;
        }
        return ret;
    }

    g_mp3decFun.getLastFrameInfo(mp3Decoder->decoderHandle, &frameInfo);
    if (frameInfo.chn_num <= 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "frameInfo.chn_num invalid!\n");
        return TD_FAILURE;
    }
    *chns = frameInfo.chn_num;
    *bufInfo->out_valid_len = (frameInfo.output_samples / frameInfo.chn_num) *
        (frameInfo.bits_per_sample / 8); /* 8bit */

    return ret;
}

td_s32 GetMp3FrameInfo(td_void *decoder, td_void *info)
{
    MAPI_ADEC_Mp3Decoder *mp3Decoder = NULL;
    ot_mp3dec_frame_info mp3dec_frame_info;
    MAPI_ADEC_Mp3FrameInfo *mp3Frame = NULL;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);
    CHECK_MAPI_ADEC_NULL_PTR_RET(info);
    CHECK_MAPI_ADEC_NULL_PTR_RET(g_mp3decFun.getLastFrameInfo);

    mp3Decoder = (MAPI_ADEC_Mp3Decoder *)decoder;
    mp3Frame = (MAPI_ADEC_Mp3FrameInfo *)info;

    g_mp3decFun.getLastFrameInfo(mp3Decoder->decoderHandle, &mp3dec_frame_info);

    mp3Frame->bit_rate         = mp3dec_frame_info.bit_rate;
    mp3Frame->bits_per_sample   = mp3dec_frame_info.bits_per_sample;
    mp3Frame->chans           = mp3dec_frame_info.chn_num;
    mp3Frame->layer           = mp3dec_frame_info.layer;
    mp3Frame->outputSample    = mp3dec_frame_info.output_samples;
    mp3Frame->sample_rate      = mp3dec_frame_info.sample_rate;
    mp3Frame->version         = mp3dec_frame_info.version;

    return TD_SUCCESS;
}

td_s32 CloseMp3Decoder(td_void *decoder)
{
    MAPI_ADEC_Mp3Decoder *mp3Decoder = NULL;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);
    mp3Decoder = (MAPI_ADEC_Mp3Decoder *)decoder;

    if (g_mp3decFun.freeDecoder != NULL) {
        g_mp3decFun.freeDecoder(mp3Decoder->decoderHandle);
    }

    free(mp3Decoder);
    mp3Decoder = NULL;
    decoder = NULL;

    return TD_SUCCESS;
}

td_s32 ResetMp3Decoder(td_void *decoder)
{
    MAPI_ADEC_Mp3Decoder *mp3Decoder = NULL;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);
    CHECK_MAPI_ADEC_NULL_PTR_RET(g_mp3decFun.freeDecoder);
    CHECK_MAPI_ADEC_NULL_PTR_RET(g_mp3decFun.initDecoder);
    mp3Decoder = (MAPI_ADEC_Mp3Decoder *)decoder;

    g_mp3decFun.freeDecoder(mp3Decoder->decoderHandle);

    /* create decoder */
    mp3Decoder->decoderHandle = g_mp3decFun.initDecoder();
    if (mp3Decoder->decoderHandle == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "MP3ResetDecoder failed!");
        return OT_ERR_ADEC_DECODER_ERR;
    }

    return TD_SUCCESS;
}

td_s32 MAPI_ADEC_RegisterMp3(td_void)
{
    ot_adec_decoder mp3;
    td_s32 handle = OT_INVALID_HANDLE;

    if (g_mp3DecHandle != OT_INVALID_HANDLE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "aacDec have inited, return successful \n");
        return TD_SUCCESS;
    }

    mp3.type = OT_PT_MP3;
    td_s32 ret = snprintf_s(mp3.name, sizeof(mp3.name), sizeof(mp3.name) - 1, "Mp3");
    if (ret <= EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "snprintf_s fail, ret:0x%x\n", ret);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    mp3.func_open_decoder = OpenMp3Decoder;
    mp3.func_dec_frame = DecodeMp3Frame;
    mp3.func_get_frame_info = GetMp3FrameInfo;
    mp3.func_close_decoder = CloseMp3Decoder;
    mp3.func_reset_decoder = ResetMp3Decoder;

    ret = MP3DEC_InitFun();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "sample_audio_init_ext_mp3dec_fun fail, ret:0x%x\n", ret);
        return ret;
    }

    ret = ss_mpi_adec_register_decoder(&handle, &mp3);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "ss_mpi_adec_register_decoder return ERR, %x", ret);
        return ret;
    }

    g_mp3DecHandle = handle;

    return TD_SUCCESS;
}

td_s32 MAPI_ADEC_UnRegisterMp3(td_void)
{
    if (g_mp3DecHandle == OT_INVALID_HANDLE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "aacDec have Deinited, return successful \n");
        return TD_SUCCESS;
    }

    td_s32 ret = ss_mpi_adec_unregister_decoder(g_mp3DecHandle);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "ss_mpi_adec_unregister_decoder fail,s32Ret:%x\n", ret);
        return ret;
    }

    g_mp3DecHandle = OT_INVALID_HANDLE;

    ret = MP3DEC_DeinitFun();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "MP3DEC_DeinitFun fail.\n");
        return ret;
    }

    return TD_SUCCESS;
}
