/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "adpt_aenc_mp3.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mapi_acap_inner.h"
#include "mapi_aenc_inner.h"
#include "mapi_comm_adapt.h"
#include "mapi_comm_inner.h"
#include "securec.h"

#define MP3ENC_LIB_NAME "libmp3_enc.so"
#define MAPI_MP3_MAX_NCHANS      2          /* mp3 max number of channels */

static MAPI_AENC_Mp3FunAttr g_mp3encFun = {0};

td_s32 MP3ENC_DeinitFun(td_void)
{
    td_s32 ret;

    if (g_mp3encFun.libHandle != TD_NULL) {
        mapi_adapt_comm_dlclose(g_mp3encFun.libHandle);
        ret = memset_s(&g_mp3encFun, sizeof(MAPI_AENC_Mp3FunAttr), 0, sizeof(MAPI_AENC_Mp3FunAttr));
        if (ret != EOK) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "memset_s error:0x%x.#########\n", ret);
            return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
        }
    }
    return TD_SUCCESS;
}

static td_s32 MP3ENC_Dlsym(MAPI_AENC_Mp3FunAttr *mp3encFun)
{
    td_s32 ret;
    ret = mapi_adapt_comm_dlsym((td_void **)&(mp3encFun->create), mp3encFun->libHandle, "ot_mp3enc_create");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "find symbol error!\n");
        return TD_FAILURE;
    }

    ret = mapi_adapt_comm_dlsym((td_void **)&(mp3encFun->processFrame),
        mp3encFun->libHandle, "ot_mp3enc_process_frame");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "find symbol error!\n");
        return TD_FAILURE;
    }

    ret = mapi_adapt_comm_dlsym((td_void **)&(mp3encFun->destroy), mp3encFun->libHandle, "ot_mp3enc_destroy");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "find symbol error!\n");
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

static td_s32 MP3ENC_InitFun(td_void)
{
    td_s32 ret;
    MAPI_AENC_Mp3FunAttr mp3encFun = {0};

    ret = memset_s(&mp3encFun, sizeof(MAPI_AENC_Mp3FunAttr), 0, sizeof(MAPI_AENC_Mp3FunAttr));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "memset_s error:0x%x.#########\n", ret);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    ret = MP3ENC_DeinitFun();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "LUnload mp3enc lib fail!\n");
        return TD_FAILURE;
    }

    ret = mapi_adapt_comm_dlopen(&(mp3encFun.libHandle), MP3ENC_LIB_NAME);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "load mp3enc lib fail!\n");
        return TD_FAILURE;
    }

    ret = MP3ENC_Dlsym(&mp3encFun);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "find mp3enc symbol fail:%#x \n", ret);
        mapi_adapt_comm_dlclose(mp3encFun.libHandle);
        return TD_FAILURE;
    }

    ret = memcpy_s(&g_mp3encFun, sizeof(g_mp3encFun), &mp3encFun, sizeof(mp3encFun));
    if (ret != EOK) {
        mapi_adapt_comm_dlclose(mp3encFun.libHandle);
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "memcpy_s error:0x%x.#########\n", ret);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    return TD_SUCCESS;
}

static td_bool AencCheckMp3SampleRate(hi_mapi_aenc_mp3_attr *mp3Attr)
{
    if ((mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_8000) &&
        (mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_12000) &&
        (mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_11025) &&
        (mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_16000) &&
        (mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_22050) &&
        (mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_24000) &&
        (mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_32000) &&
        (mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_44100) &&
        (mp3Attr->sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_48000)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid sample_rate for mp3 encoder\n");
        return TD_FALSE;
    }

    return TD_TRUE;
}

td_s32 AencCheckMp3Attr(hi_mapi_aenc_mp3_attr *mp3Attr)
{
    if (!AencCheckMp3SampleRate(mp3Attr)) {
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (mp3Attr->bit_width != HI_MAPI_AUDIO_BIT_WIDTH_16) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid bit_width for mp3 encoder\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if ((mp3Attr->sound_mode != HI_MAPI_AUDIO_SOUND_MODE_MONO) &&
        (mp3Attr->sound_mode != HI_MAPI_AUDIO_SOUND_MODE_STEREO)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid soundMod for mp3 encoder\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if ((mp3Attr->bit_rate != HI_MAPI_MP3_BPS_32K) && (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_40K) &&
        (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_48K) && (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_56K) &&
        (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_64K) && (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_80K) &&
        (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_96K) && (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_112K) &&
        (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_128K) && (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_160K) &&
        (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_192K) && (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_224K) &&
        (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_256K) && (mp3Attr->bit_rate != HI_MAPI_MP3_BPS_320K)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid bit_rate for mp3 encoder\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    if (mp3Attr->quality > MAPI_AENC_MP3_ENCODER_QUALITY_MAX_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid quality for mp3 encoder, only support[0,9].\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

td_s32 OpenMp3Encoder(td_void *mp3EncoderAttr, td_void **encoder)
{
    MAPI_AENC_Mp3Encoder *mp3Encoder = NULL;
    hi_mapi_aenc_mp3_attr *mp3Attr = NULL;
    ot_mp3enc_attr config;

    CHECK_MAPI_AENC_NULL_PTR_RET(mp3EncoderAttr);
    CHECK_MAPI_AENC_NULL_PTR_RET(encoder);
    CHECK_MAPI_AENC_NULL_PTR_RET(g_mp3encFun.create);
    /* check attribute of encoder */
    mp3Attr = (hi_mapi_aenc_mp3_attr *)mp3EncoderAttr;
    td_s32 ret = AencCheckMp3Attr(mp3Attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AencCheckMp3Attr error:0x%x.#########\n", ret);
        return ret;
    }

    /* allocate memory for encoder */
    mp3Encoder = (MAPI_AENC_Mp3Encoder *)malloc(sizeof(MAPI_AENC_Mp3Encoder));
    if (mp3Encoder == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "no memory.\n");
        return OT_ERR_AENC_NO_MEM;
    }

    (td_void)memset_s(mp3Encoder, sizeof(MAPI_AENC_Mp3Encoder), 0, sizeof(MAPI_AENC_Mp3Encoder));
    if (mp3Attr->sound_mode == HI_MAPI_AUDIO_SOUND_MODE_MONO) {
        config.channels = HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT;
    } else {
        config.channels = HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; /* 2 chns */
    }

    config.bit_rate = mp3Attr->bit_rate;
    config.sample_rate = mp3Attr->sample_rate;
    config.quality = mp3Attr->quality;

    /* create encoder */
    mp3Encoder->encoderHandle = g_mp3encFun.create(&config);
    if (mp3Encoder->encoderHandle == TD_NULL) {
        free(mp3Encoder);
        mp3Encoder = NULL;
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "mp3enc_create Fail.#########\n");
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    (td_void)memcpy_s(&mp3Encoder->mp3Attr, sizeof(mp3Encoder->mp3Attr), mp3Attr, sizeof(hi_mapi_aenc_mp3_attr));
    *encoder = (td_void *)mp3Encoder;

    return TD_SUCCESS;
}

td_s32 EncodeMp3Frame(td_void *encoder, const ot_audio_frame *data, ot_aenc_buf_info *bufInfo)
{
    td_s32 ret;
    MAPI_AENC_Mp3Encoder *mp3Encoder = NULL;
    td_u32 nums;
    td_s32 i;
    td_s16 dataTmp[OT_MP3ENC_MAX_IN_SAMPELS * 2 * MAPI_MP3_MAX_NCHANS];  /* 2:chn */
    td_s16 len;
    td_u32 waterLine = OT_MP3ENC_MAX_IN_SAMPELS;

    CHECK_MAPI_AENC_NULL_PTR_RET(encoder);
    CHECK_MAPI_AENC_NULL_PTR_RET(data);
    CHECK_MAPI_AENC_NULL_PTR_RET(bufInfo);
    CHECK_MAPI_AENC_NULL_PTR_RET(g_mp3encFun.processFrame);

    mp3Encoder = (MAPI_AENC_Mp3Encoder *)encoder;

    if (mp3Encoder->mp3Attr.sound_mode == HI_MAPI_AUDIO_SOUND_MODE_STEREO) {
        /* whether the sound mode of frame and channel is match  */
        if (data->snd_mode != OT_AUDIO_SOUND_MODE_STEREO) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "MP3 encode receive a frame which not match its Soundmode\n");
            return OT_ERR_AENC_ILLEGAL_PARAM;
        }
    }

    /* calculate point number */
    nums = data->len / (data->bit_width + 1);

    /* if frame sample larger than protocol sample, reject to receive, or buffer will be overflow */
    if (nums != waterLine) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid nums%d need:%d\n", nums, waterLine);
        return OT_ERR_AENC_ILLEGAL_PARAM;
    }

    /* MP3 encoder need uninterleaved data */
    if (mp3Encoder->mp3Attr.sound_mode == HI_MAPI_AUDIO_SOUND_MODE_STEREO) {
        len = waterLine;
        for (i = len - 1; i >= 0; i--) {
            dataTmp[i] = *((td_s16 *)data->virt_addr[0] + i);
            dataTmp[i + waterLine] = *((td_s16 *)data->virt_addr[1] + i);
        }
    } else { /* if inbuf is momo, copy left to right */
        td_s16 *temp = (td_s16 *)data->virt_addr[0];
        len = waterLine;
        for (i = len - 1; i >= 0; i--) {
            dataTmp[i] = *(temp + i);
        }
    }

    ret = g_mp3encFun.processFrame((td_void *)mp3Encoder->encoderHandle,
        dataTmp, bufInfo->out_buf, (td_s32 *)bufInfo->out_valid_len);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "MP3 encode failed\n");
    }

    return ret;
}

td_s32 CloseMp3Encoder(td_void *encoder)
{
    MAPI_AENC_Mp3Encoder *mp3Encoder = TD_NULL;
    CHECK_MAPI_AENC_NULL_PTR_RET(encoder);
    mp3Encoder = (MAPI_AENC_Mp3Encoder *)encoder;

    if (g_mp3encFun.destroy != TD_NULL) {
        g_mp3encFun.destroy(mp3Encoder->encoderHandle);
    }

    free(mp3Encoder);
    mp3Encoder = TD_NULL;

    return TD_SUCCESS;
}

td_s32 ADPT_AENC_ConfigMp3Encoder(ot_aenc_encoder *mp3Encoder)
{
    td_s32 ret;
    CHECK_MAPI_AENC_NULL_PTR_RET(mp3Encoder);

    mp3Encoder->type = OT_PT_MP3;
    ret = snprintf_s(mp3Encoder->name, sizeof(mp3Encoder->name), sizeof(mp3Encoder->name) - 1, "Mp3");
    if (ret == TD_FAILURE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "snprintf_s fail.\n");
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    mp3Encoder->max_frame_len = HI_MAPI_AENC_MAX_MAINBUF_SIZE;
    mp3Encoder->func_open_encoder = OpenMp3Encoder;
    mp3Encoder->func_enc_frame = EncodeMp3Frame;
    mp3Encoder->func_close_encoder = CloseMp3Encoder;

    ret = MP3ENC_InitFun();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "MP3ENC_InitFun fail.\n");
        return ret;
    }

    return TD_SUCCESS;
}
