/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_VCAP_ADAPT_DEFINE_H__
#define __MAPI_VCAP_ADAPT_DEFINE_H__

#include "mapi_vcap_inner.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define MIPI_DEV_NODE                          "/dev/ot_mipi_rx"
#define MAPI_VCAP_PIPE_RAW_YUV_MIN_HADNLE 2

typedef struct {
    ot_vi_dev_attr vi_dev_attr[HI_MAPI_VCAP_MAX_DEV_NUM];
    ot_vi_pipe_attr vi_pipe_attr[HI_MAPI_VCAP_MAX_PIPE_NUM];
    ot_vi_chn_attr vi_chn_attr[HI_MAPI_VCAP_PIPE_MAX_CHN_NUM];
} mapi_vcap_default_config_attr;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* __MAPI_VCAP_ADAPT_DEFINE_H__ */
