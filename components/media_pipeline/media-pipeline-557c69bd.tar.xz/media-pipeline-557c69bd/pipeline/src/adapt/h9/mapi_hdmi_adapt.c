/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifdef SUPPORT_HDMI
#include "mapi_hdmi_adapt.h"
#include "mapi_hdmi_inner.h"
#include "mapi_comm_inner.h"
#include "ss_mpi_hdmi.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 mapi_adapt_hdmi_init(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_call_back_func *hdmi_call_back_func)
{
    HDMI_CHECK_NULL_PTR(hdmi_call_back_func);

    td_s32 ret = ss_mpi_hdmi_init();
    CHECK_MAPI_RET(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_init", ret);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_init 0x%x ERR.\n", ret);
        return ret;
    }

    ret = ss_mpi_hdmi_open(hdmi_id);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_open 0x%x ERR.\n", ret);
        (td_void)ss_mpi_hdmi_deinit();
        return ret;
    }

    ot_hdmi_callback_func hdmi_call_back;
    hdmi_call_back.hdmi_event_callback = (ot_hdmi_callback)hdmi_call_back_func->hdmi_event_callback;
    hdmi_call_back.private_data = hdmi_call_back_func->private_data;

    ret = ss_mpi_hdmi_register_callback(hdmi_id, &hdmi_call_back);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_register_callback 0x%x ERR.\n", ret);
        (td_void)ss_mpi_hdmi_close(hdmi_id);
        (td_void)ss_mpi_hdmi_deinit();
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_hdmi_deinit(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_call_back_func *hdmi_call_back_func)
{
    HDMI_CHECK_NULL_PTR(hdmi_call_back_func);

    ot_hdmi_callback_func hdmi_call_back;
    hdmi_call_back.hdmi_event_callback = (ot_hdmi_callback)hdmi_call_back_func->hdmi_event_callback;
    hdmi_call_back.private_data = hdmi_call_back_func->private_data;
    td_bool func_is_err = TD_FALSE;

    td_s32 ret = ss_mpi_hdmi_unregister_callback(hdmi_id, &hdmi_call_back);
    if (ret != TD_SUCCESS) {
        func_is_err = TD_TRUE;
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_unregister_callback 0x%x ERR.\n", ret);
    }

    ret = ss_mpi_hdmi_close(hdmi_id);
    if (ret != TD_SUCCESS) {
        func_is_err = TD_TRUE;
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_close 0x%x ERR.\n", ret);
    }
    ret = ss_mpi_hdmi_deinit();
    if (ret != TD_SUCCESS) {
        func_is_err = TD_TRUE;
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_deinit 0x%x ERR.\n", ret);
    }

    if (func_is_err) {
        return HI_MAPI_HDMI_EBUSY;
    }

    return TD_SUCCESS;
}

static td_void mapi_adapt_hdmi_video_fmt_convert(ot_hdmi_video_format video_fmt, hi_mapi_disp_intf_sync *intf_sync)
{
    switch (video_fmt) {
        case OT_HDMI_VIDEO_FORMAT_1080P_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1080P60;
            break;

        case OT_HDMI_VIDEO_FORMAT_1080P_50:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1080P50;
            break;

        case OT_HDMI_VIDEO_FORMAT_1080P_30:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1080P30;
            break;

        case OT_HDMI_VIDEO_FORMAT_1080P_25:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1080P25;
            break;

        case OT_HDMI_VIDEO_FORMAT_1080P_24:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1080P24;
            break;

        case OT_HDMI_VIDEO_FORMAT_720P_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_720P60;
            break;

        case OT_HDMI_VIDEO_FORMAT_720P_50:
            *intf_sync = HI_MAPI_DISP_OUTPUT_720P50;
            break;

        case OT_HDMI_VIDEO_FORMAT_576P_50:
            *intf_sync = HI_MAPI_DISP_OUTPUT_576P50;
            break;

        case OT_HDMI_VIDEO_FORMAT_480P_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_480P60;
            break;

        case OT_HDMI_VIDEO_FORMAT_861D_640X480_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_640x480_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_800X600_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_800x600_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_1024X768_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1024x768_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_1280X800_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1280x800_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_1280X1024_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1280x1024_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_1366X768_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1366x768_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_1440X900_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1440x900_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_1600X1200_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1600x1200_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_1680X1050_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1680x1050_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_1920X1200_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1920x1200_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_2560x1440_30:
            *intf_sync = HI_MAPI_DISP_OUTPUT_2560x1440_30;
            break;

        case OT_HDMI_VIDEO_FORMAT_2560x1600_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_2560x1600_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_1920x2160_30:
            *intf_sync = HI_MAPI_DISP_OUTPUT_1920x2160_30;
            break;

        case OT_HDMI_VIDEO_FORMAT_3840X2160P_24:
            *intf_sync = HI_MAPI_DISP_OUTPUT_3840x2160_24;
            break;

        case OT_HDMI_VIDEO_FORMAT_3840X2160P_25:
            *intf_sync = HI_MAPI_DISP_OUTPUT_3840x2160_25;
            break;

        case OT_HDMI_VIDEO_FORMAT_3840X2160P_30:
            *intf_sync = HI_MAPI_DISP_OUTPUT_3840x2160_30;
            break;

        case OT_HDMI_VIDEO_FORMAT_3840X2160P_50:
            *intf_sync = HI_MAPI_DISP_OUTPUT_3840x2160_50;
            break;

        case OT_HDMI_VIDEO_FORMAT_3840X2160P_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_3840x2160_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_4096X2160P_24:
            *intf_sync = HI_MAPI_DISP_OUTPUT_4096x2160_24;
            break;

        case OT_HDMI_VIDEO_FORMAT_4096X2160P_25:
            *intf_sync = HI_MAPI_DISP_OUTPUT_4096x2160_25;
            break;

        case OT_HDMI_VIDEO_FORMAT_4096X2160P_30:
            *intf_sync = HI_MAPI_DISP_OUTPUT_4096x2160_30;
            break;

        case OT_HDMI_VIDEO_FORMAT_4096X2160P_50:
            *intf_sync = HI_MAPI_DISP_OUTPUT_4096x2160_50;
            break;

        case OT_HDMI_VIDEO_FORMAT_4096X2160P_60:
            *intf_sync = HI_MAPI_DISP_OUTPUT_4096x2160_60;
            break;

        case OT_HDMI_VIDEO_FORMAT_VESA_CUSTOMER_DEFINE:
            *intf_sync = HI_MAPI_DISP_OUTPUT_USER;
            break;

        default:
            *intf_sync = HI_MAPI_DISP_OUTPUT_BUTT;
            break;
    }

    return;
}

static td_void mapi_adapt_hdmi_video_fmt_cap_convert(const td_bool ab_video_format[], td_bool ab_intf_sync[])
{
    ot_hdmi_video_format hdmi_video_fmt;
    hi_mapi_disp_intf_sync intf_sync;

    for (intf_sync = 0; intf_sync < HI_MAPI_DISP_OUTPUT_BUTT; intf_sync++) {
        ab_intf_sync[intf_sync] = TD_FALSE;
    }

    for (hdmi_video_fmt = 0; hdmi_video_fmt < OT_HDMI_VIDEO_FORMAT_BUTT; hdmi_video_fmt++) {
        if (ab_video_format[hdmi_video_fmt]) {
            mapi_adapt_hdmi_video_fmt_convert(hdmi_video_fmt, &intf_sync);
            if (intf_sync != HI_MAPI_DISP_OUTPUT_BUTT) {
                ab_intf_sync[intf_sync] = TD_TRUE;
            }
        }
    }

    return;
}

static td_void mapi_adapt_hdmi_sample_rate_cap_convert(const ot_hdmi_sample_rate hdmi_sample_rate_cap[],
    hi_mapi_audio_sample_rate ao_samplerate_cap[])
{
    td_s32 i;
    td_s32 j = 0;
    for (i = 0; i < OT_HDMI_MAX_SAMPLE_RATE_NUM; i++) {
        switch (hdmi_sample_rate_cap[i]) {
            case OT_HDMI_SAMPLE_RATE_8K:
                ao_samplerate_cap[j] = HI_MAPI_AUDIO_SAMPLE_RATE_8000;
                j++;
                break;

            case OT_HDMI_SAMPLE_RATE_16K:
                ao_samplerate_cap[j] = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
                j++;
                break;

            case OT_HDMI_SAMPLE_RATE_48K:
                ao_samplerate_cap[j] = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
                j++;
                break;
            default:
                break;
        }

        if (j >= HI_MAPI_AO_MAX_SUPPORT_SAMPLERATE_NUM) {
            break;
        }
    }

    for (i = j; i < HI_MAPI_AO_MAX_SUPPORT_SAMPLERATE_NUM; i++) {
        ao_samplerate_cap[i] = HI_MAPI_AUDIO_SAMPLE_RATE_BUTT;
    }

    return;
}

static td_void mapi_adapt_hdmi_get_ao_sample_rate_cap(const ot_hdmi_audio_info audio_info[],
    hi_mapi_audio_sample_rate support_sample_rate[])
{
    td_s32 i, j;
    td_bool support_audio = TD_FALSE;

    for (i = 0; i < OT_HDMI_MAX_AUDIO_CAPBILITY_CNT; i++) {
        if (audio_info[i].audio_format_code == OT_HDMI_AUDIO_FORMAT_CODE_PCM) {
            break;
        }
    }

    if (i != OT_HDMI_MAX_AUDIO_CAPBILITY_CNT) {
        for (j = 0; j < OT_HDMI_MAX_BIT_DEPTH_NUM; j++) {
            if (audio_info[i].support_bit_depth[j] == OT_HDMI_BIT_DEPTH_16) {
                mapi_adapt_hdmi_sample_rate_cap_convert(audio_info[i].support_sample_rate, support_sample_rate);
                support_audio = TD_TRUE;
                break;
            }
        }
    }

    if (!support_audio) {
        for (i = 0; i < HI_MAPI_AO_MAX_SUPPORT_SAMPLERATE_NUM; i++) {
            support_sample_rate[i] = HI_MAPI_AUDIO_SAMPLE_RATE_BUTT;
        }
    }

    return;
}

td_s32 mapi_adapt_hdmi_get_sink_capability(hi_mapi_hdmi_id hdmi_id,
    hi_mapi_hdmi_sink_capability *sink_capability)
{
    HDMI_CHECK_NULL_PTR(sink_capability);
    ot_hdmi_sink_capability sink_cap;

    td_s32 ret = memset_s(&sink_cap, sizeof(ot_hdmi_sink_capability), 0, sizeof(ot_hdmi_sink_capability));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_HDMI, "memset_s", ret);
    ret = ss_mpi_hdmi_get_sink_capability(hdmi_id, &sink_cap);
    CHECK_MAPI_RET(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_get_sink_capability", ret);

    sink_capability->connected = sink_cap.is_connected;
    sink_capability->is_sink_power_on = sink_cap.is_sink_power_on;
    sink_capability->support_hdmi = sink_cap.support_hdmi;

    /* native sync */
    mapi_adapt_hdmi_video_fmt_convert(sink_cap.native_video_format, &sink_capability->native_intf_sync);

    /* sync capbility */
    mapi_adapt_hdmi_video_fmt_cap_convert(sink_cap.support_video_format, sink_capability->intf_sync);

    /* aosample rate capbility */
    mapi_adapt_hdmi_get_ao_sample_rate_cap(sink_cap.audio_info, sink_capability->support_sample_rate);

    sink_capability->support_hdmi_2_0 = sink_cap.support_hdmi_2_0;

    return TD_SUCCESS;
}

static td_void mapi_adapt_hdmi_sample_rate_convert(ot_hdmi_sample_rate hdmi_sample_rate,
    hi_mapi_audio_sample_rate *ao_sample_rate)
{
    switch (hdmi_sample_rate) {
        case OT_HDMI_SAMPLE_RATE_8K:
            *ao_sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_8000;
            break;

        case OT_HDMI_SAMPLE_RATE_16K:
            *ao_sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
            break;

        case OT_HDMI_SAMPLE_RATE_48K:
            *ao_sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
            break;

        default:
            *ao_sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_BUTT;
            break;
    }
    return;
}

td_s32 mapi_adapt_hdmi_get_attr(hi_mapi_hdmi_id hdmi_id, hi_mapi_hdmi_attr *hdmi_attr)
{
    ot_hdmi_attr attr;
    HDMI_CHECK_NULL_PTR(hdmi_attr);

    td_s32 ret = memset_s(&attr, sizeof(ot_hdmi_attr), 0, sizeof(ot_hdmi_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_HDMI, "memset_s", ret);

    ret = ss_mpi_hdmi_get_attr(hdmi_id, &attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_get_attr", ret);

    mapi_adapt_hdmi_video_fmt_convert(attr.video_format, &hdmi_attr->hdmi_sync);
    mapi_adapt_hdmi_sample_rate_convert(attr.sample_rate, &hdmi_attr->sample_rate);

    hdmi_attr->enable_hdmi = attr.hdmi_en;
    hdmi_attr->enable_video = attr.video_format;
    hdmi_attr->enable_audio = attr.audio_en;
    hdmi_attr->pix_clk = attr.pix_clk;

    return TD_SUCCESS;
}

static td_void mapi_adapt_hdmi_ao_sample_rate_convert(hi_mapi_audio_sample_rate ao_sample_rate,
    ot_hdmi_sample_rate *hdmi_sample_rate)
{
    switch (ao_sample_rate) {
        case HI_MAPI_AUDIO_SAMPLE_RATE_8000:
            *hdmi_sample_rate = OT_HDMI_SAMPLE_RATE_8K;
            break;

        case HI_MAPI_AUDIO_SAMPLE_RATE_16000:
            *hdmi_sample_rate = OT_HDMI_SAMPLE_RATE_16K;
            break;

        case HI_MAPI_AUDIO_SAMPLE_RATE_48000:
            *hdmi_sample_rate = OT_HDMI_SAMPLE_RATE_48K;
            break;

        default:
            *hdmi_sample_rate = OT_HDMI_SAMPLE_RATE_BUTT;
            break;
    }
    return;
}

static td_void mapi_adapt_hdmi_intf_sync_convert(hi_mapi_disp_intf_sync intf_sync, ot_hdmi_video_format *video_fmt)
{
    switch (intf_sync) {
        case HI_MAPI_DISP_OUTPUT_1080P24:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_1080P_24;
            break;

        case HI_MAPI_DISP_OUTPUT_1080P25:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_1080P_25;
            break;

        case HI_MAPI_DISP_OUTPUT_1080P30:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_1080P_30;
            break;

        case HI_MAPI_DISP_OUTPUT_720P50:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_720P_50;
            break;

        case HI_MAPI_DISP_OUTPUT_720P60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_720P_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1080P50:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_1080P_50;
            break;

        case HI_MAPI_DISP_OUTPUT_1080P60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_1080P_60;
            break;

        case HI_MAPI_DISP_OUTPUT_576P50:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_576P_50;
            break;

        case HI_MAPI_DISP_OUTPUT_480P60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_480P_60;
            break;

        case HI_MAPI_DISP_OUTPUT_800x600_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_800X600_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1024x768_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_1024X768_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1280x1024_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_1280X1024_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1366x768_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_1366X768_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1440x900_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_1440X900_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1280x800_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_1280X800_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1600x1200_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_1600X1200_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1680x1050_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_1680X1050_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1920x1200_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_1920X1200_60;
            break;

        case HI_MAPI_DISP_OUTPUT_640x480_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_861D_640X480_60;
            break;

        case HI_MAPI_DISP_OUTPUT_1920x2160_30:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_1920x2160_30;
            break;

        case HI_MAPI_DISP_OUTPUT_2560x1440_30:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_2560x1440_30;
            break;

        case HI_MAPI_DISP_OUTPUT_2560x1600_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_2560x1600_60;
            break;

        case HI_MAPI_DISP_OUTPUT_3840x2160_24:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_3840X2160P_24;
            break;

        case HI_MAPI_DISP_OUTPUT_3840x2160_25:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_3840X2160P_25;
            break;

        case HI_MAPI_DISP_OUTPUT_3840x2160_30:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_3840X2160P_30;
            break;

        case HI_MAPI_DISP_OUTPUT_3840x2160_50:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_3840X2160P_50;
            break;

        case HI_MAPI_DISP_OUTPUT_3840x2160_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_3840X2160P_60;
            break;

        case HI_MAPI_DISP_OUTPUT_4096x2160_24:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_4096X2160P_24;
            break;

        case HI_MAPI_DISP_OUTPUT_4096x2160_25:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_4096X2160P_25;
            break;

        case HI_MAPI_DISP_OUTPUT_4096x2160_30:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_4096X2160P_30;
            break;

        case HI_MAPI_DISP_OUTPUT_4096x2160_50:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_4096X2160P_50;
            break;

        case HI_MAPI_DISP_OUTPUT_4096x2160_60:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_4096X2160P_60;
            break;

        case HI_MAPI_DISP_OUTPUT_USER:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_VESA_CUSTOMER_DEFINE;
            break;

        default:
            *video_fmt = OT_HDMI_VIDEO_FORMAT_BUTT;
            break;
    }
    return;
}

static td_bool mapi_adapt_hdmi_check_attr(const hi_mapi_hdmi_attr *get_hdmi_attr,
    const hi_mapi_hdmi_attr *set_hdmi_attr)
{
    if ((set_hdmi_attr->enable_hdmi == get_hdmi_attr->enable_hdmi) &&
        (set_hdmi_attr->enable_video == get_hdmi_attr->enable_video) &&
        (set_hdmi_attr->hdmi_sync == get_hdmi_attr->hdmi_sync) &&
        (set_hdmi_attr->enable_audio == get_hdmi_attr->enable_audio) &&
        (set_hdmi_attr->sample_rate == get_hdmi_attr->sample_rate)) {
        if ((set_hdmi_attr->hdmi_sync != HI_MAPI_DISP_OUTPUT_USER) ||
            (set_hdmi_attr->pix_clk == get_hdmi_attr->pix_clk)) {
            return TD_TRUE;
        }
    }

    return TD_FALSE;
}

static td_void mapi_adapt_hdmi_config_attr(const hi_mapi_hdmi_attr *hdmi_attr, ot_hdmi_attr *attr)
{
    mapi_adapt_hdmi_intf_sync_convert(hdmi_attr->hdmi_sync, &attr->video_format);
    mapi_adapt_hdmi_ao_sample_rate_convert(hdmi_attr->sample_rate, &attr->sample_rate);

    if (attr->sample_rate == OT_HDMI_SAMPLE_RATE_BUTT) {
        attr->sample_rate = OT_HDMI_SAMPLE_RATE_48K;
    }

    attr->hdmi_en = hdmi_attr->enable_hdmi;
    attr->video_format = hdmi_attr->enable_video;
    attr->audio_en = hdmi_attr->enable_audio;
    attr->bit_depth = OT_HDMI_BIT_DEPTH_16;
    attr->deep_color_mode = OT_HDMI_DEEP_COLOR_24BIT;

    return;
}

td_s32 mapi_adapt_hdmi_set_attr(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_attr *hdmi_attr, td_bool is_start)
{
    HDMI_CHECK_NULL_PTR(hdmi_attr);

    ot_hdmi_attr attr;
    td_s32 ret = memset_s(&attr, sizeof(ot_hdmi_attr), 0, sizeof(ot_hdmi_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_HDMI, "memset_s", ret);
    ret = ss_mpi_hdmi_get_attr(hdmi_id, &attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_get_attr", ret);

    hi_mapi_hdmi_attr get_hdmi_attr;
    mapi_adapt_hdmi_video_fmt_convert(attr.video_format, &get_hdmi_attr.hdmi_sync);
    mapi_adapt_hdmi_sample_rate_convert(attr.sample_rate, &get_hdmi_attr.sample_rate);
    get_hdmi_attr.enable_hdmi = attr.hdmi_en;
    get_hdmi_attr.enable_video = attr.video_format;
    get_hdmi_attr.enable_audio = attr.audio_en;
    get_hdmi_attr.pix_clk = attr.pix_clk;

    if (is_start) {
        if (mapi_adapt_hdmi_check_attr(&get_hdmi_attr, hdmi_attr)) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI Attr is not change, return successful\n\n");
            return TD_SUCCESS;
        } else {
            MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has started and does not support setting HDMI Attr\n");
            return HI_MAPI_HDMI_ENOT_SUPPORT;
        }
    }

    mapi_adapt_hdmi_config_attr(hdmi_attr, &attr);
    ret = ss_mpi_hdmi_set_attr(hdmi_id, &attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_HDMI, "ss_mpi_hdmi_set_attr", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_hdmi_start(hi_mapi_hdmi_id hdmi_id)
{
    return ss_mpi_hdmi_start(hdmi_id);
}

td_s32 mapi_adapt_hdmi_stop(hi_mapi_hdmi_id hdmi_id)
{
    return ss_mpi_hdmi_stop(hdmi_id);
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
#endif
