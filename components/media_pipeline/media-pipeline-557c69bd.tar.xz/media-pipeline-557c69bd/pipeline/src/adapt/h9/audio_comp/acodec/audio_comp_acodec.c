/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_acodec.h"
#include "mapi_comm_inner.h"
#include <string.h>
#include <stdio.h>

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define AUDIO_COMP_ACODEC_MAX_PROVIDERS 4
#define AUDIO_COMP_ACODEC_NAME_LEN      32

typedef struct {
    char name[AUDIO_COMP_ACODEC_NAME_LEN];
    const audio_comp_acodec_ops_t *ops;
} audio_comp_acodec_entry_t;

static audio_comp_acodec_entry_t       g_providers[AUDIO_COMP_ACODEC_MAX_PROVIDERS];
static int                             g_provider_count = 0;
static const audio_comp_acodec_ops_t  *g_active_ops = NULL;

/* Registry */
td_s32 audio_comp_acodec_register(const char *name, const audio_comp_acodec_ops_t *ops)
{
    if (name == NULL || ops == NULL) {
        return -1;
    }
    if (g_provider_count >= AUDIO_COMP_ACODEC_MAX_PROVIDERS) {
        fprintf(stderr, "[audio_comp_acodec] provider table full (cap=%d)\n",
                AUDIO_COMP_ACODEC_MAX_PROVIDERS);
        return -1;
    }
    for (int i = 0; i < g_provider_count; i++) {
        if (strcmp(g_providers[i].name, name) == 0) {
            if (g_providers[i].ops == ops) {
                return 0;
            }
            fprintf(stderr, "[audio_comp_acodec] duplicate provider name: %s\n", name);
            return -1;
        }
    }

    strncpy(g_providers[g_provider_count].name, name, AUDIO_COMP_ACODEC_NAME_LEN - 1);
    g_providers[g_provider_count].name[AUDIO_COMP_ACODEC_NAME_LEN - 1] = '\0';
    g_providers[g_provider_count].ops = ops;
    g_provider_count++;

    /* First registration becomes the default active provider. */
    if (g_active_ops == NULL) {
        g_active_ops = ops;
    }
    return 0;
}

const audio_comp_acodec_ops_t *audio_comp_acodec_get_ops(const char *name)
{
    if (name == NULL) {
        return NULL;
    }
    for (int i = 0; i < g_provider_count; i++) {
        if (strcmp(g_providers[i].name, name) == 0) {
            return g_providers[i].ops;
        }
    }
    return NULL;
}

td_s32 audio_comp_acodec_set_active(const char *name)
{
    const audio_comp_acodec_ops_t *ops = audio_comp_acodec_get_ops(name);
    if (ops == NULL) {
        return -1;
    }
    g_active_ops = ops;
    return 0;
}

const audio_comp_acodec_ops_t *audio_comp_acodec_get_active(void)
{
    return g_active_ops;
}

/* Public API dispatchers */
#define ACODEC_DISPATCH(fn_name, ...) \
    do { \
        if (g_active_ops == NULL || g_active_ops->fn_name == NULL) { \
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "no acodec provider active for " #fn_name "\n"); \
            return TD_FAILURE; \
        } \
        return g_active_ops->fn_name(__VA_ARGS__); \
    } while (0)

td_s32 audio_comp_acodec_open(td_void)
{
    ACODEC_DISPATCH(open);
}

td_s32 audio_comp_acodec_close(td_void)
{
    ACODEC_DISPATCH(close);
}

td_s32 audio_comp_acodec_config_attr(hi_mapi_audio_sample_rate sample_rate, hi_mapi_aio_acodec_mixer mixer_mic_mode)
{
    ACODEC_DISPATCH(config_attr, sample_rate, mixer_mic_mode);
}

td_s32 audio_comp_acodec_set_ai_vol(td_s32 input_vol)
{
    ACODEC_DISPATCH(set_ai_vol, input_vol);
}

td_s32 audio_comp_acodec_get_ai_vol(td_s32 *input_vol)
{
    ACODEC_DISPATCH(get_ai_vol, input_vol);
}

td_s32 audio_comp_acodec_set_ao_vol(td_s32 output_vol)
{
    ACODEC_DISPATCH(set_ao_vol, output_vol);
}

td_s32 audio_comp_acodec_get_ao_vol(td_s32 *output_vol)
{
    ACODEC_DISPATCH(get_ao_vol, output_vol);
}

td_s32 audio_comp_acodec_mute_ai(td_void)
{
    ACODEC_DISPATCH(mute_ai);
}

td_s32 audio_comp_acodec_unmute_ai(td_void)
{
    ACODEC_DISPATCH(unmute_ai);
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
