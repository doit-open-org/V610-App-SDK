/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_ao.h"
#include "audio_comp/audio_comp_acodec.h"
#include "audio_comp/aec_ref_bus.h"
#include "mapi_comm_inner.h"
#include "ss_mpi_audio.h"
#include "ss_mpi_sys.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static td_s32 audio_comp_ao_config_attr(const mapi_ao_server_context *ao_context,
    const hi_mapi_ao_attr *ao_attr, ot_aio_attr *aio_attr)
{
    aio_attr->expand_flag = ao_context->expand_flag;
    aio_attr->chn_cnt = ao_context->chn_cnt;
    aio_attr->frame_num = ao_context->frm_num;
    aio_attr->clk_share = ao_context->clk_sel;
    switch (ao_attr->sample_rate) {
        case HI_MAPI_AUDIO_SAMPLE_RATE_8000:
        case HI_MAPI_AUDIO_SAMPLE_RATE_16000:
        case HI_MAPI_AUDIO_SAMPLE_RATE_48000:
            aio_attr->sample_rate = (ot_audio_sample_rate)ao_attr->sample_rate;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "do not support this sample_rate:%d error.\n", ao_attr->sample_rate);
            return HI_MAPI_AO_EILLPARAM;
    }
    switch (ao_attr->bit_width) {
        case HI_MAPI_AUDIO_BIT_WIDTH_16:
            aio_attr->bit_width = (ot_audio_bit_width)ao_attr->bit_width;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "not support bitwidth\n");
            return HI_MAPI_AO_EILLPARAM;
    }

    aio_attr->work_mode = (ot_aio_mode)ao_attr->work_mode;
    aio_attr->snd_mode = (ot_audio_snd_mode)ao_attr->sound_mode;
    aio_attr->point_num_per_frame = ao_attr->pt_num_per_frm;
    aio_attr->i2s_type = (ot_aio_i2s_type)ao_attr->i2s_type;

    if (aio_attr->i2s_type == OT_AIO_I2STYPE_EXTERN) {
        aio_attr->clk_share = 1;
        aio_attr->chn_cnt = 1;
    }

    return TD_SUCCESS;
}

td_s32 audio_comp_ao_set_pub_attr(td_handle ao_hdl, const mapi_ao_server_context *ao_context,
    const hi_mapi_ao_attr *ao_attr)
{
    ot_aio_attr aio_attr;
    CHECK_MAPI_AO_NULL_PTR_RET(ao_context);
    CHECK_MAPI_AO_NULL_PTR_RET(ao_attr);

    td_s32 ret = audio_comp_ao_config_attr(ao_context, ao_attr, &aio_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "audio_comp_ao_config_attr", ret);

    MAPI_WARN_TRACE(HI_MAPI_MOD_AO,
        "AO attr: rate=%d bit=%d mode=%d snd=%d frame=%u points=%u chn=%u clk=%u i2s=%d\n",
        aio_attr.sample_rate, aio_attr.bit_width, aio_attr.work_mode, aio_attr.snd_mode,
        aio_attr.frame_num, aio_attr.point_num_per_frame, aio_attr.chn_cnt, aio_attr.clk_share, aio_attr.i2s_type);
    ret = ss_mpi_ao_set_pub_attr(ao_hdl, &aio_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_set_pub_attr", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_ao_enable(td_handle ao_hdl)
{
    return ss_mpi_ao_enable(ao_hdl);
}

td_s32 audio_comp_ao_disable(td_handle ao_hdl)
{
    return ss_mpi_ao_disable(ao_hdl);
}

td_s32 audio_comp_ao_enable_chn(td_handle ao_hdl, td_handle ao_chn_hdl)
{
    return ss_mpi_ao_enable_chn(ao_hdl, ao_chn_hdl);
}

td_s32 audio_comp_ao_disable_chn(td_handle ao_hdl, td_handle ao_chn_hdl)
{
    return ss_mpi_ao_disable_chn(ao_hdl, ao_chn_hdl);
}

td_s32 audio_comp_ao_enable_resmp(td_handle ao_hdl, td_handle ao_chn_hdl, hi_mapi_audio_sample_rate sample_rate)
{
    td_s32 ret = ss_mpi_ao_disable_resample(ao_hdl, ao_chn_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_disable_resample", ret);

    ret = ss_mpi_ao_enable_resample(ao_hdl, ao_chn_hdl, sample_rate);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_enable_resample", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_ao_disable_resmp(td_handle ao_hdl, td_handle ao_chn_hdl)
{
    return ss_mpi_ao_disable_resample(ao_hdl, ao_chn_hdl);
}

td_s32 audio_comp_ao_start(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_ao_attr *ao_attr)
{
    CHECK_MAPI_AO_NULL_PTR_RET(ao_attr);

    td_s32 ret = ss_mpi_ao_enable(ao_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_enable", ret);

    if (ao_attr->i2s_type == HI_MAPI_AIO_I2STYPE_INNERCODEC) {
        ret = audio_comp_acodec_config_attr(ao_attr->sample_rate, HI_MAPI_ACODEC_MIXER_IN1);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "audio inner codec config error.\n");
            (td_void)ss_mpi_ao_disable(ao_hdl);
            return ret;
        }
    }

    if (ao_attr->work_mode == HI_MAPI_AIO_MODE_I2S_MASTER || ao_attr->work_mode == HI_MAPI_AIO_MODE_I2S_SLAVE) {
        ret = ss_mpi_ao_set_track_mode(ao_hdl, ao_attr->track_mode);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ss_mpi_ao_set_track_mode fail, ret:%x\n", ret);
            (td_void)ss_mpi_ao_disable(ao_hdl);
            return ret;
        }
    }

    ret = ss_mpi_ao_enable_chn(ao_hdl, ao_chn_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ss_mpi_ao_enable_chn error.\n");
        (td_void)ss_mpi_ao_disable(ao_hdl);
        return ret;
    }

    ret = ss_mpi_ao_enable_chn(ao_hdl, OT_AO_SYS_CHN_ID);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ss_mpi_ao_enable_sys_chn[%d] error.\n", OT_AO_SYS_CHN_ID);
        (td_void)ss_mpi_ao_disable(ao_hdl);
        (td_void)ss_mpi_ao_disable_chn(ao_hdl, ao_chn_hdl);
        return ret;
    }

    if (ao_attr->sample_rate != ao_attr->in_sample_rate) {
        ret = ss_mpi_ao_enable_resample(ao_hdl, ao_chn_hdl, ao_attr->in_sample_rate);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "enable ao resample error. chn_id:%d\n", ao_chn_hdl);
            (td_void)ss_mpi_ao_disable(ao_hdl);
            (td_void)ss_mpi_ao_disable_chn(ao_hdl, ao_chn_hdl);
            (td_void)ss_mpi_ao_disable_chn(ao_hdl, OT_AO_SYS_CHN_ID);
            return ret;
        }
    }

    return TD_SUCCESS;
}

td_s32 audio_comp_ao_stop(td_handle ao_hdl)
{
    td_s32 ret = ss_mpi_ao_disable_chn(ao_hdl, OT_AO_SYS_CHN_ID);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_disable_chn", ret);

    ret = ss_mpi_ao_disable(ao_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_disable", ret);

    return TD_SUCCESS;
}

#ifdef SUPPORT_TALKVQE
static td_s32 audio_comp_ao_get_vqe_config(td_handle ao_hdl, ot_ao_vqe_cfg *ao_vqe_cfg,
    const hi_mapi_ao_attr *ao_attr)
{
    td_s32 ret;
    (td_void)ao_hdl;

    switch (ao_attr->sample_rate) {
        case HI_MAPI_AUDIO_SAMPLE_RATE_16000:
            ao_vqe_cfg->work_sample_rate = OT_AUDIO_SAMPLE_RATE_16000;
            break;

        case HI_MAPI_AUDIO_SAMPLE_RATE_8000:
            ao_vqe_cfg->work_sample_rate = OT_AUDIO_SAMPLE_RATE_8000;
            break;

        default:
            ao_vqe_cfg->work_sample_rate = OT_AUDIO_SAMPLE_RATE_8000;
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "VQE sample_rate only support 16K or 8K, default use 8K.\n");
            break;
    }

    ao_vqe_cfg->frame_sample = ao_attr->pt_num_per_frm;

    ao_vqe_cfg->agc_cfg.usr_mode = TD_FALSE;
    ao_vqe_cfg->agc_cfg.noise_suppress_switch = 0;
    ao_vqe_cfg->agc_cfg.adjust_speed = 0;
    ao_vqe_cfg->agc_cfg.improve_snr = 0;
    ao_vqe_cfg->agc_cfg.max_gain = 0;
    ao_vqe_cfg->agc_cfg.noise_floor = -50;
    ao_vqe_cfg->agc_cfg.output_mode = 0;
    ao_vqe_cfg->agc_cfg.target_level = -40;
    ao_vqe_cfg->agc_cfg.use_hpf = 0;

    ao_vqe_cfg->anr_cfg.usr_mode = TD_FALSE;
    ao_vqe_cfg->anr_cfg.nr_intensity = 0;
    ao_vqe_cfg->anr_cfg.noise_db_threshold = 30;
    ao_vqe_cfg->anr_cfg.music_probe_switch = 0;
    ao_vqe_cfg->anr_cfg.reserved = 0;

    ao_vqe_cfg->hpf_cfg.usr_mode = TD_FALSE;
    ao_vqe_cfg->hpf_cfg.hpf_freq = OT_AUDIO_HPF_FREQ_80;

    ret = memset_s(&ao_vqe_cfg->eq_cfg.gain_db, sizeof(OT_VQE_EQ_BAND_NUM), 0, sizeof(OT_VQE_EQ_BAND_NUM));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_AO, "memset_s", ret);
    ao_vqe_cfg->eq_cfg.reserved = 0;

    return TD_SUCCESS;
}

td_s32 audio_comp_ao_enable_vqe(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_ao_vqe_attr *ao_vqe_attr,
    const hi_mapi_ao_attr *ao_attr, td_u32 open_mask)
{
    ot_ao_vqe_cfg ao_vqe_cfg;
    CHECK_MAPI_AO_NULL_PTR_RET(ao_vqe_attr);
    CHECK_MAPI_AO_NULL_PTR_RET(ao_attr);

    td_s32 ret = memset_s(&ao_vqe_cfg, sizeof(ot_ao_vqe_cfg), 0, sizeof(ot_ao_vqe_cfg));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_AO, "memset_s", ret);

    ao_vqe_cfg.work_state = (ot_vqe_work_state)ao_vqe_attr->work_state;
    ao_vqe_cfg.open_mask = open_mask;
    ret = audio_comp_ao_get_vqe_config(ao_hdl, &ao_vqe_cfg, ao_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "audio_comp_ao_get_vqe_config", ret);

    ret = ss_mpi_ao_set_vqe_attr(ao_hdl, ao_chn_hdl, &ao_vqe_cfg);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_set_vqe_attr", ret);

    ret = ss_mpi_ao_enable_vqe(ao_hdl, ao_chn_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_enable_vqe", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_ao_disable_vqe(td_handle ao_hdl, td_handle ao_chn_hdl)
{
    return ss_mpi_ao_disable_vqe(ao_hdl, ao_chn_hdl);
}
#endif

td_s32 audio_comp_ao_set_mute(td_handle ao_hdl, td_bool enable)
{
    ot_audio_fade fade;
    fade.fade = TD_TRUE;
    if (enable == TD_TRUE) {
        fade.fade_in_rate = OT_AUDIO_FADE_RATE_1;
        fade.fade_out_rate = OT_AUDIO_FADE_RATE_64;
    } else {
        fade.fade_in_rate = OT_AUDIO_FADE_RATE_8;
        fade.fade_out_rate = OT_AUDIO_FADE_RATE_1;
    }
    td_s32 ret = ss_mpi_ao_set_mute(ao_hdl, enable, &fade);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_set_mute", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_ao_send_frame(td_handle ao_hdl, td_handle ao_chn_hdl,
    const hi_mapi_audio_frame *audio_frame, td_u32 timeout)
{
    ot_audio_frame frame;
    CHECK_MAPI_AO_NULL_PTR_RET(audio_frame);

    frame.bit_width = audio_frame->bit_width;
    frame.snd_mode = audio_frame->snd_mode;
    frame.time_stamp = audio_frame->time_stamp;
    frame.seq = audio_frame->seq;
    frame.len = audio_frame->len;
    for (td_u32 i = 0; i < HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i++) {
        frame.virt_addr[i] = audio_frame->virt_addr[i];
        frame.phys_addr[i] = audio_frame->phys_addr[i];
        frame.pool_id[i] = audio_frame->pool_id[i];
    }

    /* AEC 参考旁路：当软件 AFE 激活（如云知声 external）且消费端已使能参考总线
     * （内置 CODEC 无物理回采通道场景），把要播放的远端 PCM 旁路给 ACAP 软件 AFE
     * 作回声参考。AO 在本方案中配置为 mono/16bit，取 virt_addr[0] 即单声道播放帧；
     * 非该场景（hisi / ES7210 物理回采）总线保持关闭，此处为零开销。 */
    if (aec_ref_bus_enabled() == TD_TRUE && audio_frame->virt_addr[0] != TD_NULL &&
        audio_frame->len > 0) {
        aec_ref_bus_write((const int16_t *)audio_frame->virt_addr[0],
            audio_frame->len / (td_u32)sizeof(int16_t));
    }

    td_s32 ret = ss_mpi_ao_send_frame(ao_hdl, ao_chn_hdl, &frame, timeout);
    CHECK_MAPI_RET(HI_MAPI_MOD_AO, "ss_mpi_ao_send_frame", ret);

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
