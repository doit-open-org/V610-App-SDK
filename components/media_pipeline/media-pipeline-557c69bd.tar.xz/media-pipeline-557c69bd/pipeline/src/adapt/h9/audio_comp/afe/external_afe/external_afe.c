/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_afe.h"
#include "mapi_comm_inner.h"
#include "nr_adapter.h"

#include <stdint.h>
#include "ot_type.h"

#define EXTERNAL_AFE_FRAME_SAMPLES 256
#define EXT_AFE_CHANNELS 2  /* dual mic (interleaved); reference passed separately */

static const NrOpsT *g_nr_ops;
static td_bool g_external_inited;

static int external_afe_init(const audio_comp_afe_attr_t *attr)
{
    if (attr == TD_NULL || g_external_inited == TD_TRUE) {
        return attr == TD_NULL ? TD_FAILURE : TD_SUCCESS;
    }

    g_nr_ops = NrAdapterGetActive();
    if (g_nr_ops == TD_NULL || g_nr_ops->init == TD_NULL ||
        g_nr_ops->process == TD_NULL) {
        return TD_FAILURE;
    }

    g_nr_ops->init(attr->model_path);

    g_external_inited = TD_TRUE;
    return TD_SUCCESS;
}

static int external_afe_process(const audio_comp_pcm_view_in_t *in,
    audio_comp_pcm_view_out_t *out)
{
    int16_t merged[EXTERNAL_AFE_FRAME_SAMPLES * EXT_AFE_CHANNELS];
    int16_t *nr_out = TD_NULL;
    int32_t nr_out_samples = 0;
    int32_t nr_out_size = 0;

    if (g_external_inited != TD_TRUE || in == TD_NULL || out == TD_NULL ||
        in->data == TD_NULL || in->data_ch1 == TD_NULL ||
        in->ref_data == TD_NULL || in->channels != EXT_AFE_CHANNELS ||
        in->samples != EXTERNAL_AFE_FRAME_SAMPLES) {
        return TD_FAILURE;
    }

    for (td_u32 i = 0; i < EXTERNAL_AFE_FRAME_SAMPLES; i++) {
        merged[EXT_AFE_CHANNELS * i] = in->data[i];
        merged[EXT_AFE_CHANNELS * i + 1] = in->data_ch1[i];
    }

    int ret = g_nr_ops->process(merged, (int16_t *)(uintptr_t)in->ref_data,
        EXTERNAL_AFE_FRAME_SAMPLES, &nr_out, &nr_out_samples, &nr_out_size);
    if (ret != 0 || nr_out == TD_NULL) {
        return TD_FAILURE;
    }

    out->data = nr_out;
    out->samples = EXTERNAL_AFE_FRAME_SAMPLES;
    out->channels = 1;
    out->sample_rate = in->sample_rate;
    return TD_SUCCESS;
}

static void external_afe_deinit(void)
{
    if (g_external_inited == TD_TRUE && g_nr_ops != TD_NULL &&
        g_nr_ops->deinit != TD_NULL) {
        g_nr_ops->deinit();
    }
    g_nr_ops = TD_NULL;
    g_external_inited = TD_FALSE;
}

static const audio_comp_afe_ops_t g_external_afe_ops = {
    .init = external_afe_init,
    .process = external_afe_process,
    .deinit = external_afe_deinit,
    .needs_raw_frame = 1,
    .software_process = 1,
};

void external_afe_provider_register(void)
{
    (void)audio_comp_afe_register("external", &g_external_afe_ops);
}

static void __attribute__((constructor)) external_afe_auto_register(void)
{
    external_afe_provider_register();
}
