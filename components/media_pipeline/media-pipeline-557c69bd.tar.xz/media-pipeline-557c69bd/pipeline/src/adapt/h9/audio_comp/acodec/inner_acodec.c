/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>

#include "ot_common_aio.h"
#include "ot_acodec.h"
#include "audio_comp/audio_comp_acodec.h"
#include "mapi_acap_inner.h"
#include "mapi_ao_inner.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define INNER_ACODEC_DEV "/dev/acodec"

/* Single /dev/acodec fd shared between mic (AI) and speaker (AO).  The
 * dispatcher in audio_comp_acodec.c never touches this fd; only this provider
 * does, so multiple registered providers cannot double-open the device. */
static td_s32 g_inner_acodec_fd = -1;

static td_s32 inner_acodec_open(td_void)
{
    if (g_inner_acodec_fd != -1) {
        MAPI_DEBUG_TRACE(HI_MAPI_MOD_ACAP, "Acodec have already open, fd:%d\n", g_inner_acodec_fd);
        return TD_SUCCESS;
    }

    g_inner_acodec_fd = open(INNER_ACODEC_DEV, O_RDWR | O_CLOEXEC);
    if (g_inner_acodec_fd < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "can't open Acodec, errno: %d\n", errno);
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

static td_s32 inner_acodec_close(td_void)
{
    if (g_inner_acodec_fd == -1) {
        MAPI_DEBUG_TRACE(HI_MAPI_MOD_ACAP, "Acodec have already close\n");
        return TD_SUCCESS;
    }
    td_s32 ret = close(g_inner_acodec_fd);
    if (ret < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "close Acodec fail, errno: %d\n", errno);
        return TD_FAILURE;
    }
    g_inner_acodec_fd = -1;
    return TD_SUCCESS;
}

static td_s32 inner_acodec_config_attr(hi_mapi_audio_sample_rate sample_rate,
                                        hi_mapi_aio_acodec_mixer mixer_mic_mode)
{
    ot_acodec_fs i2s_fs = 0;
    ot_acodec_mixer input_mode;
    td_u32 mute_ctrl = 0x0;

    if (g_inner_acodec_fd == -1) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "Acodec not open\n");
        return TD_FAILURE;
    }

    switch (sample_rate) {
        case HI_MAPI_AUDIO_SAMPLE_RATE_8000:
            i2s_fs = OT_ACODEC_FS_8000;  break;
        case HI_MAPI_AUDIO_SAMPLE_RATE_16000:
            i2s_fs = OT_ACODEC_FS_16000; break;
        case HI_MAPI_AUDIO_SAMPLE_RATE_48000:
            i2s_fs = OT_ACODEC_FS_48000; break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "not support sample_rate:%d\n", sample_rate);
            return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_I2S1_FS, &i2s_fs) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "set acodec sample rate failed\n");
        return TD_FAILURE;
    }

    if (mixer_mic_mode != HI_MAPI_ACODEC_MIXER_BUTT) {
        input_mode = mixer_mic_mode;
        if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_MIXER_MIC, &input_mode) != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "select acodec input_mode failed\n");
            return TD_FAILURE;
        }
        if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_MICL_MUTE, &mute_ctrl) != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_MICL_MUTE failed\n");
            return TD_FAILURE;
        }
        if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_MICR_MUTE, &mute_ctrl) != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_MICR_MUTE failed\n");
            return TD_FAILURE;
        }
    }
    return TD_SUCCESS;
}

static td_s32 inner_acodec_set_ai_vol(td_s32 input_vol)
{
    if (g_inner_acodec_fd == -1) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "Acodec not open\n");
        return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_INPUT_VOLUME, &input_vol) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "set acodec micin volume failed\n");
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

static td_s32 inner_acodec_get_ai_vol(td_s32 *input_vol)
{
    CHECK_MAPI_AO_NULL_PTR_RET(input_vol);
    td_s32 vol = 0;
    if (g_inner_acodec_fd == -1) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "Acodec not open\n");
        return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_GET_INPUT_VOLUME, &vol) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "set acodec micin volume failed\n");
        return TD_FAILURE;
    }
    *input_vol = vol;
    return TD_SUCCESS;
}

static td_s32 inner_acodec_set_ao_vol(td_s32 output_vol)
{
    if (g_inner_acodec_fd == -1) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "Acodec not open\n");
        return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_OUTPUT_VOLUME, &output_vol) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "set acodec mic out volume failed\n");
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

static td_s32 inner_acodec_get_ao_vol(td_s32 *output_vol)
{
    CHECK_MAPI_AO_NULL_PTR_RET(output_vol);
    td_s32 vol = 0;
    if (g_inner_acodec_fd == -1) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "Acodec not open\n");
        return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_GET_OUTPUT_VOLUME, &vol) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "set acodec mic out volume failed\n");
        return TD_FAILURE;
    }
    *output_vol = vol;
    return TD_SUCCESS;
}

static td_s32 inner_acodec_mute_ai(td_void)
{
    if (g_inner_acodec_fd == -1) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "Acodec not open in mute ai\n");
        return TD_FAILURE;
    }
    ot_acodec_volume_ctrl ctl;
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_GET_ADCR_VOLUME, &ctl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_GET_ADCR_VOL failed\n");
        return TD_FAILURE;
    }
    ctl.volume_ctrl_mute = 0x1;
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_ADCR_VOLUME, &ctl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_ADCR_VOLUME failed\n");
        return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_GET_ADCL_VOLUME, &ctl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACODEC_GET_ADCL_VOLUME failed\n");
        return TD_FAILURE;
    }
    ctl.volume_ctrl_mute = 0x1;
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_ADCL_VOLUME, &ctl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_ADCL_VOLUME failed\n");
        return TD_FAILURE;
    }
    unsigned int mute = 0x1;
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_MICL_MUTE, &mute) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_MICL_MUTE failed in mute ai\n");
        return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_MICR_MUTE, &mute) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_MICR_MUTE failed in mute ai\n");
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

static td_s32 inner_acodec_unmute_ai(td_void)
{
    if (g_inner_acodec_fd == -1) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "Acodec not open in unmute ai\n");
        return TD_FAILURE;
    }
    ot_acodec_volume_ctrl ctl;
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_GET_ADCR_VOLUME, &ctl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_GET_ADCR_VOLUME failed\n");
        return TD_FAILURE;
    }
    ctl.volume_ctrl_mute = 0x0;
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_ADCR_VOLUME, &ctl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_ADCR_VOLUME failed\n");
        return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_GET_ADCL_VOLUME, &ctl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_GET_ADCL_VOLUME failed\n");
        return TD_FAILURE;
    }
    ctl.volume_ctrl_mute = 0x0;
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_ADCL_VOLUME, &ctl) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_ADCL_VOLUME failed\n");
        return TD_FAILURE;
    }
    unsigned int mute = 0x0;
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_MICL_MUTE, &mute) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_MICL_MUTE failed in unmute ai\n");
        return TD_FAILURE;
    }
    if (ioctl(g_inner_acodec_fd, OT_ACODEC_SET_MICR_MUTE, &mute) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "OT_ACODEC_SET_MICR_MUTE failed in unmute ai\n");
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

static const audio_comp_acodec_ops_t g_inner_acodec_ops = {
    .open        = inner_acodec_open,
    .close       = inner_acodec_close,
    .config_attr = inner_acodec_config_attr,
    .set_ai_vol  = inner_acodec_set_ai_vol,
    .get_ai_vol  = inner_acodec_get_ai_vol,
    .set_ao_vol  = inner_acodec_set_ao_vol,
    .get_ao_vol  = inner_acodec_get_ao_vol,
    .mute_ai     = inner_acodec_mute_ai,
    .unmute_ai   = inner_acodec_unmute_ai,
};

/* Called explicitly from mapi_acap_init() to guarantee inclusion in static-lib
 * builds where __attribute__((constructor)) objects may be stripped by the
 * linker.  Idempotent: audio_comp_acodec_register() rejects duplicate names. */
void inner_acodec_register(td_void)
{
    (void)audio_comp_acodec_register("inner", &g_inner_acodec_ops);
}

/* Keep constructor for shared-library builds where explicit call path is absent. */
static void __attribute__((constructor)) inner_acodec_auto_register(void)
{
    inner_acodec_register();
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
