/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_disp_adapt.h"
#include "mapi_disp_inner.h"
#include "mapi_comm_adapt.h"
#include "mapi_comm_inner.h"
#ifdef SUPPORT_DISP
#include "ot_common_vo.h"
#include "ss_mpi_vo.h"
#include "ss_mpi_vo_dev.h"
#endif
#include "ss_mpi_sys.h"
#include "ot_common.h"
#include "ot_common_svp.h"
#include "ot_common_ive.h"
#include "ss_mpi_ive.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 mapi_adapt_disp_set_vo_pub_attr(td_handle disp_hdl, const hi_mapi_disp_pub_attr *pub_attr)
{
    DISP_CHECK_NULL_PTR_RET(pub_attr);
#ifdef SUPPORT_DISP
    ot_vo_pub_attr vo_pub_attr;
    vo_pub_attr.bg_color = pub_attr->bg_color;
    vo_pub_attr.intf_type = pub_attr->intf_type;
    vo_pub_attr.intf_sync = pub_attr->intf_sync;
    vo_pub_attr.sync_info.syncm = pub_attr->sync_info.synm;
    vo_pub_attr.sync_info.iop = pub_attr->sync_info.iop;
    vo_pub_attr.sync_info.intfb = pub_attr->sync_info.intfb;
    vo_pub_attr.sync_info.vact = pub_attr->sync_info.vact;
    vo_pub_attr.sync_info.vbb = pub_attr->sync_info.vbb;
    vo_pub_attr.sync_info.vfb = pub_attr->sync_info.vfb;
    vo_pub_attr.sync_info.hact = pub_attr->sync_info.hact;
    vo_pub_attr.sync_info.hbb = pub_attr->sync_info.hbb;
    vo_pub_attr.sync_info.hfb = pub_attr->sync_info.hfb;
    vo_pub_attr.sync_info.hmid = pub_attr->sync_info.hmid;
    vo_pub_attr.sync_info.bvact = pub_attr->sync_info.bvact;
    vo_pub_attr.sync_info.bvbb = pub_attr->sync_info.bvbb;
    vo_pub_attr.sync_info.bvfb = pub_attr->sync_info.bvfb;
    vo_pub_attr.sync_info.hpw = pub_attr->sync_info.hpw;
    vo_pub_attr.sync_info.vpw = pub_attr->sync_info.vpw;
    vo_pub_attr.sync_info.idv = pub_attr->sync_info.idv;
    vo_pub_attr.sync_info.ihs = pub_attr->sync_info.ihs;
    vo_pub_attr.sync_info.ivs = pub_attr->sync_info.ivs;

    td_s32 ret = ss_mpi_vo_set_pub_attr(disp_hdl, &vo_pub_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_pub_attr", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_set_user_intf_sync_info(td_handle disp_hdl,
    const hi_mapi_disp_user_info_attr *user_info_attr)
{
    DISP_CHECK_NULL_PTR_RET(user_info_attr);
    td_u32 dev_frame_rate;
    /* 60: acquiescent frame is 60 FPS with user mode */
    user_info_attr->dev_frame_rate == 0 ? (dev_frame_rate = 60) : (dev_frame_rate = user_info_attr->dev_frame_rate);
#ifdef SUPPORT_DISP
    td_s32 ret = ss_mpi_vo_set_dev_frame_rate(disp_hdl, dev_frame_rate);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, " ss_mpi_vo_set_dev_frame_rate", ret);

    ot_vo_user_sync_info user_info;
    user_info.op_mode = user_info_attr->user_info.mode;
    user_info.clk_reverse_en = user_info_attr->user_info.clk_reverse;
    if (user_info.op_mode == OT_OP_MODE_MANUAL) {
        user_info.manual_user_sync_info.user_sync_attr.clk_src =
            user_info_attr->user_info.manual_sync_attr.user_intf_sync_attr.clk_source;
        user_info.manual_user_sync_info.pre_div = user_info_attr->user_info.manual_sync_attr.pre_div;
        user_info.manual_user_sync_info.dev_div = user_info_attr->user_info.manual_sync_attr.dev_div;
        user_info.clk_reverse_en = user_info_attr->user_info.clk_reverse;
        if ((user_info.manual_user_sync_info.user_sync_attr.clk_src == OT_VO_CLK_SRC_PLL) ||
            (user_info.manual_user_sync_info.user_sync_attr.clk_src == OT_VO_CLK_SRC_PLL_FOUT4)) {
            user_info.manual_user_sync_info.user_sync_attr.vo_pll.fb_div =
                user_info_attr->user_info.manual_sync_attr.user_intf_sync_attr.user_sync_pll.fbdiv;
            user_info.manual_user_sync_info.user_sync_attr.vo_pll.frac =
                user_info_attr->user_info.manual_sync_attr.user_intf_sync_attr.user_sync_pll.frac;
            user_info.manual_user_sync_info.user_sync_attr.vo_pll.ref_div =
                user_info_attr->user_info.manual_sync_attr.user_intf_sync_attr.user_sync_pll.refdiv;
            user_info.manual_user_sync_info.user_sync_attr.vo_pll.post_div1 =
                user_info_attr->user_info.manual_sync_attr.user_intf_sync_attr.user_sync_pll.postdiv1;
            user_info.manual_user_sync_info.user_sync_attr.vo_pll.post_div2 =
                user_info_attr->user_info.manual_sync_attr.user_intf_sync_attr.user_sync_pll.postdiv2;
        } else if (user_info.manual_user_sync_info.user_sync_attr.clk_src == OT_VO_CLK_SRC_LCDMCLK) {
            user_info.manual_user_sync_info.user_sync_attr.lcd_m_clk_div =
                user_info_attr->user_info.manual_sync_attr.user_intf_sync_attr.lcd_mclk_div;
        } else if (user_info.manual_user_sync_info.user_sync_attr.clk_src == OT_VO_CLK_SRC_FIXED) {
            user_info.manual_user_sync_info.user_sync_attr.fixed_clk =
                user_info_attr->user_info.manual_sync_attr.user_intf_sync_attr.fixed_clk;
        } else {
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "the clk_src is error :%d\n",
                user_info.manual_user_sync_info.user_sync_attr.clk_src);
            return HI_MAPI_DISP_EILLEGAL_PARAM;
        }
    } else if (user_info.op_mode == OT_OP_MODE_AUTO) {
        user_info.auto_user_sync_info.pixel_clk = user_info_attr->user_info.auto_sync_attr.pixel_clk;
    }
    ret = ss_mpi_vo_set_user_sync_info(disp_hdl, &user_info);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_user_sync_info", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_enable_vo(td_handle disp_hdl)
{
#ifdef SUPPORT_DISP
    return ss_mpi_vo_enable(disp_hdl);
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_disable_vo(td_handle disp_hdl)
{
#ifdef SUPPORT_DISP
    return ss_mpi_vo_disable(disp_hdl);
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_set_video_layer_csc(td_handle disp_hdl, const hi_mapi_disp_csc_attr_ex *csc_attr)
{
    DISP_CHECK_NULL_PTR_RET(csc_attr);
#ifdef SUPPORT_DISP
    ot_vo_csc vo_csc;
    vo_csc.csc_matrix = csc_attr->vo_csc.csc_matrix;
    vo_csc.luma = csc_attr->vo_csc.luma;
    vo_csc.contrast = csc_attr->vo_csc.contrast;
    vo_csc.hue = csc_attr->vo_csc.hue;
    vo_csc.saturation = csc_attr->vo_csc.satuature;
    vo_csc.ex_csc_en = csc_attr->vo_csc.enable_ex_csc;

    td_s32 ret = ss_mpi_vo_set_layer_csc(disp_hdl, &vo_csc);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_layer_csc", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_get_video_layer_csc(td_handle disp_hdl, hi_mapi_disp_csc_attr_ex *csc_attr)
{
    DISP_CHECK_NULL_PTR_RET(csc_attr);
#ifdef SUPPORT_DISP
    ot_vo_csc vo_csc;
    td_s32 ret = ss_mpi_vo_get_layer_csc(disp_hdl, &vo_csc);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_get_layer_csc", ret);

    csc_attr->vo_csc.csc_matrix = vo_csc.csc_matrix;
    csc_attr->vo_csc.luma = vo_csc.luma;
    csc_attr->vo_csc.contrast = vo_csc.contrast;
    csc_attr->vo_csc.hue = vo_csc.hue;
    csc_attr->vo_csc.satuature = vo_csc.saturation;
    csc_attr->vo_csc.enable_ex_csc = vo_csc.ex_csc_en;

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_set_graphic_layer_csc(td_handle disp_hdl, const hi_mapi_disp_csc_attr_ex *csc_attr)
{
    DISP_CHECK_NULL_PTR_RET(csc_attr);
#ifdef SUPPORT_DISP
    ot_vo_csc vo_csc;
    vo_csc.csc_matrix = csc_attr->vo_csc.csc_matrix;
    vo_csc.luma = csc_attr->vo_csc.luma;
    vo_csc.contrast = csc_attr->vo_csc.contrast;
    vo_csc.hue = csc_attr->vo_csc.hue;
    vo_csc.saturation = csc_attr->vo_csc.satuature;
    vo_csc.ex_csc_en = csc_attr->vo_csc.enable_ex_csc;

    td_s32 ret = ss_mpi_vo_set_layer_csc(disp_hdl, &vo_csc);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_layer_csc", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_get_graphic_layer_csc(td_handle disp_hdl, hi_mapi_disp_csc_attr_ex *csc_attr)
{
    DISP_CHECK_NULL_PTR_RET(csc_attr);
#ifdef SUPPORT_DISP
    ot_vo_csc vo_csc;
    td_s32 ret = ss_mpi_vo_get_layer_csc(disp_hdl, &vo_csc);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_layer_csc", ret);

    csc_attr->vo_csc.csc_matrix = vo_csc.csc_matrix;
    csc_attr->vo_csc.luma = vo_csc.luma;
    csc_attr->vo_csc.contrast = vo_csc.contrast;
    csc_attr->vo_csc.hue = vo_csc.hue;
    csc_attr->vo_csc.satuature = vo_csc.saturation;
    csc_attr->vo_csc.enable_ex_csc = vo_csc.ex_csc_en;

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_set_chn_rotation(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_rotate *disp_rotate)
{
    DISP_CHECK_NULL_PTR_RET(disp_rotate);
#ifdef SUPPORT_DISP
    ot_rotation rotate = disp_rotate->rorate;
    td_s32 ret = ss_mpi_vo_set_chn_rotation(disp_hdl, wnd_hdl, rotate);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_chn_rotation", ret);

    return ret;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_get_chn_rotation(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_rotate *disp_rotate)
{
    DISP_CHECK_NULL_PTR_RET(disp_rotate);
#ifdef SUPPORT_DISP
    ot_rotation rotate;
    td_s32 ret = ss_mpi_vo_get_chn_rotation(disp_hdl, wnd_hdl, &rotate);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_get_chn_rotation", ret);

    disp_rotate->rorate = rotate;

    return ret;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_set_video_layer_param(td_handle disp_hdl,
    const hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr)
{
    DISP_CHECK_NULL_PTR_RET(aspect_ratio_attr);
#ifdef SUPPORT_DISP
    ot_vo_layer_param layer_param;
    layer_param.hor_split_en = aspect_ratio_attr->hor_split_en;

    td_s32 ret = ss_mpi_vo_set_video_layer_param(disp_hdl, &layer_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_video_layer_param", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_get_video_layer_param(td_handle disp_hdl,
    hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr)
{
    DISP_CHECK_NULL_PTR_RET(aspect_ratio_attr);
#ifdef SUPPORT_DISP
    ot_vo_layer_param layer_param;
    td_s32 ret = ss_mpi_vo_get_video_layer_param(disp_hdl, &layer_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_get_video_layer_param", ret);
    aspect_ratio_attr->hor_split_en = layer_param.hor_split_en;

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_set_chn_param(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr)
{
    DISP_CHECK_NULL_PTR_RET(aspect_ratio_attr);
#ifdef SUPPORT_DISP
    ot_vo_chn_param chn_param;

    chn_param.aspect_ratio.mode = aspect_ratio_attr->aspect_ratio.mode;
    chn_param.aspect_ratio.bg_color = aspect_ratio_attr->aspect_ratio.bg_color;
    chn_param.aspect_ratio.video_rect.x = aspect_ratio_attr->aspect_ratio.video_rect.x;
    chn_param.aspect_ratio.video_rect.y = aspect_ratio_attr->aspect_ratio.video_rect.y;
    chn_param.aspect_ratio.video_rect.width = aspect_ratio_attr->aspect_ratio.video_rect.width;
    chn_param.aspect_ratio.video_rect.height = aspect_ratio_attr->aspect_ratio.video_rect.height;

    td_s32 ret = ss_mpi_vo_set_chn_param(disp_hdl, wnd_hdl, &chn_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_chn_param", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_get_chn_param(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr)
{
    DISP_CHECK_NULL_PTR_RET(aspect_ratio_attr);
#ifdef SUPPORT_DISP
    ot_vo_chn_param chn_param;

    td_s32 ret = ss_mpi_vo_get_chn_param(disp_hdl, wnd_hdl, &chn_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_get_chn_param", ret);

    aspect_ratio_attr->aspect_ratio.mode = chn_param.aspect_ratio.mode;
    aspect_ratio_attr->aspect_ratio.bg_color = chn_param.aspect_ratio.bg_color;
    aspect_ratio_attr->aspect_ratio.video_rect.x = chn_param.aspect_ratio.video_rect.x;
    aspect_ratio_attr->aspect_ratio.video_rect.y = chn_param.aspect_ratio.video_rect.y;
    aspect_ratio_attr->aspect_ratio.video_rect.width = chn_param.aspect_ratio.video_rect.width;
    aspect_ratio_attr->aspect_ratio.video_rect.height = chn_param.aspect_ratio.video_rect.height;

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_start(td_handle disp_hdl, const hi_mapi_disp_video_layer_attr *video_layer_attr,
    const hi_mapi_rect *disp_rect)
{
    DISP_CHECK_NULL_PTR_RET(video_layer_attr);
    DISP_CHECK_NULL_PTR_RET(disp_rect);
#ifdef SUPPORT_DISP
    td_s32 ret;
    ot_vo_video_layer_attr layer_attr;

    layer_attr.display_rect.x = disp_rect->x;
    layer_attr.display_rect.y = disp_rect->y;
    layer_attr.display_rect.width = disp_rect->width;
    layer_attr.display_rect.height = disp_rect->height;

    layer_attr.img_size.width = video_layer_attr->image_size.width;
    layer_attr.img_size.height = video_layer_attr->image_size.height;
    layer_attr.display_frame_rate = video_layer_attr->frame_rate;
    layer_attr.display_buf_len = video_layer_attr->buf_len;

    layer_attr.partition_mode = OT_VO_PARTITION_MODE_SINGLE;
    layer_attr.pixel_format = OT_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    layer_attr.double_frame_en = TD_FALSE;
    layer_attr.cluster_mode_en = TD_FALSE;
    layer_attr.dst_dynamic_range = OT_DYNAMIC_RANGE_SDR8;
    layer_attr.compress_mode = OT_COMPRESS_MODE_NONE;
    ret = ss_mpi_vo_set_video_layer_attr(disp_hdl, &layer_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_video_layer_attr", ret);

    ret = ss_mpi_vo_enable_video_layer(disp_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_enable_video_layer", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_stop(td_handle disp_hdl)
{
#ifdef SUPPORT_DISP
    return ss_mpi_vo_disable_video_layer(disp_hdl);
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_set_vo_chn_attr(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_attr *wnd_attr)
{
    DISP_CHECK_NULL_PTR_RET(wnd_attr);
#ifdef SUPPORT_DISP
    ot_vo_chn_attr vo_chn_attr;
    td_s32 ret;

    vo_chn_attr.priority = wnd_attr->priority;
    vo_chn_attr.rect.x = wnd_attr->rect.x;
    vo_chn_attr.rect.y = wnd_attr->rect.y;
    vo_chn_attr.rect.width = wnd_attr->rect.width;
    vo_chn_attr.rect.height = wnd_attr->rect.height;
    vo_chn_attr.deflicker_en = TD_FALSE;
    ret = ss_mpi_vo_set_chn_attr(disp_hdl, wnd_hdl, &vo_chn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_set_chn_attr", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_get_vo_chn_attr(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_attr *wnd_attr)
{
    DISP_CHECK_NULL_PTR_RET(wnd_attr);
#ifdef SUPPORT_DISP
    ot_vo_chn_attr vo_chn_attr;

    td_s32 ret = ss_mpi_vo_get_chn_attr(disp_hdl, wnd_hdl, &vo_chn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_get_chn_attr", ret);

    wnd_attr->priority = vo_chn_attr.priority;
    wnd_attr->rect.x = vo_chn_attr.rect.x;
    wnd_attr->rect.y = vo_chn_attr.rect.y;
    wnd_attr->rect.width = vo_chn_attr.rect.width;
    wnd_attr->rect.height = vo_chn_attr.rect.height;

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_enable_vo_chn(td_handle disp_hdl, td_handle wnd_hdl)
{
#ifdef SUPPORT_DISP
    return ss_mpi_vo_enable_chn(disp_hdl, wnd_hdl);
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_disable_vo_chn(td_handle disp_hdl, td_handle wnd_hdl)
{
#ifdef SUPPORT_DISP
    return ss_mpi_vo_disable_chn(disp_hdl, wnd_hdl);
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_clear_vo_chn_buf(td_handle disp_hdl, td_handle wnd_hdl)
{
#ifdef SUPPORT_DISP
    return ss_mpi_vo_clear_chn_buf(disp_hdl, wnd_hdl, TD_TRUE);
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_send_frame(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_frame_data *frame_data)
{
    DISP_CHECK_NULL_PTR_RET(frame_data);
#ifdef SUPPORT_DISP
    ot_video_frame_info video_frame;
    mapi_adapt_comm_frame_info_to_mpi(frame_data, &video_frame);

    td_s32 ret = ss_mpi_vo_send_frame(disp_hdl, wnd_hdl, &video_frame, 0);
    CHECK_MAPI_RET(HI_MAPI_MOD_DISP, "ss_mpi_vo_send_frame", ret);

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_disp_nv12_to_rgb888_ive(const hi_mapi_frame_data *yuv_frame,
    td_phys_addr_t out_phys_addr, td_void *out_virt_addr)
{
    ot_svp_src_img src_data = {0};
    ot_svp_src_img dst_data = {0};
    ot_ive_handle ive_handle;
    td_bool is_finish;
    td_bool is_block;
    ot_ive_csc_ctrl ctrl;
    td_s32 ret;
    td_s32 i;

    src_data.type = OT_SVP_IMG_TYPE_YUV420SP;
    src_data.width = yuv_frame->width;
    src_data.height = yuv_frame->height;
    for (i = 0; i < HI_MAPI_FRAME_DATA_ADDR_NUM; i++) {
        src_data.virt_addr[i] = yuv_frame->vir_addr[i];
        src_data.phys_addr[i] = yuv_frame->phy_addr[i];
        src_data.stride[i] = yuv_frame->stride[i];
    }

    dst_data.type = OT_SVP_IMG_TYPE_U8C3_PACKAGE;
    dst_data.width = yuv_frame->width;
    dst_data.height = yuv_frame->height;
    for (i = 0; i < OT_SVP_IMG_STRIDE_NUM; i++) {
        dst_data.stride[i] = OT_ALIGN_UP(yuv_frame->width, 16);
        dst_data.virt_addr[i] = (td_u64)(td_uintptr_t)out_virt_addr + dst_data.stride[i] * dst_data.height * (td_u32)i;
        dst_data.phys_addr[i] = out_phys_addr + dst_data.stride[i] * dst_data.height * (td_u32)i;
    }
    ctrl.mode = OT_IVE_CSC_MODE_VIDEO_BT709_YUV_TO_RGB;

    ret = ss_mpi_ive_csc(&ive_handle, &src_data, &dst_data, &ctrl, TD_FALSE);
    if (ret != TD_SUCCESS) {
        return ret;
    }
    is_block = TD_TRUE;
    return ss_mpi_ive_query(ive_handle, &is_finish, is_block);
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
