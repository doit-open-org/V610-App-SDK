/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_adec.h"
#include "audio_comp/audio_comp_opus.h"
#include "mapi_adec_inner.h"
#include "mapi_comm_inner.h"
#include "adpt_adec_aac.h"
#ifdef ENABLE_MP3
#include "adpt_adec_mp3.h"
#endif
#include "ss_mpi_audio.h"
#include "ot_common_adec.h"
#include "ss_audio_opus_adp.h"
#include "securec.h"
#include <stdlib.h>

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/* Per-channel scratch buffer used only on the OPUS STANDARD-payload ingress path
 * to prepend an 8-byte big-endian length header before forwarding to SDK.
 * Lazily allocated when the channel is created with OPUS format; freed on
 * destroy.  Capacity = AUDIO_COMP_OPUS_MAX_PACKET_SIZE + header. */
#define AUDIO_COMP_OPUS_TMP_BUF_CAP (AUDIO_COMP_OPUS_HEADER_SIZE + AUDIO_COMP_OPUS_MAX_PACKET_SIZE)
static unsigned char *g_adec_opus_tmp_buf[HI_MAPI_ADEC_CHN_MAX_NUM] = {0};

td_s32 audio_comp_adec_create_chn(td_handle adec_hdl, const hi_mapi_adec_attr *adec_attr)
{
    ot_adec_chn adec_chn = adec_hdl;
    ot_adec_chn_attr adec_chn_attr;
    MAPI_ADEC_AacAttr adec_aac;
    ot_adec_attr_g711 adec_g711;
    ot_adec_attr_lpcm adec_lpcm;
    ot_adec_attr_opus adec_opus;
#ifdef ENABLE_MP3
    MAPI_ADEC_Mp3Attr adec_mp3;
#endif
    CHECK_MAPI_ADEC_NULL_PTR_RET(adec_attr);

    adec_chn_attr.buf_size = MAPI_ADEC_DEFAULT_BUF_SIZE;
    /* SDK constraint: LPCM uses PACK mode; AAC/G711A/G711U/MP3 use STREAM mode. */
    adec_chn_attr.mode = (adec_attr->adec_format == HI_MAPI_AUDIO_FORMAT_LPCM)
                         ? OT_ADEC_MODE_PACK
                         : OT_ADEC_MODE_STREAM;

    switch (adec_attr->adec_format) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            adec_chn_attr.type = OT_PT_AAC;
            adec_chn_attr.value = &adec_aac;
            adec_aac.trans_type = AAC_TRANS_TYPE_ADTS;
            break;

        case HI_MAPI_AUDIO_FORMAT_G711A:
            adec_chn_attr.type = OT_PT_G711A;
            adec_chn_attr.value = &adec_g711;
            break;

        case HI_MAPI_AUDIO_FORMAT_G711U:
            adec_chn_attr.type = OT_PT_G711U;
            adec_chn_attr.value = &adec_g711;
            break;

        case HI_MAPI_AUDIO_FORMAT_OPUS:
            adec_chn_attr.type = OT_PT_OPUS;
            adec_chn_attr.value = &adec_opus;
            adec_opus.sample_rate = OT_AUDIO_SAMPLE_RATE_16000;
            adec_opus.snd_mode = OT_AUDIO_SOUND_MODE_MONO;
            break;

#ifdef ENABLE_MP3
        case HI_MAPI_AUDIO_FORMAT_MP3:
            adec_chn_attr.type = OT_PT_MP3;
            adec_chn_attr.value = &adec_mp3;
            break;
#endif

        case HI_MAPI_AUDIO_FORMAT_LPCM:
            adec_chn_attr.type = OT_PT_LPCM;
            adec_chn_attr.value = &adec_lpcm;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "Do not support adec type %d \n", adec_attr->adec_format);
            return HI_MAPI_ADEC_EILLPARAM;
    }

    td_s32 ret = ss_mpi_adec_create_chn(adec_chn, &adec_chn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_ADEC, "ss_mpi_adec_create_chn", ret);

    /* Lazy-allocate OPUS scratch buffer only for OPUS channels.  Other formats
     * never enter the STANDARD path so the slot stays NULL. */
    if (adec_attr->adec_format == HI_MAPI_AUDIO_FORMAT_OPUS &&
        adec_hdl < HI_MAPI_ADEC_CHN_MAX_NUM &&
        g_adec_opus_tmp_buf[adec_hdl] == TD_NULL) {
        g_adec_opus_tmp_buf[adec_hdl] = (unsigned char *)malloc(AUDIO_COMP_OPUS_TMP_BUF_CAP);
        if (g_adec_opus_tmp_buf[adec_hdl] == TD_NULL) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC,
                "OPUS scratch buf alloc (%u bytes) failed for adec_hdl=%d\n",
                AUDIO_COMP_OPUS_TMP_BUF_CAP, (int)adec_hdl);
            (td_void)ss_mpi_adec_destroy_chn(adec_chn);
            return HI_MAPI_ADEC_ERR_OPERATE_FAIL;
        }
    }

    return TD_SUCCESS;
}

td_s32 audio_comp_adec_destroy_chn(td_handle adec_hdl)
{
    if (adec_hdl < HI_MAPI_ADEC_CHN_MAX_NUM && g_adec_opus_tmp_buf[adec_hdl] != TD_NULL) {
        free(g_adec_opus_tmp_buf[adec_hdl]);
        g_adec_opus_tmp_buf[adec_hdl] = TD_NULL;
    }
    return ss_mpi_adec_destroy_chn(adec_hdl);
}

td_s32 audio_comp_adec_send_stream(td_handle adec_hdl, const hi_mapi_audio_stream *adec_stream, td_bool block,
                                    hi_mapi_audio_payload_format payload_format)
{
    ot_adec_chn adec_chn = adec_hdl;
    ot_audio_stream audio_stream;

    CHECK_MAPI_ADEC_NULL_PTR_RET(adec_stream);
    audio_stream.stream = adec_stream->stream;
    audio_stream.phys_addr = adec_stream->phy_addr;
    audio_stream.len = adec_stream->len;
    audio_stream.time_stamp = adec_stream->time_stamp;
    audio_stream.seq = adec_stream->seq;

    /* STANDARD: caller provided a bare OPUS packet.  Compose
     * <8-byte big-endian length><packet> into the channel scratch buffer,
     * then forward that buffer to the SDK.  HI_NATIVE passes through. */
    if (payload_format == HI_MAPI_AUDIO_PAYLOAD_STANDARD) {
        if (adec_hdl >= HI_MAPI_ADEC_CHN_MAX_NUM || g_adec_opus_tmp_buf[adec_hdl] == TD_NULL) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "OPUS scratch buf not ready for adec_hdl=%d\n", (int)adec_hdl);
            return HI_MAPI_ADEC_ESTATEERR;
        }
        if (adec_stream->stream == TD_NULL || adec_stream->len == 0 ||
            adec_stream->len > AUDIO_COMP_OPUS_MAX_PACKET_SIZE) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC,
                "OPUS standard packet len=%u out of bounds (max %u)\n",
                adec_stream->len, AUDIO_COMP_OPUS_MAX_PACKET_SIZE);
            return HI_MAPI_ADEC_EILLPARAM;
        }
        unsigned char *buf = g_adec_opus_tmp_buf[adec_hdl];
        audio_comp_opus_encode_be64(buf, (unsigned long long)adec_stream->len);
        td_s32 cret = memcpy_s(buf + AUDIO_COMP_OPUS_HEADER_SIZE,
                               AUDIO_COMP_OPUS_TMP_BUF_CAP - AUDIO_COMP_OPUS_HEADER_SIZE,
                               adec_stream->stream, adec_stream->len);
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ADEC, "memcpy_s", cret);
        audio_stream.stream    = buf;
        audio_stream.len       = adec_stream->len + AUDIO_COMP_OPUS_HEADER_SIZE;
        audio_stream.phys_addr = 0;   /* scratch buffer is virt-only */
    }

    td_s32 ret = ss_mpi_adec_send_stream(adec_chn, &audio_stream, block);
    if (ret == OT_ERR_ADEC_BUF_FULL) {
        ret = HI_MAPI_ADEC_ERR_BUF_FULL;
    }
    CHECK_MAPI_RET(HI_MAPI_MOD_ADEC, "ss_mpi_adec_send_stream", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_adec_get_frame(td_handle adec_hdl, hi_mapi_audio_frame_info *audio_frame_info, td_bool block)
{
    ot_audio_frame_info frm_info;
    ot_adec_chn adec_chn = adec_hdl;

    CHECK_MAPI_ADEC_NULL_PTR_RET(audio_frame_info);

    td_s32 ret = memset_s(&frm_info, sizeof(ot_audio_frame_info), 0, sizeof(ot_audio_frame_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ADEC, "memset_s", ret);

    ret = ss_mpi_adec_get_frame(adec_chn, &frm_info, block);
    CHECK_MAPI_RET(HI_MAPI_MOD_ADEC, "ss_mpi_adec_get_frame", ret);

    audio_frame_info->index = frm_info.id;
    audio_frame_info->frame = frm_info.frame;

    CHECK_MAPI_ADEC_NULL_PTR_RET(frm_info.frame);
    audio_frame_info->audio_frame.bit_width = frm_info.frame->bit_width;
    audio_frame_info->audio_frame.snd_mode = frm_info.frame->snd_mode;
    audio_frame_info->audio_frame.time_stamp = frm_info.frame->time_stamp;
    audio_frame_info->audio_frame.seq = frm_info.frame->seq;
    audio_frame_info->audio_frame.len = frm_info.frame->len;
    for (td_u32 i = 0; i < HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i++) {
        audio_frame_info->audio_frame.virt_addr[i] = frm_info.frame->virt_addr[i];
        audio_frame_info->audio_frame.phys_addr[i] = frm_info.frame->phys_addr[i];
        audio_frame_info->audio_frame.pool_id[i] = frm_info.frame->pool_id[i];
    }

    return TD_SUCCESS;
}

td_s32 audio_comp_adec_release_frame(td_handle adec_hdl, const hi_mapi_audio_frame_info *audio_frame_info)
{
    ot_audio_frame_info frm_info;
    ot_adec_chn adec_chn = adec_hdl;
    CHECK_MAPI_ADEC_NULL_PTR_RET(audio_frame_info);

    frm_info.id = audio_frame_info->index;
    frm_info.frame = (td_void *)audio_frame_info->frame;

    td_s32 ret = ss_mpi_adec_release_frame(adec_chn, &frm_info);
    CHECK_MAPI_RET(HI_MAPI_MOD_ADEC, "ss_mpi_adec_release_frame", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_adec_send_end_of_stream(td_handle adec_hdl)
{
    return ss_mpi_adec_send_end_of_stream(adec_hdl, TD_FALSE);
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
