/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "adpt_adec_aac.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "ss_aacdec.h"
#include "ot_common_adec.h"
#include "hi_mw_log.h"
#include "mapi_adec_inner.h"
#include "mapi_comm_inner.h"
#include "ss_mpi_audio.h"
#include "securec.h"

#define OT_ADEC_AAC_ADTS_HEAD_BYTE_LEN  7

static td_s32 g_aacDecHandle = OT_INVALID_HANDLE;

td_s32 OpenAACDecoder(td_void *decoderAttr, td_void **decoder)
{
    MAPI_ADEC_AacDecoder *aacDecoder = NULL;
    MAPI_ADEC_AacAttr *aacAttr = NULL;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoderAttr);
    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);

    aacAttr = (MAPI_ADEC_AacAttr *)decoderAttr;

    /* allocate memory for decoder */
    aacDecoder = (MAPI_ADEC_AacDecoder *)malloc(sizeof(MAPI_ADEC_AacDecoder));
    if (aacDecoder == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "[Info]:%s\n", "no memory");
        return TD_FAILURE;
    }

    td_s32 ret = memset_s(aacDecoder, sizeof(MAPI_ADEC_AacDecoder), 0, sizeof(MAPI_ADEC_AacDecoder));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "memset_s error:%#x\n", ret);
        free(aacDecoder);
        aacDecoder = NULL;
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    /* create decoder */
    aacDecoder->aacDecoderHdl = ot_aacdec_init_decoder((ot_aacdec_transport_type)aacAttr->trans_type);
    if (!aacDecoder->aacDecoderHdl) {
        free(aacDecoder);
        aacDecoder = NULL;
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "[Info]:%s\n", "ot_aacdec_init_decoder failed");
        return TD_FAILURE;
    }

    aacDecoder->aacAttr.trans_type = aacAttr->trans_type;
    *decoder = (td_void *)aacDecoder;

    return TD_SUCCESS;
}

td_s32 DecodeAACFrm(td_void *decoder, ot_adec_buf_info *buf_info, td_u32 *chns)
{
    td_s32 ret;
    MAPI_ADEC_AacDecoder *aacDecoder = NULL;
    td_s32 samples, frmLen, sampleBytes;
    ot_aacdec_frame_info aacFrameInfo;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);
    CHECK_MAPI_ADEC_NULL_PTR_RET(buf_info);
    CHECK_MAPI_ADEC_NULL_PTR_RET(buf_info->in_buf);
    CHECK_MAPI_ADEC_NULL_PTR_RET(buf_info->in_left_byte);
    CHECK_MAPI_ADEC_NULL_PTR_RET(buf_info->out_buf);
    CHECK_MAPI_ADEC_NULL_PTR_RET(buf_info->out_valid_len);
    CHECK_MAPI_ADEC_NULL_PTR_RET(chns);

    *chns = 1; /* voice encoder only one channle */
    aacDecoder = (MAPI_ADEC_AacDecoder *)decoder;

    CHECK_MAPI_ADEC_NULL_PTR_RET(aacDecoder->aacDecoderHdl);
    frmLen = ot_aacdec_find_sync_header(aacDecoder->aacDecoderHdl, buf_info->in_buf, buf_info->in_left_byte);
    if (frmLen < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "[Info]:%s\n", "AAC decoder can't find sync header");
        return TD_FAILURE;
    }

    if (aacDecoder->aacAttr.trans_type == AAC_TRANS_TYPE_ADTS) {
        td_s32 oldLeftBytes = *buf_info->in_left_byte;
        if (oldLeftBytes <= OT_ADEC_AAC_ADTS_HEAD_BYTE_LEN) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "LeftBytes:%d, not enough for AAC ADTS header\n", oldLeftBytes);
            return TD_FAILURE;
        }
         /* 4 3 5 0x1F: Calculated  PacketSize */
        td_s32 packetSize = ((*buf_info->in_buf)[4] << 3) | (((*buf_info->in_buf)[5] - 0x1F) >> 5);
        if (oldLeftBytes < packetSize) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "AAC packet size %d, buffer left %d bytes, not enough for a frame\n",
                packetSize, oldLeftBytes);
            return TD_FAILURE;
        }
    }

    /* Notes: pInbuf will updated */
    ret = ot_aacdec_frame(aacDecoder->aacDecoderHdl, buf_info->in_buf,
        buf_info->in_left_byte, (td_s16 *)buf_info->out_buf);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "aac decoder failed!, ret:0x%x\n", ret);
        return ret;
    }
    ot_aacdec_get_last_frame_info(aacDecoder->aacDecoderHdl, &aacFrameInfo);
    aacFrameInfo.chn_num = ((aacFrameInfo.chn_num != 0) ? aacFrameInfo.chn_num : 1);
    /* samples per frame of one sound track */
    samples = aacFrameInfo.output_samples / aacFrameInfo.chn_num;

    CHECK_MAPI_UINT_PRODUCT_OVERFLOW_RET(HI_MAPI_MOD_ADEC, sizeof(td_u16), samples);
    sampleBytes = samples * sizeof(td_u16);
    *chns = aacFrameInfo.chn_num;
    *buf_info->out_valid_len = sampleBytes;

    return ret;
}

td_s32 GetAACFrmInfo(td_void *decoder, td_void *info)
{
    MAPI_ADEC_AacDecoder *aacDecoder = NULL;
    ot_aacdec_frame_info aacFrameInfo;
    MAPI_ADEC_AacFrameInfo *aacFrm = NULL;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);
    CHECK_MAPI_ADEC_NULL_PTR_RET(info);

    aacDecoder = (MAPI_ADEC_AacDecoder *)decoder;
    aacFrm = (MAPI_ADEC_AacFrameInfo *)info;

    CHECK_MAPI_ADEC_NULL_PTR_RET(aacDecoder->aacDecoderHdl);
    ot_aacdec_get_last_frame_info(aacDecoder->aacDecoderHdl, &aacFrameInfo);

    aacFrm->samplerate = aacFrameInfo.sample_rate_out;
    aacFrm->bit_rate = aacFrameInfo.bit_rate;
    aacFrm->profile = aacFrameInfo.profile;
    aacFrm->tnsUsed = aacFrameInfo.tns_used;
    aacFrm->pnsUsed = aacFrameInfo.pns_used;

    return TD_SUCCESS;
}

td_s32 CloseAACDecoder(td_void *decoder)
{
    MAPI_ADEC_AacDecoder *aacDecoder = NULL;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);
    aacDecoder = (MAPI_ADEC_AacDecoder *)decoder;

    if (aacDecoder->aacDecoderHdl != NULL) {
        ot_aacdec_free_decoder(aacDecoder->aacDecoderHdl);
    }

    free(aacDecoder);
    aacDecoder = NULL;
    decoder = NULL;
    return TD_SUCCESS;
}

td_s32 ResetAACDecoder(td_void *decoder)
{
    MAPI_ADEC_AacDecoder *aacDecoder = NULL;

    CHECK_MAPI_ADEC_NULL_PTR_RET(decoder);
    aacDecoder = (MAPI_ADEC_AacDecoder *)decoder;

    if (aacDecoder->aacDecoderHdl != NULL) {
        ot_aacdec_free_decoder(aacDecoder->aacDecoderHdl);
    }

    /* create decoder */
    aacDecoder->aacDecoderHdl = ot_aacdec_init_decoder((ot_aacdec_transport_type)aacDecoder->aacAttr.trans_type);
    if (!aacDecoder->aacDecoderHdl) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "[Info]:%s\n", "AACResetDecoder failed");
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

td_s32 MAPI_ADEC_RegisterAac(td_void)
{
    td_s32 ret;
    td_s32 handle = OT_INVALID_HANDLE;
    ot_adec_decoder aacDecoder;

    if (g_aacDecHandle != OT_INVALID_HANDLE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "aacDec have inited, return successful \n");
        return TD_SUCCESS;
    }

    aacDecoder.type = OT_PT_AAC;
    ret = snprintf_s(aacDecoder.name, sizeof(aacDecoder.name), sizeof(aacDecoder.name) - 1, "Aac");
    if (ret == TD_FAILURE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "snprintf_s error:%#x \n", ret);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    aacDecoder.func_open_decoder = OpenAACDecoder;
    aacDecoder.func_dec_frame = DecodeAACFrm;
    aacDecoder.func_get_frame_info = GetAACFrmInfo;
    aacDecoder.func_close_decoder = CloseAACDecoder;
    aacDecoder.func_reset_decoder = ResetAACDecoder;
    ret = ss_mpi_adec_register_decoder(&handle, &aacDecoder);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "ss_mpi_adec_register_decoder return ERR, %x", ret);
        return ret;
    }

    g_aacDecHandle = handle;

    return TD_SUCCESS;
}

td_s32 MAPI_ADEC_UnRegisterAac(td_void)
{
    td_s32 ret;

    if (g_aacDecHandle == OT_INVALID_HANDLE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "aacDec have Deinited, return successful \n");
        return TD_SUCCESS;
    }

    ret = ss_mpi_adec_unregister_decoder(g_aacDecHandle);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "ss_mpi_adec_unregister_decoder fail,ret:%x\n", ret);
        return ret;
    }
    g_aacDecHandle = OT_INVALID_HANDLE;

    return TD_SUCCESS;
}

