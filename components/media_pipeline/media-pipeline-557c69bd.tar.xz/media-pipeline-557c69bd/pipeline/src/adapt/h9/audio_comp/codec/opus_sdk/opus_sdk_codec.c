/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_codec.h"
#include "mapi_comm_inner.h"

static int opus_sdk_aenc_register(void *out_encoder)
{
    (void)out_encoder;
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "[opus_sdk] aenc_register (stub)\n");
    return 0;
}

static int opus_sdk_aenc_unregister(void)
{
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "[opus_sdk] aenc_unregister (stub)\n");
    return 0;
}

static int opus_sdk_adec_register(void)
{
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ADEC, "[opus_sdk] adec_register (stub)\n");
    return 0;
}

static int opus_sdk_adec_unregister(void)
{
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ADEC, "[opus_sdk] adec_unregister (stub)\n");
    return 0;
}

static const audio_comp_codec_ops_t g_opus_sdk_codec_ops = {
    .format           = HI_MAPI_AUDIO_FORMAT_OPUS,
    .backend_name     = "sdk",
    .aenc_register    = opus_sdk_aenc_register,
    .aenc_unregister  = opus_sdk_aenc_unregister,
    .adec_register    = opus_sdk_adec_register,
    .adec_unregister  = opus_sdk_adec_unregister,
};

static void __attribute__((constructor)) opus_sdk_codec_provider_register(void)
{
    (void)audio_comp_codec_register("opus_sdk", &g_opus_sdk_codec_ops);
}
