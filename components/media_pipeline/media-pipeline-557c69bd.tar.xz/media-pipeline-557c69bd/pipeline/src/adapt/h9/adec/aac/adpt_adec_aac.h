/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ADPT_ADEC_AAC_H
#define ADPT_ADEC_AAC_H

#include "ss_aacdec.h"
#include "hi_mw_type.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

typedef enum {
    AAC_TRANS_TYPE_ADTS = 0,
    AAC_TRANS_TYPE_LOAS = 1,
    AAC_TRANS_TYPE_LATM_MCP1 = 2,
    AAC_TRANS_TYPE_BUTT
} MAPI_ADEC_AacTransType;

typedef struct {
    MAPI_ADEC_AacTransType trans_type;
} MAPI_ADEC_AacAttr;

typedef struct {
    ot_aac_decoder         aacDecoderHdl;
    MAPI_ADEC_AacAttr      aacAttr;
} MAPI_ADEC_AacDecoder;

typedef struct {
    td_s32 samplerate;   /* sample rate */
    td_s32 bit_rate;      /* bitrate */
    td_s32 profile;      /* profile */
    td_s32 tnsUsed;      /* TNS Tools */
    td_s32 pnsUsed;      /* PNS Tools */
} MAPI_ADEC_AacFrameInfo;

td_s32 MAPI_ADEC_RegisterAac(td_void);
td_s32 MAPI_ADEC_UnRegisterAac(td_void);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
