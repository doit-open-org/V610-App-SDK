/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <stdio.h>
#include <fcntl.h>

/* mapi header */
#include "hi_mapi_vpss_define.h"
#include "hi_mapi_venc_define.h"
/* mpi header */
#include "mapi_vpss_inner.h"
#include "mapi_comm_adapt.h"
#include "ot_common_vb.h"
#include "ot_common_vpss.h"
#include "ot_common_vi.h"
#include "ot_common_region.h"

#include "ot_common_venc.h"
#include "ss_mpi_vpss.h"
#include "ss_mpi_sys_mem.h"
#include "ss_mpi_vi.h"
#include "ss_mpi_region.h"
#include "ss_mpi_venc.h"
#include "ss_mpi_sys.h"
#include "ss_mpi_vb.h"
#include "mapi_vcap_inner.h"
#include "securec.h"

#ifdef SUPPORT_IVE
#include "ss_mpi_ive.h"
#include "ot_common_ive.h"
#endif

#include "mapi_vpss_adapt.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

#define FRAMESTRIDE 2

static td_s32 calc_data_size(const ot_video_frame_info *video_frame, const td_u32 data_num, td_u32 data_size[])
{
    td_u32 i, factor;

    for (i = 0; i < data_num; i++) {
        if (video_frame->video_frame.pixel_format == OT_PIXEL_FORMAT_YVU_PLANAR_420 ||
            video_frame->video_frame.pixel_format == OT_PIXEL_FORMAT_YVU_SEMIPLANAR_420 ||
            video_frame->video_frame.pixel_format == OT_PIXEL_FORMAT_YUV_SEMIPLANAR_420) {
            factor = (i == 0) ? 1 : 2; /* 2 for stride * height / 2 */
            data_size[i] = (video_frame->video_frame.stride[i] * video_frame->video_frame.height) / factor;
        } else if (video_frame->video_frame.pixel_format == OT_PIXEL_FORMAT_YVU_PLANAR_422 ||
                   video_frame->video_frame.pixel_format == OT_PIXEL_FORMAT_YVU_SEMIPLANAR_422 ||
                   video_frame->video_frame.pixel_format == OT_PIXEL_FORMAT_YUV_SEMIPLANAR_422) {
            data_size[i] = video_frame->video_frame.stride[i] * video_frame->video_frame.height;
        } else {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "Not support format:%d\n", video_frame->video_frame.pixel_format);
            return TD_FAILURE;
        }
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_frame(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_frame_data *yuv_frame_data,
    td_s32 milli_sec)
{
    td_s32 i;
    td_s32 ret;
    ot_video_frame_info video_frame;
    td_u32 data_size[HI_MAPI_FRAME_DATA_ADDR_NUM];
    VPSS_CHECK_NULL_PTR_RET(yuv_frame_data);

    ret = ss_mpi_vpss_get_chn_frame(grp_hdl, chn_hdl, &video_frame, milli_sec);
    if (ret == OT_ERR_VPSS_BUF_EMPTY) {
        ret = HI_MAPI_VPSS_EBUF_EMPTY;
    }
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_frame failed", ret);

    mapi_adapt_comm_frame_info_to_mapi(&video_frame, yuv_frame_data);
    if (calc_data_size(&video_frame, HI_MAPI_FRAME_DATA_ADDR_NUM, data_size) != TD_SUCCESS) {
        return TD_FAILURE;
    }
    for (i = 0; i < HI_MAPI_FRAME_DATA_ADDR_NUM; i++) {
        yuv_frame_data->vir_addr[i] = (uintptr_t)(td_u8 *)ss_mpi_sys_mmap(video_frame.video_frame.phys_addr[i],
                                                                       data_size[i]);
    }

    ret = memcpy_s(&yuv_frame_data->video_supplement, sizeof(yuv_frame_data->video_supplement),
        &video_frame.video_frame.supplement, sizeof(video_frame.video_frame.supplement));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memcpy_s", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_release_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    const hi_mapi_frame_data *yuv_frame_data)
{
    td_s32 i;
    td_s32 ret;
    ot_video_frame_info video_frame;
    td_u32 data_size[HI_MAPI_FRAME_DATA_ADDR_NUM];
    VPSS_CHECK_NULL_PTR_RET(yuv_frame_data);

    video_frame.video_frame.width = yuv_frame_data->width;
    video_frame.video_frame.height = yuv_frame_data->height;
    video_frame.video_frame.pixel_format = yuv_frame_data->pixel_format;
    video_frame.video_frame.compress_mode = yuv_frame_data->compress_mode;
    video_frame.video_frame.video_format = yuv_frame_data->video_format;

    for (i = 0; i < HI_MAPI_FRAME_DATA_ADDR_NUM; i++) {
        video_frame.video_frame.phys_addr[i] = yuv_frame_data->phy_addr[i];
        video_frame.video_frame.stride[i] = yuv_frame_data->stride[i];

        video_frame.video_frame.header_phys_addr[i] = (td_phys_addr_t)yuv_frame_data->header_phys_addr[i];
        video_frame.video_frame.header_stride[i] = yuv_frame_data->heade_stride[i];
        video_frame.video_frame.header_virt_addr[i] = NULL;
    }

    if (calc_data_size(&video_frame, HI_MAPI_FRAME_DATA_ADDR_NUM, data_size) != TD_SUCCESS) {
        return TD_FAILURE;
    }

    for (i = 0; i < HI_MAPI_FRAME_DATA_ADDR_NUM; i++) {
        ss_mpi_sys_munmap((td_u8 *)(uintptr_t)yuv_frame_data->vir_addr[i], data_size[i]);
    }

    video_frame.video_frame.pts = yuv_frame_data->pts;
    video_frame.pool_id = yuv_frame_data->pool_id;
    video_frame.video_frame.supplement.misc_info_phys_addr = yuv_frame_data->video_supplement.misc_info_phys_addr;
    video_frame.video_frame.supplement.jpeg_dcf_phys_addr = yuv_frame_data->video_supplement.jpeg_dcf_phy_addr;
    video_frame.video_frame.supplement.isp_info_phys_addr = yuv_frame_data->video_supplement.isp_info_phy_addr;
    video_frame.video_frame.supplement.low_delay_phys_addr = yuv_frame_data->video_supplement.low_delay_phy_addr;
    video_frame.video_frame.supplement.bnr_mot_phys_addr = yuv_frame_data->video_supplement.bnr_mot_phy_addr;
    video_frame.video_frame.supplement.motion_data_phys_addr = yuv_frame_data->video_supplement.motion_data_phy_addr;
    video_frame.video_frame.supplement.frame_dng_phys_addr = yuv_frame_data->video_supplement.frame_dng_phy_addr;
    video_frame.video_frame.supplement.aiisp_phys_addr = yuv_frame_data->video_supplement.assip_phy_addr;

    video_frame.video_frame.supplement.misc_info_virt_addr = yuv_frame_data->video_supplement.misc_info_vir_addr;
    video_frame.video_frame.supplement.jpeg_dcf_virt_addr = yuv_frame_data->video_supplement.jpeg_dcf_vir_addr;
    video_frame.video_frame.supplement.isp_info_virt_addr = yuv_frame_data->video_supplement.isp_info_vir_addr;
    video_frame.video_frame.supplement.low_delay_virt_addr = yuv_frame_data->video_supplement.low_delay_vir_addr;
    video_frame.video_frame.supplement.bnr_mot_virt_addr = yuv_frame_data->video_supplement.bnr_mot_virt_addr;
    video_frame.video_frame.supplement.motion_data_virt_addr = yuv_frame_data->video_supplement.motion_data_vir_addr;
    video_frame.video_frame.supplement.frame_dng_virt_addr = yuv_frame_data->video_supplement.frame_dng_vir_addr;
    video_frame.video_frame.supplement.aiisp_virt_addr = yuv_frame_data->video_supplement.assip_vir_addr;

    ret = ss_mpi_vpss_release_chn_frame(grp_hdl, chn_hdl, &video_frame);
    VPSS_CHECK_RET("call ss_mpi_vpss_release_chn_frame failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_create_grp(td_handle vpss_hdl, const hi_mapi_vpss_grp_attr *vpss_attr)
{
    td_s32 ret;
    ot_vpss_grp_attr vpss_grp_attr = {0};
    VPSS_CHECK_NULL_PTR_RET(vpss_attr);

    vpss_grp_attr.ie_en                     = TD_FALSE;
    vpss_grp_attr.dci_en                    = TD_FALSE;
    vpss_grp_attr.buf_share_en              = TD_FALSE;
    vpss_grp_attr.mcf_en                    = TD_FALSE;
    vpss_grp_attr.max_dei_width             = 0;
    vpss_grp_attr.max_dei_height            = 0;
    vpss_grp_attr.dei_mode                  = OT_VPSS_DEI_MODE_OFF;
    vpss_grp_attr.buf_share_chn             = OT_VPSS_CHN0;

    vpss_grp_attr.max_width = vpss_attr->max_width;
    vpss_grp_attr.max_height = vpss_attr->max_height;
    vpss_grp_attr.pixel_format = vpss_attr->pixel_format;
    vpss_grp_attr.dynamic_range = OT_DYNAMIC_RANGE_SDR8; /* default value */
    vpss_grp_attr.frame_rate.src_frame_rate = vpss_attr->frame_rate_ctrl.src_frame_rate;
    vpss_grp_attr.frame_rate.dst_frame_rate = vpss_attr->frame_rate_ctrl.dst_frame_rate;

    ret = ss_mpi_vpss_create_grp(vpss_hdl, &vpss_grp_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_create_grp failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_destroy_grp(td_handle vpss_hdl)
{
    td_s32 ret;

    ret = ss_mpi_vpss_destroy_grp(vpss_hdl);
    VPSS_CHECK_RET("call ss_mpi_vpss_destroy_grp failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_start_grp(td_handle vpss_hdl)
{
    td_s32 ret;

    ret = ss_mpi_vpss_start_grp(vpss_hdl);
    VPSS_CHECK_RET("call ss_mpi_vpss_start_grp failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_stop_grp(td_handle vpss_hdl)
{
    td_s32 ret;

    ret = ss_mpi_vpss_stop_grp(vpss_hdl);
    VPSS_CHECK_RET("call ss_mpi_vpss_stop_grp failed", ret);

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_vpss_set_chn_vb(const ot_vpss_chn_attr *vpss_chn_attr, td_u32 *pool_id,
    td_u32 vb_pool_blk_cnt, td_u32 scale)
{
    if (*pool_id != OT_VB_INVALID_POOL_ID) {
        td_s32 ret = mapi_adapt_comm_destroy_vb_pool(*pool_id);
        VPSS_CHECK_RET("call mapi_adapt_comm_destroy_vb_pool failed", ret);
        *pool_id = OT_VB_INVALID_POOL_ID;
    }

    if (vb_pool_blk_cnt > 0) {
        ot_pic_buf_attr frame_attr = {0};
        frame_attr.width = vpss_chn_attr->width * scale;
        frame_attr.height = vpss_chn_attr->height * scale;
        frame_attr.align = OT_DEFAULT_ALIGN;
        frame_attr.bit_width = vpss_chn_attr->depth;
        frame_attr.pixel_format = vpss_chn_attr->pixel_format;
        frame_attr.compress_mode = vpss_chn_attr->compress_mode;
        frame_attr.video_format = vpss_chn_attr->video_format;

        *pool_id =  mapi_adapt_comm_create_vb_pool(&frame_attr, vb_pool_blk_cnt);
        if (*pool_id == OT_VB_INVALID_POOL_ID) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "create pool failed! cnt:[%u]\n", vb_pool_blk_cnt);
            return TD_FAILURE;
        }
    }
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_attr(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_chn_attr *chn_attr, td_u32 *pool_id, td_u32 scale)
{
    td_s32 ret;
    ot_vpss_chn_attr vpss_chn_attr;
    VPSS_CHECK_NULL_PTR_RET(chn_attr);
    VPSS_CHECK_NULL_PTR_RET(pool_id);

    ret = memset_s(&vpss_chn_attr, sizeof(vpss_chn_attr), 0, sizeof(vpss_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memset_s", ret);

    ret = ss_mpi_vpss_get_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_attr failed", ret);

    vpss_chn_attr.width = chn_attr->width;
    vpss_chn_attr.height = chn_attr->height;
    vpss_chn_attr.pixel_format = chn_attr->pixel_format;
    vpss_chn_attr.video_format = chn_attr->video_format;
    vpss_chn_attr.compress_mode = chn_attr->compress_mode;
    vpss_chn_attr.chn_mode = OT_VPSS_CHN_MODE_USER; /* default value */
    vpss_chn_attr.dynamic_range = OT_DYNAMIC_RANGE_SDR8; /* default value */
    vpss_chn_attr.frame_rate.src_frame_rate = chn_attr->frame_rate_ctrl.src_frame_rate;
    vpss_chn_attr.frame_rate.dst_frame_rate = chn_attr->frame_rate_ctrl.dst_frame_rate;

    vpss_chn_attr.aspect_ratio.mode = chn_attr->aspect_ratio.mode;
    vpss_chn_attr.aspect_ratio.bg_color = chn_attr->aspect_ratio.bg_color;
    vpss_chn_attr.aspect_ratio.video_rect.x = chn_attr->aspect_ratio.video_rect.x;
    vpss_chn_attr.aspect_ratio.video_rect.y = chn_attr->aspect_ratio.video_rect.y;
    vpss_chn_attr.aspect_ratio.video_rect.width = chn_attr->aspect_ratio.video_rect.width;
    vpss_chn_attr.aspect_ratio.video_rect.height = chn_attr->aspect_ratio.video_rect.height;

    ret = ss_mpi_vpss_set_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_attr failed", ret);

    if (*pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vpss_detach_chn_vb_pool((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl);
        VPSS_CHECK_RET("call ss_mpi_vpss_detach_chn_vb_pool failed", ret);
    }

    ret = mapi_adapt_vpss_set_chn_vb(&vpss_chn_attr, pool_id, chn_attr->vb_pool_blk_cnt, scale);
    VPSS_CHECK_RET("call mapi_adapt_vpss_set_chn_vb failed", ret);

    if (*pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vpss_set_chn_vb_src((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl, OT_VB_SRC_USER);
        VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_vb_src failed", ret);
        ret = ss_mpi_vpss_attach_chn_vb_pool((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl, *pool_id);
        VPSS_CHECK_RET("call ss_mpi_vpss_attach_chn_vb_pool failed", ret);
    }
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_attr(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_chn_attr *chn_attr)
{
    td_s32 ret;
    ot_vpss_chn_attr vpss_chn_attr;
    VPSS_CHECK_NULL_PTR_RET(chn_attr);

    ret = ss_mpi_vpss_get_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_attr failed", ret);

    chn_attr->width = vpss_chn_attr.width;
    chn_attr->height = vpss_chn_attr.height;
    chn_attr->pixel_format = vpss_chn_attr.pixel_format;
    chn_attr->video_format = vpss_chn_attr.video_format;
    chn_attr->compress_mode = vpss_chn_attr.compress_mode;
    chn_attr->frame_rate_ctrl.src_frame_rate = vpss_chn_attr.frame_rate.src_frame_rate;
    chn_attr->frame_rate_ctrl.dst_frame_rate = vpss_chn_attr.frame_rate.dst_frame_rate;

    chn_attr->aspect_ratio.mode = vpss_chn_attr.aspect_ratio.mode;
    chn_attr->aspect_ratio.bg_color = vpss_chn_attr.aspect_ratio.bg_color;
    chn_attr->aspect_ratio.video_rect.x = vpss_chn_attr.aspect_ratio.video_rect.x;
    chn_attr->aspect_ratio.video_rect.y = vpss_chn_attr.aspect_ratio.video_rect.y;
    chn_attr->aspect_ratio.video_rect.width = vpss_chn_attr.aspect_ratio.video_rect.width;
    chn_attr->aspect_ratio.video_rect.height = vpss_chn_attr.aspect_ratio.video_rect.height;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_align(td_handle vpss_hdl, td_handle chn_hdl, td_u32 align)
{
    TD_UNUSED(vpss_hdl);
    TD_UNUSED(chn_hdl);
    TD_UNUSED(align);
    MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "this function is not supported currently\n");
    return HI_MAPI_VPSS_ENOT_SUPPORT;
}

static td_s32 mapi_adapt_vpss_set_ext_chn_vb(const ot_vpss_ext_chn_attr *vpss_ext_chn_attr, td_u32 *pool_id,
    td_u32 vb_pool_blk_cnt, td_u32 scale)
{
    if (*pool_id != OT_VB_INVALID_POOL_ID) {
        td_s32 ret = mapi_adapt_comm_destroy_vb_pool(*pool_id);
        VPSS_CHECK_RET("call mapi_adapt_comm_destroy_vb_pool failed", ret);
        *pool_id = OT_VB_INVALID_POOL_ID;
    }

    if (vb_pool_blk_cnt > 0) {
        ot_pic_buf_attr frame_attr = {0};
        frame_attr.width = vpss_ext_chn_attr->width * scale;
        frame_attr.height = vpss_ext_chn_attr->height * scale;
        frame_attr.align = OT_DEFAULT_ALIGN;
        frame_attr.bit_width = vpss_ext_chn_attr->depth;
        frame_attr.pixel_format = vpss_ext_chn_attr->pixel_format;
        frame_attr.compress_mode = vpss_ext_chn_attr->compress_mode;
        frame_attr.video_format = vpss_ext_chn_attr->video_format;

        *pool_id =  mapi_adapt_comm_create_vb_pool(&frame_attr, vb_pool_blk_cnt);
        if (*pool_id == OT_VB_INVALID_POOL_ID) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "create pool failed! cnt:[%u]\n", vb_pool_blk_cnt);
            return TD_FAILURE;
        }
    }
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_ext_chn_attr(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_ext_chn_attr *ext_chn_attr, td_u32 *pool_id, td_u32 scale)
{
    td_s32 ret;
    ot_vpss_ext_chn_attr vpss_ext_chn_attr;
    VPSS_CHECK_NULL_PTR_RET(ext_chn_attr);
    VPSS_CHECK_NULL_PTR_RET(pool_id);

    ret = memset_s(&vpss_ext_chn_attr, sizeof(vpss_ext_chn_attr), 0, sizeof(vpss_ext_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memset_s", ret);

    ret = ss_mpi_vpss_get_ext_chn_attr(vpss_hdl, chn_hdl, &vpss_ext_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_ext_chn_attr failed", ret);

    vpss_ext_chn_attr.bind_chn = ext_chn_attr->bind_chn_hdl;
    vpss_ext_chn_attr.width = ext_chn_attr->width;
    vpss_ext_chn_attr.height = ext_chn_attr->height;
    vpss_ext_chn_attr.pixel_format = ext_chn_attr->pixel_format;
    vpss_ext_chn_attr.video_format = ext_chn_attr->video_format;
    vpss_ext_chn_attr.compress_mode = ext_chn_attr->compress_mode;
    vpss_ext_chn_attr.dynamic_range = OT_DYNAMIC_RANGE_SDR8;
    vpss_ext_chn_attr.frame_rate.src_frame_rate = ext_chn_attr->frame_rate_ctrl.src_frame_rate;
    vpss_ext_chn_attr.frame_rate.dst_frame_rate = ext_chn_attr->frame_rate_ctrl.dst_frame_rate;

    ret = ss_mpi_vpss_set_ext_chn_attr(vpss_hdl, chn_hdl, &vpss_ext_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_ext_chn_attr failed", ret);

    if (*pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vpss_detach_chn_vb_pool((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl);
        VPSS_CHECK_RET("call ss_mpi_vpss_detach_chn_vb_pool failed", ret);
    }

    ret = mapi_adapt_vpss_set_ext_chn_vb(&vpss_ext_chn_attr, pool_id, ext_chn_attr->vb_pool_blk_cnt, scale);
    VPSS_CHECK_RET("call mapi_adapt_vpss_set_ext_chn_vb failed", ret);

    if (*pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vpss_set_chn_vb_src((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl, OT_VB_SRC_USER);
        VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_vb_src failed", ret);
        ret = ss_mpi_vpss_attach_chn_vb_pool((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl, *pool_id);
        VPSS_CHECK_RET("call ss_mpi_vpss_attach_chn_vb_pool failed", ret);
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_ext_chn_attr(td_handle vpss_hdl, td_handle chn_hdl,
    hi_mapi_vpss_ext_chn_attr *ext_chn_attr)
{
    td_s32 ret;
    ot_vpss_ext_chn_attr vpss_ext_chn_attr;
    VPSS_CHECK_NULL_PTR_RET(ext_chn_attr);

    ret = memset_s(&vpss_ext_chn_attr, sizeof(vpss_ext_chn_attr), 0x00, sizeof(vpss_ext_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memset_s", ret);

    ret = ss_mpi_vpss_get_ext_chn_attr(vpss_hdl, chn_hdl, &vpss_ext_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_ext_chn_attr failed", ret);

    ext_chn_attr->bind_chn_hdl = vpss_ext_chn_attr.bind_chn;
    ext_chn_attr->width = vpss_ext_chn_attr.width;
    ext_chn_attr->height = vpss_ext_chn_attr.height;
    ext_chn_attr->video_format = vpss_ext_chn_attr.video_format;
    ext_chn_attr->pixel_format = vpss_ext_chn_attr.pixel_format;
    ext_chn_attr->compress_mode = vpss_ext_chn_attr.compress_mode;
    ext_chn_attr->frame_rate_ctrl.src_frame_rate = vpss_ext_chn_attr.frame_rate.src_frame_rate;
    ext_chn_attr->frame_rate_ctrl.dst_frame_rate = vpss_ext_chn_attr.frame_rate.dst_frame_rate;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_low_delay_attr(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_low_delay_info *low_delay)
{
    td_s32 ret;
    ot_low_delay_info low_delay_info;
    VPSS_CHECK_NULL_PTR_RET(low_delay);

    low_delay_info.enable = low_delay->enable;
    low_delay_info.line_cnt = low_delay->line_cnt;
    low_delay_info.one_buf_en = TD_FALSE;

    ret = ss_mpi_vpss_set_chn_low_delay(vpss_hdl, chn_hdl, &low_delay_info);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_low_delay_attr failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_low_delay_attr(td_handle vpss_hdl, td_handle chn_hdl,
    hi_mapi_vpss_low_delay_info *low_delay)
{
    td_s32 ret;
    ot_low_delay_info low_delay_info;
    VPSS_CHECK_NULL_PTR_RET(low_delay);

    ret = ss_mpi_vpss_get_chn_low_delay(vpss_hdl, chn_hdl, &low_delay_info);
    if (ret != TD_SUCCESS) {
        if (ret == OT_ERR_VPSS_NOT_SUPPORT) {
            low_delay->enable = TD_FALSE;
            low_delay->line_cnt = 0;
            return TD_SUCCESS;
        }
        return TD_FAILURE;
    }
    low_delay->enable = low_delay_info.enable;
    low_delay->line_cnt = low_delay_info.line_cnt;
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_buf_wrap(td_handle vpss_hdl, td_handle chn_hdl,
    const mapi_vpss_buf_wrap_info *info)
{
    td_s32 ret;
    ot_vpss_chn_buf_wrap_attr wrap_attr;
    VPSS_CHECK_NULL_PTR_RET(info);

    wrap_attr.enable = info->enable;
    wrap_attr.buf_line = info->buf_line;
    wrap_attr.buf_size = info->buf_size;

    ret = ss_mpi_vpss_set_chn_buf_wrap(vpss_hdl, chn_hdl, &wrap_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_buf_wrap failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_buf_wrap(td_handle vpss_hdl, td_handle chn_hdl,
    mapi_vpss_buf_wrap_info *info)
{
    td_s32 ret;
    ot_vpss_chn_buf_wrap_attr wrap_attr;
    VPSS_CHECK_NULL_PTR_RET(info);

    ret = ss_mpi_vpss_get_chn_buf_wrap(vpss_hdl, chn_hdl, &wrap_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_buf_wrap failed", ret);

    info->enable = wrap_attr.enable;
    info->buf_line = wrap_attr.buf_line;
    info->buf_size = wrap_attr.buf_size;
    return TD_SUCCESS;
}

/* In online mode chn0 wrap requires EARLY_END frame interrupt at grp_height/2. */
td_s32 mapi_adapt_vpss_set_wrap_grp_frame_interrupt(td_handle vpss_hdl, td_u32 max_height)
{
    td_s32 ret;
    ot_frame_interrupt_attr frame_interrupt_attr;

    frame_interrupt_attr.interrupt_type = OT_FRAME_INTERRUPT_EARLY_END;
    frame_interrupt_attr.early_line = max_height / 2; /* 2: half of group height */

    ret = ss_mpi_vpss_set_grp_frame_interrupt_attr((ot_vpss_grp)vpss_hdl, &frame_interrupt_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_grp_frame_interrupt_attr failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_enable_buffer_share(td_handle vpss_hdl, td_handle chn_hdl)
{
    td_s32 ret;
    TD_UNUSED(chn_hdl);
    ot_vpss_grp_attr vpss_grp_attr;

    ret = ss_mpi_vpss_get_grp_attr(vpss_hdl, &vpss_grp_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_grp_attr failed", ret);

    vpss_grp_attr.buf_share_en = TD_TRUE;

    ret = ss_mpi_vpss_set_grp_attr(vpss_hdl, &vpss_grp_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_grp_attr failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_disable_buffer_share(td_handle vpss_hdl, td_handle chn_hdl)
{
    td_s32 ret;
    TD_UNUSED(chn_hdl);
    ot_vpss_grp_attr vpss_grp_attr;

    ret = ss_mpi_vpss_get_grp_attr(vpss_hdl, &vpss_grp_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_grp_attr failed", ret);

    vpss_grp_attr.buf_share_en = TD_FALSE;

    ret = ss_mpi_vpss_set_grp_attr(vpss_hdl, &vpss_grp_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_grp_attr failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_enable_chn(td_handle vpss_hdl, td_handle chn_hdl)
{
    td_s32 ret;

    ret = ss_mpi_vpss_enable_chn(vpss_hdl, chn_hdl);
    VPSS_CHECK_RET("call ss_mpi_vpss_enable_chn failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_disable_chn(td_handle vpss_hdl, td_handle chn_hdl, td_u32 pool_id)
{
    td_s32 ret;

    ret = ss_mpi_vpss_disable_chn(vpss_hdl, chn_hdl);
    VPSS_CHECK_RET("call ss_mpi_vpss_disable_chn failed", ret);

    if (pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vpss_detach_chn_vb_pool((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl);
        VPSS_CHECK_RET("call ss_mpi_vpss_detach_chn_vb_pool failed", ret);
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_grp_crop(td_handle vpss_hdl, const hi_mapi_vpss_crop_info *crop_info)
{
    td_s32 ret;
    ot_vpss_crop_info vpss_crop_info;
    VPSS_CHECK_NULL_PTR_RET(crop_info);

    vpss_crop_info.enable = crop_info->enable;
    vpss_crop_info.crop_mode = crop_info->crop_coordinate;
    vpss_crop_info.crop_rect.x = crop_info->crop_rect.x;
    vpss_crop_info.crop_rect.y = crop_info->crop_rect.y;
    vpss_crop_info.crop_rect.width = crop_info->crop_rect.width;
    vpss_crop_info.crop_rect.height = crop_info->crop_rect.height;

    ret = ss_mpi_vpss_set_grp_crop(vpss_hdl, &vpss_crop_info);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_grp_crop failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_crop(td_handle vpss_hdl, td_handle chn_hdl, const hi_mapi_vpss_crop_info *crop_info)
{
    td_s32 ret;
    ot_vpss_crop_info vpss_crop_info;
    VPSS_CHECK_NULL_PTR_RET(crop_info);

    vpss_crop_info.enable = crop_info->enable;
    vpss_crop_info.crop_mode = crop_info->crop_coordinate;
    vpss_crop_info.crop_rect.x = crop_info->crop_rect.x;
    vpss_crop_info.crop_rect.y = crop_info->crop_rect.y;
    vpss_crop_info.crop_rect.width = crop_info->crop_rect.width;
    vpss_crop_info.crop_rect.height = crop_info->crop_rect.height;

    ret = ss_mpi_vpss_set_chn_crop(vpss_hdl, chn_hdl, &vpss_crop_info);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_crop failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_grp_crop(td_handle vpss_hdl, hi_mapi_vpss_crop_info *crop_info)
{
    td_s32 ret;
    ot_vpss_crop_info vpss_crop_info;
    VPSS_CHECK_NULL_PTR_RET(crop_info);

    ret = memset_s(&vpss_crop_info, sizeof(vpss_crop_info), 0, sizeof(vpss_crop_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memset_s", ret);

    ret = ss_mpi_vpss_get_grp_crop(vpss_hdl, &vpss_crop_info);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_grp_crop failed", ret);

    crop_info->enable = vpss_crop_info.enable;
    crop_info->crop_coordinate = vpss_crop_info.crop_mode;
    crop_info->crop_rect.x = vpss_crop_info.crop_rect.x;
    crop_info->crop_rect.y = vpss_crop_info.crop_rect.y;
    crop_info->crop_rect.width = vpss_crop_info.crop_rect.width;
    crop_info->crop_rect.height = vpss_crop_info.crop_rect.height;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_crop(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_vpss_crop_info *crop_info)
{
    td_s32 ret;
    ot_vpss_crop_info vpss_crop_info;
    VPSS_CHECK_NULL_PTR_RET(crop_info);

    ret = memset_s(&vpss_crop_info, sizeof(vpss_crop_info), 0, sizeof(vpss_crop_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memset_s", ret);

    ret = ss_mpi_vpss_get_chn_crop(vpss_hdl, chn_hdl, &vpss_crop_info);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_crop failed", ret);

    crop_info->enable = vpss_crop_info.enable;
    crop_info->crop_coordinate = vpss_crop_info.crop_mode;
    crop_info->crop_rect.x = vpss_crop_info.crop_rect.x;
    crop_info->crop_rect.y = vpss_crop_info.crop_rect.y;
    crop_info->crop_rect.width = vpss_crop_info.crop_rect.width;
    crop_info->crop_rect.height = vpss_crop_info.crop_rect.height;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_mirror(td_handle vpss_hdl, td_handle chn_hdl, td_bool is_mirror)
{
    td_s32 ret;
    ot_vpss_chn_attr vpss_chn_attr;

    ret = ss_mpi_vpss_get_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_attr failed", ret);

    vpss_chn_attr.mirror_en = is_mirror;
    ret = ss_mpi_vpss_set_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_attr failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_mirror(td_handle vpss_hdl, td_handle chn_hdl, td_bool *is_mirror)
{
    td_s32 ret;
    ot_vpss_chn_attr vpss_chn_attr;
    VPSS_CHECK_NULL_PTR_RET(is_mirror);

    ret = ss_mpi_vpss_get_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_attr failed", ret);

    *is_mirror = vpss_chn_attr.mirror_en;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_flip(td_handle vpss_hdl, td_handle chn_hdl, td_bool is_flip)
{
    td_s32 ret;
    ot_vpss_chn_attr vpss_chn_attr;

    ret = ss_mpi_vpss_get_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_attr failed", ret);

    vpss_chn_attr.flip_en = is_flip;
    ret = ss_mpi_vpss_set_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_attr failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_flip(td_handle vpss_hdl, td_handle chn_hdl, td_bool *is_flip)
{
    td_s32 ret;
    ot_vpss_chn_attr vpss_chn_attr;
    VPSS_CHECK_NULL_PTR_RET(is_flip);

    ret = ss_mpi_vpss_get_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_attr failed", ret);

    *is_flip = vpss_chn_attr.flip_en;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_rotation(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_rotation *vpss_rotation)
{
    td_s32 ret;
    VPSS_CHECK_NULL_PTR_RET(vpss_rotation);
    ot_rotation_attr vpss_rotate;

    ret = ss_mpi_vpss_get_chn_rotation(vpss_hdl, chn_hdl, &vpss_rotate);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_rotation failed", ret);

    if (*vpss_rotation == (hi_mapi_rotation)vpss_rotate.rotation_fixed) {
        return TD_SUCCESS;
    }

    if (*vpss_rotation != 0) {
        vpss_rotate.enable = TD_TRUE;
        vpss_rotate.rotation_type = 0;
    }
    vpss_rotate.rotation_fixed = (ot_rotation)*vpss_rotation;

    ret = ss_mpi_vpss_set_chn_rotation(vpss_hdl, chn_hdl, &vpss_rotate);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_rotation failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_rotation(td_handle vpss_hdl, td_handle chn_hdl, hi_mapi_rotation *vpss_rotation)
{
    td_s32 ret;
    ot_rotation_attr vpss_rotate;
    VPSS_CHECK_NULL_PTR_RET(vpss_rotation);

    ret = ss_mpi_vpss_get_chn_rotation(vpss_hdl, chn_hdl, &vpss_rotate);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_rotation failed", ret);

    *vpss_rotation = (hi_mapi_rotation)vpss_rotate.rotation_fixed;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_ldc(td_handle vpss_hdl, __attribute__((unused)) td_handle chn_hdl,
    hi_mapi_vpss_ldc_attr *attr)
{
#ifdef __HI3516CV610__
    MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "not support set ldcv1 at vpss device\n");
    return HI_MAPI_VPSS_ENOT_SUPPORT;
#endif

    ot_ldc_attr ldc_attr = {};
    VPSS_CHECK_NULL_PTR_RET(attr);

    ldc_attr.ldc_version = OT_LDC_V1;
    td_s32 ret = ss_mpi_vpss_get_grp_ldc((ot_vpss_grp)vpss_hdl, &ldc_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_grp_ldc failed", ret);
    attr->enable = ldc_attr.enable;
    attr->ldc_attr.aspect = ldc_attr.ldc_v1_attr.aspect;
    attr->ldc_attr.x_ratio = ldc_attr.ldc_v1_attr.x_ratio;
    attr->ldc_attr.y_ratio = ldc_attr.ldc_v1_attr.y_ratio;
    attr->ldc_attr.xy_ratio = ldc_attr.ldc_v1_attr.xy_ratio;
    attr->ldc_attr.center_x_offset = ldc_attr.ldc_v1_attr.center_x_offset;
    attr->ldc_attr.center_y_offset = ldc_attr.ldc_v1_attr.center_y_offset;
    attr->ldc_attr.distortion_ratio = ldc_attr.ldc_v1_attr.distortion_ratio;
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_ldc(td_handle vpss_hdl, __attribute__((unused)) td_handle chn_hdl,
    const hi_mapi_vpss_ldc_attr *attr)
{
#ifdef __HI3516CV610__
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "not support set ldcv1 at vpss device\n");
        return HI_MAPI_VPSS_ENOT_SUPPORT;
#endif

    ot_ldc_attr ldc_attr = {};
    VPSS_CHECK_NULL_PTR_RET(attr);
    ldc_attr.ldc_version = OT_LDC_V1;
    ldc_attr.enable = attr->enable;
    ldc_attr.ldc_v1_attr.aspect = attr->ldc_attr.aspect;
    ldc_attr.ldc_v1_attr.x_ratio = attr->ldc_attr.x_ratio;
    ldc_attr.ldc_v1_attr.y_ratio = attr->ldc_attr.y_ratio;
    ldc_attr.ldc_v1_attr.xy_ratio = attr->ldc_attr.xy_ratio;
    ldc_attr.ldc_v1_attr.center_x_offset = attr->ldc_attr.center_x_offset;
    ldc_attr.ldc_v1_attr.center_y_offset = attr->ldc_attr.center_y_offset;
    ldc_attr.ldc_v1_attr.distortion_ratio = attr->ldc_attr.distortion_ratio;

    td_s32 ret = ss_mpi_vpss_set_grp_ldc((ot_vpss_grp)vpss_hdl, &ldc_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_grp_ldc failed", ret);
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_ldcv2(__attribute__((unused)) td_handle vpss_hdl,
    __attribute__((unused)) td_handle chn_hdl, __attribute__((unused)) hi_mapi_vpss_ldc_v2_attr *attr)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "not support set ldcv2 at vpss device\n");
    return HI_MAPI_VPSS_ENOT_SUPPORT;
}

td_s32 mapi_adapt_vpss_set_chn_ldcv2(__attribute__((unused)) td_handle vpss_hdl,
    __attribute__((unused)) td_handle chn_hdl, __attribute__((unused)) const hi_mapi_vpss_ldc_v2_attr *attr)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "not support set ldcv2 at vpss device\n");
    return HI_MAPI_VPSS_ENOT_SUPPORT;
}

td_s32 mapi_adapt_vpss_get_chn_ldcv4(td_handle vpss_hdl, td_handle chn_hdl,
    hi_mapi_vpss_ldc_v4_attr *attr)
{
#ifdef __HI3516CV610__
    ot_ldc_attr ldc_attr = {};
    VPSS_CHECK_NULL_PTR_RET(attr);

    ldc_attr.ldc_version = OT_LDC_V3; /* cv610 v4 maps v3 */
    td_s32 ret = ss_mpi_vpss_get_chn_ldc((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl, &ldc_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_ldc failed", ret);
    attr->enable = ldc_attr.enable;
    attr->attr.view_type = ldc_attr.ldc_v3_attr.view_type;
    attr->attr.center_x_offset = ldc_attr.ldc_v3_attr.center_x_offset;
    attr->attr.center_y_offset = ldc_attr.ldc_v3_attr.center_y_offset;
    attr->attr.distortion_ratio = ldc_attr.ldc_v3_attr.distortion_ratio;
    attr->attr.min_ratio = ldc_attr.ldc_v3_attr.min_ratio;
    return TD_SUCCESS;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "not support set ldcv4 at vpss device\n");
    return HI_MAPI_VPSS_ENOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_vpss_set_chn_ldcv4(td_handle vpss_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_ldc_v4_attr *attr)
{
#ifdef __HI3516CV610__
    ot_ldc_attr ldc_attr = {};
    VPSS_CHECK_NULL_PTR_RET(attr);
    ldc_attr.ldc_version = OT_LDC_V3;
    ldc_attr.enable = attr->enable;
    ldc_attr.ldc_v3_attr.view_type = attr->attr.view_type;
    ldc_attr.ldc_v3_attr.center_x_offset = attr->attr.center_x_offset;
    ldc_attr.ldc_v3_attr.center_y_offset = attr->attr.center_y_offset;
    ldc_attr.ldc_v3_attr.distortion_ratio = attr->attr.distortion_ratio;
    ldc_attr.ldc_v3_attr.min_ratio = attr->attr.min_ratio;

    td_s32 ret = ss_mpi_vpss_set_chn_ldc((ot_vpss_grp)vpss_hdl, (ot_vpss_chn)chn_hdl, &ldc_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_ldc failed", ret);
    return TD_SUCCESS;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "not support set ldcv4 at vpss device\n");
    return HI_MAPI_VPSS_ENOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_vpss_get_chn_ldcv3(td_handle vpss_hdl, __attribute__((unused)) td_handle chn_hdl,
    hi_mapi_vpss_ldc_v3_attr *attr)
{
    ot_ldc_attr ldc_attr = {};
    VPSS_CHECK_NULL_PTR_RET(attr);

    ldc_attr.ldc_version = OT_LDC_V2; /* dv500 v2 maps sd3403 v3 */
    td_s32 ret = ss_mpi_vpss_get_grp_ldc((ot_vpss_grp)vpss_hdl, &ldc_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_grp_ldc failed", ret);
    attr->enable = ldc_attr.enable;
    attr->attr.aspect = ldc_attr.ldc_v2_attr.aspect;
    attr->attr.x_ratio = ldc_attr.ldc_v2_attr.x_ratio;
    attr->attr.y_ratio = ldc_attr.ldc_v2_attr.y_ratio;
    attr->attr.xy_ratio = ldc_attr.ldc_v2_attr.xy_ratio;
    attr->attr.focal_len_x = ldc_attr.ldc_v2_attr.focal_len_x;
    attr->attr.focal_len_y = ldc_attr.ldc_v2_attr.focal_len_y;
    attr->attr.coord_shift_x = ldc_attr.ldc_v2_attr.coord_shift_x;
    attr->attr.coord_shift_y = ldc_attr.ldc_v2_attr.coord_shift_y;
    attr->attr.coef_intp_ratio = ldc_attr.ldc_v2_attr.coef_intp_ratio;
    for (td_u32 i = 0; i < OT_SRC_LENS_COEF_NUM; i++) {
        attr->attr.src_calibration_ratio[i] = ldc_attr.ldc_v2_attr.src_calibration_ratio[i];
        attr->attr.src_calibration_ratio_next[i] = ldc_attr.ldc_v2_attr.src_calibration_ratio_next[i];
    }
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_ldcv3(td_handle vpss_hdl, __attribute__((unused)) td_handle chn_hdl,
    const hi_mapi_vpss_ldc_v3_attr *attr)
{
    ot_ldc_attr ldc_attr = {};
    VPSS_CHECK_NULL_PTR_RET(attr);
    ldc_attr.ldc_version = OT_LDC_V2; /* dv500 v2 maps sd3403 v3 */
    ldc_attr.enable = attr->enable;
    ldc_attr.ldc_v2_attr.aspect = attr->attr.aspect;
    ldc_attr.ldc_v2_attr.x_ratio = attr->attr.x_ratio;
    ldc_attr.ldc_v2_attr.y_ratio = attr->attr.y_ratio;
    ldc_attr.ldc_v2_attr.xy_ratio = attr->attr.xy_ratio;
    ldc_attr.ldc_v2_attr.focal_len_x = attr->attr.focal_len_x;
    ldc_attr.ldc_v2_attr.focal_len_y = attr->attr.focal_len_y;
    ldc_attr.ldc_v2_attr.coord_shift_x = attr->attr.coord_shift_x;
    ldc_attr.ldc_v2_attr.coord_shift_y = attr->attr.coord_shift_y;
    ldc_attr.ldc_v2_attr.coef_intp_ratio = attr->attr.coef_intp_ratio;
    for (td_u32 i = 0; i < OT_SRC_LENS_COEF_NUM; i++) {
        ldc_attr.ldc_v2_attr.src_calibration_ratio[i] = attr->attr.src_calibration_ratio[i];
        ldc_attr.ldc_v2_attr.src_calibration_ratio_next[i] = attr->attr.src_calibration_ratio_next[i];
    }

    td_s32 ret = ss_mpi_vpss_set_grp_ldc((ot_vpss_grp)vpss_hdl, &ldc_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_grp_ldc failed", ret);
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_gdc(td_handle vpss_hdl, __attribute__((unused)) td_handle chn_hdl,
    const hi_mapi_vpss_gdc_param *param)
{
    ot_gdc_param gdc_param;
    gdc_param.in_size.width = param->in_width;
    gdc_param.in_size.height = param->in_height;
    gdc_param.cell_size = param->cell_size;
    td_s32 ret = ss_mpi_vpss_set_grp_gdc_param(vpss_hdl, &gdc_param);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_grp_gdc_param failed", ret);
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_gdc(td_handle vpss_hdl, __attribute__((unused)) td_handle chn_hdl,
    hi_mapi_vpss_gdc_param *param)
{
    ot_gdc_param gdc_param;
    td_s32 ret = ss_mpi_vpss_get_grp_gdc_param(vpss_hdl, &gdc_param);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_grp_gdc_param failed", ret);
    param->in_width = gdc_param.in_size.width;
    param->in_height = gdc_param.in_size.height;
    param->cell_size = gdc_param.cell_size;
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_chn_depth(td_handle vpss_hdl, td_handle chn_hdl, td_u32 depth)
{
    td_s32 ret;
    ot_vpss_chn_attr vpss_chn_attr;

    ret = ss_mpi_vpss_get_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_attr failed", ret);

    vpss_chn_attr.depth = depth;

    ret = ss_mpi_vpss_set_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_chn_attr failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_chn_depth(td_handle vpss_hdl, td_handle chn_hdl, td_u32 *depth)
{
    td_s32 ret;
    ot_vpss_chn_attr vpss_chn_attr;
    VPSS_CHECK_NULL_PTR_RET(depth);

    ret = ss_mpi_vpss_get_chn_attr(vpss_hdl, chn_hdl, &vpss_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_chn_attr failed", ret);
    *depth = vpss_chn_attr.depth;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_set_ext_chn_depth(td_handle vpss_hdl, td_handle chn_hdl, td_u32 depth)
{
    td_s32 ret;
    ot_vpss_ext_chn_attr vpss_ext_chn_attr;

    ret = ss_mpi_vpss_get_ext_chn_attr(vpss_hdl, chn_hdl, &vpss_ext_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_ext_chn_attr failed", ret);

    vpss_ext_chn_attr.depth = depth;
    ret = ss_mpi_vpss_set_ext_chn_attr(vpss_hdl, chn_hdl, &vpss_ext_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_set_ext_chn_attr failed", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_ext_chn_depth(td_handle vpss_hdl, td_handle chn_hdl, td_u32 *depth)
{
    td_s32 ret;
    ot_vpss_ext_chn_attr vpss_ext_chn_attr;
    VPSS_CHECK_NULL_PTR_RET(depth);

    ret = ss_mpi_vpss_get_ext_chn_attr(vpss_hdl, chn_hdl, &vpss_ext_chn_attr);
    VPSS_CHECK_RET("call ss_mpi_vpss_get_ext_chn_attr failed", ret);
    *depth = vpss_ext_chn_attr.depth;

    return TD_SUCCESS;
}

static td_void mapi_vpss_get_video_frame_info(const hi_mapi_frame_data *framedata,
    ot_video_frame_info *video_frame)
{
    /* header stride */
    video_frame->video_frame.header_stride[0] = framedata->heade_stride[0];
    video_frame->video_frame.header_stride[1] = framedata->heade_stride[1];

    /* stride */
    video_frame->video_frame.stride[0] = framedata->stride[0];
    video_frame->video_frame.stride[1] = framedata->stride[1]; /* 1: stride array index */

    /* header phy addr */
    video_frame->video_frame.header_phys_addr[0] = framedata->header_phys_addr[0];
    video_frame->video_frame.header_phys_addr[1] = framedata->header_phys_addr[1];
    video_frame->video_frame.header_virt_addr[0] = (td_void *)(uintptr_t)framedata->heade_virt_addr[0];
    video_frame->video_frame.header_virt_addr[1] = (td_void *)(uintptr_t)framedata->heade_virt_addr[1];

    /* phy addr */
    video_frame->video_frame.phys_addr[0] = framedata->phy_addr[0];
    video_frame->video_frame.phys_addr[1] = framedata->phy_addr[1]; /* 1: stride array index */

    /* vir addr */
    video_frame->video_frame.virt_addr[0] = (td_void *)(uintptr_t)framedata->vir_addr[0];
    video_frame->video_frame.virt_addr[1] = (td_void *)(uintptr_t)framedata->vir_addr[1]; /* 1: stride array index */
}

td_s32 mapi_adapt_vpss_send_frame(td_handle vpss_hdl, const hi_mapi_frame_data *frame_data, td_u32 time_ref)
{
    td_s32 ret;
    ot_video_frame_info video_frame;
    VPSS_CHECK_NULL_PTR_RET(frame_data);

    ret = memset_s(&video_frame, sizeof(video_frame), 0x00, sizeof(video_frame));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memset_s", ret);

    video_frame.pool_id = frame_data->pool_id;
    video_frame.mod_id = OT_ID_USER;

    video_frame.video_frame.width = frame_data->width;
    video_frame.video_frame.height = frame_data->height;
    video_frame.video_frame.field = OT_VIDEO_FIELD_FRAME;
    video_frame.video_frame.pixel_format = frame_data->pixel_format;
    video_frame.video_frame.video_format = frame_data->video_format;
    video_frame.video_frame.compress_mode = frame_data->compress_mode;
    video_frame.video_frame.dynamic_range = OT_DYNAMIC_RANGE_SDR8;
    video_frame.video_frame.color_gamut = OT_COLOR_GAMUT_BT709;
    mapi_vpss_get_video_frame_info(frame_data, &video_frame);
    video_frame.video_frame.time_ref = time_ref;

    video_frame.video_frame.supplement.misc_info_phys_addr = frame_data->video_supplement.misc_info_phys_addr;
    video_frame.video_frame.supplement.jpeg_dcf_phys_addr = frame_data->video_supplement.jpeg_dcf_phy_addr;
    video_frame.video_frame.supplement.isp_info_phys_addr = frame_data->video_supplement.isp_info_phy_addr;
    video_frame.video_frame.supplement.low_delay_phys_addr = frame_data->video_supplement.low_delay_phy_addr;
    video_frame.video_frame.supplement.bnr_mot_phys_addr = frame_data->video_supplement.bnr_mot_phy_addr;
    video_frame.video_frame.supplement.motion_data_phys_addr = frame_data->video_supplement.motion_data_phy_addr;
    video_frame.video_frame.supplement.frame_dng_phys_addr = frame_data->video_supplement.frame_dng_phy_addr;

    video_frame.video_frame.supplement.misc_info_virt_addr = frame_data->video_supplement.misc_info_vir_addr;
    video_frame.video_frame.supplement.jpeg_dcf_virt_addr = frame_data->video_supplement.jpeg_dcf_vir_addr;
    video_frame.video_frame.supplement.isp_info_virt_addr = frame_data->video_supplement.isp_info_vir_addr;
    video_frame.video_frame.supplement.low_delay_virt_addr = frame_data->video_supplement.low_delay_vir_addr;
    video_frame.video_frame.supplement.bnr_mot_virt_addr = frame_data->video_supplement.bnr_mot_virt_addr;
    video_frame.video_frame.supplement.motion_data_virt_addr = frame_data->video_supplement.motion_data_vir_addr;
    video_frame.video_frame.supplement.frame_dng_virt_addr = frame_data->video_supplement.frame_dng_vir_addr;

    ret = ss_mpi_vpss_send_frame(vpss_hdl, &video_frame, MAPI_VPSS_SEND_FRAME_TIMEOUTS_MS);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "ss_mpi_vpss_send_frame exec error ret:%x\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_u64 mapi_adapt_vpss_get_photo_virt_addr(td_u64 phy_addr, td_u32 size)
{
    td_void *vir_addr = NULL;

    vir_addr = ss_mpi_sys_mmap(phy_addr, size);
    if (vir_addr == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_sys_mmap fail!\n");
    }

    return (td_u64)(uintptr_t)vir_addr;
}

td_s32 mapi_adapt_vpss_release_photo_virt_addr(td_u64 vir_addr, td_u32 size)
{
    td_s32 ret;

    ret = ss_mpi_sys_munmap((td_void *)(uintptr_t)vir_addr, size);
    VPSS_CHECK_RET("call ss_mpi_sys_munmap failed", ret);

    return TD_SUCCESS;
}

#if (defined SUPPORT_IVE)
static td_void mapi_vpss_switch_frame_info_to_mpi(const mapi_adapt_video_frame_info *frame_info,
    ot_video_frame_info *video_frame)
{
    if (sizeof(ot_video_frame_info) != sizeof(mapi_adapt_video_frame_info)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "video frame adapt is error!\n");
        return;
    }
    video_frame->mod_id = frame_info->mod_id;
    video_frame->pool_id = frame_info->pool_id;
    video_frame->video_frame.width = frame_info->v_frame.width;
    video_frame->video_frame.height = frame_info->v_frame.height;
    video_frame->video_frame.field = frame_info->v_frame.field;
    video_frame->video_frame.pixel_format = frame_info->v_frame.pixel_format;
    video_frame->video_frame.video_format = frame_info->v_frame.video_format;
    video_frame->video_frame.compress_mode = frame_info->v_frame.compress_mode;
    video_frame->video_frame.dynamic_range = frame_info->v_frame.dynamic_range;
    video_frame->video_frame.color_gamut = frame_info->v_frame.color_gamut;

    for (td_u32 i = 0; i < MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN; i++) {
        video_frame->video_frame.header_stride[i] = frame_info->v_frame.header_stride[i];
        video_frame->video_frame.stride[i] = frame_info->v_frame.stride[i];

        video_frame->video_frame.header_phys_addr[i] = (td_phys_addr_t)frame_info->v_frame.header_phy_addr[i];
        video_frame->video_frame.header_virt_addr[i] = (td_void* ATTRIBUTE)(uintptr_t)frame_info->v_frame.header_vir_addr[i];
        video_frame->video_frame.phys_addr[i] = (td_phys_addr_t)frame_info->v_frame.phy_addr[i];
        video_frame->video_frame.virt_addr[i] = (td_void* ATTRIBUTE)(uintptr_t)frame_info->v_frame.vir_addr[i];
    }

    video_frame->video_frame.time_ref = frame_info->v_frame.time_ref;
    video_frame->video_frame.pts = frame_info->v_frame.pts;
    for (td_u32 i = 0; i < MAPI_ADAPT_MAX_USER_DATA_NUM; i++) {
        video_frame->video_frame.user_data[i] = frame_info->v_frame.private_data[i];
    }
    video_frame->video_frame.frame_flag = frame_info->v_frame.frame_flag;

    td_s32 ret = memcpy_s(&video_frame->video_frame.supplement, sizeof(video_frame->video_frame.supplement),
        &frame_info->v_frame.supplement, sizeof(frame_info->v_frame.supplement));
    CHECK_MAPI_PRINT(HI_MAPI_MOD_VPSS, "memcpy_s", ret);
}

static td_void mapi_vpss_switch_frame_info_to_mapi(const ot_video_frame_info *video_frame,
    mapi_adapt_video_frame_info *frame_info)
{
    frame_info->mod_id = video_frame->mod_id;
    frame_info->pool_id = video_frame->pool_id;
    frame_info->v_frame.width = video_frame->video_frame.width;
    frame_info->v_frame.height = video_frame->video_frame.height;
    frame_info->v_frame.field = video_frame->video_frame.field;
    frame_info->v_frame.pixel_format = video_frame->video_frame.pixel_format;
    frame_info->v_frame.video_format = video_frame->video_frame.video_format;
    frame_info->v_frame.compress_mode = video_frame->video_frame.compress_mode;
    frame_info->v_frame.dynamic_range = video_frame->video_frame.dynamic_range;
    frame_info->v_frame.color_gamut = video_frame->video_frame.color_gamut;

    for (td_u32 i = 0; i < MAPI_ADAPT_VPSS_FRAMEINFO_ARRAYLEN; i++) {
        frame_info->v_frame.header_stride[i] = video_frame->video_frame.header_stride[i];
        frame_info->v_frame.stride[i] = video_frame->video_frame.stride[i];
        frame_info->v_frame.header_phy_addr[i] = (td_u64)video_frame->video_frame.header_phys_addr[i];
        frame_info->v_frame.header_vir_addr[i] = (td_u64)(uintptr_t)video_frame->video_frame.header_virt_addr[i];
        frame_info->v_frame.phy_addr[i] = (td_u64)video_frame->video_frame.phys_addr[i];
        frame_info->v_frame.vir_addr[i] = (td_u64)(uintptr_t)video_frame->video_frame.virt_addr[i];
    }
    frame_info->v_frame.time_ref = video_frame->video_frame.time_ref;
    frame_info->v_frame.pts = video_frame->video_frame.pts;

    for (td_u32 i = 0; i < MAPI_ADAPT_MAX_USER_DATA_NUM; i++) {
        frame_info->v_frame.private_data[i] = video_frame->video_frame.user_data[i];
    }
    frame_info->v_frame.frame_flag = video_frame->video_frame.frame_flag;

    td_s32 ret = memcpy_s(&frame_info->v_frame.supplement, sizeof(frame_info->v_frame.supplement),
        &video_frame->video_frame.supplement, sizeof(video_frame->video_frame.supplement));

    CHECK_MAPI_PRINT(HI_MAPI_MOD_VPSS, "memcpy_s", ret);
}

#endif

#ifdef SUPPORT_IVE
static td_u32 mapi_ive_get_stride(td_u32 width)
{
    return (width + (MAPI_IVE_ALIGN - width % MAPI_IVE_ALIGN) % MAPI_IVE_ALIGN);
}

static td_s32 mapi_ive_get_vb(const ot_video_frame_info *src_frame, ot_video_frame_info *dest_frame,
    mapi_vpss_ive_param *ive_param)
{
    /* only support yuv422 pixel format, one pixel need two bytes */
    td_u32 height = src_frame->video_frame.height;
    td_u32 stride = mapi_ive_get_stride(src_frame->video_frame.width);
    CHECK_MAPI_UINT_PRODUCT_OVERFLOW_RET(HI_MAPI_MOD_VPSS, stride, height);
    td_u32 size = stride * height * 2; /* 2: yuv422 size formula */

    ot_vb_blk vb_blk = ss_mpi_vb_get_blk(OT_VB_INVALID_POOL_ID, size, NULL);
    if (vb_blk == OT_VB_INVALID_HANDLE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_vb_get_blk fail, size:%u\n", size);
        return TD_FAILURE;
    }

    ive_param->vb_blk = vb_blk;
    td_u64 addr = ss_mpi_vb_handle_to_phys_addr(vb_blk);
    if (addr == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_vb_handle_to_phys_addr fail\n");
        (td_void)ss_mpi_vb_release_blk(vb_blk);
        return TD_FAILURE;
    }

    ot_vb_pool vb_pool = ss_mpi_vb_handle_to_pool_id(vb_blk);
    if (vb_pool == OT_VB_INVALID_POOL_ID) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_vb_handle_to_pool_id fail\n");
        (td_void)ss_mpi_vb_release_blk(vb_blk);
        return TD_FAILURE;
    }

    dest_frame->pool_id = vb_pool;
    dest_frame->video_frame.stride[0] = stride;
    dest_frame->video_frame.phys_addr[0] = (td_phys_addr_t)addr;
    dest_frame->video_frame.virt_addr[0] = (td_void* ATTRIBUTE)(uintptr_t)addr;
    dest_frame->video_frame.stride[1] = stride;
    dest_frame->video_frame.phys_addr[1] =
        (td_phys_addr_t)(dest_frame->video_frame.phys_addr[0] + dest_frame->video_frame.stride[0] * height);
    dest_frame->video_frame.virt_addr[1] =
        (td_void* ATTRIBUTE)(uintptr_t)(dest_frame->video_frame.virt_addr[0] + dest_frame->video_frame.stride[0] * height);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_ive_vb(mapi_vpss_ive_param *ive_param, mapi_adapt_video_frame_info *frame_info)
{
    td_s32 ret;
    VPSS_CHECK_NULL_PTR_RET(ive_param);
    VPSS_CHECK_NULL_PTR_RET(frame_info);
    ot_vi_pipe vi_pipe = (ot_vi_pipe)ive_param->vcap_pipe_hdl;
    ot_video_frame_info src_frame;
    ot_video_frame_info dst_frame;

    ret = memset_s(&src_frame, sizeof(ot_video_frame_info), 0, sizeof(ot_video_frame_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memset_s", ret);

    ret = memset_s(&dst_frame, sizeof(ot_video_frame_info), 0, sizeof(ot_video_frame_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VPSS, "memset_s", ret);

    while (ive_param->is_thread_start) {
        ret = ss_mpi_vi_get_pipe_frame(vi_pipe, &src_frame, MAPI_IVE_GET_FRMAE_SLEEP_MS);
        if (ret != TD_SUCCESS) {
            if (ret == OT_ERR_VI_BUF_EMPTY) {
                continue;
            } else {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS,
                    "call ss_mpi_vi_get_pipe_frame failed, return:[%#x]!!\n", ret);
                return ret;
            }
        }

        ret = mapi_ive_get_vb(&src_frame, &dst_frame, ive_param);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "ive get vb for dest frame failed, ret:%x \n", ret);
            (td_void)ss_mpi_vi_release_pipe_frame(vi_pipe, &src_frame);
            return ret;
        }

        ret = ss_mpi_vi_release_pipe_frame(vi_pipe, &src_frame);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_vi_release_pipe_frame failed, ret:%x \n", ret);
            (td_void)ss_mpi_vb_release_blk(ive_param->vb_blk);
            return ret;
        }

        break;
    }

    frame_info->pool_id = dst_frame.pool_id;

    for (td_u32 i = 0; i < 0x3 && i < OT_MAX_COLOR_COMPONENT; i++) { /* 3: phy_addr Strid vir_addr array len */
        frame_info->v_frame.phy_addr[i] = (td_u64)dst_frame.video_frame.phys_addr[i];
        frame_info->v_frame.stride[i] = dst_frame.video_frame.stride[i];
        frame_info->v_frame.vir_addr[i] = (td_u64)(uintptr_t)dst_frame.video_frame.virt_addr[i];
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_release_ive_vb(const mapi_vpss_ive_param *ive_param)
{
    VPSS_CHECK_NULL_PTR_RET(ive_param);
    ot_vb_blk vb_blk = (ot_vb_blk)ive_param->vb_blk;

    td_s32 ret = ss_mpi_vb_release_blk(vb_blk);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ot_vb_blk failed, return:[%#x]!!\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_get_ive_pipe_raw(const mapi_vpss_ive_param *ive_param,
    mapi_adapt_video_frame_info *frame_info)
{
    td_s32 ret;
    VPSS_CHECK_NULL_PTR_RET(ive_param);
    VPSS_CHECK_NULL_PTR_RET(frame_info);
    ot_vi_pipe vi_pipe = (ot_vi_pipe)ive_param->vcap_pipe_hdl;
    ot_video_frame_info video_frame;

    ret = memset_s(&video_frame, sizeof(video_frame), 0, sizeof(video_frame));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    while (ive_param->is_thread_start) {
        ret = ss_mpi_vi_get_pipe_frame(vi_pipe, &video_frame, MAPI_IVE_GET_FRMAE_SLEEP_MS);
        if (ret != TD_SUCCESS) {
            if (ret == OT_ERR_VI_BUF_EMPTY) {
                continue;
            } else {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS,
                    "call ss_mpi_vi_get_pipe_frame failed, return:[%#x]!!\n", ret);
                return ret;
            }
        }
        break;
    }

    mapi_vpss_switch_frame_info_to_mapi(&video_frame, frame_info);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_release_ive_pipe_raw(const mapi_vpss_ive_param *ive_param,
    const mapi_adapt_video_frame_info *frame_info)
{
    td_s32 ret;
    VPSS_CHECK_NULL_PTR_RET(ive_param);
    VPSS_CHECK_NULL_PTR_RET(frame_info);
    ot_vi_pipe vi_pipe = (ot_vi_pipe)ive_param->vcap_pipe_hdl;
    ot_video_frame_info video_frame;

    mapi_vpss_switch_frame_info_to_mpi(frame_info, &video_frame);

    ret = ss_mpi_vi_release_pipe_frame(vi_pipe, &video_frame);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_vi_release_pipe_frame failed, return:[%#x]!!\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_proc_ive_left_y_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, td_handle *ive_hdl, hi_mapi_yuv_data_seq vi_yuv_seq)
{
    td_s32 ret;
    ot_ive_handle ive_handle;
    ot_svp_data src_data;
    ot_svp_dst_data dst_data;
    ot_ive_dma_ctrl dma_ctrl = { 0 };
    dma_ctrl.mode = OT_IVE_DMA_MODE_INTERVAL_COPY;
    dma_ctrl.hor_seg_size = 2; /* 2: two parts of yuv */
    dma_ctrl.elem_size = 1;
    dma_ctrl.ver_seg_rows = 1;
    VPSS_CHECK_NULL_PTR_RET(src_frame);
    VPSS_CHECK_NULL_PTR_RET(dst_frame);
    VPSS_CHECK_NULL_PTR_RET(ive_hdl);

    ret = memset_s(&src_data, sizeof(src_data), 0, sizeof(src_data));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = memset_s(&dst_data, sizeof(dst_data), 0, sizeof(dst_data));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    src_data.virt_addr = src_frame->v_frame.vir_addr[0];
    src_data.phys_addr = src_frame->v_frame.phy_addr[0];
    src_data.width = src_frame->v_frame.width;
    src_data.height = src_frame->v_frame.height;
    src_data.stride = src_frame->v_frame.stride[0];

    dst_data.virt_addr = dst_frame->v_frame.vir_addr[0];
    dst_data.phys_addr = dst_frame->v_frame.phy_addr[0];
    dst_data.width = dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
    dst_data.height = dst_frame->v_frame.height;
    dst_data.stride = dst_frame->v_frame.stride[0];
    if (vi_yuv_seq == HI_MAPI_DATA_SEQ_UYVY) {
        dst_data.virt_addr = dst_frame->v_frame.vir_addr[1];
        dst_data.phys_addr = dst_frame->v_frame.phy_addr[1];
        dst_data.stride = dst_frame->v_frame.stride[1];
    }

    ret = ss_mpi_ive_dma(&ive_handle, &src_data, &dst_data, &dma_ctrl, TD_FALSE);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_ive_dma failed, return:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }
    *ive_hdl = ive_handle;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_proc_ive_right_y_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, td_handle *ive_hdl, hi_mapi_yuv_data_seq vi_yuv_seq)
{
    td_s32 ret;
    ot_ive_handle ive_handle;
    ot_svp_data src_data;
    ot_svp_dst_data dst_data;
    ot_ive_dma_ctrl dma_ctrl = { 0 };
    dma_ctrl.mode = OT_IVE_DMA_MODE_INTERVAL_COPY;
    dma_ctrl.hor_seg_size = 2; /* 2: two parts of yuv */
    dma_ctrl.elem_size = 1;
    dma_ctrl.ver_seg_rows = 1;
    VPSS_CHECK_NULL_PTR_RET(src_frame);
    VPSS_CHECK_NULL_PTR_RET(dst_frame);
    VPSS_CHECK_NULL_PTR_RET(ive_hdl);

    ret = memset_s(&src_data, sizeof(src_data), 0, sizeof(src_data));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = memset_s(&dst_data, sizeof(dst_data), 0, sizeof(dst_data));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    src_data.virt_addr = src_frame->v_frame.vir_addr[0] + dst_frame->v_frame.width;
    src_data.phys_addr = src_frame->v_frame.phy_addr[0] + dst_frame->v_frame.width;
    src_data.width = src_frame->v_frame.width;
    src_data.height = src_frame->v_frame.height;
    src_data.stride = src_frame->v_frame.stride[0];

    dst_data.virt_addr = dst_frame->v_frame.vir_addr[0] + dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
    dst_data.phys_addr = dst_frame->v_frame.phy_addr[0] + dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
    dst_data.width = dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
    dst_data.height = dst_frame->v_frame.height;
    dst_data.stride = dst_frame->v_frame.stride[0];
    if (vi_yuv_seq == HI_MAPI_DATA_SEQ_UYVY) {
        dst_data.virt_addr = dst_frame->v_frame.vir_addr[1] + dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
        dst_data.phys_addr = dst_frame->v_frame.phy_addr[1] + dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
        dst_data.stride = dst_frame->v_frame.stride[1];
    }

    ret = ss_mpi_ive_dma(&ive_handle, &src_data, &dst_data, &dma_ctrl, TD_FALSE);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_ive_dma failed, return:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }
    *ive_hdl = ive_handle;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_proc_ive_left_vu_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, td_handle *ive_hdl, hi_mapi_yuv_data_seq vi_yuv_seq)
{
    td_s32 ret;
    ot_ive_handle ive_handle;
    ot_svp_data src_data;
    ot_svp_dst_data dst_data;
    ot_ive_dma_ctrl dma_ctrl = { 0 };
    dma_ctrl.mode = OT_IVE_DMA_MODE_INTERVAL_COPY;
    dma_ctrl.hor_seg_size = 2; /* 2: two parts of yuv */
    dma_ctrl.elem_size = 1;
    dma_ctrl.ver_seg_rows = 1;
    VPSS_CHECK_NULL_PTR_RET(src_frame);
    VPSS_CHECK_NULL_PTR_RET(dst_frame);
    VPSS_CHECK_NULL_PTR_RET(ive_hdl);

    ret = memset_s(&src_data, sizeof(src_data), 0, sizeof(src_data));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = memset_s(&dst_data, sizeof(dst_data), 0, sizeof(dst_data));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    src_data.virt_addr = src_frame->v_frame.vir_addr[0] + sizeof(td_u8);
    src_data.phys_addr = src_frame->v_frame.phy_addr[0] + sizeof(td_u8);
    src_data.width = src_frame->v_frame.width;
    src_data.height = src_frame->v_frame.height;
    src_data.stride = src_frame->v_frame.stride[0];

    dst_data.virt_addr = dst_frame->v_frame.vir_addr[1];
    dst_data.phys_addr = dst_frame->v_frame.phy_addr[1];
    dst_data.width = dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
    dst_data.height = dst_frame->v_frame.height;
    dst_data.stride = dst_frame->v_frame.stride[1];
    if (vi_yuv_seq == HI_MAPI_DATA_SEQ_UYVY) {
        dst_data.virt_addr = dst_frame->v_frame.vir_addr[0];
        dst_data.phys_addr = dst_frame->v_frame.phy_addr[0];
        dst_data.stride = dst_frame->v_frame.stride[0];
    }

    ret = ss_mpi_ive_dma(&ive_handle, &src_data, &dst_data, &dma_ctrl, TD_FALSE);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_ive_dma failed, return:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }
    *ive_hdl = ive_handle;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_proc_ive_right_vu_pixel(const mapi_adapt_video_frame_info *src_frame,
    const mapi_adapt_video_frame_info *dst_frame, td_handle *ive_hdl, hi_mapi_yuv_data_seq vi_yuv_seq)
{
    td_s32 ret;
    ot_ive_handle ive_handle;
    ot_svp_data src_data;
    ot_svp_dst_data dst_data;
    ot_ive_dma_ctrl dma_ctrl = { 0 };
    dma_ctrl.mode = OT_IVE_DMA_MODE_INTERVAL_COPY;
    dma_ctrl.hor_seg_size = 2; /* 2: two parts of yuv */
    dma_ctrl.elem_size = 1;
    dma_ctrl.ver_seg_rows = 1;
    VPSS_CHECK_NULL_PTR_RET(src_frame);
    VPSS_CHECK_NULL_PTR_RET(dst_frame);
    VPSS_CHECK_NULL_PTR_RET(ive_hdl);

    ret = memset_s(&src_data, sizeof(src_data), 0, sizeof(src_data));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = memset_s(&dst_data, sizeof(dst_data), 0, sizeof(dst_data));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    src_data.virt_addr = src_frame->v_frame.vir_addr[0] + sizeof(td_u8) + dst_frame->v_frame.width;
    src_data.phys_addr = src_frame->v_frame.phy_addr[0] + sizeof(td_u8) + dst_frame->v_frame.width;
    src_data.width = src_frame->v_frame.width;
    src_data.height = src_frame->v_frame.height;
    src_data.stride = src_frame->v_frame.stride[0];

    dst_data.virt_addr = dst_frame->v_frame.vir_addr[1] + dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
    dst_data.phys_addr = dst_frame->v_frame.phy_addr[1] + dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
    dst_data.width = dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
    dst_data.height = dst_frame->v_frame.height;
    dst_data.stride = dst_frame->v_frame.stride[1];
    if (vi_yuv_seq == HI_MAPI_DATA_SEQ_UYVY) {
        dst_data.virt_addr = dst_frame->v_frame.vir_addr[0] + dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
        dst_data.phys_addr = dst_frame->v_frame.phy_addr[0] + dst_frame->v_frame.width / 2; /* 2: two parts of yuv */
        dst_data.stride = dst_frame->v_frame.stride[0];
    }

    ret = ss_mpi_ive_dma(&ive_handle, &src_data, &dst_data, &dma_ctrl, TD_FALSE);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_ive_dma failed, return:[%#x]!!\n", ret);
        return HI_MAPI_VPSS_ENOT_PERM;
    }
    *ive_hdl = ive_handle;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vpss_query_ive_status(td_handle ive_hdl)
{
    td_s32 ret;
    td_bool is_finish;

    ret = ss_mpi_ive_query(ive_hdl, &is_finish, TD_TRUE);
    while (ret == OT_ERR_IVE_QUERY_TIMEOUT) {
        ret = ss_mpi_ive_query(ive_hdl, &is_finish, TD_TRUE);
    }

    return ret;
}

td_s32 mapi_adapt_vpss_send_ive_frame(td_handle vpss_hdl, td_handle chn_hdl,
    const mapi_adapt_video_frame_info *frame_info)
{
    td_s32 ret;
    ot_video_frame_info video_frame;
    VPSS_CHECK_NULL_PTR_RET(frame_info);
    MAPI_UNUSED(chn_hdl);

    ret = memset_s(&video_frame, sizeof(video_frame), 0, sizeof(video_frame));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    mapi_vpss_switch_frame_info_to_mpi(frame_info, &video_frame);

    ret = ss_mpi_vpss_send_frame(vpss_hdl, &video_frame, MAPI_VPSS_SEND_FRMAE_TIMEOUT_MS);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VPSS, "call ss_mpi_vpss_send_frame failed, return:[%#x]!!\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif
