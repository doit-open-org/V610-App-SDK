/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef MAPI_SYS_ADAPT_DEFINE_H
#define MAPI_SYS_ADAPT_DEFINE_H

#ifdef SUPPORT_PHOTO_POST_PROCESS
#define MAPI_SYS_ONE_GROUP_INCLUDE_BIN_CNT 4
#endif

#define MAPI_VB_SUPPLEMENT_JPEG_MASK        0x1
#define MAPI_VB_SUPPLEMENT_MOTION_DATA_MASK 0x2
#define MAPI_VB_SUPPLEMENT_DNG_MASK         0x4
#define MAPI_VB_SUPPLEMENT_BNR_MOT_MASK     0x8

#endif
