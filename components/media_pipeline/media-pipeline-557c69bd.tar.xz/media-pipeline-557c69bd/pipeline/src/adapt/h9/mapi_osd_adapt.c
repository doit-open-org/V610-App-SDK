/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <pthread.h>
#include <stdio.h>

/* mapi header */
#include "hi_mapi_osd_define.h"
#include "mapi_comm_inner.h"
#include "mapi_osd_inner.h"
#include "mapi_osd_adapt.h"

/* mpi header */
#include "ss_mpi_vi.h"
#include "ss_mpi_vpss.h"
#ifdef SUPPORT_AVS
#include "ss_mpi_avs.h"
#endif
#include "ss_mpi_venc.h"
#ifdef SUPPORT_DISP
#include "ss_mpi_vo.h"
#endif
#include "ss_mpi_region.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

td_s32 mapi_adapt_osd_detach_rgn(td_u32 osd_idx, const hi_mapi_osd_disp_attr *disp_attr)
{
    td_s32 ret;
    ot_mpp_chn mpp_chn;
    ot_rgn_handle rgn_hdl = osd_idx;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, disp_attr, HI_MAPI_OSD_ENULL_PTR);

    mpp_chn.dev_id = disp_attr->mod_hdl;
    mpp_chn.chn_id = disp_attr->chn_hdl;
    switch (disp_attr->binded_mod) {
        case HI_MAPI_OSD_BINDMOD_VCAP:
            mpp_chn.mod_id = OT_ID_VI;
            break;

        case HI_MAPI_OSD_BINDMOD_VPSS:
            mpp_chn.mod_id = OT_ID_VPSS;
            break;

        case HI_MAPI_OSD_BINDMOD_STITCH:
            mpp_chn.mod_id = OT_ID_AVS;
            break;

        case HI_MAPI_OSD_BINDMOD_VENC:
            mpp_chn.dev_id = 0;
            mpp_chn.mod_id = OT_ID_VENC;
            break;

        case HI_MAPI_OSD_BINDMOD_DISP:
            mpp_chn.mod_id = OT_ID_VO;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "rgn_hdl[%d] invalide bind mode [%d]\n", osd_idx, disp_attr->binded_mod);
            return HI_MAPI_OSD_EILLEGAL_PARAM;
    }

    ret = ss_mpi_rgn_detach_from_chn(rgn_hdl, &mpp_chn);
    if (ret == OT_ERR_RGN_UNEXIST) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_OSD, "rgn_hdl[%d] is unexist!\n", rgn_hdl);
        return TD_SUCCESS;
    }

    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD,
            "call ss_mpi_rgn_detach_from_chn fail,rgn_hdl[%d] ChnInfo[%d,%d,%d] Error Code: [0x%08X]\n",
            osd_idx, mpp_chn.mod_id, mpp_chn.dev_id, mpp_chn.chn_id, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_osd_destroy_rgn(td_u32 osd_idx)
{
    td_s32 ret;
    ot_rgn_handle rgn_hdl = osd_idx;

    ret = ss_mpi_rgn_destroy(rgn_hdl);
    if (ret == OT_ERR_RGN_UNEXIST) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_OSD, "rgn_hdl[%d] is unexist!\n", rgn_hdl);
        return TD_SUCCESS;
    }

    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_rgn_destroy fail,rgn_hdl[%d] Error Code: [0x%08X]\n", rgn_hdl, ret);
        return ret;
    }

    return TD_SUCCESS;
}

typedef struct {
    mapi_osd_rgn_type mapi_type;
    ot_rgn_type type;
} mapi_adapt_osd_rgn_map;

static ot_rgn_type mapi_adapt_osd_trans_rgn_type(mapi_osd_rgn_type mapi_type)
{
    const mapi_adapt_osd_rgn_map rgn_type_map[MAPI_OSD_RGN_BUTT] = {
        {MAPI_OSD_OVERLAY_RGN, OT_RGN_OVERLAY},
        {MAPI_OSD_COVER_RGN, OT_RGN_COVER},
        {MAPI_OSD_OVERLAYEX_RGN, OT_RGN_OVERLAYEX},
        {MAPI_OSD_COVEREX_RGN, OT_RGN_COVEREX},
        {MAPI_OSD_LINEEX_RGN, OT_RGN_LINEEX},
        {MAPI_OSD_MOSAIC_RGN, OT_RGN_MOSAIC},
        {MAPI_OSD_MOSAICEX_RGN, OT_RGN_MOSAICEX},
        {MAPI_OSD_CORNER_RGN, OT_RGN_CORNER_RECT},
        {MAPI_OSD_CORNEREX_RGN, OT_RGN_CORNER_RECTEX}
    };

    if (mapi_type < MAPI_OSD_OVERLAY_RGN || mapi_type > MAPI_OSD_RGN_BUTT) {
        return OT_RGN_BUTT;
    }

    ot_rgn_type type = OT_RGN_BUTT;
    for (td_u32 i = 0; i < MAPI_OSD_RGN_BUTT; i++) {
        if (rgn_type_map[i].mapi_type == mapi_type) {
            type = rgn_type_map[i].type;
            break;
        }
    }
    return type;
}

td_s32 mapi_adapt_osd_create_rgn(td_u32 osd_idx, const mapi_adapt_osd_rgn_attr *rgn_attr)
{
    ot_rgn_handle rgn_hdl = osd_idx;
    ot_rgn_attr mpi_rgn_attr;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, rgn_attr, HI_MAPI_OSD_ENULL_PTR);

    td_s32 ret = memset_s(&mpi_rgn_attr, sizeof(mpi_rgn_attr), 0x0, sizeof(mpi_rgn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    mpi_rgn_attr.type = mapi_adapt_osd_trans_rgn_type(rgn_attr->type);
    if (rgn_attr->type == MAPI_OSD_OVERLAYEX_RGN) {
        mpi_rgn_attr.attr.overlayex.pixel_format = rgn_attr->pixel_format;
        mpi_rgn_attr.attr.overlayex.bg_color = rgn_attr->color;
        mpi_rgn_attr.attr.overlayex.size.width = rgn_attr->rgn_size.width;
        mpi_rgn_attr.attr.overlayex.size.height = rgn_attr->rgn_size.height;
        mpi_rgn_attr.attr.overlayex.canvas_num =
            (rgn_attr->osd_type == HI_MAPI_OSD_TYPE_BITMAP) ? 1 : 2; /* 2: Canvas  default Num */
    } else if (rgn_attr->type == MAPI_OSD_OVERLAY_RGN) {
        mpi_rgn_attr.attr.overlay.pixel_format = rgn_attr->pixel_format;
        mpi_rgn_attr.attr.overlay.bg_color = rgn_attr->color;
        mpi_rgn_attr.attr.overlay.size.width = rgn_attr->rgn_size.width;
        mpi_rgn_attr.attr.overlay.size.height = rgn_attr->rgn_size.height;
        mpi_rgn_attr.attr.overlay.canvas_num =
            (rgn_attr->osd_type == HI_MAPI_OSD_TYPE_BITMAP) ? 1 : 2;  /* 2: Canvas  default Num */
    }

    ret = ss_mpi_rgn_create(rgn_hdl, &mpi_rgn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_rgn_create fail,rgn_hdl[%d] Error Code: [0x%08X]\n", rgn_hdl, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_osd_set_rgn_bitmap(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr)
{
    td_s32 ret;
    ot_bmp bitmap;
    ot_rgn_handle rgn_hdl = osd_idx;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, osd_attr, HI_MAPI_OSD_ENULL_PTR);

    ret = memset_s(&bitmap, sizeof(bitmap), 0x0, sizeof(bitmap));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    bitmap.pixel_format = osd_attr->osd_content.bitmap_content.pixel_format;
    bitmap.width = osd_attr->osd_content.bitmap_content.width;
    bitmap.height = osd_attr->osd_content.bitmap_content.height;
    bitmap.data = osd_attr->osd_content.bitmap_content.data;

    ret = ss_mpi_rgn_set_bmp(rgn_hdl, &bitmap);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD,
            "call ss_mpi_rgn_set_bmp fail,rgn_hdl[%d] Error Code: [0x%08X]\n", rgn_hdl, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_osd_get_canvas_info(td_u32 osd_idx, mapi_comm_text_bitmap *osd_text)
{
    td_s32 ret;
    ot_rgn_handle rgn_hdl = osd_idx;
    ot_rgn_canvas_info canvas_info;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, osd_text, HI_MAPI_OSD_ENULL_PTR);

    ret = memset_s(&canvas_info, sizeof(canvas_info), 0x0, sizeof(canvas_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    ret = ss_mpi_rgn_get_canvas_info(rgn_hdl, &canvas_info);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_rgn_get_canvas_info fail,rgn_hdl[%d] Error Code: [0x%08X]\n",
            rgn_hdl, ret);
        return ret;
    }

    osd_text->bitmap_data = (td_u16 *)(uintptr_t)canvas_info.virt_addr;
    osd_text->stride = canvas_info.stride;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_osd_update_canvas(td_u32 osd_idx)
{
    td_s32 ret;
    ot_rgn_handle rgn_hdl = osd_idx;

    ret = ss_mpi_rgn_update_canvas(rgn_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_rgn_update_canvas fail,rgn_hdl[%d] Error Code: [0x%08X]\n",
            rgn_hdl, ret);
        return ret;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_osd_get_vcap_image_size(const mapi_adapt_osd_chn_bind_info *chn_info, hi_mapi_size *img_size)
{
    ot_vi_chn_attr chn_attr;

    td_s32 ret = ss_mpi_vi_get_chn_attr(chn_info->dev_id, chn_info->chn_id, &chn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_vi_get_chn_attr(%d, %d) fail,Error Code: [0x%08X]\n",
            chn_info->dev_id, chn_info->chn_id, ret);
        return ret;
    }

    img_size->height = chn_attr.size.height;
    img_size->width = chn_attr.size.width;

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_osd_get_vpss_image_size(const mapi_adapt_osd_chn_bind_info *chn_info, hi_mapi_size *img_size)
{
    ot_vpss_chn_attr chn_attr;

    td_s32 ret = ss_mpi_vpss_get_chn_attr(chn_info->dev_id, chn_info->chn_id, &chn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_vpss_get_chn_attr(%d, %d) fail,Error Code: [0x%08X]\n",
            chn_info->dev_id, chn_info->chn_id, ret);
        return ret;
    }

    img_size->width = chn_attr.width;
    img_size->height = chn_attr.height;

    return TD_SUCCESS;
}

#ifdef SUPPORT_AVS
static td_s32 mapi_adapt_osd_get_stitch_image_size(const mapi_adapt_osd_chn_bind_info *chn_info, hi_mapi_size *img_size)
{
    ot_avs_chn_attr chn_attr;
    td_s32 ret = ss_mpi_avs_get_chn_attr(chn_info->dev_id, chn_info->chn_id, &chn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_avs_get_chn_attr(%d, %d) fail,Error Code: [0x%08X]\n",
            chn_info->dev_id, chn_info->chn_id, ret);
        return ret;
    }

    img_size->width = chn_attr.width;
    img_size->height = chn_attr.height;

    return TD_SUCCESS;
}
#endif

static td_s32 mapi_adapt_osd_get_venc_image_size(const mapi_adapt_osd_chn_bind_info *chn_info, hi_mapi_size *img_size)
{
    ot_venc_chn_attr chn_attr;

    td_s32 ret = ss_mpi_venc_get_chn_attr(chn_info->chn_id, &chn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_venc_get_chn_attr(%d) fail,Error Code: [0x%08X]\n",
            chn_info->chn_id, ret);
        return ret;
    }

    img_size->width = chn_attr.venc_attr.pic_width;
    img_size->height = chn_attr.venc_attr.pic_height;

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_osd_get_disp_image_size(const mapi_adapt_osd_chn_bind_info *chn_info, hi_mapi_size *img_size)
{
#ifdef SUPPORT_DISP
    ot_vo_chn_attr chn_attr;

    td_s32 ret = ss_mpi_vo_get_chn_attr(chn_info->dev_id, chn_info->chn_id, &chn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_vo_get_chn_attr(%d,%d) fail,Error Code: [0x%08X]\n",
            chn_info->dev_id, chn_info->chn_id, ret);
        return ret;
    }

    img_size->width = chn_attr.rect.width;
    img_size->height = chn_attr.rect.height;

    return TD_SUCCESS;
#else
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 mapi_adapt_osd_get_image_size(const mapi_adapt_osd_chn_bind_info *chn_info, hi_mapi_size *img_size)
{
    td_s32 ret;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, chn_info, HI_MAPI_OSD_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, img_size, HI_MAPI_OSD_ENULL_PTR);

    switch (chn_info->bind_module) {
        case HI_MAPI_OSD_BINDMOD_VCAP:
            ret = mapi_adapt_osd_get_vcap_image_size(chn_info, img_size);
            break;

        case HI_MAPI_OSD_BINDMOD_VPSS:
            ret = mapi_adapt_osd_get_vpss_image_size(chn_info, img_size);
            break;

        case HI_MAPI_OSD_BINDMOD_STITCH:
#ifdef SUPPORT_AVS
            ret = mapi_adapt_osd_get_stitch_image_size(chn_info, img_size);
            break;
#else
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "stitch is not support.\n");
            return HI_MAPI_OSD_ENOT_PERM;
#endif

        case HI_MAPI_OSD_BINDMOD_VENC:
            ret = mapi_adapt_osd_get_venc_image_size(chn_info, img_size);
            break;

        case HI_MAPI_OSD_BINDMOD_DISP:
            ret = mapi_adapt_osd_get_disp_image_size(chn_info, img_size);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "invalide mode id [%d]\n", chn_info->bind_module);
            return HI_MAPI_OSD_EILLEGAL_PARAM;
    }

    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "module[%d] get image size fail\n", chn_info->bind_module);
        return ret;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_osd_get_mpp_chn_info(const mapi_adapt_osd_rgn_chn_attr *rgn_chn_attr,
    const hi_mapi_osd_disp_attr *disp_attr, ot_mpp_chn *mpp_chn, ot_rgn_chn_attr *rgn_attr)
{
    mpp_chn->dev_id = rgn_chn_attr->chn_bind_info.dev_id;
    mpp_chn->chn_id = rgn_chn_attr->chn_bind_info.chn_id;

    switch (rgn_chn_attr->chn_bind_info.bind_module) {
        case HI_MAPI_OSD_BINDMOD_VCAP:
            mpp_chn->mod_id = OT_ID_VI;
            break;

        case HI_MAPI_OSD_BINDMOD_VPSS:
            mpp_chn->mod_id = OT_ID_VPSS;
            break;

        case HI_MAPI_OSD_BINDMOD_STITCH:
#ifdef SUPPORT_AVS
            mpp_chn->mod_id = OT_ID_AVS;
            break;
#else
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "stitch is not support.\n");
            return HI_MAPI_OSD_ENOT_PERM;
#endif

        case HI_MAPI_OSD_BINDMOD_VENC:
            mpp_chn->mod_id = OT_ID_VENC;
            mpp_chn->dev_id = 0;
            rgn_attr->attr.overlay_chn.dst = disp_attr->attach_dest;
            break;

        case HI_MAPI_OSD_BINDMOD_DISP:
            mpp_chn->mod_id = OT_ID_VO;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "invalid bind mode [%d]\n", rgn_chn_attr->chn_bind_info.bind_module);
            return HI_MAPI_OSD_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_void mapi_adapt_osd_get_coverex_attr(const mapi_adapt_osd_rgn_chn_attr *rgn_chn_attr,
    ot_rgn_chn_attr *rgn_attr)
{
    td_u32 i = 0; /* Four points for recording quadrilateral */

    rgn_attr->attr.coverex_chn.coverex.color = rgn_chn_attr->content_color;
    rgn_attr->attr.coverex_chn.coverex.type = OT_COVER_QUAD;
    rgn_attr->attr.coverex_chn.coverex.quad_attr.is_solid = TD_FALSE;
    rgn_attr->attr.coverex_chn.coverex.quad_attr.thick = 4; /* 4: width of the edge */
    /* point[0] 左上 */
    rgn_attr->attr.coverex_chn.coverex.quad_attr.point[i].x = rgn_chn_attr->start_pos.x;
    rgn_attr->attr.coverex_chn.coverex.quad_attr.point[i++].y = rgn_chn_attr->start_pos.y;
    /* point[1] 右上 */
    rgn_attr->attr.coverex_chn.coverex.quad_attr.point[i].x =
        rgn_chn_attr->start_pos.x + rgn_chn_attr->content_width;
    rgn_attr->attr.coverex_chn.coverex.quad_attr.point[i++].y = rgn_chn_attr->start_pos.y;
    /* point[2] 右下 */
    rgn_attr->attr.coverex_chn.coverex.quad_attr.point[i].x =
        rgn_chn_attr->start_pos.x + rgn_chn_attr->content_width;
    rgn_attr->attr.coverex_chn.coverex.quad_attr.point[i++].y =
        rgn_chn_attr->start_pos.y + rgn_chn_attr->content_height;
    /* point[3] 左下 */
    rgn_attr->attr.coverex_chn.coverex.quad_attr.point[i].x = rgn_chn_attr->start_pos.x;
    rgn_attr->attr.coverex_chn.coverex.quad_attr.point[i].y =
        rgn_chn_attr->start_pos.y + rgn_chn_attr->content_height;
}

td_s32 mapi_adapt_osd_attach_rgn_to_chn(td_u32 osd_idx, const mapi_adapt_osd_rgn_chn_attr *rgn_chn_attr,
    const hi_mapi_osd_disp_attr *disp_attr)
{
    ot_rgn_handle rgn_hdl = osd_idx;
    ot_rgn_chn_attr rgn_attr;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, rgn_chn_attr, HI_MAPI_OSD_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, disp_attr, HI_MAPI_OSD_ENULL_PTR);

    td_s32 ret = memset_s(&rgn_attr, sizeof(rgn_attr), 0x0, sizeof(rgn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    ot_mpp_chn mpp_chn;

    ret = memset_s(&mpp_chn, sizeof(mpp_chn), 0x0, sizeof(mpp_chn));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    ret = mapi_adapt_osd_get_mpp_chn_info(rgn_chn_attr, disp_attr, &mpp_chn, &rgn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get mpp chn info fail\n");
        return ret;
    }

    rgn_attr.is_show = disp_attr->show;
    rgn_attr.type = mapi_adapt_osd_trans_rgn_type(rgn_chn_attr->rgn_type);
    if (rgn_attr.type == OT_RGN_OVERLAYEX) {
        rgn_attr.attr.overlayex_chn.point.x = rgn_chn_attr->start_pos.x;
        rgn_attr.attr.overlayex_chn.point.y = rgn_chn_attr->start_pos.y;
        rgn_attr.attr.overlayex_chn.bg_alpha = disp_attr->bg_alpha;
        rgn_attr.attr.overlayex_chn.fg_alpha = disp_attr->fg_alpha;
        rgn_attr.attr.overlayex_chn.layer = 0;
    } else if (rgn_attr.type == OT_RGN_OVERLAY) {
        rgn_attr.attr.overlay_chn.point.x = rgn_chn_attr->start_pos.x;
        rgn_attr.attr.overlay_chn.point.y = rgn_chn_attr->start_pos.y;
        rgn_attr.attr.overlay_chn.bg_alpha = disp_attr->bg_alpha;
        rgn_attr.attr.overlay_chn.fg_alpha = disp_attr->fg_alpha;
        rgn_attr.attr.overlay_chn.layer = 0;
    } else {
        rgn_attr.attr.coverex_chn.layer = 0;
        mapi_adapt_osd_get_coverex_attr(rgn_chn_attr, &rgn_attr);
    }

    ret = ss_mpi_rgn_attach_to_chn(rgn_hdl, &mpp_chn, &rgn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD,
            "call ss_mpi_rgn_attach_to_chn fail,rgn_hdl[%d] ChnInfo[%d,%d,%d] Error Code: [0x%08X]\n",
            rgn_hdl, mpp_chn.mod_id, mpp_chn.dev_id, mpp_chn.chn_id, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_osd_set_display_attr(td_u32 osd_idx, const mapi_adapt_osd_rgn_chn_attr *rgn_chn_attr,
    const hi_mapi_osd_disp_attr *disp_attr)
{
    td_s32 ret;
    ot_rgn_handle rgn_hdl = osd_idx;
    ot_rgn_chn_attr rgn_attr;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, rgn_chn_attr, HI_MAPI_OSD_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, disp_attr, HI_MAPI_OSD_ENULL_PTR);

    ret = memset_s(&rgn_attr, sizeof(rgn_attr), 0x0, sizeof(rgn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    ot_mpp_chn mpp_chn;

    ret = memset_s(&mpp_chn, sizeof(mpp_chn), 0x0, sizeof(mpp_chn));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    ret = mapi_adapt_osd_get_mpp_chn_info(rgn_chn_attr, disp_attr, &mpp_chn, &rgn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get mpp chn info fail\n");
        return ret;
    }

    ret = ss_mpi_rgn_get_chn_display_attr(rgn_hdl, &mpp_chn, &rgn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD,
            "call ss_mpi_rgn_get_display_attr fail,rgn_hdl[%d] stChn[%d,%d,%d] Error Code: [0x%08X]\n",
            rgn_hdl, mpp_chn.mod_id, mpp_chn.dev_id, mpp_chn.chn_id, ret);
        return ret;
    }

    rgn_attr.is_show = disp_attr->show;
    if (rgn_attr.type == OT_RGN_OVERLAYEX) {
        rgn_attr.attr.overlayex_chn.point.x = rgn_chn_attr->start_pos.x;
        rgn_attr.attr.overlayex_chn.point.y = rgn_chn_attr->start_pos.y;
        rgn_attr.attr.overlayex_chn.bg_alpha = disp_attr->bg_alpha;
        rgn_attr.attr.overlayex_chn.fg_alpha = disp_attr->fg_alpha;
    } else if (rgn_attr.type == OT_RGN_OVERLAY) {
        rgn_attr.attr.overlay_chn.point.x = rgn_chn_attr->start_pos.x;
        rgn_attr.attr.overlay_chn.point.y = rgn_chn_attr->start_pos.y;
        rgn_attr.attr.overlay_chn.bg_alpha = disp_attr->bg_alpha;
        rgn_attr.attr.overlay_chn.fg_alpha = disp_attr->fg_alpha;
    } else if (rgn_attr.type == OT_RGN_COVEREX) {
        mapi_adapt_osd_get_coverex_attr(rgn_chn_attr, &rgn_attr);
    }

    ret = ss_mpi_rgn_set_chn_display_attr(rgn_hdl, &mpp_chn, &rgn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD,
            "call ss_mpi_rgn_set_display_attr fail,rgn_hdl[%d] stChn[%d,%d,%d] Error Code: [0x%08X]\n",
            rgn_hdl, mpp_chn.mod_id, mpp_chn.dev_id, mpp_chn.chn_id, ret);
        return ret;
    }

    return TD_SUCCESS;
}

#ifdef SUPPORT_AVS
td_s32 mapi_adapt_osd_get_stitch_mode(td_handle stitch_hdl, hi_mapi_vpss_stitch_mode *stitch_mode)
{
    td_s32 ret;
    ot_avs_grp_attr avs_grp_attr;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, stitch_mode, HI_MAPI_OSD_ENULL_PTR);

    ret = memset_s(&avs_grp_attr, sizeof(avs_grp_attr), 0x0, sizeof(avs_grp_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    ret = ss_mpi_avs_get_grp_attr(stitch_hdl, &avs_grp_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "call ss_mpi_avs_get_grp_attr fail, stitchHdl[%d] Error Code: [0x%08X]\n",
            stitch_hdl, ret);
        return ret;
    }

    switch (avs_grp_attr.mode) {
        case OT_AVS_MODE_BLEND:
            *stitch_mode = HI_MAPI_VPSS_STITCH_MODE_BLEND;
            break;
        case OT_AVS_MODE_NOBLEND_VER:
            *stitch_mode = HI_MAPI_VPSS_STITCH_MODE_NOBLEND_VER;
            break;
        case OT_AVS_MODE_NOBLEND_HOR:
            *stitch_mode = HI_MAPI_VPSS_STITCH_MODE_NOBLEND_HOR;
            break;
        case OT_AVS_MODE_NOBLEND_QR:
            *stitch_mode = HI_MAPI_VPSS_STITCH_MODE_NOBLEND_QR;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "not support stitch mode, stitchHdl[%d]\n", stitch_hdl);
            return HI_MAPI_OSD_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
