/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_acap.h"
#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>
#include "audio_comp/audio_comp_acodec.h"
#include "audio_comp/audio_comp_afe.h"
#include "audio_comp/aec_ref_bus.h"
#include "mapi_comm_inner.h"
#include "ss_mpi_audio.h"
#include "ss_mpi_sys.h"
#include "ot_resample.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static ot_audio_frame g_acap_raw_audio_frame[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM];
static ot_aec_frame g_acap_raw_aec_frame[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM];
static td_bool g_acap_raw_frame_cached[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM] = { TD_FALSE };
static td_s16 g_acap_afe_out_buf[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM][MAPI_ACAP_RESAMPLE_BUFF_SIZE];
static td_bool g_acap_afe_synthetic[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM];

/* 内置 CODEC + 外部软件 AFE：AO 旁路参考帧的暂存与"欠帧告警只打一次"标记。
 * MAPI_ACAP_EXT_REF_MAX_SAMPLES 覆盖外部 AFE 单帧样本数（256）并留余量。 */
#define MAPI_ACAP_EXT_REF_MAX_SAMPLES 512
static td_bool g_acap_ext_ref_warned[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM] = { TD_FALSE };

#define MAPI_ACAP_DUMP_FLAG "/tmp/.ai_dump_enable"

enum {
    MAPI_ACAP_DUMP_MIC0,
    MAPI_ACAP_DUMP_MIC1,
    MAPI_ACAP_DUMP_REF,
    MAPI_ACAP_DUMP_AFE,
    MAPI_ACAP_DUMP_NUM
};

static const td_char *g_acap_software_dump_path[MAPI_ACAP_DUMP_NUM] = {
    "/tmp/ai_dump_mic0.pcm",
    "/tmp/ai_dump_mic1.pcm",
    "/tmp/ai_dump_ref.pcm",
    "/tmp/ai_dump_afe.pcm",
};
static FILE *g_acap_software_dump[MAPI_ACAP_DUMP_NUM];
static td_bool g_acap_software_dump_active;

static td_void audio_comp_acap_poll_software_dump(td_void)
{
    td_bool enable = access(MAPI_ACAP_DUMP_FLAG, F_OK) == 0;
    if (enable && g_acap_software_dump_active == TD_FALSE) {
        for (td_u32 i = 0; i < MAPI_ACAP_DUMP_NUM; i++) {
            g_acap_software_dump[i] = fopen(g_acap_software_dump_path[i], "wb");
        }
        g_acap_software_dump_active = TD_TRUE;
        (td_void)printf("[ACAP_DIAG] software AFE dump started\n");
    } else if (!enable && g_acap_software_dump_active == TD_TRUE) {
        for (td_u32 i = 0; i < MAPI_ACAP_DUMP_NUM; i++) {
            if (g_acap_software_dump[i] != TD_NULL) {
                (td_void)fclose(g_acap_software_dump[i]);
                g_acap_software_dump[i] = TD_NULL;
            }
        }
        g_acap_software_dump_active = TD_FALSE;
        (td_void)printf("[ACAP_DIAG] software AFE dump stopped\n");
    }
}

static td_void audio_comp_acap_write_software_dump(td_u32 index, const td_void *data, td_u32 bytes)
{
    if (g_acap_software_dump_active && index < MAPI_ACAP_DUMP_NUM &&
        g_acap_software_dump[index] != TD_NULL && data != TD_NULL && bytes > 0) {
        (td_void)fwrite(data, 1, bytes, g_acap_software_dump[index]);
        (td_void)fflush(g_acap_software_dump[index]);
    }
}

/* HI_MAPI_ACAP_CMD_DUMP_RAW_ENABLE_CONFIG / hi_mapi_acap_get_raw_frame state.
 * Kept separate from g_acap_raw_audio_frame/g_acap_raw_frame_cached above, which
 * belong to the AFE-provider-needs_raw_frame path used inside get_frame(); this is
 * an independent debug tap that a provider using SDK VQE (needs_raw_frame == 0) can
 * still opt into via set_param, without touching that provider's own frame path. */
static td_bool g_acap_dump_raw_enable[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM] = { TD_FALSE };
static ot_audio_frame g_acap_dump_raw_audio_frame[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM];
static ot_aec_frame g_acap_dump_raw_aec_frame[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM];

td_s32 mapi_acap_audio_init(td_void)
{
    return ss_mpi_audio_init();
}

td_void mapi_acap_audio_deinit(td_void)
{
    ss_mpi_audio_exit();
}

td_s32 mapi_acap_dlopen(td_void **lib_handle, td_char *lib_name)
{
    if (lib_handle == TD_NULL || lib_name == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "lib_handle or lib_name is NULL!\n");
        return TD_FAILURE;
    }

    *lib_handle = TD_NULL;
    *lib_handle = dlopen(lib_name, RTLD_LAZY | RTLD_LOCAL);
    if (*lib_handle == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "dlopen %s failed!\n", lib_name);
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

td_s32 mapi_acap_dlsym(td_void **func_handle, td_void *lib_handle, td_char *func_name)
{
    if (lib_handle == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "lib_handle is NULL!\n");
        return TD_FAILURE;
    }

    *func_handle = TD_NULL;
    *func_handle = dlsym(lib_handle, func_name);
    if (*func_handle == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "dlsym %s fail, error msg is %s!\n", func_name, dlerror());
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

td_void mapi_acap_dlclose(td_void *lib_handle)
{
    if (lib_handle == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "lib_handle is NULL!\n");
        return;
    }

    dlclose(lib_handle);
}

static td_s32 audio_comp_acap_config_attr(const mapi_acap_server_context *acap_context,
    const hi_mapi_acap_attr *acap_attr, ot_aio_attr *aio_attr)
{
    aio_attr->expand_flag = acap_context->expand_flag;
    aio_attr->chn_cnt = acap_context->chn_cnt;
    aio_attr->frame_num = acap_context->frm_num;
    aio_attr->clk_share = acap_context->clk_sel;
    switch (acap_attr->sample_rate) {
        case HI_MAPI_AUDIO_SAMPLE_RATE_8000:
        case HI_MAPI_AUDIO_SAMPLE_RATE_16000:
        case HI_MAPI_AUDIO_SAMPLE_RATE_48000:
            aio_attr->sample_rate = (ot_audio_sample_rate)acap_attr->sample_rate;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "not support samplerate!\n");
            return HI_MAPI_ACAP_EILLPARAM;
    }

    switch (acap_attr->bit_width) {
        case HI_MAPI_AUDIO_BIT_WIDTH_16:
            aio_attr->bit_width = (ot_audio_bit_width)acap_attr->bit_width;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "not support bitwidth!\n");
            return HI_MAPI_ACAP_EILLPARAM;
    }

    aio_attr->snd_mode = (ot_audio_snd_mode)acap_attr->sound_mode;
    aio_attr->work_mode = (ot_aio_mode)acap_attr->work_mode;

    if (acap_attr->pt_num_per_frm > OT_MAX_AI_POINT_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "Point Number per Frame Overrange!\n");
        return HI_MAPI_ACAP_EILLPARAM;
    }
    aio_attr->point_num_per_frame = acap_attr->pt_num_per_frm;

    switch (acap_attr->resample_rate) {
        case HI_MAPI_AUDIO_SAMPLE_RATE_8000:
        case HI_MAPI_AUDIO_SAMPLE_RATE_16000:
        case HI_MAPI_AUDIO_SAMPLE_RATE_48000:
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "not support resamplerate!\n");
            return HI_MAPI_ACAP_EILLPARAM;
    }

    aio_attr->i2s_type = acap_attr->i2s_type;

    return TD_SUCCESS;
}

td_s32 audio_comp_acap_set_ai_pub_attr(td_handle acap_hdl, const mapi_acap_server_context *acap_context,
    const hi_mapi_acap_attr *acap_attr)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(acap_context);
    CHECK_MAPI_ACAP_NULL_PTR_RET(acap_attr);

    ot_aio_attr aio_attr = {0};
    td_s32 ret = audio_comp_acap_config_attr(acap_context, acap_attr, &aio_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "audio_comp_acap_config_attr", ret);

    ret = ss_mpi_ai_set_pub_attr(acap_hdl, &aio_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_pub_attr", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_acap_enable_ai(td_handle acap_hdl)
{
    return ss_mpi_ai_enable(acap_hdl);
}

td_s32 audio_comp_acap_disable_ai(td_handle acap_hdl)
{
    for (td_s32 chn = 0; chn < HI_MAPI_ACAP_CHN_MAX_NUM; chn++) {
        (td_void)ss_mpi_ai_disable_chn(acap_hdl, chn);
    }
    return ss_mpi_ai_disable(acap_hdl);
}

td_s32 audio_comp_acap_enable_ai_chn(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    return ss_mpi_ai_enable_chn(acap_hdl, acap_chn_hdl);
}

td_s32 audio_comp_acap_disable_ai_chn(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    td_s32 ret = ss_mpi_ai_disable_chn(acap_hdl, acap_chn_hdl);
    /* Allow provider switching after channel destroy. */
    audio_comp_afe_unlock_active();
    /* Debug dump toggle is per-channel-lifetime, not sticky across re-init. */
    g_acap_dump_raw_enable[acap_hdl][acap_chn_hdl] = TD_FALSE;
    return ret;
}

td_s32 audio_comp_acap_start(td_handle acap_hdl, td_handle acap_chn_hdl, const hi_mapi_acap_attr *acap_attr)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(acap_attr);

    td_s32 ret = ss_mpi_ai_enable(acap_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ss_mpi_ai_enable fail, ret:%x\n", ret);
        return ret;
    }

    if (acap_attr->i2s_type == HI_MAPI_AIO_I2STYPE_INNERCODEC) {
        ret = audio_comp_acodec_config_attr(acap_attr->sample_rate, acap_attr->mixer_mic_mode);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "audio_comp_acodec_config_attr fail, ret:%x\n", ret);
            (td_void)ss_mpi_ai_disable(acap_hdl);
            return ret;
        }
    }

    if (acap_attr->work_mode == HI_MAPI_AIO_MODE_I2S_MASTER ||
        acap_attr->work_mode == HI_MAPI_AIO_MODE_I2S_SLAVE) {
        ret = ss_mpi_ai_set_track_mode(acap_hdl, (ot_audio_track_mode)acap_attr->track_mode);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_track_mode fail, ret:%x\n", ret);
            (td_void)ss_mpi_ai_disable(acap_hdl);
            return ret;
        }
    }

    /* Select raw-frame capture based on the active AFE provider.
     * Providers that need raw frames process mic/ref data themselves; SDK-style
     * providers consume the normal SDK-processed PCM path. */
    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_active();
    td_bool need_raw = (afe != NULL && afe->software_process &&
        acap_attr->input_topology.enable == TD_TRUE &&
        acap_attr->input_topology.ref_chn_hdl != OT_INVALID_HANDLE) ? TD_TRUE : TD_FALSE;
    td_bool dump_raw = g_acap_dump_raw_enable[acap_hdl][acap_chn_hdl];

    ot_ai_chn_attr ai_chn_attr = {0};
    ret = ss_mpi_ai_get_chn_attr(acap_hdl, acap_chn_hdl, &ai_chn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ss_mpi_ai_get_chn_attr fail, ret:%x\n", ret);
        (td_void)ss_mpi_ai_disable(acap_hdl);
        return ret;
    }
    /* dump_raw (HI_MAPI_ACAP_CMD_DUMP_RAW_ENABLE_CONFIG) only ORs the SDK raw-frame
     * cache on for the debug tap in audio_comp_acap_get_raw_frame; it must not flip
     * `mode` below, which stays driven purely by need_raw (the active provider's own
     * requirement) so enabling dump never silently disables VQE on a hisi/SDK-VQE
     * provider channel. */
    ai_chn_attr.raw_frame_enable = need_raw || dump_raw;
    /*
     * Defensive: OT_AI_CHN_MODE_FAST takes the low-latency path that bypasses
     * the SDK's VQE engine entirely (mic data delivered raw, VQE never
     * scheduled -- silently, with no error). This bit is only meaningful for
     * providers that actually run in-band SDK VQE (need_raw == false); for
     * raw-frame AFE providers the channel is meant to hand off unprocessed
     * data anyway, so leave the SDK's own attr untouched there.
     */
    if (!need_raw) {
        ai_chn_attr.mode = OT_AI_CHN_MODE_NORMAL;
    }
    ret = ss_mpi_ai_set_chn_attr(acap_hdl, acap_chn_hdl, &ai_chn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_chn_attr fail, ret:%x\n", ret);
        (td_void)ss_mpi_ai_disable(acap_hdl);
        return ret;
    }

    ret = ss_mpi_ai_enable_chn(acap_hdl, acap_chn_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ss_mpi_ai_enable_chn fail, ret:%x\n", ret);
        (td_void)ss_mpi_ai_disable(acap_hdl);
        return ret;
    }

    if (need_raw) {
        const hi_mapi_acap_input_topology *topology = &acap_attr->input_topology;
        td_handle channels[HI_MAPI_ACAP_MIC_CHN_MAX_NUM + 1] = {
            topology->mic_chn_hdl[0], topology->mic_chn_hdl[1], topology->ref_chn_hdl
        };
        for (td_u32 i = 0; i < topology->mic_chn_cnt + 1; i++) {
            if (channels[i] == acap_chn_hdl) {
                continue;
            }
            ot_ai_chn_attr extra_attr = {0};
            ret = ss_mpi_ai_get_chn_attr(acap_hdl, channels[i], &extra_attr);
            if (ret != TD_SUCCESS) {
                return ret;
            }
            extra_attr.raw_frame_enable = TD_TRUE;
            ret = ss_mpi_ai_set_chn_attr(acap_hdl, channels[i], &extra_attr);
            if (ret != TD_SUCCESS) {
                return ret;
            }
            ret = ss_mpi_ai_enable_chn(acap_hdl, channels[i]);
            if (ret != TD_SUCCESS) {
                return ret;
            }
        }
    }
    /* Lock the active provider until this channel is disabled. */
    audio_comp_afe_lock_active();

    return TD_SUCCESS;
}

#ifdef SUPPORT_RECORDVQE
static td_void audio_comp_acap_get_record_vqe_config(const hi_mapi_acap_attr *acap_attr,
    ot_ai_record_vqe_cfg *vqe_attr)
{
    switch (acap_attr->sample_rate) {
        case HI_MAPI_AUDIO_SAMPLE_RATE_48000:
            vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_48000;
            break;

        case HI_MAPI_AUDIO_SAMPLE_RATE_16000:
            vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_16000;
            break;

        default:
            vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_48000;
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "VQE sample_rate only support 16K or 48K, default use 48K.\n");
            break;
    }

    vqe_attr->frame_sample = acap_attr->pt_num_per_frm;
    vqe_attr->work_state = OT_VQE_WORK_STATE_COMMON;
    if (acap_attr->sound_mode == HI_MAPI_AUDIO_SOUND_MODE_MONO) {
        vqe_attr->in_chn_num = HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT;
        vqe_attr->out_chn_num = HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT;
    } else {
        vqe_attr->in_chn_num = HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT;
        vqe_attr->out_chn_num = HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT;
    }
    vqe_attr->record_type = OT_VQE_RECORD_NORMAL;

    vqe_attr->drc_cfg.usr_mode = TD_FALSE;
    vqe_attr->rnr_cfg.usr_mode = TD_FALSE;
    vqe_attr->hdr_cfg.usr_mode = TD_FALSE;

    vqe_attr->hpf_cfg.usr_mode = TD_TRUE;
    vqe_attr->hpf_cfg.hpf_freq = OT_AUDIO_HPF_FREQ_80;

    vqe_attr->agc_cfg.usr_mode = TD_FALSE;

    /* EQ band gain adjustment */
    vqe_attr->eq_cfg.gain_db[0] = -10;
    vqe_attr->eq_cfg.gain_db[1] = -3;
    vqe_attr->eq_cfg.gain_db[2] = -2;
    vqe_attr->eq_cfg.gain_db[3] = -2;
    vqe_attr->eq_cfg.gain_db[4] = -1;
    vqe_attr->eq_cfg.gain_db[5] = -1;
    vqe_attr->eq_cfg.gain_db[6] = -2;
    vqe_attr->eq_cfg.gain_db[7] = -5;
    vqe_attr->eq_cfg.gain_db[8] = -6;
    vqe_attr->eq_cfg.gain_db[9] = -8;

    vqe_attr->open_mask = OT_AI_RECORDVQE_MASK_DRC | OT_AI_RECORDVQE_MASK_HDR | OT_AI_RECORDVQE_MASK_HPF |
                          OT_AI_RECORDVQE_MASK_RNR | OT_AI_RECORDVQE_MASK_AGC;
}

/* Centralize AFE provider and SDK VQE mutual-exclusion checks. */
static td_s32 audio_comp_acap_vqe_check_afe_mutex(td_void)
{
    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_active();
    if (afe != NULL && afe->software_process) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP,
            "software AFE and SDK VQE cannot be enabled simultaneously\n");
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

td_s32 audio_comp_acap_enable_record_vqe(td_handle acap_hdl, td_handle acap_chn_hdl,
    const hi_mapi_acap_attr *acap_attr)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(acap_attr);

    if (audio_comp_acap_vqe_check_afe_mutex() != TD_SUCCESS) {
        return TD_FAILURE;
    }

    ot_ai_record_vqe_cfg vqe_attr;
    td_s32 ret = memset_s(&vqe_attr, sizeof(ot_ai_record_vqe_cfg), 0, sizeof(ot_ai_record_vqe_cfg));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);

    audio_comp_acap_get_record_vqe_config(acap_attr, &vqe_attr);
    ret = ss_mpi_ai_set_record_vqe_attr(acap_hdl, acap_chn_hdl, &vqe_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_record_vqe_attr", ret);

    ret = ss_mpi_ai_enable_vqe(acap_hdl, acap_chn_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_enable_vqe", ret);

    return TD_SUCCESS;
}
#endif

#ifdef SUPPORT_TALKVQE
static td_void audio_comp_acap_get_talk_vqe_config(td_u32 open_mask, const hi_mapi_acap_attr *acap_attr,
    ot_ai_talk_vqe_cfg *ai_vqe_attr)
{
    if (acap_attr->sample_rate == HI_MAPI_AUDIO_SAMPLE_RATE_8000) {
        ai_vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_8000;
    } else {
        ai_vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_16000;
    }
    ai_vqe_attr->frame_sample = acap_attr->pt_num_per_frm;
    ai_vqe_attr->work_state = OT_VQE_WORK_STATE_COMMON;
    ai_vqe_attr->open_mask = open_mask;

    ai_vqe_attr->hpf_cfg.usr_mode = TD_TRUE;
    ai_vqe_attr->hpf_cfg.hpf_freq = OT_AUDIO_HPF_FREQ_120;

    ai_vqe_attr->anr_cfg.usr_mode = TD_TRUE;
    ai_vqe_attr->anr_cfg.noise_db_threshold = MAPI_VQE_ANR_NOISE_DB_THR;
    ai_vqe_attr->anr_cfg.nr_intensity = MAPI_VQE_ANR_NR_INTENSITY;
    ai_vqe_attr->anr_cfg.music_probe_switch = 1;

    ai_vqe_attr->agc_cfg.usr_mode = TD_FALSE;
}

td_s32 audio_comp_acap_enable_talk_vqe(td_handle acap_hdl, td_handle acap_chn_hdl, td_handle talk_ao_hdl,
    td_u32 open_mask, const hi_mapi_acap_attr *acap_attr)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(acap_attr);

    if (audio_comp_acap_vqe_check_afe_mutex() != TD_SUCCESS) {
        return TD_FAILURE;
    }

    ot_ai_talk_vqe_cfg talk_vqe_attr;
    ot_ao_chn ao_chn = acap_chn_hdl;

    td_s32 ret = memset_s(&talk_vqe_attr, sizeof(ot_ai_talk_vqe_cfg), 0, sizeof(ot_ai_talk_vqe_cfg));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);
    audio_comp_acap_get_talk_vqe_config(open_mask, acap_attr, &talk_vqe_attr);

    ret = ss_mpi_ai_set_talk_vqe_attr(acap_hdl, acap_chn_hdl, talk_ao_hdl, ao_chn, &talk_vqe_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_talk_vqe_attr", ret);

    ret = ss_mpi_ai_enable_vqe(acap_hdl, acap_chn_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_enable_vqe", ret);

    return TD_SUCCESS;
}
#endif

#if defined(SUPPORT_TALKVQE) || defined(SUPPORT_RECORDVQE)
td_s32 audio_comp_acap_disable_vqe(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    return ss_mpi_ai_disable_vqe(acap_hdl, acap_chn_hdl);
}
#endif

static td_void audio_comp_acap_get_frame_info(const ot_audio_frame *audio_frame, const ot_aec_frame *aec_frame,
    hi_mapi_audio_frame *audio_frm, hi_mapi_aec_frame *aec_frm)
{
    td_u32 i;

    audio_frm->bit_width = audio_frame->bit_width;
    audio_frm->snd_mode = audio_frame->snd_mode;
    audio_frm->time_stamp = audio_frame->time_stamp;
    audio_frm->seq = audio_frame->seq;
    audio_frm->len = audio_frame->len;
    for (i = 0; i < HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i++) {
        audio_frm->virt_addr[i] = audio_frame->virt_addr[i];
        audio_frm->phys_addr[i] = audio_frame->phys_addr[i];
        audio_frm->pool_id[i] = audio_frame->pool_id[i];
    }

    aec_frm->valid = aec_frame->valid;
    aec_frm->sys_bind = aec_frame->sys_bind;
    aec_frm->ref_frame.bit_width = aec_frame->ref_frame.bit_width;
    aec_frm->ref_frame.snd_mode = aec_frame->ref_frame.snd_mode;
    aec_frm->ref_frame.time_stamp = aec_frame->ref_frame.time_stamp;
    aec_frm->ref_frame.seq = aec_frame->ref_frame.seq;
    aec_frm->ref_frame.len = aec_frame->ref_frame.len;
    for (i = 0; i < HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i++) {
        aec_frm->ref_frame.virt_addr[i] = aec_frame->ref_frame.virt_addr[i];
        aec_frm->ref_frame.phys_addr[i] = aec_frame->ref_frame.phys_addr[i];
        aec_frm->ref_frame.pool_id[i] = aec_frame->ref_frame.pool_id[i];
    }
}

static td_s32 audio_comp_acap_process_afe(td_handle acap_hdl, td_handle acap_chn_hdl,
    const hi_mapi_acap_attr *acap_attr, const ot_audio_frame *audio_frame, const ot_aec_frame *aec_frame,
    hi_mapi_audio_frame *audio_frm)
{
    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_active();
    if (afe == NULL || afe->process == NULL) {
        return TD_SUCCESS;
    }
    if (audio_frame->virt_addr[0] == TD_NULL) {
        return TD_SUCCESS;
    }

    td_u32 channels = (acap_attr->sound_mode == HI_MAPI_AUDIO_SOUND_MODE_MONO) ?
        HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT : HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT;
    audio_comp_pcm_view_in_t in = {
        .data = (const int16_t *)audio_frame->virt_addr[0],
        .data_ch1 = (const int16_t *)audio_frame->virt_addr[1],
        .ref_data = (aec_frame->valid && aec_frame->ref_frame.virt_addr[0] != TD_NULL) ?
            (const int16_t *)aec_frame->ref_frame.virt_addr[0] : NULL,
        .samples = audio_frame->len / sizeof(td_s16),
        .channels = channels,
        .sample_rate = (td_u32)acap_attr->sample_rate,
    };
    audio_comp_pcm_view_out_t out = {0};
    int rc = afe->process(&in, &out);
    if (rc != 0 || out.data == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "AFE process failed, rc:%d\n", rc);
        return HI_MAPI_ACAP_EOPERATE;
    }

    if (out.data == in.data) {
        return TD_SUCCESS;
    }

    td_u32 out_bytes = out.samples * sizeof(td_s16);
    if (out_bytes > sizeof(g_acap_afe_out_buf[acap_hdl][acap_chn_hdl])) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "AFE output too large:%u\n", out_bytes);
        return HI_MAPI_SYS_ARRAY_OUT_BOUNDS;
    }

    td_s32 ret = memcpy_s(g_acap_afe_out_buf[acap_hdl][acap_chn_hdl],
        sizeof(g_acap_afe_out_buf[acap_hdl][acap_chn_hdl]), out.data, out_bytes);
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memcpy_s", ret);

    audio_frm->virt_addr[0] = (td_u8 *)g_acap_afe_out_buf[acap_hdl][acap_chn_hdl];
    audio_frm->phys_addr[0] = (td_u64)(uintptr_t)audio_frm->virt_addr[0];
    audio_frm->pool_id[0] = audio_frame->pool_id[0];
    audio_frm->len = out_bytes;
    if (out.channels == HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT) {
        audio_frm->snd_mode = HI_MAPI_AUDIO_SOUND_MODE_MONO;
        audio_frm->virt_addr[1] = TD_NULL;
        audio_frm->phys_addr[1] = 0;
        audio_frm->pool_id[1] = 0;
    }
    return TD_SUCCESS;
}

static td_s32 audio_comp_acap_get_software_frame(td_handle acap_hdl, td_handle acap_chn_hdl,
    const hi_mapi_acap_attr *acap_attr, hi_mapi_audio_frame *audio_frm, hi_mapi_aec_frame *aec_frm)
{
    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_active();
    ot_audio_frame mic[HI_MAPI_ACAP_MIC_CHN_MAX_NUM] = {0};
    ot_aec_frame mic_aec[HI_MAPI_ACAP_MIC_CHN_MAX_NUM] = {0};
    ot_audio_frame ref = {0};
    ot_aec_frame ref_aec = {0};
    td_bool raw_topology = acap_attr->input_topology.enable == TD_TRUE &&
        acap_attr->input_topology.ref_chn_hdl != OT_INVALID_HANDLE;
    td_s32 ret;
    td_bool ref_local = TD_FALSE;

    if (afe == TD_NULL || afe->process == TD_NULL) {
        return TD_FAILURE;
    }

    if (raw_topology) {
        const hi_mapi_acap_input_topology *topology = &acap_attr->input_topology;
        for (td_u32 i = 0; i < topology->mic_chn_cnt; i++) {
            ot_ai_chn_param chn_param = {0};
            ret = ss_mpi_ai_get_chn_param(acap_hdl, topology->mic_chn_hdl[i], &chn_param);
            if (ret != TD_SUCCESS) {
                return ret;
            }
            chn_param.usr_frame_depth = MAPI_ACAP_FRAME_CACHED_DEPTH;
            ret = ss_mpi_ai_set_chn_param(acap_hdl, topology->mic_chn_hdl[i], &chn_param);
            if (ret != TD_SUCCESS) {
                return ret;
            }
            ret = ss_mpi_ai_get_raw_frame(acap_hdl, topology->mic_chn_hdl[i],
                &mic[i], &mic_aec[i], -1);
            if (ret != TD_SUCCESS) {
                return ret;
            }
        }
        ot_ai_chn_param ref_param = {0};
        ret = ss_mpi_ai_get_chn_param(acap_hdl, topology->ref_chn_hdl, &ref_param);
        if (ret != TD_SUCCESS) {
            return ret;
        }
        ref_param.usr_frame_depth = MAPI_ACAP_FRAME_CACHED_DEPTH;
        ret = ss_mpi_ai_set_chn_param(acap_hdl, topology->ref_chn_hdl, &ref_param);
        if (ret != TD_SUCCESS) {
            return ret;
        }
        ret = ss_mpi_ai_get_raw_frame(acap_hdl, topology->ref_chn_hdl, &ref, &ref_aec, 0);
        if (ret != TD_SUCCESS) {
            static td_u8 g_ref_zero[MAPI_ACAP_EXT_REF_MAX_SAMPLES * sizeof(td_s16)];
            td_u32 zero_bytes = mic[0].len;
            if (zero_bytes > sizeof(g_ref_zero)) {
                zero_bytes = sizeof(g_ref_zero);
            }
            (td_void)memset_s(g_ref_zero, sizeof(g_ref_zero), 0, sizeof(g_ref_zero));
            (td_void)memset_s(&ref, sizeof(ref), 0, sizeof(ref));
            ref.virt_addr[0] = g_ref_zero;
            ref.len = zero_bytes;
            ref_local = TD_TRUE;
        }
    } else {
        ot_ai_chn_param chn_param = {0};
        ret = ss_mpi_ai_get_chn_param(acap_hdl, acap_chn_hdl, &chn_param);
        if (ret != TD_SUCCESS) {
            return ret;
        }
        chn_param.usr_frame_depth = MAPI_ACAP_FRAME_CACHED_DEPTH;
        ret = ss_mpi_ai_set_chn_param(acap_hdl, acap_chn_hdl, &chn_param);
        if (ret != TD_SUCCESS) {
            return ret;
        }
        ret = ss_mpi_ai_get_frame(acap_hdl, acap_chn_hdl, &mic[0], &mic_aec[0], -1);
        if (ret != TD_SUCCESS) {
            return ret;
        }
        /* 内置 CODEC + 软件 AFE：SDK raw/get_frame 路径不携带 AEC 参考，内置又无物理
         * 回采通道。仍要求真双麦（STEREO ch0/ch1）；回声参考由 AO 播放旁路
         * (aec_ref_bus) 提供，缺参考不再视为致命错误——此时软件 AFE 退化为双麦降噪
         * （参考补零）。使能参考总线，触发 AO 侧开始旁路播放 PCM。 */
        if (mic[0].virt_addr[1] == TD_NULL) {
            (td_void)ss_mpi_ai_release_frame(acap_hdl, acap_chn_hdl, &mic[0], &mic_aec[0]);
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "external AFE requires dual mic (stereo capture)\n");
            return TD_FAILURE;
        }
        aec_ref_bus_set_enabled(TD_TRUE);
    }

    td_u32 frame_samples = mic[0].len / sizeof(td_s16);
    int16_t ext_ref_buf[MAPI_ACAP_EXT_REF_MAX_SAMPLES];
    const int16_t *ref_ptr;
    if (raw_topology) {
        ref_ptr = (const int16_t *)ref.virt_addr[0];
    } else if (frame_samples <= MAPI_ACAP_EXT_REF_MAX_SAMPLES &&
               aec_ref_bus_read(ext_ref_buf, frame_samples) == 0) {
        /* 内置 CODEC：AO 播放旁路提供的回声参考 */
        ref_ptr = ext_ref_buf;
    } else {
        /* 参考欠帧（无播放/刚启动）：补零 -> 软件 AFE 退化为双麦降噪，只告警一次 */
        (td_void)memset_s(ext_ref_buf, sizeof(ext_ref_buf), 0,
            (frame_samples <= MAPI_ACAP_EXT_REF_MAX_SAMPLES ? frame_samples :
                MAPI_ACAP_EXT_REF_MAX_SAMPLES) * sizeof(int16_t));
        ref_ptr = ext_ref_buf;
        if (g_acap_ext_ref_warned[acap_hdl][acap_chn_hdl] == TD_FALSE) {
            MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP,
                "external AFE inner path: AEC ref underrun, zero-filled (NR-only until playback)\n");
            g_acap_ext_ref_warned[acap_hdl][acap_chn_hdl] = TD_TRUE;
        }
    }

    audio_comp_acap_poll_software_dump();
    audio_comp_acap_write_software_dump(MAPI_ACAP_DUMP_MIC0, mic[0].virt_addr[0], mic[0].len);
    audio_comp_acap_write_software_dump(MAPI_ACAP_DUMP_MIC1,
        raw_topology ? mic[1].virt_addr[0] : mic[0].virt_addr[1], mic[0].len);
    audio_comp_acap_write_software_dump(MAPI_ACAP_DUMP_REF, ref_ptr,
        frame_samples * sizeof(td_s16));

    audio_comp_pcm_view_in_t in = {
        .data = (const int16_t *)mic[0].virt_addr[0],
        .data_ch1 = raw_topology ? (const int16_t *)mic[1].virt_addr[0] :
            (const int16_t *)mic[0].virt_addr[1],
        .ref_data = ref_ptr,
        .samples = frame_samples,
        .channels = 2,
        .sample_rate = (td_u32)acap_attr->sample_rate,
    };
    audio_comp_pcm_view_out_t out = {0};
    ret = afe->process(&in, &out);

    if (raw_topology) {
        const hi_mapi_acap_input_topology *topology = &acap_attr->input_topology;
        for (td_u32 i = 0; i < topology->mic_chn_cnt; i++) {
            (td_void)ss_mpi_ai_release_raw_frame(acap_hdl, topology->mic_chn_hdl[i],
                &mic[i], &mic_aec[i]);
        }
        if (!ref_local) {
            (td_void)ss_mpi_ai_release_raw_frame(acap_hdl, topology->ref_chn_hdl, &ref, &ref_aec);
        }
    } else {
        (td_void)ss_mpi_ai_release_frame(acap_hdl, acap_chn_hdl, &mic[0], &mic_aec[0]);
    }

    if (ret != TD_SUCCESS || out.data == TD_NULL || out.channels != 1) {
        return TD_FAILURE;
    }

    td_u32 out_bytes = out.samples * sizeof(td_s16);
    if (out_bytes > sizeof(g_acap_afe_out_buf[acap_hdl][acap_chn_hdl])) {
        return HI_MAPI_SYS_ARRAY_OUT_BOUNDS;
    }
    audio_comp_acap_write_software_dump(MAPI_ACAP_DUMP_AFE, out.data, out_bytes);
    ret = memcpy_s(g_acap_afe_out_buf[acap_hdl][acap_chn_hdl],
        sizeof(g_acap_afe_out_buf[acap_hdl][acap_chn_hdl]), out.data, out_bytes);
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memcpy_s", ret);

    (td_void)memset_s(audio_frm, sizeof(*audio_frm), 0, sizeof(*audio_frm));
    (td_void)memset_s(aec_frm, sizeof(*aec_frm), 0, sizeof(*aec_frm));
    audio_frm->bit_width = HI_MAPI_AUDIO_BIT_WIDTH_16;
    audio_frm->snd_mode = HI_MAPI_AUDIO_SOUND_MODE_MONO;
    audio_frm->time_stamp = mic[0].time_stamp;
    audio_frm->seq = mic[0].seq;
    audio_frm->len = out_bytes;
    audio_frm->virt_addr[0] = (td_u8 *)g_acap_afe_out_buf[acap_hdl][acap_chn_hdl];
    audio_frm->phys_addr[0] = (td_u64)(uintptr_t)audio_frm->virt_addr[0];
    g_acap_afe_synthetic[acap_hdl][acap_chn_hdl] = TD_TRUE;
    return TD_SUCCESS;
}
td_s32 audio_comp_acap_get_frame(td_handle acap_hdl, td_handle acap_chn_hdl,
    const hi_mapi_acap_attr *acap_attr, hi_mapi_audio_frame *audio_frm, hi_mapi_aec_frame *aec_frm)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(acap_attr);
    CHECK_MAPI_ACAP_NULL_PTR_RET(audio_frm);
    CHECK_MAPI_ACAP_NULL_PTR_RET(aec_frm);

    const audio_comp_afe_ops_t *active_afe = audio_comp_afe_get_active();
    if (active_afe != TD_NULL && active_afe->software_process) {
        return audio_comp_acap_get_software_frame(acap_hdl, acap_chn_hdl,
            acap_attr, audio_frm, aec_frm);
    }

    ot_ai_chn_param chn_param = {0};
    ot_audio_frame audio_frame = {0};
    ot_aec_frame aec_frame = {0};

    td_s32 ret = ss_mpi_ai_get_chn_param(acap_hdl, acap_chn_hdl, &chn_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_get_chn_param", ret);

    chn_param.usr_frame_depth = MAPI_ACAP_FRAME_CACHED_DEPTH;
    ret = ss_mpi_ai_set_chn_param(acap_hdl, acap_chn_hdl, &chn_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_chn_param", ret);

    /* -1: block get frame.
     * The active AFE provider decides whether to use raw frames or normal frames. */
    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_active();
    if (afe != NULL && afe->software_process) {
        ret = ss_mpi_ai_get_raw_frame(acap_hdl, acap_chn_hdl, &audio_frame, &aec_frame, -1);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_get_raw_frame", ret);
        g_acap_raw_audio_frame[acap_hdl][acap_chn_hdl] = audio_frame;
        g_acap_raw_aec_frame[acap_hdl][acap_chn_hdl] = aec_frame;
        g_acap_raw_frame_cached[acap_hdl][acap_chn_hdl] = TD_TRUE;
    } else {
        ret = ss_mpi_ai_get_frame(acap_hdl, acap_chn_hdl, &audio_frame, &aec_frame, -1);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_get_frame", ret);
        g_acap_raw_frame_cached[acap_hdl][acap_chn_hdl] = TD_FALSE;
    }

    audio_comp_acap_get_frame_info(&audio_frame, &aec_frame, audio_frm, aec_frm);
    ret = audio_comp_acap_process_afe(acap_hdl, acap_chn_hdl, acap_attr, &audio_frame, &aec_frame, audio_frm);
    if (ret != TD_SUCCESS) {
        if (afe != NULL && afe->software_process) {
            (td_void)ss_mpi_ai_release_raw_frame(acap_hdl, acap_chn_hdl, &audio_frame, &aec_frame);
            g_acap_raw_frame_cached[acap_hdl][acap_chn_hdl] = TD_FALSE;
        } else {
            (td_void)ss_mpi_ai_release_frame(acap_hdl, acap_chn_hdl, &audio_frame, &aec_frame);
        }
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 audio_comp_acap_release_frame(td_handle acap_hdl, td_handle acap_chn_hdl,
    const hi_mapi_audio_frame *audio_frm, const hi_mapi_aec_frame *aec_frm)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(audio_frm);
    CHECK_MAPI_ACAP_NULL_PTR_RET(aec_frm);

    if (g_acap_afe_synthetic[acap_hdl][acap_chn_hdl] == TD_TRUE) {
        g_acap_afe_synthetic[acap_hdl][acap_chn_hdl] = TD_FALSE;
        return TD_SUCCESS;
    }

    td_u32 i;
    ot_audio_frame audio_frame = {0};
    ot_aec_frame aec_frame = {0};

    audio_frame.bit_width = audio_frm->bit_width;
    audio_frame.snd_mode = audio_frm->snd_mode;
    audio_frame.time_stamp = audio_frm->time_stamp;
    audio_frame.seq = audio_frm->seq;
    audio_frame.len = audio_frm->len;
    for (i = 0; i < HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i++) {
        /* prevent client addr error */
        audio_frame.virt_addr[i] = (td_u8 *)(uintptr_t)audio_frm->phys_addr[i];
        audio_frame.phys_addr[i] = audio_frm->phys_addr[i];
        audio_frame.pool_id[i] = audio_frm->pool_id[i];
    }

    aec_frame.valid = aec_frm->valid;
    aec_frame.sys_bind = aec_frm->sys_bind;
    aec_frame.ref_frame.bit_width = aec_frm->ref_frame.bit_width;
    aec_frame.ref_frame.snd_mode = aec_frm->ref_frame.snd_mode;
    aec_frame.ref_frame.time_stamp = aec_frm->ref_frame.time_stamp;
    aec_frame.ref_frame.seq = aec_frm->ref_frame.seq;
    aec_frame.ref_frame.len = aec_frm->ref_frame.len;
    for (i = 0; i < HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i++) {
        aec_frame.ref_frame.virt_addr[i] = (td_u8 *)(uintptr_t)aec_frm->ref_frame.virt_addr[i];
        aec_frame.ref_frame.phys_addr[i] = aec_frm->ref_frame.phys_addr[i];
        aec_frame.ref_frame.pool_id[i] = aec_frm->ref_frame.pool_id[i];
    }

    /* Mirror the get_frame dispatch path. */
    td_s32 ret;
    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_active();
    if (afe != NULL && afe->software_process) {
        if (g_acap_raw_frame_cached[acap_hdl][acap_chn_hdl]) {
            audio_frame = g_acap_raw_audio_frame[acap_hdl][acap_chn_hdl];
            aec_frame = g_acap_raw_aec_frame[acap_hdl][acap_chn_hdl];
            g_acap_raw_frame_cached[acap_hdl][acap_chn_hdl] = TD_FALSE;
        }
        ret = ss_mpi_ai_release_raw_frame(acap_hdl, acap_chn_hdl, &audio_frame, &aec_frame);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_release_raw_frame", ret);
    } else {
        ret = ss_mpi_ai_release_frame(acap_hdl, acap_chn_hdl, &audio_frame, &aec_frame);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_release_frame", ret);
    }

    return TD_SUCCESS;
}

td_void audio_comp_acap_set_dump_raw_enable(td_handle acap_hdl, td_handle acap_chn_hdl, td_bool enable)
{
    g_acap_dump_raw_enable[acap_hdl][acap_chn_hdl] = enable;
}


td_s32 audio_comp_acap_get_raw_frame(td_handle acap_hdl, td_handle acap_chn_hdl,
    hi_mapi_audio_frame *audio_frm, hi_mapi_aec_frame *aec_frm)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(audio_frm);
    CHECK_MAPI_ACAP_NULL_PTR_RET(aec_frm);

    if (!g_acap_dump_raw_enable[acap_hdl][acap_chn_hdl]) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP,
            "acap[%d][%d] dump raw not enabled; set HI_MAPI_ACAP_CMD_DUMP_RAW_ENABLE_CONFIG before start\n",
            (int)acap_hdl, (int)acap_chn_hdl);
        return HI_MAPI_ACAP_EOPERATE;
    }

    ot_audio_frame audio_frame = {0};
    ot_aec_frame aec_frame = {0};
    /* -1: block get frame, mirrors audio_comp_acap_get_frame. */
    td_s32 ret = ss_mpi_ai_get_raw_frame(acap_hdl, acap_chn_hdl, &audio_frame, &aec_frame, -1);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_get_raw_frame", ret);

    g_acap_dump_raw_audio_frame[acap_hdl][acap_chn_hdl] = audio_frame;
    g_acap_dump_raw_aec_frame[acap_hdl][acap_chn_hdl] = aec_frame;
    audio_comp_acap_get_frame_info(&audio_frame, &aec_frame, audio_frm, aec_frm);
    return TD_SUCCESS;
}

td_s32 audio_comp_acap_release_raw_frame(td_handle acap_hdl, td_handle acap_chn_hdl,
    const hi_mapi_audio_frame *audio_frm, const hi_mapi_aec_frame *aec_frm)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(audio_frm);
    CHECK_MAPI_ACAP_NULL_PTR_RET(aec_frm);
    (td_void)audio_frm;
    (td_void)aec_frm;

    /* Release the cached SDK-side frame captured by get_raw_frame above (same
     * pattern as the needs_raw_frame branch of audio_comp_acap_release_frame),
     * rather than reconstructing pointers from the caller's phys_addr echo --
     * the raw path's aec_frame is currently unused by the SDK (ref not supported),
     * so round-tripping it through hi_mapi_aec_frame has nothing to preserve. */
    ot_audio_frame audio_frame = g_acap_dump_raw_audio_frame[acap_hdl][acap_chn_hdl];
    ot_aec_frame aec_frame = g_acap_dump_raw_aec_frame[acap_hdl][acap_chn_hdl];
    td_s32 ret = ss_mpi_ai_release_raw_frame(acap_hdl, acap_chn_hdl, &audio_frame, &aec_frame);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_release_raw_frame", ret);
    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
