/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_vgs_adapt.h"
#include "mapi_comm_adapt.h"
#include "mapi_comm_inner.h"
#include "ss_mpi_vgs.h"
#include "ss_mpi_region.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 mapi_adapt_vgs_begin_job(td_handle *vgs_hdl)
{
    return ss_mpi_vgs_begin_job((ot_vgs_handle *)vgs_hdl);
}

td_s32 mapi_adapt_vgs_add_scale_task(td_handle vgs_hdl, const hi_mapi_vgs_scale_task_attr *scale_task_attr)
{
    ot_vgs_task_attr vgs_task;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, scale_task_attr, HI_MAPI_VGS_ENULL_PTR);

    ot_vgs_scale_coef_mode scale_coef_mode = scale_task_attr->scale_coef_mode;

    mapi_adapt_comm_frame_info_to_mpi(&scale_task_attr->vgs_task_attr.frame_data_in, &vgs_task.img_in);
    vgs_task.img_in.mod_id = OT_ID_VPSS;

    mapi_adapt_comm_frame_info_to_mpi(&scale_task_attr->vgs_task_attr.frame_data_out, &vgs_task.img_out);
    vgs_task.img_out.mod_id = OT_ID_VGS;

    td_s32 ret = ss_mpi_vgs_add_scale_task(vgs_hdl, &vgs_task, scale_coef_mode);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_vgs_add_scale_task", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vgs_add_draw_line_task(td_handle vgs_hdl, const hi_mapi_vgs_draw_line_task_attr *draw_line_task_attr)
{
    ot_vgs_task_attr vgs_task;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, draw_line_task_attr, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, draw_line_task_attr->vgs_draw_line, HI_MAPI_VGS_ENULL_PTR);

    mapi_adapt_comm_frame_info_to_mpi(&draw_line_task_attr->vgs_task_attr.frame_data_in, &vgs_task.img_in);
    vgs_task.img_in.mod_id = OT_ID_VPSS;

    mapi_adapt_comm_frame_info_to_mpi(&draw_line_task_attr->vgs_task_attr.frame_data_out, &vgs_task.img_out);
    vgs_task.img_out.mod_id = OT_ID_VGS;

    ot_vgs_line vgs_draw_line[HI_MAPI_VGS_TASK_MAX_CNT];
    td_u32 i;
    for (i = 0; i < draw_line_task_attr->num; i++) {
        vgs_draw_line[i].start_point.x = draw_line_task_attr->vgs_draw_line[i].start_point.x;
        vgs_draw_line[i].start_point.y = draw_line_task_attr->vgs_draw_line[i].start_point.y;
        vgs_draw_line[i].end_point.x = draw_line_task_attr->vgs_draw_line[i].end_point.x;
        vgs_draw_line[i].end_point.y = draw_line_task_attr->vgs_draw_line[i].end_point.y;
        vgs_draw_line[i].thick = draw_line_task_attr->vgs_draw_line[i].thick;
        vgs_draw_line[i].color = draw_line_task_attr->vgs_draw_line[i].color;
    }

    td_s32 ret = ss_mpi_vgs_add_draw_line_task(vgs_hdl, &vgs_task, vgs_draw_line, draw_line_task_attr->num);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_vgs_add_draw_line_task", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vgs_add_cover_task(td_handle vgs_hdl, const hi_mapi_vgs_cover_task_attr *cover_task_attr)
{
    ot_vgs_task_attr vgs_task;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, cover_task_attr, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, cover_task_attr->vgs_add_cover, HI_MAPI_VGS_ENULL_PTR);

    mapi_adapt_comm_frame_info_to_mpi(&cover_task_attr->vgs_task_attr.frame_data_in, &vgs_task.img_in);
    vgs_task.img_in.mod_id = OT_ID_VPSS;

    mapi_adapt_comm_frame_info_to_mpi(&cover_task_attr->vgs_task_attr.frame_data_out, &vgs_task.img_out);
    vgs_task.img_out.mod_id = OT_ID_VGS;

    td_u32 i, j;
    ot_cover vgs_add_cover[HI_MAPI_VGS_TASK_MAX_CNT];
    for (i = 0; i < cover_task_attr->num; i++) {
        vgs_add_cover[i].type = OT_COVER_QUAD;
        vgs_add_cover[i].quad_attr.is_solid = cover_task_attr->vgs_add_cover[i].quad_rangle.is_solid;
        vgs_add_cover[i].quad_attr.thick = cover_task_attr->vgs_add_cover[i].quad_rangle.thick;
        vgs_add_cover[i].color = cover_task_attr->vgs_add_cover[i].color;
        for (j = 0; j < HI_MAPI_VGS_QUADRANGLE_POINT_NUM; j++) {
            vgs_add_cover[i].quad_attr.point[j].x = cover_task_attr->vgs_add_cover[i].quad_rangle.point[j].x;
            vgs_add_cover[i].quad_attr.point[j].y = cover_task_attr->vgs_add_cover[i].quad_rangle.point[j].y;
        }
    }
    td_s32 ret = ss_mpi_vgs_add_cover_task(vgs_hdl, &vgs_task, vgs_add_cover, cover_task_attr->num);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_vgs_add_cover_task", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vgs_create_rgn(td_handle rgn_hdl, const hi_mapi_vgs_rgn_attr *vgs_rgn_attr)
{
    ot_rgn_attr rgn_attr;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, vgs_rgn_attr, HI_MAPI_VGS_ENULL_PTR);
#ifdef SUPPORT_RGN_OVERLAYEX
    rgn_attr.type = OT_RGN_OVERLAYEX;
#else
    rgn_attr.type = OT_RGN_OVERLAY; /* cv610 not support overlayex */
#endif
    rgn_attr.attr.overlayex.pixel_format = OT_PIXEL_FORMAT_ARGB_1555;
    rgn_attr.attr.overlayex.bg_color = vgs_rgn_attr->bg_color;
    rgn_attr.attr.overlayex.size.width = vgs_rgn_attr->size.width;
    rgn_attr.attr.overlayex.size.height = vgs_rgn_attr->size.height;
    rgn_attr.attr.overlayex.canvas_num = 1;  /* Number of region buffers */
    td_s32 ret = ss_mpi_rgn_create(rgn_hdl, &rgn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_rgn_create", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vgs_destroy_rgn(td_handle rgn_hdl)
{
    td_s32 ret = ss_mpi_rgn_destroy(rgn_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_rgn_destroy", ret);

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_vgs_update_text_bitmap(ot_vgs_osd *osd_arg, const hi_mapi_vgs_add_osd *vgs_add_osd)
{
    ot_rgn_attr rgn_attr;
    ot_rgn_canvas_info canvas_info;
    mapi_comm_text_bitmap text;

    td_u32 str_len = strnlen(vgs_add_osd->str_content.str, HI_MAPI_MAX_STR_LEN);

    td_s32 ret = ss_mpi_rgn_get_attr(vgs_add_osd->rgn_hdl + HI_MAPI_OSD_MAX_CNT, &rgn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_rgn_get_attr", ret);
    text.rgn_size.width = rgn_attr.attr.overlayex.size.width;
    text.rgn_size.height = rgn_attr.attr.overlayex.size.height;

    if ((rgn_attr.attr.overlayex.size.width < (vgs_add_osd->str_content.font_size.width * str_len)) ||
        (rgn_attr.attr.overlayex.size.height < vgs_add_osd->str_content.font_size.height)) {
        ret = mapi_adapt_vgs_destroy_rgn(vgs_add_osd->rgn_hdl + HI_MAPI_OSD_MAX_CNT);
        CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_destroy_rgn", ret);

        hi_mapi_vgs_rgn_attr vgs_rgn_attr;
        vgs_rgn_attr.bg_color = vgs_add_osd->str_content.bg_color;
        CHECK_MAPI_UINT_PRODUCT_OVERFLOW_RET(HI_MAPI_MOD_VGS, vgs_add_osd->str_content.font_size.width, str_len);
        vgs_rgn_attr.size.width = vgs_add_osd->str_content.font_size.width * str_len;
        vgs_rgn_attr.size.height = vgs_add_osd->str_content.font_size.height;
        ret = mapi_adapt_vgs_create_rgn(vgs_add_osd->rgn_hdl + HI_MAPI_OSD_MAX_CNT, &vgs_rgn_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_create_rgn", ret);
        text.rgn_size.width = vgs_rgn_attr.size.width;
        text.rgn_size.height = vgs_rgn_attr.size.height;

        ret = ss_mpi_rgn_get_attr(vgs_add_osd->rgn_hdl + HI_MAPI_OSD_MAX_CNT, &rgn_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_rgn_get_attr", ret);
    }

    ret = ss_mpi_rgn_get_canvas_info(vgs_add_osd->rgn_hdl + HI_MAPI_OSD_MAX_CNT, &canvas_info);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_rgn_get_canvas_info", ret);

    text.bitmap_data = (td_u16 *)(uintptr_t)canvas_info.virt_addr;
    text.stride = canvas_info.stride;
    text.font_size.width = vgs_add_osd->str_content.font_size.width;
    text.font_size.height = vgs_add_osd->str_content.font_size.height;
    text.bg_color = vgs_add_osd->str_content.bg_color;
    text.font_color = vgs_add_osd->color;
    ret = memcpy_s(text.str, sizeof(text.str), vgs_add_osd->str_content.str, sizeof(vgs_add_osd->str_content.str));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memcpy_s", ret);

    ret = mapi_comm_config_text_bitmap(&text, TD_FALSE);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_comm_config_text_bitmap", ret);

    ret = ss_mpi_rgn_update_canvas(vgs_add_osd->rgn_hdl + HI_MAPI_OSD_MAX_CNT);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_rgn_update_canvas", ret);

    osd_arg->rect.width = rgn_attr.attr.overlayex.size.width;
    osd_arg->rect.height = rgn_attr.attr.overlayex.size.height;
    osd_arg->bg_color = rgn_attr.attr.overlayex.bg_color;
    osd_arg->pixel_format = rgn_attr.attr.overlayex.pixel_format;
    osd_arg->phys_addr = canvas_info.phys_addr;
    osd_arg->stride = canvas_info.stride;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vgs_add_osd_task(td_handle vgs_hdl, const hi_mapi_vgs_osd_task_attr *osd_task_attr)
{
    ot_vgs_osd osd_arg[HI_MAPI_VGS_TASK_MAX_CNT];
    td_u32 i;
    td_s32 ret;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, osd_task_attr, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, osd_task_attr->vgs_add_osd, HI_MAPI_VGS_ENULL_PTR);

    for (i = 0; i < osd_task_attr->num; i++) {
        ret = mapi_adapt_vgs_update_text_bitmap(&osd_arg[i], &osd_task_attr->vgs_add_osd[i]);
        CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_update_text_bitmap", ret);

        osd_arg[i].rect.x = osd_task_attr->vgs_add_osd[i].start_point.x;
        osd_arg[i].rect.y = osd_task_attr->vgs_add_osd[i].start_point.y;
        osd_arg[i].bg_alpha = osd_task_attr->vgs_add_osd[i].bg_alpha;
        osd_arg[i].fg_alpha = osd_task_attr->vgs_add_osd[i].fg_alpha;
        osd_arg[i].osd_inverted_color = OT_VGS_OSD_INVERTED_COLOR_NONE;
    }

    ot_vgs_task_attr vgs_task;
    mapi_adapt_comm_frame_info_to_mpi(&osd_task_attr->vgs_task_attr.frame_data_in, &vgs_task.img_in);
    vgs_task.img_in.mod_id = OT_ID_VPSS;

    mapi_adapt_comm_frame_info_to_mpi(&osd_task_attr->vgs_task_attr.frame_data_out, &vgs_task.img_out);
    vgs_task.img_out.mod_id = OT_ID_VGS;

    ret = ss_mpi_vgs_add_osd_task(vgs_hdl, &vgs_task, osd_arg, osd_task_attr->num);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "ss_mpi_vgs_add_osd_task", ret);

    return TD_SUCCESS;
}


td_s32 mapi_adapt_vgs_end_job(td_handle vgs_hdl)
{
    return ss_mpi_vgs_end_job(vgs_hdl);
}

td_s32 mapi_adapt_vgs_cancel_job(td_handle vgs_hdl)
{
    return ss_mpi_vgs_cancel_job(vgs_hdl);
}


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
