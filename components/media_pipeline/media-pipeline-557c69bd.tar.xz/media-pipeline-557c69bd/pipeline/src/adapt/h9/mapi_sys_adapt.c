/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_sys_adapt.h"
#include "mapi_comm_adapt.h"
#include <unistd.h>
#include "mapi_comm_inner.h"
#include "ot_common_vb.h"
#include "ot_common_video.h"
#include "ot_buffer.h"
#include "ss_mpi_sys.h"
#include "ss_mpi_sys_bind.h"
#include "ss_mpi_vb.h"
#include "ss_mpi_sys_mem.h"
#include "securec.h"
#include "ss_vqe_register.h"
#include "hi_mapi_audio_adapt_define.h"
#include "ss_mpi_audio.h"

#ifdef SUPPORT_PHOTO_POST_PROCESS
#include "ss_mpi_dsp.h"
#endif

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 mapi_adapt_sys_register_vqe_module(const hi_mapi_audio_vqe_attr *audio_vqe_attr)
{
    ot_audio_vqe_register vqe_reg_cfg = {0};
    CHECK_MAPI_SYS_NULL_PTR_RET("audio_vqe_attr", audio_vqe_attr);

    /* Resample */
    vqe_reg_cfg.resample_mod_cfg.handle = ss_vqe_resample_get_handle();

    /* RecordVQE */
#ifdef SUPPORT_RECORDVQE
    vqe_reg_cfg.record_mod_cfg.handle = ss_vqe_record_get_handle();
#endif

    /* TalkVQE */
#ifdef SUPPORT_TALKVQE
    if ((audio_vqe_attr->talk_vqe_attr.open_mask & HI_MAPI_AI_TALKVQE_MASK_HPF) ||
        (audio_vqe_attr->ao_vqe_attr.open_mask & HI_MAPI_AO_VQE_MASK_HPF)) {
        vqe_reg_cfg.hpf_mod_cfg.handle = ss_vqe_hpf_get_handle();
    }

    if (audio_vqe_attr->talk_vqe_attr.open_mask & HI_MAPI_AI_TALKVQE_MASK_AEC) {
        vqe_reg_cfg.aec_mod_cfg.handle = ss_vqe_aec_get_handle();
    }

    if ((audio_vqe_attr->talk_vqe_attr.open_mask & HI_MAPI_AI_TALKVQE_MASK_AGC) ||
        (audio_vqe_attr->ao_vqe_attr.open_mask & HI_MAPI_AO_VQE_MASK_AGC)) {
        vqe_reg_cfg.agc_mod_cfg.handle = ss_vqe_agc_get_handle();
    }

    if ((audio_vqe_attr->talk_vqe_attr.open_mask & HI_MAPI_AI_TALKVQE_MASK_ANR) ||
        (audio_vqe_attr->ao_vqe_attr.open_mask & HI_MAPI_AO_VQE_MASK_ANR)) {
        vqe_reg_cfg.anr_mod_cfg.handle = ss_vqe_anr_get_handle();
    }

    if ((audio_vqe_attr->talk_vqe_attr.open_mask & HI_MAPI_AI_TALKVQE_MASK_EQ) ||
        (audio_vqe_attr->ao_vqe_attr.open_mask & HI_MAPI_AO_VQE_MASK_EQ)) {
        vqe_reg_cfg.eq_mod_cfg.handle = ss_vqe_eq_get_handle();
    }
#endif

    td_s32 ret = ss_mpi_audio_register_vqe_mod(&vqe_reg_cfg);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "register vqe module fail with s32Ret = %d!\n", ret);
        return ret;
    }
    return TD_SUCCESS;
}

td_s32 mapi_adapt_sys_init_media(const hi_mapi_sys_media_config *media_config, td_u32 supplement_config)
{
    ot_mpp_sys_cfg sys_cfg;
    ot_vb_supplement_cfg vb_supplement_conf = {0};
    ot_vb_cfg vb_cfg = {0};

    CHECK_MAPI_SYS_NULL_PTR_RET("media_config", media_config);

    (td_void)ss_mpi_sys_exit();
    (td_void)ss_mpi_vb_exit();

    td_s32 ret = memcpy_s(&vb_cfg, sizeof(vb_cfg), &media_config->vb_config, sizeof(media_config->vb_config));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_SYS, "memcpy_s", ret);

    ret = ss_mpi_vb_set_cfg(&vb_cfg);
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "ss_mpi_vb_set_cfg", ret);

    vb_supplement_conf.supplement_cfg = supplement_config;
    ret = ss_mpi_vb_set_supplement_cfg(&vb_supplement_conf);
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "ss_mpi_vb_set_supplement_cfg", ret);

    sys_cfg.align = OT_DEFAULT_ALIGN;
    ret = ss_mpi_sys_set_cfg(&sys_cfg);
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "ss_mpi_sys_set_cfg", ret);

    ret = ss_mpi_vb_init();
    CHECK_MAPI_RET(HI_MAPI_MOD_SYS, "ss_mpi_vb_init", ret);

    ret = ss_mpi_sys_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_sys_init failed:%x \n", ret);
        (td_void)ss_mpi_vb_exit();
        return ret;
    }

#ifdef CFG_3DNR_POS_VPSS
    ret = ss_mpi_sys_set_3dnr_pos(OT_3DNR_POS_VPSS);
#else
    ret = ss_mpi_sys_set_3dnr_pos(OT_3DNR_POS_VI);
#endif
    if (ret != TD_SUCCESS && ret != OT_ERR_SYS_NOT_SUPPORT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_sys_set_3dnr_pos failed:%x \n", ret);
        (td_void)ss_mpi_sys_exit();
        (td_void)ss_mpi_vb_exit();
        return ret;
    }

    ot_vi_vpss_mode vi_vpss_mode;
    for (td_u32 i = 0; i < HI_MAPI_VI_VPSS_MAX_MODE_NUM; i++) {
        vi_vpss_mode.mode[i] = media_config->vi_vpss_mode.mode[i];
    }
    ret = ss_mpi_sys_set_vi_vpss_mode(&vi_vpss_mode);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_sys_set_vi_vpss_mode failed:%x \n", ret);
        (td_void)ss_mpi_sys_exit();
        (td_void)ss_mpi_vb_exit();
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_sys_deinit_media(td_void)
{
    td_s32 sys_exit_ret = ss_mpi_sys_exit();
    if (sys_exit_ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_sys_exit failed:%#x.\n", sys_exit_ret);
    }

    /* vb exit need sys exit */
    td_s32 vb_exit_ret;
    for (td_u32 i = 0; i < MAPI_SYS_VB_EXIT_MAX_CNT; i++) {
        vb_exit_ret = ss_mpi_vb_exit();
        if (vb_exit_ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_vb_exit failed:%#x.\n", vb_exit_ret);
            usleep(MAPI_SYS_VB_EXIT_USLEEP_TIME);
            continue;
        }

        break;
    }

    if ((sys_exit_ret != TD_SUCCESS) || (vb_exit_ret != TD_SUCCESS)) {
        return HI_MAPI_SYS_EBUSY;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_sys_alloc_mmz_buffer(td_u64 *phy_addr, td_void **virt_addr, td_u32 buf_len, const td_char *buf_name,
    td_bool is_cache)
{
    td_s32 ret;
    td_phys_addr_t phy_buffer;
    td_u8 *vir_buffer = NULL;

    CHECK_MAPI_SYS_NULL_PTR_RET("buf_name", buf_name);
    CHECK_MAPI_SYS_NULL_PTR_RET("phy_addr", phy_addr);
    CHECK_MAPI_SYS_NULL_PTR_RET("virt_addr", virt_addr);

    if (is_cache) {
        ret = ss_mpi_sys_mmz_alloc_cached(&phy_buffer, (td_void **)&vir_buffer, buf_name, "anonymous", buf_len);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_sys_mmz_alloc_cached fail,ret:%x\n", ret);
            return ret;
        }
    } else {
        ret = ss_mpi_sys_mmz_alloc(&phy_buffer, (td_void **)&vir_buffer, buf_name, "anonymous", buf_len);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_sys_mmz_alloc fail,ret:%x\n", ret);
            return ret;
        }
    }

    *phy_addr = (td_u64)phy_buffer;
    *virt_addr = vir_buffer;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_sys_free_mmz_buffer(td_u64 phy_addr, td_void *virt_addr)
{
    td_s32 ret = ss_mpi_sys_mmz_free(phy_addr, virt_addr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_sys_mmz_free fail\n");
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_sys_flush_cache(td_u64 phy_addr, td_void *virt_addr, td_u32 buf_len)
{
    td_s32 ret = ss_mpi_sys_flush_cache(phy_addr, virt_addr, buf_len);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_sys_flush_cache fail\n");
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_sys_get_video_block(td_handle *pool_hdl, td_u64 *phy_addr, td_u64 blk_size,
    const td_char *mmz_name)
{
    CHECK_MAPI_SYS_NULL_PTR_RET("pool_hdl", pool_hdl);
    CHECK_MAPI_SYS_NULL_PTR_RET("phy_addr", phy_addr);
    ot_vb_pool pool_id = *pool_hdl;

    ot_vb_blk vb_blk = ss_mpi_vb_get_blk(pool_id, blk_size, mmz_name);
    if (vb_blk == OT_VB_INVALID_HANDLE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_vb_get_blk failed! size:%lld\n", blk_size);
        return HI_MAPI_SYS_ENOMEM;
    }

    td_u64 get_phy_addr = ss_mpi_vb_handle_to_phys_addr(vb_blk);
    if (get_phy_addr == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_vb_handle_to_phys_addr failed!\n");
        (td_void)ss_mpi_vb_release_blk(vb_blk);
        return HI_MAPI_SYS_ENOMEM;
    }

    pool_id = ss_mpi_vb_handle_to_pool_id(vb_blk);
    if (pool_id == OT_VB_INVALID_HANDLE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_vb_handle_to_pool_id failed!\n");
        (td_void)ss_mpi_vb_release_blk(vb_blk);
        return HI_MAPI_SYS_ENOMEM;
    }

    *phy_addr = get_phy_addr;
    *pool_hdl = pool_id;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_sys_release_video_block(td_u64 phy_addr)
{
    ot_vb_blk vb_blk = ss_mpi_vb_phys_addr_to_handle(phy_addr);
    if (vb_blk == OT_VB_INVALID_HANDLE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_vb_phys_addr_to_handle fail.\n");
        return HI_MAPI_SYS_EILLEGAL_PARAM;
    }

    td_s32 ret = ss_mpi_vb_release_blk(vb_blk);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "ss_mpi_vb_release_blk fail.\n");
        return ret;
    }

    return TD_SUCCESS;
}

typedef struct {
    hi_mapi_module_id mapi_id;
    ot_mod_id         sdk_id;
} mapi_adapt_sys_mod_map;

static const mapi_adapt_sys_mod_map g_mapi_adapt_sys_mod_map[] = {
    { HI_MAPI_MOD_VCAP,  OT_ID_VI   },
    { HI_MAPI_MOD_VPSS, OT_ID_VPSS },
    { HI_MAPI_MOD_VENC,  OT_ID_VENC },
    { HI_MAPI_MOD_VDEC,  OT_ID_VDEC },
    { HI_MAPI_MOD_DISP,  OT_ID_VO   },
    { HI_MAPI_MOD_ACAP,  OT_ID_AI   },
    { HI_MAPI_MOD_AENC,  OT_ID_AENC },
    { HI_MAPI_MOD_ADEC,  OT_ID_ADEC },
    { HI_MAPI_MOD_AO,    OT_ID_AO   },
};

static td_s32 mapi_adapt_sys_translate_chn(const hi_mapi_mpp_chn *chn, ot_mpp_chn *sdk_chn)
{
    td_u32 i;
    for (i = 0; i < sizeof(g_mapi_adapt_sys_mod_map) / sizeof(g_mapi_adapt_sys_mod_map[0]); i++) {
        if (g_mapi_adapt_sys_mod_map[i].mapi_id == chn->mod_id) {
            sdk_chn->mod_id = g_mapi_adapt_sys_mod_map[i].sdk_id;
            sdk_chn->dev_id = chn->dev_id;
            sdk_chn->chn_id = chn->chn_id;
            return TD_SUCCESS;
        }
    }
    MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "unsupported mapi mod_id %d for bind/unbind\n", chn->mod_id);
    return HI_MAPI_SYS_EILLEGAL_PARAM;
}

td_s32 mapi_adapt_sys_bind(const hi_mapi_mpp_chn *src_chn, const hi_mapi_mpp_chn *dst_chn)
{
    ot_mpp_chn sdk_src;
    ot_mpp_chn sdk_dst;
    td_s32 ret;

    CHECK_MAPI_SYS_NULL_PTR_RET("src_chn", src_chn);
    CHECK_MAPI_SYS_NULL_PTR_RET("dst_chn", dst_chn);

    ret = mapi_adapt_sys_translate_chn(src_chn, &sdk_src);
    if (ret != TD_SUCCESS) {
        return ret;
    }
    ret = mapi_adapt_sys_translate_chn(dst_chn, &sdk_dst);
    if (ret != TD_SUCCESS) {
        return ret;
    }

    ret = ss_mpi_sys_bind(&sdk_src, &sdk_dst);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS,
            "ss_mpi_sys_bind fail, src(mod=%d,dev=%d,chn=%d) dst(mod=%d,dev=%d,chn=%d), ret:%#x\n",
            src_chn->mod_id, src_chn->dev_id, src_chn->chn_id,
            dst_chn->mod_id, dst_chn->dev_id, dst_chn->chn_id, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_sys_unbind(const hi_mapi_mpp_chn *src_chn, const hi_mapi_mpp_chn *dst_chn)
{
    ot_mpp_chn sdk_src;
    ot_mpp_chn sdk_dst;
    td_s32 ret;

    CHECK_MAPI_SYS_NULL_PTR_RET("src_chn", src_chn);
    CHECK_MAPI_SYS_NULL_PTR_RET("dst_chn", dst_chn);

    ret = mapi_adapt_sys_translate_chn(src_chn, &sdk_src);
    if (ret != TD_SUCCESS) {
        return ret;
    }
    ret = mapi_adapt_sys_translate_chn(dst_chn, &sdk_dst);
    if (ret != TD_SUCCESS) {
        return ret;
    }

    ret = ss_mpi_sys_unbind(&sdk_src, &sdk_dst);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS,
            "ss_mpi_sys_unbind fail, src(mod=%d,dev=%d,chn=%d) dst(mod=%d,dev=%d,chn=%d), ret:%#x\n",
            src_chn->mod_id, src_chn->dev_id, src_chn->chn_id,
            dst_chn->mod_id, dst_chn->dev_id, dst_chn->chn_id, ret);
        return ret;
    }

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
