/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_codec.h"
#include <string.h>
#include <stdio.h>

#define AUDIO_COMP_CODEC_MAX_PROVIDERS 8
#define AUDIO_COMP_CODEC_NAME_LEN      32

typedef struct {
    char name[AUDIO_COMP_CODEC_NAME_LEN];
    const audio_comp_codec_ops_t *ops;
} audio_comp_codec_entry_t;

static audio_comp_codec_entry_t       g_providers[AUDIO_COMP_CODEC_MAX_PROVIDERS];
static int                            g_provider_count = 0;
static const audio_comp_codec_ops_t  *g_active_ops = NULL;

int audio_comp_codec_register(const char *name, const audio_comp_codec_ops_t *ops)
{
    if (name == NULL || ops == NULL) {
        return -1;
    }
    if (g_provider_count >= AUDIO_COMP_CODEC_MAX_PROVIDERS) {
        fprintf(stderr, "[audio_comp_codec] provider table full (cap=%d)\n",
                AUDIO_COMP_CODEC_MAX_PROVIDERS);
        return -1;
    }
    for (int i = 0; i < g_provider_count; i++) {
        if (strcmp(g_providers[i].name, name) == 0) {
            fprintf(stderr, "[audio_comp_codec] duplicate provider name: %s\n", name);
            return -1;
        }
    }

    strncpy(g_providers[g_provider_count].name, name, AUDIO_COMP_CODEC_NAME_LEN - 1);
    g_providers[g_provider_count].name[AUDIO_COMP_CODEC_NAME_LEN - 1] = '\0';
    g_providers[g_provider_count].ops = ops;
    g_provider_count++;

    if (g_active_ops == NULL) {
        g_active_ops = ops;
    }
    return 0;
}

const audio_comp_codec_ops_t *audio_comp_codec_get_ops(const char *name)
{
    if (name == NULL) {
        return NULL;
    }
    for (int i = 0; i < g_provider_count; i++) {
        if (strcmp(g_providers[i].name, name) == 0) {
            return g_providers[i].ops;
        }
    }
    return NULL;
}

int audio_comp_codec_set_active(const char *name)
{
    const audio_comp_codec_ops_t *ops = audio_comp_codec_get_ops(name);
    if (ops == NULL) {
        return -1;
    }
    g_active_ops = ops;
    return 0;
}

const audio_comp_codec_ops_t *audio_comp_codec_get_active(void)
{
    return g_active_ops;
}

const audio_comp_codec_ops_t *audio_comp_codec_find_by_format(hi_mapi_audio_format format)
{
    for (int i = 0; i < g_provider_count; i++) {
        if (g_providers[i].ops != NULL && g_providers[i].ops->format == format) {
            return g_providers[i].ops;
        }
    }
    return NULL;
}
