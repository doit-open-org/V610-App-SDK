/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_afe.h"
#include "mapi_comm_inner.h"
#include "mapi_acap_inner.h"
#include "ss_mpi_audio.h"
#include "securec.h"
#include <stdio.h>
#include "hi_log.h"

static td_bool g_hisi_afe_inited = TD_FALSE;
static td_handle g_hisi_ai_dev = OT_INVALID_HANDLE;
static td_handle g_hisi_ai_chn = OT_INVALID_HANDLE;
static audio_comp_afe_vqe_mode_t g_hisi_vqe_mode = AUDIO_COMP_AFE_VQE_NONE;

#ifdef SUPPORT_RECORDVQE
static td_void hisi_afe_get_record_vqe_config(const audio_comp_afe_attr_t *attr,
    ot_ai_record_vqe_cfg *vqe_attr)
{
    switch (attr->sample_rate) {
        case HI_MAPI_AUDIO_SAMPLE_RATE_48000:
            vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_48000;
            break;
        case HI_MAPI_AUDIO_SAMPLE_RATE_16000:
            vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_16000;
            break;
        default:
            vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_48000;
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "VQE sample_rate only support 16K or 48K, default use 48K.\n");
            break;
    }

    vqe_attr->frame_sample = attr->samples_per_frame;
    vqe_attr->work_state = OT_VQE_WORK_STATE_COMMON;
    vqe_attr->in_chn_num = attr->channels;
    vqe_attr->out_chn_num = attr->channels;
    vqe_attr->record_type = OT_VQE_RECORD_NORMAL;
    vqe_attr->drc_cfg.usr_mode = TD_FALSE;
    vqe_attr->rnr_cfg.usr_mode = TD_FALSE;
    vqe_attr->hdr_cfg.usr_mode = TD_FALSE;
    vqe_attr->hpf_cfg.usr_mode = TD_TRUE;
    vqe_attr->hpf_cfg.hpf_freq = OT_AUDIO_HPF_FREQ_80;
    vqe_attr->agc_cfg.usr_mode = TD_FALSE;
    vqe_attr->eq_cfg.gain_db[0] = -10;
    vqe_attr->eq_cfg.gain_db[1] = -3;
    vqe_attr->eq_cfg.gain_db[2] = -2;
    vqe_attr->eq_cfg.gain_db[3] = -2;
    vqe_attr->eq_cfg.gain_db[4] = -1;
    vqe_attr->eq_cfg.gain_db[5] = -1;
    vqe_attr->eq_cfg.gain_db[6] = -2;
    vqe_attr->eq_cfg.gain_db[7] = -5;
    vqe_attr->eq_cfg.gain_db[8] = -6;
    vqe_attr->eq_cfg.gain_db[9] = -8;
    vqe_attr->open_mask = OT_AI_RECORDVQE_MASK_DRC | OT_AI_RECORDVQE_MASK_HDR | OT_AI_RECORDVQE_MASK_HPF |
                          OT_AI_RECORDVQE_MASK_RNR | OT_AI_RECORDVQE_MASK_AGC;
}
#endif

#ifdef SUPPORT_TALKVQE
static td_void hisi_afe_get_talk_vqe_config(const audio_comp_afe_attr_t *attr,
    ot_ai_talk_vqe_cfg *vqe_attr)
{
    if (attr->sample_rate == HI_MAPI_AUDIO_SAMPLE_RATE_8000) {
        vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_8000;
    } else {
        vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_16000;
    }
    vqe_attr->frame_sample = attr->samples_per_frame;
    vqe_attr->work_state = OT_VQE_WORK_STATE_COMMON;
    vqe_attr->open_mask = attr->talk_open_mask;
    vqe_attr->hpf_cfg.usr_mode = TD_TRUE;
    vqe_attr->hpf_cfg.hpf_freq = OT_AUDIO_HPF_FREQ_120;
    vqe_attr->anr_cfg.usr_mode = TD_FALSE;
    vqe_attr->anr_cfg.music_probe_switch = 1;
    vqe_attr->agc_cfg.usr_mode = TD_FALSE;
}
#endif

#ifdef SUPPORT_TALKVQE

static td_void hisi_afe_get_talk_vqe_v2_config(const audio_comp_afe_attr_t *attr,
    ot_ai_talk_vqe_v2_cfg *vqe_attr)
{
    if (attr->sample_rate == HI_MAPI_AUDIO_SAMPLE_RATE_8000) {
        vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_8000;
    } else {
        vqe_attr->work_sample_rate = OT_AUDIO_SAMPLE_RATE_16000;
    }
    vqe_attr->frame_sample = attr->samples_per_frame;
    vqe_attr->work_state = OT_VQE_WORK_STATE_COMMON;
    vqe_attr->in_chn_num = attr->channels;
    vqe_attr->out_chn_num = attr->channels;
    vqe_attr->pnr_cfg.usr_mode = TD_FALSE;

    vqe_attr->agc_cfg.usr_mode          = TD_TRUE;
    vqe_attr->agc_cfg.target_level      = -16;
    vqe_attr->agc_cfg.max_gain          = 96;
    vqe_attr->agc_cfg.min_gain          = -60;
    vqe_attr->agc_cfg.up_gradient_ratio = 9;
    vqe_attr->agc_cfg.down_gradient_ratio = 3;
    vqe_attr->agc_cfg.decay             = -260;
    vqe_attr->agc_cfg.vad_threshold     = 100;
    vqe_attr->agc_cfg.vad_ctrl          = 1;

    vqe_attr->nr_cfg.usr_mode                  = TD_TRUE;
    vqe_attr->nr_cfg.min_gain_limit            = 3276;
    vqe_attr->nr_cfg.snr_prior_limit           = 327;
    vqe_attr->nr_cfg.ht_threshold              = 130;
    vqe_attr->nr_cfg.hs_threshold              = 100;
    vqe_attr->nr_cfg.prior_snr                 = 10;
    vqe_attr->nr_cfg.snr_smooth_factor         = 8000;
    vqe_attr->nr_cfg.speech_prob_smooth_factor = 9394;
    vqe_attr->nr_cfg.noise_pwr_smooth_factor   = 7594;
    vqe_attr->nr_cfg.low_freq_suppress_enable  = 1;
    vqe_attr->nr_cfg.low_freq_gain_suppress    = 0;
    vqe_attr->nr_cfg.env_mode                  = 1;
    vqe_attr->nr_cfg.cep_alpha                 = 100;
    vqe_attr->nr_cfg.cep_threshold             = 10;
    vqe_attr->nr_cfg.cep_amp                   = 200;
    vqe_attr->nr_cfg.gain_sm_mode               = 1;
    vqe_attr->nr_cfg.gain_sm_alpha1             = 30;
    vqe_attr->nr_cfg.gain_sm_alpha2             = 70;
    vqe_attr->nr_cfg.gain_sm_alpha3             = 80;

    vqe_attr->aec_cfg.usr_mode          = TD_TRUE;
    vqe_attr->aec_cfg.pure_delay        = 0;
    vqe_attr->aec_cfg.switch_nlp        = 1;
    vqe_attr->aec_cfg.band1             = 100;
    vqe_attr->aec_cfg.band2             = 1500;
    vqe_attr->aec_cfg.band3             = 3000;
    vqe_attr->aec_cfg.band4             = 4500;
    vqe_attr->aec_cfg.gain_lower_limit1 = 0;
    vqe_attr->aec_cfg.gain_lower_limit2 = 0;
    vqe_attr->aec_cfg.gain_lower_limit3 = 0;
    vqe_attr->aec_cfg.gain_lower_limit4 = 0;
    vqe_attr->aec_cfg.gain_lower_limit5 = 0;
    vqe_attr->aec_cfg.ols_on            = 1;
    vqe_attr->aec_cfg.speaker_nl_on     = 1;
    vqe_attr->aec_cfg.block_num         = 6;
    vqe_attr->aec_cfg.echo_boost1       = 1;
    vqe_attr->aec_cfg.echo_boost2       = 4;
    vqe_attr->aec_cfg.echo_boost3       = 12;
    vqe_attr->aec_cfg.echo_boost4       = 4;
    vqe_attr->aec_cfg.echo_boost5       = 1;

    vqe_attr->fmp_cfg.usr_mode          = TD_TRUE;
    vqe_attr->fmp_cfg.comfort_flag      = 1;
    vqe_attr->fmp_cfg.comfort_intensity = 1;

    vqe_attr->open_mask = HI_MAPI_AI_TALKVQEV2_MASK_AEC |
                          HI_MAPI_AI_TALKVQEV2_MASK_AGC |
                          HI_MAPI_AI_TALKVQEV2_MASK_NR |
                          HI_MAPI_AI_TALKVQEV2_MASK_WNR |
                          HI_MAPI_AI_TALKVQEV2_MASK_FMP;
}
#endif

static int hisi_afe_init(const audio_comp_afe_attr_t *attr)
{
    if (attr == NULL) {
        return -1;
    }

    td_s32 ret;
    if (attr->vqe_mode == AUDIO_COMP_AFE_VQE_RECORD) {
#ifdef SUPPORT_RECORDVQE
        ot_ai_record_vqe_cfg vqe_attr;
        ret = memset_s(&vqe_attr, sizeof(vqe_attr), 0, sizeof(vqe_attr));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);
        hisi_afe_get_record_vqe_config(attr, &vqe_attr);
        ret = ss_mpi_ai_set_record_vqe_attr(attr->ai_dev_id, attr->ai_chn_id, &vqe_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_record_vqe_attr", ret);
#else
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "SUPPORT_RECORDVQE not enabled\n");
        return -1;
#endif
    } else if (attr->vqe_mode == AUDIO_COMP_AFE_VQE_TALK) {
#ifdef SUPPORT_TALKVQE
        ot_ai_talk_vqe_cfg vqe_attr;
        ret = memset_s(&vqe_attr, sizeof(vqe_attr), 0, sizeof(vqe_attr));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);
        hisi_afe_get_talk_vqe_config(attr, &vqe_attr);
        ret = ss_mpi_ai_set_talk_vqe_attr(attr->ai_dev_id, attr->ai_chn_id,
            attr->ref_ao_dev_id, attr->ref_ao_chn_id, &vqe_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_talk_vqe_attr", ret);
#else
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "SUPPORT_TALKVQE not enabled\n");
        return -1;
#endif
    } else if (attr->vqe_mode == AUDIO_COMP_AFE_VQE_TALKV2) {
#ifdef SUPPORT_TALKVQE
        ot_ai_talk_vqe_v2_cfg vqe_attr;
        ret = memset_s(&vqe_attr, sizeof(vqe_attr), 0, sizeof(vqe_attr));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);
        hisi_afe_get_talk_vqe_v2_config(attr, &vqe_attr);
        ret = ss_mpi_ai_set_talk_vqe_v2_attr(attr->ai_dev_id, attr->ai_chn_id,
            attr->ref_ao_dev_id, attr->ref_ao_chn_id, &vqe_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_set_talk_vqe_v2_attr", ret);
#else
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "SUPPORT_TALKVQE not enabled\n");
        return -1;
#endif
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "[hisi_afe] invalid vqe_mode=%d\n", attr->vqe_mode);
        return -1;
    }

    ret = ss_mpi_ai_enable_vqe(attr->ai_dev_id, attr->ai_chn_id);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "ss_mpi_ai_enable_vqe", ret);
    g_hisi_ai_dev = attr->ai_dev_id;
    g_hisi_ai_chn = attr->ai_chn_id;
    g_hisi_vqe_mode = attr->vqe_mode;
    g_hisi_afe_inited = TD_TRUE;
    HI_LOGI("hisi_afe", "ss_mpi_ai_enable_vqe success: dev=%d chn=%d mode=%d sr=%u channels=%u",
        (int)attr->ai_dev_id, (int)attr->ai_chn_id, (int)attr->vqe_mode,
        attr->sample_rate, attr->channels);
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ACAP, "[hisi_afe] init: vqe_mode=%d sample_rate=%u channels=%u\n",
        (int)attr->vqe_mode, attr->sample_rate, attr->channels);
    return TD_SUCCESS;
}

static int hisi_afe_process(const audio_comp_pcm_view_in_t *in, audio_comp_pcm_view_out_t *out)
{
    if (in == NULL || out == NULL) {
        return -1;
    }
    /* Pass-through: SDK VQE already processed the PCM upstream in the acap
     * pipeline.  Output view shares the input buffer (zero-copy). */
    out->data        = in->data;
    out->samples     = in->samples;
    out->channels    = in->channels;
    out->sample_rate = in->sample_rate;
    return 0;
}

static void hisi_afe_deinit(void)
{
    if (g_hisi_afe_inited) {
        (td_void)ss_mpi_ai_disable_vqe(g_hisi_ai_dev, g_hisi_ai_chn);
        g_hisi_afe_inited = TD_FALSE;
        g_hisi_ai_dev = OT_INVALID_HANDLE;
        g_hisi_ai_chn = OT_INVALID_HANDLE;
        g_hisi_vqe_mode = AUDIO_COMP_AFE_VQE_NONE;
    }
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ACAP, "[hisi_afe] deinit\n");
}

static const audio_comp_afe_ops_t g_hisi_afe_ops = {
    .init             = hisi_afe_init,
    .process          = hisi_afe_process,
    .deinit           = hisi_afe_deinit,
    .needs_raw_frame  = 0,
    .software_process = 0,
};

void hisi_afe_provider_register(void)
{
    (void)audio_comp_afe_register("hisi", &g_hisi_afe_ops);
}

static void __attribute__((constructor)) hisi_afe_auto_register(void)
{
    hisi_afe_provider_register();
}
