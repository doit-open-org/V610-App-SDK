/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_vcap_adapt.h"
#include <string.h>
#include <pthread.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>

/* mapi header */
#include "mapi_comm_adapt.h"
#include "ot_buffer.h"

/* mpi header */
#include "ot_mipi_rx.h"
#include "ss_mpi_vi.h"
#include "ss_mpi_isp.h"
#include "ss_mpi_ae.h"
#include "ss_mpi_awb.h"
#include "ot_sns_ctrl.h"
#include "ot_common_ae.h"
#include "ot_common_awb.h"
#include "ot_common_region.h"
#include "ot_common.h"
#include "ss_mpi_vb.h"
#include "ss_mpi_sys.h"
#include "ss_mpi_region.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static td_void mapi_vcap_load_dev_param(mapi_vcap_default_config_attr *vcap_default_cfg)
{
    td_u32 i, j;

    for (i = 0; i < HI_MAPI_VCAP_MAX_DEV_NUM; i++) {
        for (j = 0; j < OT_VI_MAX_AD_CHN_NUM; j++) {
            vcap_default_cfg->vi_dev_attr[i].ad_chn_id[j] = OT_INVALID_HANDLE;
        }

        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.hsync_hfb = 0;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.hsync_act = 1280; /* 1280: 720p width */
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.hsync_hbb = 0;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.vsync_vfb = 0;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.vsync_vact = 720; /* 720: 720p height */
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.vsync_vbb = 0;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.vsync_vbfb = 0;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.vsync_vbact = 0;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.timing_blank.vsync_vbbb = 0;
        vcap_default_cfg->vi_dev_attr[i].data_reverse = TD_FALSE;
        vcap_default_cfg->vi_dev_attr[i].scan_mode = OT_VI_SCAN_PROGRESSIVE;
        vcap_default_cfg->vi_dev_attr[i].work_mode = OT_VI_WORK_MODE_MULTIPLEX_1;

        vcap_default_cfg->vi_dev_attr[i].sync_cfg.vsync = OT_VI_VSYNC_PULSE;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.vsync_neg = OT_VI_VSYNC_NEG_LOW;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.hsync = OT_VI_HSYNC_VALID_SIG;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.hsync_neg = OT_VI_HSYNC_NEG_HIGH;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.vsync_valid = OT_VI_VSYNC_VALID_SIG;
        vcap_default_cfg->vi_dev_attr[i].sync_cfg.vsync_valid_neg = OT_VI_VSYNC_VALID_NEG_HIGH;
    }
}

static td_void mapi_vcap_load_param(mapi_vcap_default_config_attr *vcap_default_cfg)
{
    td_u32 i;

    mapi_vcap_load_dev_param(vcap_default_cfg);

    for (i = 0; i < HI_MAPI_VCAP_PIPE_MAX_CHN_NUM; i++) {
        vcap_default_cfg->vi_chn_attr[i].mirror_en = TD_FALSE;
        vcap_default_cfg->vi_chn_attr[i].flip_en = TD_FALSE;
        vcap_default_cfg->vi_chn_attr[i].dynamic_range = OT_DYNAMIC_RANGE_SDR8;
        vcap_default_cfg->vi_chn_attr[i].video_format = OT_VIDEO_FORMAT_LINEAR;
        vcap_default_cfg->vi_chn_attr[i].depth = 0;
        vcap_default_cfg->vi_chn_attr[i].pixel_format = OT_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    }
}

static td_s32 mapi_vcap_generate_isp_init_attr(const hi_mapi_vcap_isp_init_attr *vcap_init_attr,
    ot_isp_init_attr *isp_init_attr)
{
    td_s32 ret;

    ret = memset_s(isp_init_attr, sizeof(ot_isp_init_attr), 0, sizeof(ot_isp_init_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    if (HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE != OT_ISP_CCM_MATRIX_SIZE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "set OT_ISP_CCM_MATRIX_SIZE param not match Isp,please check\n");
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    isp_init_attr->is_ir_mode = vcap_init_attr->is_ir_mode;
    isp_init_attr->exp_time = vcap_init_attr->exp_time;
    isp_init_attr->a_gain = vcap_init_attr->a_gain;
    isp_init_attr->d_gain = vcap_init_attr->d_gain;
    isp_init_attr->ispd_gain = vcap_init_attr->isp_dgain;
    isp_init_attr->exposure = vcap_init_attr->exposure;
    isp_init_attr->init_iso = vcap_init_attr->init_iso;
    isp_init_attr->lines_per500ms = vcap_init_attr->lines_per500ms;
    isp_init_attr->piris_fno = vcap_init_attr->piris_fno;
    isp_init_attr->wb_r_gain = vcap_init_attr->wb_rgain;
    isp_init_attr->wb_g_gain = vcap_init_attr->wb_ggain;
    isp_init_attr->wb_b_gain = vcap_init_attr->wb_bgain;
    isp_init_attr->sample_r_gain = vcap_init_attr->sample_rgain;
    isp_init_attr->sample_b_gain = vcap_init_attr->sample_bgain;
    isp_init_attr->ae_stat_pos = vcap_init_attr->ae_stat_pos;

    ret = memcpy_s(isp_init_attr->init_ccm, sizeof(td_u16) * OT_ISP_CCM_MATRIX_SIZE,
        vcap_init_attr->ccm, sizeof(td_u16) * HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE);
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_switch_type_to_isp(hi_mapi_vcap_op_type src_type, ot_op_mode *dst_type)
{
    CHECK_MAPI_VCAP_NULL_PTR_RET(dst_type);

    switch (src_type) {
        case HI_MAPI_VCAP_OP_TYPE_AUTO:
            *dst_type = OT_OP_MODE_AUTO;
            break;
        case HI_MAPI_VCAP_OP_TYPE_MANUAL:
            *dst_type = OT_OP_MODE_MANUAL;
            break;
        case HI_MAPI_VCAP_OP_TYPE_DISABLE:
        case HI_MAPI_VCAP_OP_TYPE_BUTT:
            *dst_type = OT_OP_MODE_BUTT;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "unsupport mapi vcap operate Type.\n");
            return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_switch_type_to_mapi(ot_op_mode src_type, hi_mapi_vcap_op_type *dst_type)
{
    CHECK_MAPI_VCAP_NULL_PTR_RET(dst_type);

    switch (src_type) {
        case OT_OP_MODE_AUTO:
            *dst_type = HI_MAPI_VCAP_OP_TYPE_AUTO;
            break;
        case OT_OP_MODE_MANUAL:
            *dst_type = HI_MAPI_VCAP_OP_TYPE_MANUAL;
            break;
        case OT_OP_MODE_BUTT:
            *dst_type = HI_MAPI_VCAP_OP_TYPE_BUTT;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "unsupport mapi vcap operate Type.\n");
            return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_isp_mode_param(const hi_mapi_isp_param_mode *isp_mod_param)
{
    td_s32 ret;
    ot_isp_mod_param isp_mod_para;
    CHECK_MAPI_VCAP_NULL_PTR_RET(isp_mod_param);

    ret = memset_s(&isp_mod_para, sizeof(isp_mod_para), 0x00, sizeof(isp_mod_para));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_mod_param(&isp_mod_para);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_mod_param fail,ret:%#x!\n", ret);

    isp_mod_para.interrupt_bottom_half = isp_mod_param->int_bottom_half;

    ret = ss_mpi_isp_set_mod_param(&isp_mod_para);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_mod_param fail,ret:%#x!\n", ret);

    return TD_SUCCESS;
}

td_bool mapi_adapt_vcap_is_bt656_mode(input_mode_t input_mode)
{
    MAPI_UNUSED(input_mode);
    return TD_FALSE;
}

td_s32 mapi_adapt_vcap_get_vi_vpss_mode(td_handle vcap_pipe_hdl, hi_mapi_vi_vpss_mode *work_mode)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_vi_vpss_mode vi_vpss_mode;
    CHECK_MAPI_VCAP_NULL_PTR_RET(work_mode);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = ss_mpi_sys_get_vi_vpss_mode(&vi_vpss_mode);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_sys_get_vi_vpss_mode failed,ret:%#x!\n", vi_pipe, ret);

    switch (vi_vpss_mode.mode[vi_pipe]) {
        case OT_VI_OFFLINE_VPSS_OFFLINE:
            *work_mode = HI_MAPI_VI_OFFLINE_VPSS_OFFLINE;
            break;
        case OT_VI_OFFLINE_VPSS_ONLINE:
            *work_mode = HI_MAPI_VI_OFFLINE_VPSS_ONLINE;
            break;
        case OT_VI_ONLINE_VPSS_OFFLINE:
            *work_mode = HI_MAPI_VI_ONLINE_VPSS_OFFLINE;
            break;
        case OT_VI_ONLINE_VPSS_ONLINE:
            *work_mode = HI_MAPI_VI_ONLINE_VPSS_ONLINE;
            break;
        case OT_VI_PARALLEL_VPSS_OFFLINE:
            *work_mode = HI_MAPI_VI_PARALLEL_VPSS_OFFLINE;
            break;
        case OT_VI_PARALLEL_VPSS_PARALLEL:
            *work_mode = HI_MAPI_VI_PARALLEL_VPSS_PARALLEL;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] get unsupport vivpss workmode.\n", vcap_pipe_hdl);
            *work_mode = HI_MAPI_VI_VPSS_MODE_BUTT;
            return TD_FAILURE;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_frame_rate(td_handle vcap_pipe_hdl, td_float frame_rate)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_isp_pub_attr isp_pub_attr;

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = memset_s(&isp_pub_attr, sizeof(isp_pub_attr), 0, sizeof(isp_pub_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_pub_attr(vi_pipe, &isp_pub_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_isp_get_pub_attr fail,ret:%#x!\n", vi_pipe, ret);

    isp_pub_attr.frame_rate = frame_rate;

    ret = ss_mpi_isp_set_pub_attr(vi_pipe, &isp_pub_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_isp_set_pub_attr fail,ret:%#x!\n", vi_pipe, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_pipe_dynamic_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_pipe_attr *vcap_pipe_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    mapi_vcap_glob_attr *vcap_glob_attr = mapi_vcap_get_glob_attr();
    ot_vi_pipe_attr vi_pipe_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_pipe_attr);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ret = memset_s(&vi_pipe_attr, sizeof(vi_pipe_attr), 0, sizeof(vi_pipe_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_vi_get_pipe_attr(vi_pipe, &vi_pipe_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_vi_get_pipe_attr fail,ret:%#x!\n", vi_pipe, ret);

    vi_pipe_attr.compress_mode = vcap_glob_attr->glob_pipe_attr[vi_pipe].pipe_attr.compress_mode;
    vi_pipe_attr.frame_rate_ctrl.src_frame_rate = vcap_pipe_attr->frame_rate_ctrl.src_frame_rate;
    vi_pipe_attr.frame_rate_ctrl.dst_frame_rate = vcap_pipe_attr->frame_rate_ctrl.dst_frame_rate;

    ret = ss_mpi_vi_set_pipe_attr(vi_pipe, &vi_pipe_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_vi_set_pipe_attr fail,ret:%#x!\n", vi_pipe, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_frame_int_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_frame_interrupt_attr *frame_int_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_frame_interrupt_attr vi_frame_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(frame_int_attr);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = memset_s(&vi_frame_attr, sizeof(vi_frame_attr), 0, sizeof(vi_frame_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    vi_frame_attr.interrupt_type = frame_int_attr->int_type;
    vi_frame_attr.early_line = frame_int_attr->early_line;

    ret = ss_mpi_vi_set_pipe_frame_interrupt_attr(vi_pipe, &vi_frame_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_set_pipe_frame_interrupt_attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_isp_pub_attr(td_handle vcap_pipe_hdl, const hi_mapi_vcap_isp_pub_attr *vcap_isp_pub_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_isp_pub_attr vi_isp_pub_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_isp_pub_attr);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = memset_s(&vi_isp_pub_attr, sizeof(vi_isp_pub_attr), 0, sizeof(vi_isp_pub_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    vi_isp_pub_attr.sns_mode = (td_u8)vcap_isp_pub_attr->sns_mode;
    vi_isp_pub_attr.wdr_mode = vcap_isp_pub_attr->wdr_mode;
    vi_isp_pub_attr.frame_rate = vcap_isp_pub_attr->frame_rate;
    vi_isp_pub_attr.bayer_format = vcap_isp_pub_attr->bayer;
    vi_isp_pub_attr.wnd_rect.x = vcap_isp_pub_attr->wnd_rect.x;
    vi_isp_pub_attr.wnd_rect.y = vcap_isp_pub_attr->wnd_rect.y;
    vi_isp_pub_attr.wnd_rect.height = vcap_isp_pub_attr->wnd_rect.height;
    vi_isp_pub_attr.wnd_rect.width = vcap_isp_pub_attr->wnd_rect.width;
    vi_isp_pub_attr.sns_size.height = vcap_isp_pub_attr->sns_size.height;
    vi_isp_pub_attr.sns_size.width = vcap_isp_pub_attr->sns_size.width;

    ret = ss_mpi_isp_set_pub_attr(vi_pipe, &vi_isp_pub_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_pub_attr fail,vcap_pipe_hdl[%u]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_isp_pub_attr(td_handle vcap_pipe_hdl, hi_mapi_vcap_isp_pub_attr *vcap_isp_pub_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_isp_pub_attr vi_isp_pub_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_isp_pub_attr);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = memset_s(&vi_isp_pub_attr, sizeof(ot_isp_pub_attr), 0, sizeof(ot_isp_pub_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_pub_attr(vi_pipe, &vi_isp_pub_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_pub_attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    vcap_isp_pub_attr->sns_mode = vi_isp_pub_attr.sns_mode;
    vcap_isp_pub_attr->wdr_mode = vi_isp_pub_attr.wdr_mode;
    vcap_isp_pub_attr->frame_rate = vi_isp_pub_attr.frame_rate;
    vcap_isp_pub_attr->bayer = vi_isp_pub_attr.bayer_format;
    vcap_isp_pub_attr->wnd_rect.x = vi_isp_pub_attr.wnd_rect.x;
    vcap_isp_pub_attr->wnd_rect.y = vi_isp_pub_attr.wnd_rect.y;
    vcap_isp_pub_attr->wnd_rect.height = vi_isp_pub_attr.wnd_rect.height;
    vcap_isp_pub_attr->wnd_rect.width = vi_isp_pub_attr.wnd_rect.width;
    vcap_isp_pub_attr->sns_size.height = vi_isp_pub_attr.sns_size.height;
    vcap_isp_pub_attr->sns_size.width = vi_isp_pub_attr.sns_size.width;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_query_isp_state(td_handle vcap_pipe_hdl, mapi_vcap_isp_inner_state *isp_inner_state)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_isp_inner_state_info isp_inner_state_info;
    CHECK_MAPI_VCAP_NULL_PTR_RET(isp_inner_state);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ret = memset_s(&isp_inner_state_info, sizeof(ot_isp_inner_state_info), 0, sizeof(ot_isp_inner_state_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_query_inner_state_info(vi_pipe, &isp_inner_state_info);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_query_inner_state_info fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    isp_inner_state->wdr_switch_finish = isp_inner_state_info.wdr_switch_finish;
    isp_inner_state->res_switch_finish = isp_inner_state_info.res_switch_finish;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_isp_interval(td_handle vcap_pipe_hdl, td_u32 isp_stat_intvl)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_isp_ctrl_param isp_ctrl_param;

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ret = memset_s(&isp_ctrl_param, sizeof(ot_isp_ctrl_param), 0, sizeof(ot_isp_ctrl_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_ctrl_param(vi_pipe, &isp_ctrl_param);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_ctrl_param fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    isp_ctrl_param.stat_interval = isp_stat_intvl;

    ret = ss_mpi_isp_set_ctrl_param(vi_pipe, &isp_ctrl_param);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_ctrl_param fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_dev_static_attr(td_handle vcap_dev_hdl, const hi_mapi_vcap_attr *vcap_attr,
    const combo_dev_attr_t *combo_dev_attr)
{
    td_s32 ret;
    ot_vi_dev vi_dev;
    ot_vi_dev_attr vi_dev_attr;
    mapi_vcap_default_config_attr vcap_default_cfg;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_attr);
    CHECK_MAPI_VCAP_NULL_PTR_RET(combo_dev_attr);

    vi_dev = (ot_vi_dev)vcap_dev_hdl;

    ret = memset_s(&vcap_default_cfg, sizeof(vcap_default_cfg), 0, sizeof(vcap_default_cfg));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    mapi_vcap_load_param(&vcap_default_cfg);

    ret = memcpy_s(&vi_dev_attr, sizeof(vi_dev_attr), &vcap_default_cfg.vi_dev_attr[vi_dev], sizeof(ot_vi_dev_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    /* dev:sensor 1:1 after refactor -- use combo_dev_attr directly for img_rect */
    if (combo_dev_attr->input_mode == INPUT_MODE_MIPI) {
        vi_dev_attr.in_size.width = combo_dev_attr->img_rect.width;
        vi_dev_attr.in_size.height = combo_dev_attr->img_rect.height - mapi_vcap_get_dev_attr(vcap_dev_hdl)->ob_height;
    }
    vi_dev_attr.intf_mode = vcap_attr->vcap_dev_attr.intf_mode;
    vi_dev_attr.data_seq = vcap_attr->vcap_dev_attr.data_seq;
    if (vcap_attr->vcap_dev_attr.data_type == HI_MAPI_VCAP_DATA_TYPE_YUV) {
        vi_dev_attr.data_type = OT_VI_DATA_TYPE_YUV;
    } else {
        vi_dev_attr.data_type = OT_VI_DATA_TYPE_RAW;
    }

    /* component_mask removed from public dev_attr; fill internal defaults derived from sensor data bit-width */
    {
        hi_mapi_vcap_input_datatype dtype =
            mapi_vcap_get_glob_attr()->glob_dev_attr[vcap_dev_hdl].sensor_attr.input_dev_attr.input_data_type;
        td_u32 mask0;
        switch (dtype) {
            case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_8BIT:
                mask0 = 0xFF000000;
                break;
            case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_12BIT:
                mask0 = 0xFFF00000;
                break;
            case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_14BIT:
                mask0 = 0xFFFC0000;
                break;
            case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_16BIT:
                mask0 = 0xFFFF0000;
                break;
            case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_10BIT:
            default:
                mask0 = 0xFFC00000;
                break;
        }
        vi_dev_attr.component_mask[0] = mask0;
        vi_dev_attr.component_mask[1] = 0x0;
    }

    if (combo_dev_attr->data_rate == MIPI_DATA_RATE_X1) {
        vi_dev_attr.data_rate = OT_DATA_RATE_X1;
    } else if (combo_dev_attr->data_rate == MIPI_DATA_RATE_X2) {
        vi_dev_attr.data_rate = OT_DATA_RATE_X2;
    }

    ret = ss_mpi_vi_set_dev_attr(vi_dev, &vi_dev_attr);
    CHECK_MAPI_VCAP_RET(ret, "dev[%d] call ss_mpi_vi_set_dev_attr fail,ret:%#x!\n", vi_dev, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_chn_dynamic_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_pipe_chn_attr *vcap_chn_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_vi_chn vi_chn;
    mapi_vcap_glob_attr *vcap_glob_attr = mapi_vcap_get_glob_attr();
    ot_vi_chn_attr vi_chn_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_chn_attr);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    vi_chn = (ot_vi_chn)pipe_chn_hdl;

    ret = ss_mpi_vi_get_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_get_chn_attr fail,ret:%#x!\n", vi_pipe, vi_chn, ret);

    vi_chn_attr.compress_mode = vcap_glob_attr->glob_pipe_attr[vi_pipe].pipe_chn_attr[vi_chn].compress_mode;
    vi_chn_attr.size.width = vcap_chn_attr->dest_size.width;
    vi_chn_attr.size.height = vcap_chn_attr->dest_size.height;
    vi_chn_attr.frame_rate_ctrl.src_frame_rate = vcap_chn_attr->frame_rate_ctrl.src_frame_rate;
    vi_chn_attr.frame_rate_ctrl.dst_frame_rate = vcap_chn_attr->frame_rate_ctrl.dst_frame_rate;
    vi_chn_attr.pixel_format = vcap_chn_attr->pixel_format;
    vi_chn_attr.video_format = vcap_chn_attr->video_format;

    ret = ss_mpi_vi_set_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_set_chn_attr fail,ret:%#x!\n", vi_pipe, vi_chn, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_chn_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_vi_chn vi_chn;
    ot_vi_chn_attr vi_chn_attr;
    mapi_vcap_default_config_attr vcap_default_cfg;
    mapi_vcap_glob_attr *vcap_glob_attr = mapi_vcap_get_glob_attr();

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    vi_chn = (ot_vi_chn)pipe_chn_hdl;

    ret = memset_s(&vcap_default_cfg, sizeof(vcap_default_cfg), 0, sizeof(vcap_default_cfg));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    mapi_vcap_load_param(&vcap_default_cfg);

    ot_vi_chn_attr *chn_attr_def = &(vcap_default_cfg.vi_chn_attr[vi_chn]);
    ret = memcpy_s(&vi_chn_attr, sizeof(vi_chn_attr), chn_attr_def, sizeof(ot_vi_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    hi_mapi_vcap_pipe_chn_attr *vcap_chn_attr =
        &vcap_glob_attr->glob_pipe_attr[vi_pipe].pipe_chn_attr[vi_chn].chn_attr;

    vi_chn_attr.pixel_format = vcap_chn_attr->pixel_format;
    vi_chn_attr.compress_mode = vcap_glob_attr->glob_pipe_attr[vi_pipe].pipe_chn_attr[vi_chn].compress_mode;
    vi_chn_attr.size.width = vcap_chn_attr->dest_size.width;
    vi_chn_attr.size.height = vcap_chn_attr->dest_size.height;
    vi_chn_attr.frame_rate_ctrl.src_frame_rate = vcap_chn_attr->frame_rate_ctrl.src_frame_rate;
    vi_chn_attr.frame_rate_ctrl.dst_frame_rate = vcap_chn_attr->frame_rate_ctrl.dst_frame_rate;
    vi_chn_attr.video_format = vcap_chn_attr->video_format;

    ret = ss_mpi_vi_set_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_set_chn_attr fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_chn_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    mapi_vcap_pipe_chn_attr *vcap_chn_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_vi_chn vi_chn;
    ot_vi_chn_attr vi_chn_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_chn_attr);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    vi_chn = (ot_vi_chn)pipe_chn_hdl;

    ret = memset_s(&vi_chn_attr, sizeof(vi_chn_attr), 0, sizeof(vi_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_vi_get_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_get_chn_attr failed,vcap_pipe_hdl[%d],pipe_chn[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    vcap_chn_attr->chn_attr.pixel_format = vi_chn_attr.pixel_format;
    /* vcap_chn_attr->chn_attr.compress_mode = vi_chn_attr.compress_mode; */ /* compress_mode kept-commented */
    vcap_chn_attr->flip = vi_chn_attr.flip_en;
    vcap_chn_attr->mirror = vi_chn_attr.mirror_en;
    vcap_chn_attr->video_format = vi_chn_attr.video_format;
    vcap_chn_attr->chn_attr.frame_rate_ctrl.src_frame_rate = vi_chn_attr.frame_rate_ctrl.src_frame_rate;
    vcap_chn_attr->chn_attr.frame_rate_ctrl.dst_frame_rate = vi_chn_attr.frame_rate_ctrl.dst_frame_rate;
    vcap_chn_attr->chn_attr.dest_size.width = vi_chn_attr.size.width;
    vcap_chn_attr->chn_attr.dest_size.height = vi_chn_attr.size.height;	
    vcap_chn_attr->chn_attr.video_format = vi_chn_attr.video_format;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_start_dev(td_handle vcap_dev_hdl)
{
    td_s32 ret;
    ot_vi_dev vi_dev = (ot_vi_dev)vcap_dev_hdl;

    ret = ss_mpi_vi_enable_dev(vi_dev);
    CHECK_MAPI_VCAP_RET(ret, "dev[%d] call ss_mpi_vi_enable_dev fail,ret:%#x!\n", vi_dev, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_stop_dev(td_handle vcap_dev_hdl)
{
    td_s32 ret;
    ot_vi_dev vi_dev = (ot_vi_dev)vcap_dev_hdl;

    ret = ss_mpi_vi_disable_dev(vi_dev);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "dev[%d] call ss_mpi_vi_disable_dev fail,ret:%#x!\n", vi_dev, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_dev_bind_pipe(td_handle vcap_dev_hdl, td_u32 pipe_bind_num,
    const td_handle pipe_id_bind[], td_u32 array_len)
{
    td_u32 i;
    td_s32 ret;
    ot_vi_dev vi_dev;
    ot_vi_bind_pipe vi_dev_bind_pipe;
    CHECK_MAPI_VCAP_NULL_PTR_RET(pipe_id_bind);

    vi_dev = (ot_vi_dev)vcap_dev_hdl;
    ret = memset_s(&vi_dev_bind_pipe, sizeof(vi_dev_bind_pipe), 0, sizeof(vi_dev_bind_pipe));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);
    for (i = 0; i < array_len; i++) {
        vi_dev_bind_pipe.pipe_id[i] = pipe_id_bind[i];
    }
    vi_dev_bind_pipe.pipe_num = pipe_bind_num;
    for (i = 0; i < vi_dev_bind_pipe.pipe_num; i++) {
        ret = ss_mpi_vi_bind(vi_dev, vi_dev_bind_pipe.pipe_id[i]);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "call ss_mpi_vi_bind fail,ret:%#x\n", ret);
            return ret;
        }
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_pipe_vc_number(td_handle vcap_pipe_hdl, td_u32 bind_vc_num)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = ss_mpi_vi_set_pipe_vc_number(vi_pipe, bind_vc_num);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] call ss_mpi_vi_set_pipe_vc_number fail,ret:%#x!\n", vi_pipe, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_pipe_vc_number(td_handle vcap_pipe_hdl, td_u32 *bind_vc_num)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    CHECK_MAPI_VCAP_NULL_PTR_RET(bind_vc_num);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = ss_mpi_vi_get_pipe_vc_number(vi_pipe, bind_vc_num);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "call ss_mpi_vi_get_pipe_vc_number fail,ret:%#x!\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_create_pipe(td_handle vcap_pipe_hdl, const mapi_vcap_pipe_attr *vcap_pipe_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_vi_pipe_attr vi_pipe_attr;
    mapi_vcap_glob_attr *vcap_glob_attr = mapi_vcap_get_glob_attr();
    mapi_vcap_default_config_attr vcap_default_cfg;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_pipe_attr);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = memset_s(&vcap_default_cfg, sizeof(vcap_default_cfg), 0, sizeof(vcap_default_cfg));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    mapi_vcap_load_param(&vcap_default_cfg);
    ret = memcpy_s(&vi_pipe_attr, sizeof(vi_pipe_attr),
        &vcap_default_cfg.vi_pipe_attr[vi_pipe], sizeof(vcap_default_cfg.vi_pipe_attr[vi_pipe]));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    vi_pipe_attr.size.height = vcap_glob_attr->glob_pipe_attr[vi_pipe].isp_pub_attr.size.height;
    vi_pipe_attr.size.width = vcap_glob_attr->glob_pipe_attr[vi_pipe].isp_pub_attr.size.width;
    vi_pipe_attr.isp_bypass = vcap_pipe_attr->isp_bypass;
    vi_pipe_attr.pipe_bypass_mode = vcap_pipe_attr->pipe_bypass_mode;
    vi_pipe_attr.compress_mode = (ot_compress_mode)vcap_pipe_attr->compress_mode;
    vi_pipe_attr.frame_rate_ctrl.src_frame_rate = vcap_pipe_attr->frame_rate_ctrl.src_frame_rate;
    vi_pipe_attr.frame_rate_ctrl.dst_frame_rate = vcap_pipe_attr->frame_rate_ctrl.dst_frame_rate;
    vi_pipe_attr.pixel_format = vcap_pipe_attr->pix_fmt;

    ret = ss_mpi_vi_create_pipe(vi_pipe, &vi_pipe_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] call ss_mpi_vi_create_pipe fail,ret:%#x!\n", vi_pipe, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_destroy_pipe(td_handle vcap_dev_hdl, td_handle vcap_pipe_hdl)
{
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    td_s32 ret = ss_mpi_vi_destroy_pipe(vi_pipe);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] call ss_mpi_vi_destroy_pipe fail,ret:%#x!\n", vi_pipe, ret);
        return ret;
    }

    ot_vi_dev vi_dev = (ot_vi_dev)vcap_dev_hdl;
    ret = ss_mpi_vi_unbind(vi_dev, vi_pipe);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "dev[%d] pipe[%d] call ss_mpi_vi_unbind fail,ret:%#x!\n",
            vi_dev, vi_pipe, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_start_pipe(td_handle vcap_pipe_hdl, td_u32 pool_id)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    if (pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vi_set_pipe_vb_src(vi_pipe, OT_VB_SRC_USER);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] ss_mpi_vi_set_pipe_vb_src fail,ret:%#x!\n", vi_pipe, ret);
            return ret;
        }
        ret = ss_mpi_vi_attach_pipe_vb_pool(vi_pipe, pool_id);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] ss_mpi_vi_attach_pipe_vb_pool fail,ret:%#x!\n", vi_pipe, ret);
            return ret;
        }
    }

    ret = ss_mpi_vi_start_pipe(vi_pipe);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] ss_mpi_vi_start_pipe fail,ret:%#x!\n", vi_pipe, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_stop_pipe(td_handle vcap_pipe_hdl, td_u32 pool_id)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = ss_mpi_vi_stop_pipe(vi_pipe);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] call ss_mpi_vi_stop_pipe fail,ret:%#x!\n", vi_pipe, ret);
        return ret;
    }

    if (pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vi_detach_pipe_vb_pool(vi_pipe);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] call ss_mpi_vi_detach_pipe_vb_pool fail,ret:%#x!\n",
                vi_pipe, ret);
            return ret;
        }
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_start_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, td_u32 pool_id)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;

    if (pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vi_set_chn_vb_src(vcap_pipe_hdl, pipe_chn_hdl, OT_VB_SRC_USER);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] chn[%d] call ss_mpi_vi_set_chn_vb_src fail,ret:%#x!\n",
                vi_pipe, vi_chn, ret);
            return ret;
        }
        ret = ss_mpi_vi_attach_chn_vb_pool(vcap_pipe_hdl, pipe_chn_hdl, pool_id);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] chn[%d] call ss_mpi_vi_attach_chn_vb_pool fail,ret:%#x!\n",
                vi_pipe, vi_chn, ret);
            return ret;
        }
    }

    ret = ss_mpi_vi_enable_chn(vi_pipe, vi_chn);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] chn[%d] call ss_mpi_vi_enable_chn fail,ret:%#x!\n",
            vi_pipe, vi_chn, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_stop_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, td_u32 pool_id)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;

    ret = ss_mpi_vi_disable_chn(vi_pipe, vi_chn);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] chn[%d] call ss_mpi_vi_disable_chn fail,ret:%#x!\n",
            vi_pipe, vi_chn, ret);
        return ret;
    }

    if (pool_id != OT_VB_INVALID_POOL_ID) {
        ret = ss_mpi_vi_detach_chn_vb_pool(vcap_pipe_hdl, pipe_chn_hdl);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] chn[%d] call ss_mpi_vi_detach_chn_vb_pool fail,ret:%#x!\n",
                vi_pipe, vi_chn, ret);
            return ret;
        }
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_frame_data *frame_data, td_s32 milli_sec)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_video_frame_info frame_info;

    CHECK_MAPI_VCAP_NULL_PTR_RET(frame_data);

    ret = memset_s(&frame_info, sizeof(frame_info), 0, sizeof(frame_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_vi_get_chn_frame(vi_pipe, vi_chn, &frame_info, milli_sec);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_get_chn_frame fail,ret:%#x!\n",
        vi_pipe, vi_chn, ret);

    mapi_adapt_comm_frame_info_to_mapi(&frame_info, frame_data);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_release_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_frame_data *frame_data)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_video_frame_info frame_info;

    CHECK_MAPI_VCAP_NULL_PTR_RET(frame_data);

    mapi_adapt_comm_frame_info_to_mpi(frame_data, &frame_info);

    ret = ss_mpi_vi_release_chn_frame(vi_pipe, vi_chn, &frame_info);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_release_chn_frame fail,ret:%#x!\n",
        vi_pipe, vi_chn, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_chn_depth(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, td_u32 depth)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_vi_chn_attr vi_chn_attr;

    ret = ss_mpi_vi_get_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_get_chn_attr fail,ret:%#x!\n",
        vi_pipe, vi_chn, ret);

    vi_chn_attr.depth = depth;

    ret = ss_mpi_vi_set_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_set_chn_attr fail,ret:%#x!\n",
        vi_pipe, vi_chn, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_chn_depth(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, td_u32 *depth)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_vi_chn_attr vi_chn_attr;

    CHECK_MAPI_VCAP_NULL_PTR_RET(depth);

    ret = ss_mpi_vi_get_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_get_chn_attr fail,ret:%#x!\n",
        vi_pipe, vi_chn, ret);

    *depth = vi_chn_attr.depth;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_pipe_low_delay(td_handle vcap_pipe_hdl, const hi_mapi_vcap_low_delay_info *info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_low_delay_info low_delay_info;

    CHECK_MAPI_VCAP_NULL_PTR_RET(info);

    low_delay_info.enable = info->enable;
    low_delay_info.line_cnt = info->line_cnt;
    low_delay_info.one_buf_en = info->one_buf_en;

    ret = ss_mpi_vi_set_pipe_low_delay(vi_pipe, &low_delay_info);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_vi_set_pipe_low_delay fail,ret:%#x!\n", vi_pipe, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_pipe_low_delay(td_handle vcap_pipe_hdl, hi_mapi_vcap_low_delay_info *info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_low_delay_info low_delay_info;

    CHECK_MAPI_VCAP_NULL_PTR_RET(info);

    ret = ss_mpi_vi_get_pipe_low_delay(vi_pipe, &low_delay_info);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_vi_get_pipe_low_delay fail,ret:%#x!\n", vi_pipe, ret);

    info->enable = low_delay_info.enable;
    info->line_cnt = low_delay_info.line_cnt;
    info->one_buf_en = low_delay_info.one_buf_en;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_pipe_buf_wrap(td_handle vcap_pipe_hdl, const mapi_vcap_buf_wrap_info *info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_pipe_buf_wrap_attr wrap_attr;

    CHECK_MAPI_VCAP_NULL_PTR_RET(info);

    wrap_attr.enable = info->enable;
    wrap_attr.buf_line = info->buf_line;

    ret = ss_mpi_vi_set_pipe_buf_wrap_attr(vi_pipe, &wrap_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_vi_set_pipe_buf_wrap_attr fail,ret:%#x!\n", vi_pipe, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_pipe_buf_wrap(td_handle vcap_pipe_hdl, mapi_vcap_buf_wrap_info *info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_pipe_buf_wrap_attr wrap_attr;

    CHECK_MAPI_VCAP_NULL_PTR_RET(info);

    ret = ss_mpi_vi_get_pipe_buf_wrap_attr(vi_pipe, &wrap_attr);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] call ss_mpi_vi_get_pipe_buf_wrap_attr fail,ret:%#x!\n", vi_pipe, ret);

    info->enable = wrap_attr.enable;
    info->buf_line = wrap_attr.buf_line;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_chn_low_delay(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_low_delay_info *info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_low_delay_info low_delay_info;

    CHECK_MAPI_VCAP_NULL_PTR_RET(info);

    low_delay_info.enable = info->enable;
    low_delay_info.line_cnt = info->line_cnt;
    low_delay_info.one_buf_en = info->one_buf_en;

    ret = ss_mpi_vi_set_chn_low_delay(vi_pipe, vi_chn, &low_delay_info);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_set_chn_low_delay fail,ret:%#x!\n",
        vi_pipe, vi_chn, ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_chn_low_delay(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_vcap_low_delay_info *info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_low_delay_info low_delay_info;

    CHECK_MAPI_VCAP_NULL_PTR_RET(info);

    ret = ss_mpi_vi_get_chn_low_delay(vi_pipe, vi_chn, &low_delay_info);
    CHECK_MAPI_VCAP_RET(ret, "pipe[%d] chn[%d] call ss_mpi_vi_get_chn_low_delay fail,ret:%#x!\n",
        vi_pipe, vi_chn, ret);

    info->enable = low_delay_info.enable;
    info->line_cnt = low_delay_info.line_cnt;
    info->one_buf_en = low_delay_info.one_buf_en;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_isp_sns_init(td_handle vcap_pipe_hdl, const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    td_s32 ret;
    ot_isp_init_attr isp_init_attr;
    const mapi_vcap_glob_attr *vcap_glob_attr = mapi_vcap_get_glob_attr();
    CHECK_MAPI_VCAP_NULL_PTR_RET(sensor_attr);

    /* obtain sensor obj from glob_pipe_attr->sensor_obj after sensor refactor */
    const ot_isp_sns_obj *isp_sns_obj = (const ot_isp_sns_obj *)sensor_attr->sns_dev_attr.sensor_obj;
    if (isp_sns_obj != TD_NULL && isp_sns_obj->pfn_set_init != TD_NULL) {
        ret = mapi_vcap_generate_isp_init_attr(
            &vcap_glob_attr->glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr.isp_init_attr, &isp_init_attr);
        CHECK_MAPI_VCAP_RET(ret, "generate isp init attr,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

        ret = isp_sns_obj->pfn_set_init(vcap_pipe_hdl, &isp_init_attr);
        CHECK_MAPI_VCAP_RET(ret, "pfn_set_init failed,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_reg_isp_sns_callback(td_handle vcap_pipe_hdl, const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_isp_3a_alg_lib ae_lib;
    ot_isp_3a_alg_lib awb_lib;
    CHECK_MAPI_VCAP_NULL_PTR_RET(sensor_attr);

    const ot_isp_sns_obj *isp_sns_obj = (const ot_isp_sns_obj *)sensor_attr->sns_dev_attr.sensor_obj;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(isp_sns_obj);
    CHECK_MAPI_VCAP_NULL_PTR_RET(isp_sns_obj->pfn_register_callback);

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ae_lib.id = vi_pipe;
    awb_lib.id = vi_pipe;

    if (sizeof(OT_AE_LIB_NAME) > ALG_LIB_NAME_SIZE_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "OT_AE_LIB_NAME string too long\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }
    if (sizeof(OT_AWB_LIB_NAME) > ALG_LIB_NAME_SIZE_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "OT_AWB_LIB_NAME string too long\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = strncpy_s(ae_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AE_LIB_NAME, sizeof(OT_AE_LIB_NAME));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);
    ret = strncpy_s(awb_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AWB_LIB_NAME, sizeof(OT_AWB_LIB_NAME));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);

    ret = isp_sns_obj->pfn_register_callback(vi_pipe, &ae_lib, &awb_lib);
    CHECK_MAPI_VCAP_RET(ret, "call pfn_register_callback fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_unreg_isp_sns_callback(td_handle vcap_pipe_hdl, const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe;
    ot_isp_3a_alg_lib ae_lib;
    ot_isp_3a_alg_lib awb_lib;

    CHECK_MAPI_VCAP_NULL_PTR_RET(sensor_attr);

    const ot_isp_sns_obj *isp_sns_obj = (const ot_isp_sns_obj *)sensor_attr->sns_dev_attr.sensor_obj;

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ae_lib.id = vi_pipe;
    awb_lib.id = vi_pipe;

    ret = strncpy_s(ae_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AE_LIB_NAME, sizeof(OT_AE_LIB_NAME));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);
    ret = strncpy_s(awb_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AWB_LIB_NAME, sizeof(OT_AWB_LIB_NAME));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);

    if (isp_sns_obj == TD_NULL || isp_sns_obj->pfn_un_register_callback == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "sensor unregister_callback is null\n");
        return HI_MAPI_VCAP_ENULL_PTR;
    }

    ret = isp_sns_obj->pfn_un_register_callback(vi_pipe, &ae_lib, &awb_lib);
    CHECK_MAPI_VCAP_RET(ret, "call pfn_un_register_callback fail,ISP[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_void mapi_adapt_vcap_set_sns_bus_info(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_sensor_comm_bus_type sns_comm_bus_type, td_s32 sns_bus_id)
{
    ot_vi_pipe vi_pipe;
    ot_isp_sns_commbus isp_comm_bus;
    const mapi_vcap_glob_attr *vcap_glob_attr = mapi_vcap_get_glob_attr();

    const ot_isp_sns_obj *isp_sns_obj =
        (const ot_isp_sns_obj *)vcap_glob_attr->glob_dev_attr[
            vcap_glob_attr->glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl].sensor_attr.sns_dev_attr.sensor_obj;

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    if (sns_comm_bus_type == HI_MAPI_SENSOR_COMMBUS_TYPE_I2C) {
        isp_comm_bus.i2c_dev = sns_bus_id;
    } else if (sns_comm_bus_type == HI_MAPI_SENSOR_COMMBUS_TYPE_SPI) {
        isp_comm_bus.ssp_dev.bit4_ssp_dev = sns_bus_id;
        isp_comm_bus.ssp_dev.bit4_ssp_cs = 0;
    }

    if (isp_sns_obj != TD_NULL && isp_sns_obj->pfn_set_bus_info != TD_NULL) {
        isp_sns_obj->pfn_set_bus_info(vi_pipe, isp_comm_bus);
    }
}

td_void mapi_adapt_vcap_set_sns_mirror_flip(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_sns_mirror_flip_type sns_mirror_flip, const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    ot_vi_pipe vi_pipe;
    if (sensor_attr == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "sensor attr is null\n");
        return;
    }

    const ot_isp_sns_obj *isp_sns_obj = (const ot_isp_sns_obj *)sensor_attr->sns_dev_attr.sensor_obj;

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    if (isp_sns_obj != TD_NULL && isp_sns_obj->pfn_mirror_flip != TD_NULL) {
        isp_sns_obj->pfn_mirror_flip(vi_pipe, sns_mirror_flip);
    }
}

td_s32 mapi_adapt_vcap_init_isp_mem(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_ctrl_param isp_ctrl_param;

    ret = memset_s(&isp_ctrl_param, sizeof(isp_ctrl_param), 0, sizeof(isp_ctrl_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_ctrl_param(vi_pipe, &isp_ctrl_param);
    CHECK_MAPI_VCAP_RET(ret, "ISP[%u] call ss_mpi_isp_get_ctrl_param failed\n", vcap_pipe_hdl);

    isp_ctrl_param.interrupt_time_out = 30; /* 30: timeout 30ms */
    isp_ctrl_param.ldci_tpr_flt_en = TD_TRUE;
    ret = ss_mpi_isp_set_ctrl_param(vi_pipe, &isp_ctrl_param);
    CHECK_MAPI_VCAP_RET(ret, "ISP[%u] call ss_mpi_isp_set_ctrl_param failed\n", vcap_pipe_hdl);

    ret = ss_mpi_isp_mem_init(vi_pipe);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%u] call ss_mpi_isp_mem_init fail,ret:%#x!\n", vi_pipe, ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_register_isp_3a(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    ot_isp_3a_alg_lib alg_lib;
    ot_vi_pipe vi_pipe;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    if (sizeof(OT_AE_LIB_NAME) > ALG_LIB_NAME_SIZE_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "OT_AE_LIB_NAME string too long\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }
    if (sizeof(OT_AWB_LIB_NAME) > ALG_LIB_NAME_SIZE_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "OT_AWB_LIB_NAME string too long\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    alg_lib.id = vi_pipe;
    ret = strncpy_s(alg_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AE_LIB_NAME, sizeof(OT_AE_LIB_NAME));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);

    ret = ss_mpi_ae_register(vi_pipe, &alg_lib);
    CHECK_MAPI_VCAP_RET(ret, "register ae lib fail, vcap_pipe_hdl[%u]\n", vcap_pipe_hdl);

    alg_lib.id = vi_pipe;
    ret = strncpy_s(alg_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AWB_LIB_NAME, sizeof(OT_AWB_LIB_NAME));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);

    ret = ss_mpi_awb_register(vi_pipe, &alg_lib);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "register awb lib failed! ret:%x\n", ret);

        ret = strncpy_s(alg_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AE_LIB_NAME, sizeof(OT_AE_LIB_NAME));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);

        ret = ss_mpi_ae_unregister(vi_pipe, &alg_lib);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "unregister ae failed!,ret:%x\n", ret);
            return ret;
        }
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_unregister_isp_3a(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    ot_isp_3a_alg_lib alg_lib;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    if (sizeof(OT_AE_LIB_NAME) > ALG_LIB_NAME_SIZE_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "OT_AE_LIB_NAME string too long\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }
    if (sizeof(OT_AWB_LIB_NAME) > ALG_LIB_NAME_SIZE_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "OT_AWB_LIB_NAME string too long\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    alg_lib.id = vi_pipe;
    ret = strncpy_s(alg_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AE_LIB_NAME, sizeof(OT_AE_LIB_NAME));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);
    alg_lib.lib_name[ALG_LIB_NAME_SIZE_MAX - 1] = '\0';

    ret = ss_mpi_ae_unregister(vi_pipe, &alg_lib);
    CHECK_MAPI_VCAP_RET(ret, "unregister ae lib fail,vcap_pipe_hdl[%u]\n", vcap_pipe_hdl);

    alg_lib.id = vi_pipe;
    ret = strncpy_s(alg_lib.lib_name, ALG_LIB_NAME_SIZE_MAX, OT_AWB_LIB_NAME, sizeof(OT_AWB_LIB_NAME));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "strncpy_s", ret);
    alg_lib.lib_name[ALG_LIB_NAME_SIZE_MAX - 1] = '\0';

    ret = ss_mpi_awb_unregister(vi_pipe, &alg_lib);
    CHECK_MAPI_VCAP_RET(ret, "unregister awb lib fail,vcap_pipe_hdl[%u]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_init_isp(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = ss_mpi_isp_init(vi_pipe);
    CHECK_MAPI_VCAP_RET(ret, "ISP[%u] call ss_mpi_isp_init failed\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_start_isp(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = ss_mpi_isp_run(vi_pipe);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "ISP[%u],call ss_mpi_isp_run fail.\n", vcap_pipe_hdl);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_stop_isp(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;

    ret = ss_mpi_isp_exit(vi_pipe);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "ISP[%u],call ss_mpi_isp_exit fail.\n", vcap_pipe_hdl);
        return ret;
    }

    return TD_SUCCESS;
}

td_void mapi_adapt_vcap_enter_standby(td_handle vcap_pipe_hdl, const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    ot_vi_pipe vi_pipe;
    if (sensor_attr == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "sensor_attr is null\n");
        return;
    }

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    const ot_isp_sns_obj *isp_sns_obj = (const ot_isp_sns_obj *)sensor_attr->sns_dev_attr.sensor_obj;

    if (isp_sns_obj == TD_NULL || isp_sns_obj->pfn_standby == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "standby callback is null\n");
        return;
    }
    isp_sns_obj->pfn_standby(vi_pipe);
}

td_void mapi_adapt_vcap_restart_sensor(td_handle vcap_pipe_hdl, const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    ot_vi_pipe vi_pipe;
    if (sensor_attr == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "sensor attr is null\n");
        return;
    }

    vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    const ot_isp_sns_obj *isp_sns_obj = (const ot_isp_sns_obj *)sensor_attr->sns_dev_attr.sensor_obj;

    if (isp_sns_obj == TD_NULL || isp_sns_obj->pfn_restart == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "restart callback is null\n");
        return;
    }
    isp_sns_obj->pfn_restart(vi_pipe);
}


td_s32 mapi_adapt_vcap_set_contrast(td_handle vcap_pipe_hdl, const hi_mapi_vcap_contrast *vcap_contrast)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_csc_attr isp_csc_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_contrast);
    CHECK_MAPI_VCAP_MAX_VAL_RET("contrast value", vcap_contrast->contrast, HI_MAPI_VCAP_MAX_CONTRAST);

    ret = memset_s(&isp_csc_attr, sizeof(isp_csc_attr), 0, sizeof(isp_csc_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_csc_attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
    isp_csc_attr.contr = vcap_contrast->contrast;

    ret = ss_mpi_isp_set_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_csc_attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_contrast(td_handle vcap_pipe_hdl, hi_mapi_vcap_contrast *vcap_contrast)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_csc_attr isp_csc_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_contrast);

    ret = memset_s(&isp_csc_attr, sizeof(isp_csc_attr), 0, sizeof(isp_csc_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_csc_attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    vcap_contrast->contrast = isp_csc_attr.contr;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_exposure(td_handle vcap_pipe_hdl, const hi_mapi_vcap_exposure_attr *vcap_exposure)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_op_mode dst_isp_type;
    ot_isp_exposure_attr isp_exposure;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_exposure);

    ret = ss_mpi_isp_get_exposure_attr(vi_pipe, &isp_exposure);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_exposure_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    switch (vcap_exposure->op_type) {
        case HI_MAPI_VCAP_OP_TYPE_DISABLE:
            isp_exposure.bypass = TD_TRUE;
            break;
        case HI_MAPI_VCAP_OP_TYPE_AUTO:
            isp_exposure.bypass = TD_FALSE;
            isp_exposure.op_type = OT_OP_MODE_AUTO;
            isp_exposure.auto_attr.ev_bias = vcap_exposure->auto_exposure_mode.ev_bias;
            isp_exposure.auto_attr.sys_gain_range.min = vcap_exposure->auto_exposure_mode.sys_gain_range.min;
            isp_exposure.auto_attr.sys_gain_range.max = vcap_exposure->auto_exposure_mode.sys_gain_range.max;
            break;
        case HI_MAPI_VCAP_OP_TYPE_MANUAL:
            isp_exposure.bypass = TD_FALSE;
            isp_exposure.op_type = OT_OP_MODE_MANUAL;
            ret = mapi_vcap_switch_type_to_isp(vcap_exposure->manu_exposure_mode.exp_time_op_type, &dst_isp_type);
            CHECK_MAPI_VCAP_RET(ret, "switch type to isp fail,pipe[%d]\n", vcap_pipe_hdl);
            isp_exposure.manual_attr.exp_time_op_type = dst_isp_type;
            ret = mapi_vcap_switch_type_to_isp(vcap_exposure->manu_exposure_mode.a_gain_op_type, &dst_isp_type);
            CHECK_MAPI_VCAP_RET(ret, "switch type to isp fail,pipe[%d]\n", vcap_pipe_hdl);
            isp_exposure.manual_attr.a_gain_op_type = dst_isp_type;
            ret = mapi_vcap_switch_type_to_isp(vcap_exposure->manu_exposure_mode.d_gain_op_type, &dst_isp_type);
            CHECK_MAPI_VCAP_RET(ret, "switch type to isp fail,pipe[%d]\n", vcap_pipe_hdl);
            isp_exposure.manual_attr.d_gain_op_type = dst_isp_type;
            ret = mapi_vcap_switch_type_to_isp(vcap_exposure->manu_exposure_mode.isp_dgain_op_type, &dst_isp_type);
            CHECK_MAPI_VCAP_RET(ret, "switch type to isp fail,pipe[%d]\n", vcap_pipe_hdl);
            isp_exposure.manual_attr.ispd_gain_op_type = dst_isp_type;
            isp_exposure.manual_attr.exp_time = vcap_exposure->manu_exposure_mode.exposure_time;
            isp_exposure.manual_attr.a_gain = vcap_exposure->manu_exposure_mode.a_gain;
            isp_exposure.manual_attr.d_gain = vcap_exposure->manu_exposure_mode.d_gain;
            isp_exposure.manual_attr.isp_d_gain = vcap_exposure->manu_exposure_mode.isp_dgain;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support exposure op type.\n");
            return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = ss_mpi_isp_set_exposure_attr(vi_pipe, &isp_exposure);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_exposure_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_exposure(td_handle vcap_pipe_hdl, hi_mapi_vcap_exposure_attr *vcap_exposure)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    hi_mapi_vcap_op_type dst_mapi_type;
    ot_isp_exposure_attr isp_exposure;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_exposure);

    ret = memset_s(&isp_exposure, sizeof(isp_exposure), 0, sizeof(isp_exposure));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_exposure_attr(vi_pipe, &isp_exposure);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_exposure_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    if (isp_exposure.bypass == TD_TRUE) {
        vcap_exposure->op_type = HI_MAPI_VCAP_OP_TYPE_DISABLE;
    } else {
        if (isp_exposure.op_type == OT_OP_MODE_AUTO) {
            vcap_exposure->op_type = HI_MAPI_VCAP_OP_TYPE_AUTO;
        } else if (isp_exposure.op_type == OT_OP_MODE_MANUAL) {
            vcap_exposure->op_type = HI_MAPI_VCAP_OP_TYPE_MANUAL;
        } else {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support exposure optype.\n");
            return HI_MAPI_VCAP_ENOTSUPPORT;
        }
    }

    ret = mapi_vcap_switch_type_to_mapi(isp_exposure.manual_attr.exp_time_op_type, &dst_mapi_type);
    CHECK_MAPI_VCAP_RET(ret, "switch type to mapi fail,pipe[%d]\n", vcap_pipe_hdl);
    vcap_exposure->manu_exposure_mode.exp_time_op_type = dst_mapi_type;
    ret = mapi_vcap_switch_type_to_mapi(isp_exposure.manual_attr.a_gain_op_type, &dst_mapi_type);
    CHECK_MAPI_VCAP_RET(ret, "switch type to mapi fail,pipe[%d]\n", vcap_pipe_hdl);
    vcap_exposure->manu_exposure_mode.a_gain_op_type = dst_mapi_type;
    ret = mapi_vcap_switch_type_to_mapi(isp_exposure.manual_attr.d_gain_op_type, &dst_mapi_type);
    CHECK_MAPI_VCAP_RET(ret, "switch type to mapi fail,pipe[%d]\n", vcap_pipe_hdl);
    vcap_exposure->manu_exposure_mode.d_gain_op_type = dst_mapi_type;
    ret = mapi_vcap_switch_type_to_mapi(isp_exposure.manual_attr.ispd_gain_op_type, &dst_mapi_type);
    CHECK_MAPI_VCAP_RET(ret, "switch type to mapi fail,pipe[%d]\n", vcap_pipe_hdl);
    vcap_exposure->manu_exposure_mode.isp_dgain_op_type = dst_mapi_type;

    vcap_exposure->manu_exposure_mode.exposure_time = isp_exposure.manual_attr.exp_time;
    vcap_exposure->manu_exposure_mode.a_gain = isp_exposure.manual_attr.a_gain;
    vcap_exposure->manu_exposure_mode.d_gain = isp_exposure.manual_attr.d_gain;
    vcap_exposure->manu_exposure_mode.isp_dgain = isp_exposure.manual_attr.isp_d_gain;

    vcap_exposure->auto_exposure_mode.ev_bias = isp_exposure.auto_attr.ev_bias;
    vcap_exposure->auto_exposure_mode.sys_gain_range.min = isp_exposure.auto_attr.sys_gain_range.min;
    vcap_exposure->auto_exposure_mode.sys_gain_range.max = isp_exposure.auto_attr.sys_gain_range.max;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_exposure_info(td_handle vcap_pipe_hdl, hi_mapi_vcap_exposure_info *exposure_info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_exp_info isp_exp_info;
    CHECK_MAPI_VCAP_NULL_PTR_RET(exposure_info);

    ret = memset_s(&isp_exp_info, sizeof(ot_isp_exp_info), 0, sizeof(ot_isp_exp_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_query_exposure_info(vi_pipe, &isp_exp_info);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_query_exposure_info fail,pipe[%d]\n", vcap_pipe_hdl);

    exposure_info->exp_time = isp_exp_info.exp_time;
    exposure_info->a_gain = isp_exp_info.a_gain;
    exposure_info->d_gain = isp_exp_info.d_gain;
    exposure_info->isp_dgain = isp_exp_info.isp_d_gain;
    exposure_info->exposure = isp_exp_info.exposure;
    exposure_info->lines_per500ms = isp_exp_info.lines_per500ms;
    exposure_info->piris_fno = isp_exp_info.piris_fno;
    exposure_info->long_exp_time = isp_exp_info.long_exp_time;
    exposure_info->short_exp_time = isp_exp_info.short_exp_time;
    exposure_info->median_exp_time = isp_exp_info.median_exp_time;
    exposure_info->exposure_is_max = isp_exp_info.exposure_is_max;
    exposure_info->hist_error = isp_exp_info.hist_error;
    exposure_info->ave_lum = isp_exp_info.ave_lum;
    exposure_info->fps = isp_exp_info.fps;
    exposure_info->iso = isp_exp_info.iso;
    exposure_info->ref_exp_ratio = isp_exp_info.ref_exp_ratio;
    exposure_info->first_stable_time = isp_exp_info.first_stable_time;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_wb(td_handle vcap_pipe_hdl, const hi_mapi_vcap_wb_attr *vcap_wb_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_wb_attr isp_wb_attr;
    td_u16 awb_gain[4]; /* 4: awb gain array len */
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_wb_attr);

    ret = memset_s(&isp_wb_attr, sizeof(isp_wb_attr), 0, sizeof(isp_wb_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_wb_attr(vi_pipe, &isp_wb_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_wb_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    switch (vcap_wb_attr->op_type) {
        case HI_MAPI_VCAP_OP_TYPE_DISABLE:
            isp_wb_attr.bypass = TD_TRUE;
            break;
        case HI_MAPI_VCAP_OP_TYPE_AUTO:
            isp_wb_attr.bypass = TD_FALSE;
            isp_wb_attr.op_type = OT_OP_MODE_AUTO;
            break;
        case HI_MAPI_VCAP_OP_TYPE_MANUAL:
            ret = ss_mpi_isp_cal_gain_by_temp(vi_pipe, &isp_wb_attr, vcap_wb_attr->wb_mode.color_temp, 0, awb_gain);
            CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_cal_gain_by_temp fail,pipe[%d]\n", vcap_pipe_hdl);
            isp_wb_attr.manual_attr.r_gain = awb_gain[0];
            isp_wb_attr.manual_attr.gr_gain = awb_gain[1];
            isp_wb_attr.manual_attr.gb_gain = awb_gain[2];
            isp_wb_attr.manual_attr.b_gain = awb_gain[3];
            isp_wb_attr.bypass = TD_FALSE;
            isp_wb_attr.op_type = OT_OP_MODE_MANUAL;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support wb op type\n");
            return HI_MAPI_VCAP_ENOTSUPPORT;
    }

    ret = ss_mpi_isp_set_wb_attr(vi_pipe, &isp_wb_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_wb_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_wb_info(td_handle vcap_pipe_hdl, hi_mapi_vcap_isp_wb_info *vcap_wb_info)
{
    td_s32 i;
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_wb_info isp_wb_info;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_wb_info);

    if (HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE != OT_ISP_CCM_MATRIX_SIZE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "OT_ISP_CCM_MATRIX_SIZE not match Isp\n");
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = memset_s(&isp_wb_info, sizeof(isp_wb_info), 0, sizeof(isp_wb_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_query_wb_info(vi_pipe, &isp_wb_info);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_query_wb_info fail,pipe[%d]\n", vcap_pipe_hdl);

    vcap_wb_info->rgain = isp_wb_info.r_gain;
    vcap_wb_info->grgain = isp_wb_info.gr_gain;
    vcap_wb_info->gbgain = isp_wb_info.gb_gain;
    vcap_wb_info->bgain = isp_wb_info.b_gain;
    vcap_wb_info->saturation = isp_wb_info.saturation;
    vcap_wb_info->color_temp = isp_wb_info.color_temp;

    for (i = 0; i < HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE; i++) {
        vcap_wb_info->ccm[i] = isp_wb_info.ccm[i];
    }

    vcap_wb_info->l_s0_ct = isp_wb_info.ls0_ct;
    vcap_wb_info->l_s1_ct = isp_wb_info.ls1_ct;
    vcap_wb_info->l_s0_area = isp_wb_info.ls0_area;
    vcap_wb_info->l_s1_area = isp_wb_info.ls1_area;
    vcap_wb_info->multi_degree = isp_wb_info.multi_degree;
    vcap_wb_info->active_shift = isp_wb_info.active_shift;
    vcap_wb_info->first_stable_time = isp_wb_info.first_stable_time;
    vcap_wb_info->in_out_status = isp_wb_info.scene_status;
    vcap_wb_info->bv = isp_wb_info.bv;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_rotation(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_rotation *vcap_rotation)
{
#ifdef SUPPORT_VI_ROTATION
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_rotation_attr rotation;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_rotation);

    ret = ss_mpi_vi_get_chn_rotation(vi_pipe, vi_chn, &rotation);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_get_chn_rotation fail,pipe[%d],chn[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    if (*vcap_rotation == (hi_mapi_rotation)rotation.rotation_fixed) {
        return TD_SUCCESS;
    }

    rotation.rotation_fixed = *vcap_rotation;
    ret = ss_mpi_vi_set_chn_rotation(vi_pipe, vi_chn, &rotation);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_set_chn_rotation fail,pipe[%d],chn[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
#else
    TD_UNUSED(vcap_pipe_hdl);
    TD_UNUSED(pipe_chn_hdl);
    TD_UNUSED(vcap_rotation);
    MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not supported rotation function.\n");
    return HI_MAPI_VCAP_ENOTSUPPORT;
#endif
}

td_s32 mapi_adapt_vcap_get_rotation(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_rotation *vcap_rotation)
{
#ifdef SUPPORT_VI_ROTATION
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_rotation_attr rotation;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_rotation);

    ret = ss_mpi_vi_get_chn_rotation(vi_pipe, vi_chn, &rotation);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_get_chn_rotation fail,pipe[%d]\n", vcap_pipe_hdl);

    *vcap_rotation = rotation.rotation_fixed;

    return TD_SUCCESS;
#else
    TD_UNUSED(vcap_pipe_hdl);
    TD_UNUSED(pipe_chn_hdl);
    TD_UNUSED(vcap_rotation);
    MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not supported rotation function.\n");
    return HI_MAPI_VCAP_ENOTSUPPORT;
#endif
}

td_s32 mapi_adapt_vcap_set_mirror_flip(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_mirror_flip_attr *mirror_flip_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_vi_chn_attr vi_chn_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(mirror_flip_attr);

    ret = memset_s(&vi_chn_attr, sizeof(vi_chn_attr), 0, sizeof(vi_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_vi_get_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_get_chn_attr fail,pipe[%d],chn[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    if ((vi_chn_attr.mirror_en == mirror_flip_attr->mirror) &&
        (vi_chn_attr.flip_en == mirror_flip_attr->flip)) {
        return TD_SUCCESS;
    }

    vi_chn_attr.mirror_en = mirror_flip_attr->mirror;
    vi_chn_attr.flip_en = mirror_flip_attr->flip;

    ret = ss_mpi_vi_set_chn_attr(vi_pipe, vi_chn, &vi_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_set_chn_attr fail,pipe[%d],chn[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_ldc_attr(__attribute__((unused)) td_handle vcap_pipe_hdl,
    __attribute__((unused)) td_handle pipe_chn_hdl,
    __attribute__((unused)) const hi_mapi_vcap_ldc_attr *vcap_ldc_attr)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support set ldc at vcap device\n");
    return HI_MAPI_VCAP_ENOTSUPPORT;
}

td_s32 mapi_adapt_vcap_get_ldc_attr(__attribute__((unused)) td_handle vcap_pipe_hdl,
    __attribute__((unused)) td_handle pipe_chn_hdl,
    __attribute__((unused)) hi_mapi_vcap_ldc_attr *vcap_ldc_attr)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support get ldc at vcap device\n");
    return HI_MAPI_VCAP_ENOTSUPPORT;
}

td_s32 mapi_adapt_vcap_set_isp_dng_color_param(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_dng_color_param *vcap_dng_color_param)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_dng_color_param isp_dng_color_param;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_dng_color_param);

    ret = memset_s(&isp_dng_color_param, sizeof(isp_dng_color_param), 0, sizeof(isp_dng_color_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    isp_dng_color_param.wb_gain1.r_gain = vcap_dng_color_param->wb_gain1.rgain;
    isp_dng_color_param.wb_gain1.g_gain = vcap_dng_color_param->wb_gain1.ggain;
    isp_dng_color_param.wb_gain1.b_gain = vcap_dng_color_param->wb_gain1.bgain;
    isp_dng_color_param.wb_gain2.r_gain = vcap_dng_color_param->wb_gain2.rgain;
    isp_dng_color_param.wb_gain2.g_gain = vcap_dng_color_param->wb_gain2.ggain;
    isp_dng_color_param.wb_gain2.b_gain = vcap_dng_color_param->wb_gain2.bgain;

    isp_dng_color_param.ccm_tab1.color_temp = vcap_dng_color_param->ccm_tab1.color_temp;
    (td_void)memcpy_s(isp_dng_color_param.ccm_tab1.ccm, OT_ISP_CCM_MATRIX_SIZE,
        vcap_dng_color_param->ccm_tab1.ccm, OT_ISP_CCM_MATRIX_SIZE);

    isp_dng_color_param.ccm_tab2.color_temp = vcap_dng_color_param->ccm_tab2.color_temp;
    (td_void)memcpy_s(isp_dng_color_param.ccm_tab2.ccm, OT_ISP_CCM_MATRIX_SIZE,
        vcap_dng_color_param->ccm_tab2.ccm, OT_ISP_CCM_MATRIX_SIZE);

    ret = ss_mpi_isp_set_dng_color_param(vi_pipe, &isp_dng_color_param);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_dng_color_param fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_isp_dng_color_param(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_dng_color_param *vcap_dng_color_param)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_dng_color_param isp_dng_color;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_dng_color_param);

    ret = memset_s(&isp_dng_color, sizeof(isp_dng_color), 0, sizeof(isp_dng_color));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_dng_color_param(vi_pipe, &isp_dng_color);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_dng_color_param fail,pipe[%d]\n", vcap_pipe_hdl);

    vcap_dng_color_param->wb_gain1.rgain = isp_dng_color.wb_gain1.r_gain;
    vcap_dng_color_param->wb_gain1.ggain = isp_dng_color.wb_gain1.g_gain;
    vcap_dng_color_param->wb_gain1.bgain = isp_dng_color.wb_gain1.b_gain;
    vcap_dng_color_param->wb_gain2.rgain = isp_dng_color.wb_gain2.r_gain;
    vcap_dng_color_param->wb_gain2.ggain = isp_dng_color.wb_gain2.g_gain;
    vcap_dng_color_param->wb_gain2.bgain = isp_dng_color.wb_gain2.b_gain;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_isp_debug(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_cmd command, const hi_mapi_vcap_isp_debug_info *vcap_isp_debug_info)
{
    TD_UNUSED(vcap_pipe_hdl);
    TD_UNUSED(command);
    TD_UNUSED(vcap_isp_debug_info);
    return HI_MAPI_VCAP_ENOTSUPPORT;
}

td_s32 mapi_adapt_vcap_set_saturation(td_handle vcap_pipe_hdl, const hi_mapi_vcap_saturation *vcap_saturation)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_csc_attr isp_csc_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_saturation);
    CHECK_MAPI_VCAP_MAX_VAL_RET("saturation value", vcap_saturation->saturation, HI_MAPI_VCAP_MAX_SATURATION);

    ret = memset_s(&isp_csc_attr, sizeof(isp_csc_attr), 0, sizeof(isp_csc_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_csc_attr fail,pipe[%d]\n", vcap_pipe_hdl);
    isp_csc_attr.satu = vcap_saturation->saturation;

    ret = ss_mpi_isp_set_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_csc_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_saturation(td_handle vcap_pipe_hdl, hi_mapi_vcap_saturation *vcap_saturation)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_csc_attr isp_csc_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_saturation);

    ret = memset_s(&isp_csc_attr, sizeof(isp_csc_attr), 0, sizeof(isp_csc_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_csc_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    vcap_saturation->saturation = isp_csc_attr.satu;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_luma(td_handle vcap_pipe_hdl, const hi_mapi_vcap_luma *vcap_luma)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_csc_attr isp_csc_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_luma);
    CHECK_MAPI_VCAP_MAX_VAL_RET("luma value", vcap_luma->luma, HI_MAPI_VCAP_MAX_LUMA);

    ret = memset_s(&isp_csc_attr, sizeof(isp_csc_attr), 0, sizeof(isp_csc_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_csc_attr fail,pipe[%d]\n", vcap_pipe_hdl);
    isp_csc_attr.luma = vcap_luma->luma;

    ret = ss_mpi_isp_set_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_csc_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_luma(td_handle vcap_pipe_hdl, hi_mapi_vcap_luma *vcap_luma)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_csc_attr isp_csc_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_luma);

    ret = memset_s(&isp_csc_attr, sizeof(isp_csc_attr), 0, sizeof(isp_csc_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_csc_attr(vi_pipe, &isp_csc_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_csc_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    vcap_luma->luma = isp_csc_attr.luma;

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_vcap_check_isp_sharpen_attr(const hi_mapi_vcap_sharpen *vcap_sharpen)
{
    if (vcap_sharpen->op_type >= HI_MAPI_VCAP_OP_TYPE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "op_type error: %d\n", vcap_sharpen->op_type);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    if (vcap_sharpen->detail_map < HI_MAPI_VCAP_ISP_SHARPEN_NORMAL ||
        vcap_sharpen->detail_map >= HI_MAPI_VCAP_ISP_SHARPEN_BUTT ||
        vcap_sharpen->detail_map == HI_MAPI_VCAP_ISP_SHARPEN_DETAIL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support type: %d\n", vcap_sharpen->detail_map);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }
    return TD_SUCCESS;
}

static td_void mapi_adapt_vcap_fill_isp_sharpen_auto_attr(ot_isp_sharpen_auto_attr *isp_auto,
    const hi_mapi_vcap_sharp_auto_attr *vcap_auto)
{
    for (td_u32 i = 0; i < OT_ISP_AUTO_ISO_NUM; i++) {
        for (td_u32 j = 0; j < OT_ISP_SHARPEN_LUMA_NUM; j++) {
            isp_auto->luma_wgt[j][i] = vcap_auto->luma_wgt[j][i];
        }
        for (td_u32 j = 0; j < OT_ISP_SHARPEN_LUMA_NUM; j++) {
            isp_auto->texture_strength[j][i] = vcap_auto->texture_strength[j][i];
            isp_auto->edge_strength[j][i] = vcap_auto->edge_strength[j][i];
            isp_auto->motion_texture_strength[j][i] = vcap_auto->motion_texture_strength[j][i];
            isp_auto->motion_edge_strength[j][i] = vcap_auto->motion_edge_strength[j][i];
        }
        isp_auto->texture_freq[i] = vcap_auto->texture_freq[i];
        isp_auto->edge_freq[i] = vcap_auto->edge_freq[i];
        isp_auto->over_shoot[i] = vcap_auto->over_shoot[i];
        isp_auto->under_shoot[i] = vcap_auto->under_shoot[i];
        isp_auto->motion_texture_freq[i] = vcap_auto->motion_texture_freq[i];
        isp_auto->motion_edge_freq[i] = vcap_auto->motion_edge_freq[i];
        isp_auto->motion_over_shoot[i] = vcap_auto->motion_over_shoot[i];
        isp_auto->motion_under_shoot[i] = vcap_auto->motion_under_shoot[i];
        isp_auto->shoot_sup_strength[i] = vcap_auto->shoot_sup_strength[i];
        isp_auto->shoot_sup_adj[i] = vcap_auto->shoot_sup_adj[i];
        isp_auto->detail_ctrl[i] = vcap_auto->detail_ctrl[i];
        isp_auto->detail_ctrl_threshold[i] = vcap_auto->detail_ctrl_threshold[i];
        isp_auto->edge_filt_strength[i] = vcap_auto->edge_filt_strength[i];
        isp_auto->edge_filt_max_cap[i] = vcap_auto->edge_filt_max_cap[i];
        isp_auto->r_gain[i] = vcap_auto->r_gain[i];
        isp_auto->g_gain[i] = vcap_auto->g_gain[i];
        isp_auto->b_gain[i] = vcap_auto->b_gain[i];
        isp_auto->skin_gain[i] = vcap_auto->skin_gain[i];
        isp_auto->max_sharp_gain[i] = vcap_auto->max_sharp_gain[i];
    }
}

static td_void mapi_adapt_vcap_fill_isp_sharpen_manual_attr(ot_isp_sharpen_manual_attr *isp_manual,
    const hi_mapi_vcap_sharp_manual_attr *vcap_manual)
{
    for (td_u32 i = 0; i < OT_ISP_SHARPEN_LUMA_NUM; i++) {
        isp_manual->luma_wgt[i] = vcap_manual->luma_wgt[i];
    }
    for (td_u32 i = 0; i < OT_ISP_SHARPEN_LUMA_NUM; i++) {
        isp_manual->texture_strength[i] = vcap_manual->texture_strength[i];
        isp_manual->edge_strength[i] = vcap_manual->edge_strength[i];
        isp_manual->motion_texture_strength[i] = vcap_manual->motion_texture_strength[i];
        isp_manual->motion_edge_strength[i] = vcap_manual->motion_edge_strength[i];
    }
    isp_manual->texture_freq = vcap_manual->texture_freq;
    isp_manual->edge_freq = vcap_manual->edge_freq;
    isp_manual->over_shoot = vcap_manual->over_shoot;
    isp_manual->under_shoot = vcap_manual->under_shoot;
    isp_manual->motion_texture_freq = vcap_manual->motion_texture_freq;
    isp_manual->motion_edge_freq = vcap_manual->motion_edge_freq;
    isp_manual->motion_over_shoot = vcap_manual->motion_over_shoot;
    isp_manual->motion_under_shoot = vcap_manual->motion_under_shoot;
    isp_manual->shoot_sup_strength = vcap_manual->shoot_sup_strength;
    isp_manual->shoot_sup_adj = vcap_manual->shoot_sup_adj;
    isp_manual->detail_ctrl = vcap_manual->detail_ctrl;
    isp_manual->detail_ctrl_threshold = vcap_manual->detail_ctrl_threshold;
    isp_manual->edge_filt_strength = vcap_manual->edge_filt_strength;
    isp_manual->edge_filt_max_cap = vcap_manual->edge_filt_max_cap;
    isp_manual->r_gain = vcap_manual->r_gain;
    isp_manual->g_gain = vcap_manual->g_gain;
    isp_manual->b_gain = vcap_manual->b_gain;
    isp_manual->skin_gain = vcap_manual->skin_gain;
    isp_manual->max_sharp_gain = vcap_manual->max_sharp_gain;
}

static td_void mapi_adapt_vcap_fill_isp_sharpen_attr(ot_isp_sharpen_attr *isp_sharpen,
    const hi_mapi_vcap_sharpen *vcap_sharpen)
{
    isp_sharpen->enable = vcap_sharpen->enable;
    isp_sharpen->motion_en = vcap_sharpen->motion_enable;
    isp_sharpen->motion_threshold0 = vcap_sharpen->motion_threshold0;
    isp_sharpen->motion_threshold1 = vcap_sharpen->motion_threshold1;
    isp_sharpen->motion_gain0 = vcap_sharpen->motion_gain0;
    isp_sharpen->motion_gain1 = vcap_sharpen->motion_gain1;
    isp_sharpen->skin_umin = vcap_sharpen->skin_umin;
    isp_sharpen->skin_vmin = vcap_sharpen->skin_vmin;
    isp_sharpen->skin_umax = vcap_sharpen->skin_umax;
    isp_sharpen->skin_vmax = vcap_sharpen->skin_vmax;
    isp_sharpen->op_type = vcap_sharpen->op_type;
    isp_sharpen->detail_map = vcap_sharpen->detail_map;

    mapi_adapt_vcap_fill_isp_sharpen_auto_attr(&isp_sharpen->auto_attr, &vcap_sharpen->auto_attr);
    mapi_adapt_vcap_fill_isp_sharpen_manual_attr(&isp_sharpen->manual_attr, &vcap_sharpen->manual_attr);
}

td_s32 mapi_adapt_vcap_set_sharpen(td_handle vcap_pipe_hdl, const hi_mapi_vcap_sharpen *vcap_sharpen)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_sharpen_attr isp_sharpen_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_sharpen);

    if (OT_ISP_SHARPEN_GAIN_NUM != HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "set sharpen gain num mismatch,pipe[%u]\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }
    if (mapi_adapt_vcap_check_isp_sharpen_attr(vcap_sharpen) != TD_SUCCESS) {
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = memset_s(&isp_sharpen_attr, sizeof(isp_sharpen_attr), 0, sizeof(isp_sharpen_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    mapi_adapt_vcap_fill_isp_sharpen_attr(&isp_sharpen_attr, vcap_sharpen);
    ret = ss_mpi_isp_set_sharpen_attr(vi_pipe, &isp_sharpen_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_sharpen_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

static td_void mapi_adapt_vcap_fill_vcap_sharpen_auto_attr(hi_mapi_vcap_sharp_auto_attr *vcap_auto,
    const ot_isp_sharpen_auto_attr *isp_auto)
{
    for (td_u32 i = 0; i < OT_ISP_AUTO_ISO_NUM; i++) {
        for (td_u32 j = 0; j < OT_ISP_SHARPEN_LUMA_NUM; j++) {
            vcap_auto->luma_wgt[j][i] = isp_auto->luma_wgt[j][i];
        }
        for (td_u32 j = 0; j < OT_ISP_SHARPEN_LUMA_NUM; j++) {
            vcap_auto->texture_strength[j][i] = isp_auto->texture_strength[j][i];
            vcap_auto->edge_strength[j][i] = isp_auto->edge_strength[j][i];
            vcap_auto->motion_texture_strength[j][i] = isp_auto->motion_texture_strength[j][i];
            vcap_auto->motion_edge_strength[j][i] = isp_auto->motion_edge_strength[j][i];
        }
        vcap_auto->texture_freq[i] = isp_auto->texture_freq[i];
        vcap_auto->edge_freq[i] = isp_auto->edge_freq[i];
        vcap_auto->over_shoot[i] = isp_auto->over_shoot[i];
        vcap_auto->under_shoot[i] = isp_auto->under_shoot[i];
        vcap_auto->motion_texture_freq[i] = isp_auto->motion_texture_freq[i];
        vcap_auto->motion_edge_freq[i] = isp_auto->motion_edge_freq[i];
        vcap_auto->motion_over_shoot[i] = isp_auto->motion_over_shoot[i];
        vcap_auto->motion_under_shoot[i] = isp_auto->motion_under_shoot[i];
        vcap_auto->shoot_sup_strength[i] = isp_auto->shoot_sup_strength[i];
        vcap_auto->shoot_sup_adj[i] = isp_auto->shoot_sup_adj[i];
        vcap_auto->detail_ctrl[i] = isp_auto->detail_ctrl[i];
        vcap_auto->detail_ctrl_threshold[i] = isp_auto->detail_ctrl_threshold[i];
        vcap_auto->edge_filt_strength[i] = isp_auto->edge_filt_strength[i];
        vcap_auto->edge_filt_max_cap[i] = isp_auto->edge_filt_max_cap[i];
        vcap_auto->r_gain[i] = isp_auto->r_gain[i];
        vcap_auto->g_gain[i] = isp_auto->g_gain[i];
        vcap_auto->b_gain[i] = isp_auto->b_gain[i];
        vcap_auto->skin_gain[i] = isp_auto->skin_gain[i];
        vcap_auto->max_sharp_gain[i] = isp_auto->max_sharp_gain[i];
    }
}

static td_void mapi_adapt_vcap_fill_vcap_sharpen_manual_attr(hi_mapi_vcap_sharp_manual_attr *vcap_manual,
    const ot_isp_sharpen_manual_attr *isp_manual)
{
    for (td_u32 i = 0; i < OT_ISP_SHARPEN_LUMA_NUM; i++) {
        vcap_manual->luma_wgt[i] = isp_manual->luma_wgt[i];
    }
    for (td_u32 i = 0; i < OT_ISP_SHARPEN_LUMA_NUM; i++) {
        vcap_manual->texture_strength[i] = isp_manual->texture_strength[i];
        vcap_manual->edge_strength[i] = isp_manual->edge_strength[i];
        vcap_manual->motion_texture_strength[i] = isp_manual->motion_texture_strength[i];
        vcap_manual->motion_edge_strength[i] = isp_manual->motion_edge_strength[i];
    }
    vcap_manual->texture_freq = isp_manual->texture_freq;
    vcap_manual->edge_freq = isp_manual->edge_freq;
    vcap_manual->over_shoot = isp_manual->over_shoot;
    vcap_manual->under_shoot = isp_manual->under_shoot;
    vcap_manual->motion_texture_freq = isp_manual->motion_texture_freq;
    vcap_manual->motion_edge_freq = isp_manual->motion_edge_freq;
    vcap_manual->motion_over_shoot = isp_manual->motion_over_shoot;
    vcap_manual->motion_under_shoot = isp_manual->motion_under_shoot;
    vcap_manual->shoot_sup_strength = isp_manual->shoot_sup_strength;
    vcap_manual->shoot_sup_adj = isp_manual->shoot_sup_adj;
    vcap_manual->detail_ctrl = isp_manual->detail_ctrl;
    vcap_manual->detail_ctrl_threshold = isp_manual->detail_ctrl_threshold;
    vcap_manual->edge_filt_strength = isp_manual->edge_filt_strength;
    vcap_manual->edge_filt_max_cap = isp_manual->edge_filt_max_cap;
    vcap_manual->r_gain = isp_manual->r_gain;
    vcap_manual->g_gain = isp_manual->g_gain;
    vcap_manual->b_gain = isp_manual->b_gain;
    vcap_manual->skin_gain = isp_manual->skin_gain;
    vcap_manual->max_sharp_gain = isp_manual->max_sharp_gain;
}

static td_void mapi_adapt_vcap_fill_vcap_sharpen_attr(hi_mapi_vcap_sharpen *vcap_sharpen,
    const ot_isp_sharpen_attr *isp_sharpen)
{
    vcap_sharpen->enable = isp_sharpen->enable;
    vcap_sharpen->motion_enable = isp_sharpen->motion_en;
    vcap_sharpen->motion_threshold0 = isp_sharpen->motion_threshold0;
    vcap_sharpen->motion_threshold1 = isp_sharpen->motion_threshold1;
    vcap_sharpen->motion_gain0 = isp_sharpen->motion_gain0;
    vcap_sharpen->motion_gain1 = isp_sharpen->motion_gain1;
    vcap_sharpen->skin_umin = isp_sharpen->skin_umin;
    vcap_sharpen->skin_vmin = isp_sharpen->skin_vmin;
    vcap_sharpen->skin_umax = isp_sharpen->skin_umax;
    vcap_sharpen->skin_vmax = isp_sharpen->skin_vmax;
    vcap_sharpen->op_type = isp_sharpen->op_type;
    vcap_sharpen->detail_map = isp_sharpen->detail_map;

    mapi_adapt_vcap_fill_vcap_sharpen_auto_attr(&vcap_sharpen->auto_attr, &isp_sharpen->auto_attr);
    mapi_adapt_vcap_fill_vcap_sharpen_manual_attr(&vcap_sharpen->manual_attr, &isp_sharpen->manual_attr);
}

td_s32 mapi_adapt_vcap_get_sharpen(td_handle vcap_pipe_hdl, hi_mapi_vcap_sharpen *vcap_sharpen)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_sharpen_attr isp_sharpen_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_sharpen);

    if (OT_ISP_SHARPEN_GAIN_NUM != HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "get sharpen gain num mismatch,pipe[%u]\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = memset_s(&isp_sharpen_attr, sizeof(isp_sharpen_attr), 0, sizeof(isp_sharpen_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_sharpen_attr(vi_pipe, &isp_sharpen_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_sharpen_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    mapi_adapt_vcap_fill_vcap_sharpen_attr(vcap_sharpen, &isp_sharpen_attr);
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_metering_mode(td_handle vcap_pipe_hdl, const hi_mapi_vcap_metering_mode *vcap_metering_mode)
{
    td_s32 i, j;
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_stats_cfg isp_stat_cfg;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_metering_mode);

    if (HI_MAPI_VCAP_AE_ZONE_ROW != OT_ISP_AE_ZONE_ROW ||
        HI_MAPI_VCAP_AE_ZONE_COLUMN != OT_ISP_AE_ZONE_COLUMN) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "set zone row/col mismatch,pipe[%u]\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = memset_s(&isp_stat_cfg, sizeof(isp_stat_cfg), 0, sizeof(isp_stat_cfg));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_stats_cfg(vi_pipe, &isp_stat_cfg);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_stats_cfg fail,pipe[%d]\n", vcap_pipe_hdl);

    for (i = 0; i < OT_ISP_AE_ZONE_ROW; i++) {
        for (j = 0; j < OT_ISP_AE_ZONE_COLUMN; j++) {
            isp_stat_cfg.ae_cfg.weight[i][j] = vcap_metering_mode->weight[i][j];
        }
    }

    ret = ss_mpi_isp_set_stats_cfg(vi_pipe, &isp_stat_cfg);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_stats_cfg fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_metering_mode(td_handle vcap_pipe_hdl, hi_mapi_vcap_metering_mode *vcap_metering_mode)
{
    td_s32 i, j;
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_stats_cfg isp_stat_cfg;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_metering_mode);

    if (HI_MAPI_VCAP_AE_ZONE_ROW != OT_ISP_AE_ZONE_ROW ||
        HI_MAPI_VCAP_AE_ZONE_COLUMN != OT_ISP_AE_ZONE_COLUMN) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "get zone row/col mismatch,pipe[%u]\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = memset_s(&isp_stat_cfg, sizeof(isp_stat_cfg), 0, sizeof(isp_stat_cfg));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_stats_cfg(vi_pipe, &isp_stat_cfg);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_stats_cfg fail,pipe[%d]\n", vcap_pipe_hdl);

    for (i = 0; i < OT_ISP_AE_ZONE_ROW; i++) {
        for (j = 0; j < OT_ISP_AE_ZONE_COLUMN; j++) {
            vcap_metering_mode->weight[i][j] = isp_stat_cfg.ae_cfg.weight[i][j];
        }
    }

    return TD_SUCCESS;
}

static td_void mapi_adapt_vcap_generate_isp_wdr_fs_attr(const hi_mapi_vcap_isp_wdr_fs_attr *vcap_wdr_fs_attr,
    ot_isp_wdr_fs_attr *isp_wdr_fs_attr)
{
    isp_wdr_fs_attr->wdr_merge_mode = vcap_wdr_fs_attr->wdr_merge_mode;
    isp_wdr_fs_attr->wdr_combine.motion_comp = vcap_wdr_fs_attr->wdr_combine.motion_comp;
    isp_wdr_fs_attr->wdr_combine.short_threshold = vcap_wdr_fs_attr->wdr_combine.short_thr;
    isp_wdr_fs_attr->wdr_combine.long_threshold = vcap_wdr_fs_attr->wdr_combine.long_thr;
    isp_wdr_fs_attr->wdr_combine.force_long = vcap_wdr_fs_attr->wdr_combine.force_long;
    isp_wdr_fs_attr->wdr_combine.force_long_low_threshold = vcap_wdr_fs_attr->wdr_combine.force_long_low_thr;
    isp_wdr_fs_attr->wdr_combine.force_long_hig_threshold = vcap_wdr_fs_attr->wdr_combine.force_long_hig_thr;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.short_expo_chk = vcap_wdr_fs_attr->wdr_combine.wdr_mdt.short_expo_chk;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.short_check_threshold = vcap_wdr_fs_attr->wdr_combine.wdr_mdt.short_check_thd;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.md_ref_flicker = vcap_wdr_fs_attr->wdr_combine.wdr_mdt.md_ref_flicker;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_still_threshold = vcap_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_still_thd;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_full_threshold = vcap_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_full_thd;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_long_blend = vcap_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_long_blend;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.op_type = vcap_wdr_fs_attr->wdr_combine.wdr_mdt.op_type;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.manual_attr.md_thr_low_gain =
        vcap_wdr_fs_attr->wdr_combine.wdr_mdt.manual_attr.md_thr_low_gain;
    isp_wdr_fs_attr->wdr_combine.wdr_mdt.manual_attr.md_thr_hig_gain =
        vcap_wdr_fs_attr->wdr_combine.wdr_mdt.manual_attr.md_thr_hig_gain;
    for (td_u32 i = 0; i < HI_MAPI_VCAP_ISP_WDR_RATIO_NUM; i++) {
        for (td_u32 j = 0; j < HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM; j++) {
            isp_wdr_fs_attr->wdr_combine.wdr_mdt.auto_attr.md_thr_low_gain[i][j] =
                vcap_wdr_fs_attr->wdr_combine.wdr_mdt.auto_attr.md_thr_low_gain[i][j];
            isp_wdr_fs_attr->wdr_combine.wdr_mdt.auto_attr.md_thr_hig_gain[i][j] =
                vcap_wdr_fs_attr->wdr_combine.wdr_mdt.auto_attr.md_thr_hig_gain[i][j];
        }
    }
    for (td_u32 i = 0; i < HI_MAPI_VCAP_ISP_FUSION_RHR_FRAME_NUM; i++) {
        isp_wdr_fs_attr->fusion_attr.fusion_threshold[i] = vcap_wdr_fs_attr->fusion.fusion_thr[i];
    }
}

td_s32 mapi_adapt_vcap_set_isp_wdr_fs_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_wdr_fs_attr *vcap_wdr_fs_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_wdr_fs_attr isp_wdr_fs_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_wdr_fs_attr);

    ret = memset_s(&isp_wdr_fs_attr, sizeof(isp_wdr_fs_attr), 0, sizeof(isp_wdr_fs_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    mapi_adapt_vcap_generate_isp_wdr_fs_attr(vcap_wdr_fs_attr, &isp_wdr_fs_attr);

    ret = ss_mpi_isp_set_fswdr_attr(vi_pipe, &isp_wdr_fs_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_fswdr_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

static td_void mapi_adapt_vcap_generate_mapi_wdr_fs_attr(const ot_isp_wdr_fs_attr *isp_wdr_fs_attr,
    hi_mapi_vcap_isp_wdr_fs_attr *vcap_wdr_fs_attr)
{
    vcap_wdr_fs_attr->wdr_merge_mode = isp_wdr_fs_attr->wdr_merge_mode;
    vcap_wdr_fs_attr->wdr_combine.motion_comp = isp_wdr_fs_attr->wdr_combine.motion_comp;
    vcap_wdr_fs_attr->wdr_combine.short_thr = isp_wdr_fs_attr->wdr_combine.short_threshold;
    vcap_wdr_fs_attr->wdr_combine.long_thr = isp_wdr_fs_attr->wdr_combine.long_threshold;
    vcap_wdr_fs_attr->wdr_combine.force_long = isp_wdr_fs_attr->wdr_combine.force_long;
    vcap_wdr_fs_attr->wdr_combine.force_long_low_thr = isp_wdr_fs_attr->wdr_combine.force_long_low_threshold;
    vcap_wdr_fs_attr->wdr_combine.force_long_hig_thr = isp_wdr_fs_attr->wdr_combine.force_long_hig_threshold;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.short_expo_chk = isp_wdr_fs_attr->wdr_combine.wdr_mdt.short_expo_chk;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.short_check_thd = isp_wdr_fs_attr->wdr_combine.wdr_mdt.short_check_threshold;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.md_ref_flicker = isp_wdr_fs_attr->wdr_combine.wdr_mdt.md_ref_flicker;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_still_thd = isp_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_still_threshold;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_full_thd = isp_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_full_threshold;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_long_blend = isp_wdr_fs_attr->wdr_combine.wdr_mdt.mdt_long_blend;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.op_type = isp_wdr_fs_attr->wdr_combine.wdr_mdt.op_type;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.manual_attr.md_thr_low_gain =
        isp_wdr_fs_attr->wdr_combine.wdr_mdt.manual_attr.md_thr_low_gain;
    vcap_wdr_fs_attr->wdr_combine.wdr_mdt.manual_attr.md_thr_hig_gain =
        isp_wdr_fs_attr->wdr_combine.wdr_mdt.manual_attr.md_thr_hig_gain;
    for (td_u32 i = 0; i < HI_MAPI_VCAP_ISP_WDR_RATIO_NUM; i++) {
        for (td_u32 j = 0; j < HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM; j++) {
            vcap_wdr_fs_attr->wdr_combine.wdr_mdt.auto_attr.md_thr_low_gain[i][j] =
                isp_wdr_fs_attr->wdr_combine.wdr_mdt.auto_attr.md_thr_low_gain[i][j];
            vcap_wdr_fs_attr->wdr_combine.wdr_mdt.auto_attr.md_thr_hig_gain[i][j] =
                isp_wdr_fs_attr->wdr_combine.wdr_mdt.auto_attr.md_thr_hig_gain[i][j];
        }
    }
    for (td_u32 i = 0; i < HI_MAPI_VCAP_ISP_FUSION_RHR_FRAME_NUM; i++) {
        vcap_wdr_fs_attr->fusion.fusion_thr[i] = isp_wdr_fs_attr->fusion_attr.fusion_threshold[i];
    }
}

td_s32 mapi_adapt_vcap_get_isp_wdr_fs_attr(td_handle vcap_pipe_hdl, hi_mapi_vcap_isp_wdr_fs_attr *vcap_wdr_fs_attr)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_wdr_fs_attr isp_wdr_fs_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_wdr_fs_attr);

    ret = memset_s(&isp_wdr_fs_attr, sizeof(isp_wdr_fs_attr), 0, sizeof(isp_wdr_fs_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_fswdr_attr(vi_pipe, &isp_wdr_fs_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_fswdr_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    mapi_adapt_vcap_generate_mapi_wdr_fs_attr(&isp_wdr_fs_attr, vcap_wdr_fs_attr);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_isp_pipe_diff_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_pipe_diff_attr *vcap_pipe_diff_attr)
{
    td_s32 i;
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_pipe_diff_attr isp_pipe_diff_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_pipe_diff_attr);

    if (HI_MAPI_VCAP_ISP_FUSION_RHR_FRAME_NUM != OT_ISP_BAYER_CHN_NUM ||
        HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE != OT_ISP_CCM_MATRIX_SIZE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "set bayer chn / ccm size mismatch,pipe[%u]\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = memset_s(&isp_pipe_diff_attr, sizeof(isp_pipe_diff_attr), 0, sizeof(isp_pipe_diff_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    for (i = 0; i < HI_MAPI_VCAP_ISP_FUSION_RHR_FRAME_NUM; i++) {
        isp_pipe_diff_attr.offset[i] = vcap_pipe_diff_attr->offset[i];
        isp_pipe_diff_attr.gain[i] = vcap_pipe_diff_attr->gain[i];
    }

    for (i = 0; i < HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE; i++) {
        isp_pipe_diff_attr.color_matrix[i] = vcap_pipe_diff_attr->color_matrix[i];
    }

    ret = ss_mpi_isp_set_pipe_differ_attr(vi_pipe, &isp_pipe_diff_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_set_pipe_differ_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_isp_pipe_diff_attr(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_pipe_diff_attr *vcap_pipe_diff_attr)
{
    td_s32 i;
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_pipe_diff_attr isp_pipe_diff_attr;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_pipe_diff_attr);

    if (HI_MAPI_VCAP_ISP_FUSION_RHR_FRAME_NUM != OT_ISP_BAYER_CHN_NUM ||
        HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE != OT_ISP_CCM_MATRIX_SIZE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "get bayer chn / ccm size mismatch,pipe[%u]\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = memset_s(&isp_pipe_diff_attr, sizeof(isp_pipe_diff_attr), 0, sizeof(isp_pipe_diff_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_pipe_differ_attr(vi_pipe, &isp_pipe_diff_attr);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_pipe_differ_attr fail,pipe[%d]\n", vcap_pipe_hdl);

    for (i = 0; i < HI_MAPI_VCAP_ISP_FUSION_RHR_FRAME_NUM; i++) {
        vcap_pipe_diff_attr->offset[i] = isp_pipe_diff_attr.offset[i];
        vcap_pipe_diff_attr->gain[i] = isp_pipe_diff_attr.gain[i];
    }
    for (i = 0; i < HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE; i++) {
        vcap_pipe_diff_attr->color_matrix[i] = isp_pipe_diff_attr.color_matrix[i];
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_isp_local_cac_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_local_cac_attr *vcap_local_cac_attr)
{
    TD_UNUSED(vcap_pipe_hdl);
    TD_UNUSED(vcap_local_cac_attr);
    MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support\n");
    return HI_MAPI_VCAP_ENOTSUPPORT;
}

td_s32 mapi_adapt_vcap_get_isp_local_cac_attr(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_isp_local_cac_attr *vcap_local_cac_attr)
{
    TD_UNUSED(vcap_pipe_hdl);
    TD_UNUSED(vcap_local_cac_attr);
    MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support\n");
    return HI_MAPI_VCAP_ENOTSUPPORT;
}

td_s32 mapi_adapt_vcap_get_dng_image_static_info(td_handle vcap_pipe_hdl,
    hi_mapi_vcap_dng_image_static_info *vcap_dng_info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_isp_dng_image_static_info dng_static_info;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_dng_info);

    ret = memset_s(&dng_static_info, sizeof(dng_static_info), 0, sizeof(dng_static_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_isp_get_dng_image_static_info(vi_pipe, &dng_static_info);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_isp_get_dng_image_static_info fail,pipe[%d]\n", vcap_pipe_hdl);

    ret = memcpy_s(vcap_dng_info, sizeof(hi_mapi_vcap_dng_image_static_info),
        &dng_static_info, sizeof(dng_static_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_cmp_param(td_handle vcap_pipe_hdl, hi_mapi_vcap_cmp_param *vcap_cmp_param)
{
    td_s32 i;
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_compress_param vi_cmp_param;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_cmp_param);

    if (HI_MAPI_VCAP_CMP_PARAM_SIZE != OT_VI_COMPRESS_PARAM_SIZE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "get OT_VI_COMPRESS_PARAM_SIZE not match,pipe[%u]\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = memset_s(&vi_cmp_param, sizeof(vi_cmp_param), 0, sizeof(vi_cmp_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_vi_get_pipe_compress_param(vi_pipe, &vi_cmp_param);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_get_pipe_compress_param fail,pipe[%d]\n", vcap_pipe_hdl);

    for (i = 0; i < OT_VI_COMPRESS_PARAM_SIZE; i++) {
        vcap_cmp_param->cmp_param[i] = vi_cmp_param.compress_param[i];
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_chn_crop_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_crop_info *vcap_crop_info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_vi_crop_info vi_crop_info;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_crop_info);

    ret = memset_s(&vi_crop_info, sizeof(vi_crop_info), 0, sizeof(vi_crop_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    vi_crop_info.enable = vcap_crop_info->enable;
    vi_crop_info.crop_mode = vcap_crop_info->crop_coordinate;
    vi_crop_info.rect.x = vcap_crop_info->crop_rect.x;
    vi_crop_info.rect.y = vcap_crop_info->crop_rect.y;
    vi_crop_info.rect.width = vcap_crop_info->crop_rect.width;
    vi_crop_info.rect.height = vcap_crop_info->crop_rect.height;

    ret = ss_mpi_vi_set_chn_crop(vi_pipe, vi_chn, &vi_crop_info);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_set_chn_crop failed,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_chn_crop_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_vcap_crop_info *vcap_crop_info)
{
    td_s32 ret;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_vi_chn vi_chn = (ot_vi_chn)pipe_chn_hdl;
    ot_vi_crop_info vi_crop_info;
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_crop_info);

    ret = memset_s(&vi_crop_info, sizeof(vi_crop_info), 0, sizeof(vi_crop_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = ss_mpi_vi_get_chn_crop(vi_pipe, vi_chn, &vi_crop_info);
    CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_get_chn_crop failed,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    vcap_crop_info->enable = vi_crop_info.enable;
    vcap_crop_info->crop_coordinate = vi_crop_info.crop_mode;
    vcap_crop_info->crop_rect.x = vi_crop_info.rect.x;
    vcap_crop_info->crop_rect.y = vi_crop_info.rect.y;
    vcap_crop_info->crop_rect.width = vi_crop_info.rect.width;
    vcap_crop_info->crop_rect.height = vi_crop_info.rect.height;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_set_pipe_dump_attr(td_handle vcap_pipe_hdl, const hi_mapi_dump_attr *vcap_dump_info)
{
	td_s32 ret;
	ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
	ot_vi_frame_dump_attr vi_dump_attr;
	CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_dump_info);

	ret = memset_s(&vi_dump_attr, sizeof(vi_dump_attr), 0, sizeof(vi_dump_attr));
	CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

	vi_dump_attr.enable = vcap_dump_info->enable;
	vi_dump_attr.depth = vcap_dump_info->depth;

	ret = ss_mpi_vi_set_pipe_frame_dump_attr(vi_pipe, &vi_dump_attr);
	CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_set_pipe_frame_dump_attr failed,pipe[%d]\n", vcap_pipe_hdl);

	return TD_SUCCESS;
}

#if 0
/* RAW related adapt APIs - external 6 RAW APIs deleted by demand 3, kept under #if 0 for future restore */
static td_void mapi_adapt_vcap_get_mapi_video_supplement(const ot_video_supplement *src_supplement,
    hi_mapi_video_supplement *dst_supplement)
{
    dst_supplement->misc_info_phys_addr = src_supplement->misc_info_phys_addr;
    dst_supplement->jpeg_dcf_phy_addr = src_supplement->jpeg_dcf_phys_addr;
    dst_supplement->isp_info_phy_addr = src_supplement->isp_info_phys_addr;
    dst_supplement->low_delay_phy_addr = src_supplement->low_delay_phys_addr;
    dst_supplement->bnr_mot_phy_addr = src_supplement->bnr_mot_phys_addr;
    dst_supplement->motion_data_phy_addr = src_supplement->motion_data_phys_addr;
    dst_supplement->frame_dng_phy_addr = src_supplement->frame_dng_phys_addr;

    dst_supplement->misc_info_vir_addr = src_supplement->misc_info_virt_addr;
    dst_supplement->jpeg_dcf_vir_addr = src_supplement->jpeg_dcf_virt_addr;
    dst_supplement->isp_info_vir_addr = src_supplement->isp_info_virt_addr;
    dst_supplement->low_delay_vir_addr = src_supplement->low_delay_virt_addr;
    dst_supplement->bnr_mot_virt_addr = src_supplement->bnr_mot_virt_addr;
    dst_supplement->motion_data_vir_addr = src_supplement->motion_data_virt_addr;
    dst_supplement->frame_dng_vir_addr = src_supplement->frame_dng_virt_addr;
}

static td_void mapi_adapt_vcap_get_mpi_video_supplement(const hi_mapi_video_supplement *src_supplement,
    ot_video_supplement *dst_supplement)
{
    dst_supplement->misc_info_phys_addr = src_supplement->misc_info_phys_addr;
    dst_supplement->jpeg_dcf_phys_addr = src_supplement->jpeg_dcf_phy_addr;
    dst_supplement->isp_info_phys_addr = src_supplement->isp_info_phy_addr;
    dst_supplement->low_delay_phys_addr = src_supplement->low_delay_phy_addr;
    dst_supplement->bnr_mot_phys_addr = src_supplement->bnr_mot_phy_addr;
    dst_supplement->motion_data_phys_addr = src_supplement->motion_data_phy_addr;
    dst_supplement->frame_dng_phys_addr = src_supplement->frame_dng_phy_addr;

    dst_supplement->misc_info_virt_addr = src_supplement->misc_info_vir_addr;
    dst_supplement->jpeg_dcf_virt_addr = src_supplement->jpeg_dcf_vir_addr;
    dst_supplement->isp_info_virt_addr = src_supplement->isp_info_vir_addr;
    dst_supplement->low_delay_virt_addr = src_supplement->low_delay_vir_addr;
    dst_supplement->bnr_mot_virt_addr = src_supplement->bnr_mot_virt_addr;
    dst_supplement->motion_data_virt_addr = src_supplement->motion_data_vir_addr;
    dst_supplement->frame_dng_virt_addr = src_supplement->frame_dng_vir_addr;
}

td_s32 mapi_adapt_vcap_set_pipe_bnr_raw_dump_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_bnr_dump_attr *vcap_dump_bnr_attr)
{
    TD_UNUSED(vcap_pipe_hdl);
    if (vcap_dump_bnr_attr->enable == TD_TRUE) {
        ot_vb_supplement_cfg supplement_config = {0};
        if (ss_mpi_vb_get_supplement_cfg(&supplement_config) != TD_SUCCESS) {
            supplement_config.supplement_cfg = OT_VB_SUPPLEMENT_BNR_MOT_MASK;
        } else {
            supplement_config.supplement_cfg |= OT_VB_SUPPLEMENT_BNR_MOT_MASK;
        }
        ss_mpi_vb_set_supplement_cfg(&supplement_config);
    } else {
        TD_UNUSED(vcap_dump_bnr_attr);
    }
    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_get_pipe_raw(td_handle vcap_pipe_hdl, td_bool is_bnr_raw,
    td_u32 frame_timeout, hi_mapi_frame_data *frame_data)
{
    td_s32 ret;
    td_s32 i;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_video_frame_info video_frame;
    CHECK_MAPI_VCAP_NULL_PTR_RET(frame_data);

    ret = memset_s(&video_frame, sizeof(video_frame), 0, sizeof(video_frame));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    if (is_bnr_raw) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "err:not support BNR!\n");
        return HI_MAPI_VCAP_ENOTSUPPORT;
    } else {
        ret = ss_mpi_vi_get_pipe_frame(vi_pipe, &video_frame, frame_timeout);
        CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_get_pipe_frame failed,pipe[%d]\n", vcap_pipe_hdl);
    }

    mapi_adapt_vcap_get_mapi_video_supplement(&video_frame.video_frame.supplement, &frame_data->video_supplement);

    frame_data->compress_mode = video_frame.video_frame.compress_mode;
    frame_data->frame_data_type = HI_MAPI_FRAME_DATA_TYPE_RAW;
    frame_data->pixel_format = video_frame.video_frame.pixel_format;
    frame_data->video_format = video_frame.video_frame.video_format;
    frame_data->height = video_frame.video_frame.height;
    frame_data->width = video_frame.video_frame.width;
    frame_data->pool_id = video_frame.pool_id;
    frame_data->pts = video_frame.video_frame.pts;

    for (i = 0; i < 2; i++) { /* 2: phys / virt addr array len */
        frame_data->phy_addr[i] = video_frame.video_frame.phys_addr[i];
        frame_data->stride[i] = video_frame.video_frame.stride[i];
        frame_data->vir_addr[i] = (td_u64)(uintptr_t)video_frame.video_frame.virt_addr[i];
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vcap_release_pipe_raw(td_handle vcap_pipe_hdl, td_bool is_bnr_raw,
    const hi_mapi_frame_data *frame_data)
{
    td_s32 ret;
    td_s32 i;
    ot_vi_pipe vi_pipe = (ot_vi_pipe)vcap_pipe_hdl;
    ot_video_frame_info video_frame;
    CHECK_MAPI_VCAP_NULL_PTR_RET(frame_data);

    ret = memset_s(&video_frame, sizeof(video_frame), 0, sizeof(video_frame));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    video_frame.video_frame.pixel_format = frame_data->pixel_format;
    video_frame.video_frame.video_format = frame_data->video_format;
    video_frame.video_frame.height = frame_data->height;
    video_frame.video_frame.width = frame_data->width;
    video_frame.pool_id = frame_data->pool_id;
    video_frame.video_frame.pts = frame_data->pts;

    for (i = 0; i < 2; i++) { /* 2: phys / virt addr array len */
        video_frame.video_frame.phys_addr[i] = frame_data->phy_addr[i];
        video_frame.video_frame.stride[i] = frame_data->stride[i];
        video_frame.video_frame.virt_addr[i] = (td_void *)(uintptr_t)frame_data->vir_addr[i];
    }

    mapi_adapt_vcap_get_mpi_video_supplement(&frame_data->video_supplement, &video_frame.video_frame.supplement);

    if (is_bnr_raw) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "err:not support BNR!\n");
        return HI_MAPI_VCAP_ENOTSUPPORT;
    } else {
        ret = ss_mpi_vi_release_pipe_frame(vi_pipe, &video_frame);
        CHECK_MAPI_VCAP_RET(ret, "call ss_mpi_vi_release_pipe_frame failed,pipe[%d]\n", vcap_pipe_hdl);
    }

    return TD_SUCCESS;
}
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
