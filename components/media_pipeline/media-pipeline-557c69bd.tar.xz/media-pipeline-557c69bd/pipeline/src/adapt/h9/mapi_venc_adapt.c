/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_venc_adapt.h"
#include "mapi_comm_adapt.h"
#include "mapi_venc_inner.h"
#include "mapi_comm_inner.h"
#include "ss_mpi_sys.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define FRAME_BUF_RATIO 100

td_s32 mapi_adapt_venc_set_h264_mod_param(const mapi_adapt_venc_mod_param *venc_mod_para)
{
    ot_venc_mod_param param;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_mod_para);

    td_s32 ret = memset_s(&param, sizeof(ot_venc_mod_param), 0, sizeof(ot_venc_mod_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    param.mod_type = OT_VENC_MOD_H264;
    ret = ss_mpi_venc_get_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_mod_param", ret);

    param.h264_mod_param.one_stream_buf = venc_mod_para->one_stream_buf;
    param.h264_mod_param.mini_buf_mode = venc_mod_para->mini_buf_mode;
    param.h264_mod_param.low_power_mode = venc_mod_para->low_power_mode;
    ret = ss_mpi_venc_set_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_mod_param", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_h265_mod_param(const mapi_adapt_venc_mod_param *venc_mod_para)
{
    ot_venc_mod_param param;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_mod_para);

    td_s32 ret = memset_s(&param, sizeof(ot_venc_mod_param), 0, sizeof(ot_venc_mod_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    param.mod_type = OT_VENC_MOD_H265;
    ret = ss_mpi_venc_get_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_mod_param", ret);
    param.h265_mod_param.one_stream_buf = venc_mod_para->one_stream_buf;
    param.h265_mod_param.mini_buf_mode = venc_mod_para->mini_buf_mode;
    param.h265_mod_param.low_power_mode = venc_mod_para->low_power_mode;
    ret = ss_mpi_venc_set_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_mod_param", ret);

    return TD_SUCCESS;
}

/* jpeg 无 low_power_mode，仅配置公共字段 one_stream_buf / mini_buf_mode（jpeg cmd 同时覆盖 MJPEG） */
td_s32 mapi_adapt_venc_set_jpeg_mod_param(const mapi_adapt_venc_mod_param *venc_mod_para)
{
    ot_venc_mod_param param;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_mod_para);

    td_s32 ret = memset_s(&param, sizeof(ot_venc_mod_param), 0, sizeof(ot_venc_mod_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    param.mod_type = OT_VENC_MOD_JPEG;
    ret = ss_mpi_venc_get_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_mod_param", ret);

    param.jpeg_mod_param.one_stream_buf = venc_mod_para->one_stream_buf;
    param.jpeg_mod_param.mini_buf_mode = venc_mod_para->mini_buf_mode;
    ret = ss_mpi_venc_set_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_mod_param", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_h264_mod_param(mapi_adapt_venc_mod_param *venc_mod_para)
{
    ot_venc_mod_param param;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_mod_para);

    td_s32 ret = memset_s(&param, sizeof(ot_venc_mod_param), 0, sizeof(ot_venc_mod_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    param.mod_type = OT_VENC_MOD_H264;
    ret = ss_mpi_venc_get_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_mod_param", ret);

    venc_mod_para->one_stream_buf = param.h264_mod_param.one_stream_buf;
    venc_mod_para->mini_buf_mode = param.h264_mod_param.mini_buf_mode;
    venc_mod_para->low_power_mode = param.h264_mod_param.low_power_mode;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_h265_mod_param(mapi_adapt_venc_mod_param *venc_mod_para)
{
    ot_venc_mod_param param;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_mod_para);

    td_s32 ret = memset_s(&param, sizeof(ot_venc_mod_param), 0, sizeof(ot_venc_mod_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    param.mod_type = OT_VENC_MOD_H265;
    ret = ss_mpi_venc_get_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_mod_param", ret);

    venc_mod_para->one_stream_buf = param.h265_mod_param.one_stream_buf;
    venc_mod_para->mini_buf_mode = param.h265_mod_param.mini_buf_mode;
    venc_mod_para->low_power_mode = param.h265_mod_param.low_power_mode;

    return TD_SUCCESS;
}

/* jpeg 无 low_power_mode，回填公共字段后将 low_power_mode 置 0 */
td_s32 mapi_adapt_venc_get_jpeg_mod_param(mapi_adapt_venc_mod_param *venc_mod_para)
{
    ot_venc_mod_param param;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_mod_para);

    td_s32 ret = memset_s(&param, sizeof(ot_venc_mod_param), 0, sizeof(ot_venc_mod_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    param.mod_type = OT_VENC_MOD_JPEG;
    ret = ss_mpi_venc_get_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_mod_param", ret);

    venc_mod_para->one_stream_buf = param.jpeg_mod_param.one_stream_buf;
    venc_mod_para->mini_buf_mode = param.jpeg_mod_param.mini_buf_mode;
    venc_mod_para->low_power_mode = 0;

    return TD_SUCCESS;
}

#ifdef SUPPORT_SVAC3
td_s32 mapi_adapt_venc_set_svac3_mod_param(const hi_mapi_sys_venc_mode_param *venc_mod_para)
{
    ot_venc_mod_param param;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_mod_para);

    td_s32 ret = memset_s(&param, sizeof(ot_venc_mod_param), 0, sizeof(ot_venc_mod_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    param.mod_type = OT_VENC_MOD_SVAC3;
    ret = ss_mpi_venc_get_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_mod_param", ret);
    param.svac3_mod_param.one_stream_buf = 1;
    param.svac3_mod_param.low_power_mode = venc_mod_para->svac3e_low_power_mode;
    ret = ss_mpi_venc_set_mod_param(&param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_mod_param", ret);

    return TD_SUCCESS;
}
#endif

static td_void mapi_adapt_venc_config_h264_cbr_attr(const hi_mapi_venc_cbr_attr *cbr_attr, ot_venc_h264_cbr *h264Cbr)
{
    h264Cbr->gop = cbr_attr->gop;
    h264Cbr->stats_time = cbr_attr->stat_time;
    h264Cbr->src_frame_rate = cbr_attr->src_frame_rate;
    h264Cbr->dst_frame_rate = cbr_attr->dst_frame_rate;
    h264Cbr->bit_rate = cbr_attr->bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_h264_vbr_attr(const hi_mapi_venc_vbr_attr *vbr_attr, ot_venc_h264_vbr *h264Vbr)
{
    h264Vbr->gop = vbr_attr->gop;
    h264Vbr->stats_time = vbr_attr->stat_time;
    h264Vbr->src_frame_rate = vbr_attr->src_frame_rate;
    h264Vbr->dst_frame_rate = vbr_attr->dst_frame_rate;
    h264Vbr->max_bit_rate = vbr_attr->max_bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_h264_qvbr_attr(const hi_mapi_venc_qvbr_attr *qvbr_attr, ot_venc_h264_qvbr *h264Qvbr)
{
    h264Qvbr->gop = qvbr_attr->gop;
    h264Qvbr->stats_time = qvbr_attr->stat_time;
    h264Qvbr->src_frame_rate = qvbr_attr->src_frame_rate;
    h264Qvbr->dst_frame_rate = qvbr_attr->dst_frame_rate;
    h264Qvbr->target_bit_rate = qvbr_attr->target_bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_h264_cvbr_attr(const hi_mapi_venc_cvbr_attr *cvbr_attr, ot_venc_h264_cvbr *h264Cvbr)
{
    h264Cvbr->gop = cvbr_attr->gop;
    h264Cvbr->stats_time = cvbr_attr->stat_time;
    h264Cvbr->src_frame_rate = cvbr_attr->src_frame_rate;
    h264Cvbr->dst_frame_rate = cvbr_attr->dst_frame_rate;
    h264Cvbr->max_bit_rate = cvbr_attr->max_bit_rate;
    h264Cvbr->short_term_stats_time = cvbr_attr->short_term_stat_time;
    h264Cvbr->long_term_stats_time = cvbr_attr->long_term_stat_time;
    h264Cvbr->long_term_max_bit_rate = cvbr_attr->long_term_max_bitrate;
    h264Cvbr->long_term_min_bit_rate = cvbr_attr->long_term_min_bitrate;

    return;
}

static td_void mapi_adapt_venc_config_h264_avbr_attr(const hi_mapi_venc_avbr_attr *avbr_attr, ot_venc_h264_avbr *h264Avbr)
{
    h264Avbr->gop = avbr_attr->gop;
    h264Avbr->stats_time = avbr_attr->stat_time;
    h264Avbr->src_frame_rate = avbr_attr->src_frame_rate;
    h264Avbr->dst_frame_rate = avbr_attr->dst_frame_rate;
    h264Avbr->max_bit_rate = avbr_attr->max_bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_h265_cbr_attr(const hi_mapi_venc_cbr_attr *cbr_attr, ot_venc_h265_cbr *h265Cbr)
{
    h265Cbr->gop = cbr_attr->gop;
    h265Cbr->stats_time = cbr_attr->stat_time;
    h265Cbr->src_frame_rate = cbr_attr->src_frame_rate;
    h265Cbr->dst_frame_rate = cbr_attr->dst_frame_rate;
    h265Cbr->bit_rate = cbr_attr->bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_h265_vbr_attr(const hi_mapi_venc_vbr_attr *vbr_attr, ot_venc_h265_vbr *h265Vbr)
{
    h265Vbr->gop = vbr_attr->gop;
    h265Vbr->stats_time = vbr_attr->stat_time;
    h265Vbr->src_frame_rate = vbr_attr->src_frame_rate;
    h265Vbr->dst_frame_rate = vbr_attr->dst_frame_rate;
    h265Vbr->max_bit_rate = vbr_attr->max_bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_h265_qvbr_attr(const hi_mapi_venc_qvbr_attr *qvbr_attr, ot_venc_h265_qvbr *h265Qvbr)
{
    h265Qvbr->gop = qvbr_attr->gop;
    h265Qvbr->stats_time = qvbr_attr->stat_time;
    h265Qvbr->src_frame_rate = qvbr_attr->src_frame_rate;
    h265Qvbr->dst_frame_rate = qvbr_attr->dst_frame_rate;
    h265Qvbr->target_bit_rate = qvbr_attr->target_bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_h265_cvbr_attr(const hi_mapi_venc_cvbr_attr *cvbr_attr, ot_venc_h265_cvbr *h265Cvbr)
{
    h265Cvbr->gop = cvbr_attr->gop;
    h265Cvbr->stats_time = cvbr_attr->stat_time;
    h265Cvbr->src_frame_rate = cvbr_attr->src_frame_rate;
    h265Cvbr->dst_frame_rate = cvbr_attr->dst_frame_rate;
    h265Cvbr->max_bit_rate = cvbr_attr->max_bit_rate;
    h265Cvbr->short_term_stats_time = cvbr_attr->short_term_stat_time;
    h265Cvbr->long_term_stats_time = cvbr_attr->long_term_stat_time;
    h265Cvbr->long_term_max_bit_rate = cvbr_attr->long_term_max_bitrate;
    h265Cvbr->long_term_min_bit_rate = cvbr_attr->long_term_min_bitrate;

    return;
}

static td_void mapi_adapt_venc_config_h265_avbr_attr(const hi_mapi_venc_avbr_attr *avbr_attr, ot_venc_h265_avbr *h265Avbr)
{
    h265Avbr->gop = avbr_attr->gop;
    h265Avbr->stats_time = avbr_attr->stat_time;
    h265Avbr->src_frame_rate = avbr_attr->src_frame_rate;
    h265Avbr->dst_frame_rate = avbr_attr->dst_frame_rate;
    h265Avbr->max_bit_rate = avbr_attr->max_bit_rate;

    return;
}

#ifdef SUPPORT_SVAC3
static td_void mapi_adapt_venc_config_svac3_cbr_attr(const hi_mapi_venc_cbr_attr *cbr_attr, ot_venc_svac3_cbr *svac3Cbr)
{
    svac3Cbr->gop = cbr_attr->gop;
    svac3Cbr->stats_time = cbr_attr->stat_time;
    svac3Cbr->src_frame_rate = cbr_attr->src_frame_rate;
    svac3Cbr->dst_frame_rate = cbr_attr->dst_frame_rate;
    svac3Cbr->bit_rate = cbr_attr->bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_svac3_vbr_attr(const hi_mapi_venc_vbr_attr *vbr_attr, ot_venc_svac3_vbr *svac3Vbr)
{
    svac3Vbr->gop = vbr_attr->gop;
    svac3Vbr->stats_time = vbr_attr->stat_time;
    svac3Vbr->src_frame_rate = vbr_attr->src_frame_rate;
    svac3Vbr->dst_frame_rate = vbr_attr->dst_frame_rate;
    svac3Vbr->max_bit_rate = vbr_attr->max_bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_svac3_qvbr_attr(const hi_mapi_venc_qvbr_attr *qvbr_attr, ot_venc_svac3_qvbr *svac3Qvbr)
{
    svac3Qvbr->gop = qvbr_attr->gop;
    svac3Qvbr->stats_time = qvbr_attr->stat_time;
    svac3Qvbr->src_frame_rate = qvbr_attr->src_frame_rate;
    svac3Qvbr->dst_frame_rate = qvbr_attr->dst_frame_rate;
    svac3Qvbr->target_bit_rate = qvbr_attr->target_bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_svac3_cvbr_attr(const hi_mapi_venc_cvbr_attr *cvbr_attr, ot_venc_svac3_cvbr *svac3Cvbr)
{
    svac3Cvbr->gop = cvbr_attr->gop;
    svac3Cvbr->stats_time = cvbr_attr->stat_time;
    svac3Cvbr->src_frame_rate = cvbr_attr->src_frame_rate;
    svac3Cvbr->dst_frame_rate = cvbr_attr->dst_frame_rate;
    svac3Cvbr->max_bit_rate = cvbr_attr->max_bit_rate;
    svac3Cvbr->short_term_stats_time = cvbr_attr->short_term_stat_time;
    svac3Cvbr->long_term_stats_time = cvbr_attr->long_term_stat_time;
    svac3Cvbr->long_term_max_bit_rate = cvbr_attr->long_term_max_bitrate;
    svac3Cvbr->long_term_min_bit_rate = cvbr_attr->long_term_min_bitrate;

    return;
}

static td_void mapi_adapt_venc_config_svac3_avbr_attr(const hi_mapi_venc_avbr_attr *avbr_attr, ot_venc_svac3_avbr *svac3Avbr)
{
    svac3Avbr->gop = avbr_attr->gop;
    svac3Avbr->stats_time = avbr_attr->stat_time;
    svac3Avbr->src_frame_rate = avbr_attr->src_frame_rate;
    svac3Avbr->dst_frame_rate = avbr_attr->dst_frame_rate;
    svac3Avbr->max_bit_rate = avbr_attr->max_bit_rate;

    return;
}
#endif

static td_void mapi_adapt_venc_config_mjpeg_cbr_attr(const hi_mapi_venc_cbr_attr *cbr_attr, ot_venc_mjpeg_cbr *mjpegCbr)
{
    mjpegCbr->stats_time = cbr_attr->stat_time;
    mjpegCbr->src_frame_rate = cbr_attr->src_frame_rate;
    mjpegCbr->dst_frame_rate = cbr_attr->dst_frame_rate;
    mjpegCbr->bit_rate = cbr_attr->bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_mjpeg_vbr_attr(const hi_mapi_venc_vbr_attr *vbr_attr, ot_venc_mjpeg_vbr *mjpegVbr)
{
    mjpegVbr->stats_time = vbr_attr->stat_time;
    mjpegVbr->src_frame_rate = vbr_attr->src_frame_rate;
    mjpegVbr->dst_frame_rate = vbr_attr->dst_frame_rate;
    mjpegVbr->max_bit_rate = vbr_attr->max_bit_rate;

    return;
}

static td_void mapi_adapt_venc_config_h264_rc_attr(const hi_mapi_venc_rc_attr *rc_attr,
    ot_venc_rc_attr *h264RcAttr)
{
    switch (rc_attr->rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            h264RcAttr->rc_mode = OT_VENC_RC_MODE_H264_CBR;
            mapi_adapt_venc_config_h264_cbr_attr(&rc_attr->cbr_attr, &h264RcAttr->h264_cbr);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            h264RcAttr->rc_mode = OT_VENC_RC_MODE_H264_VBR;
            mapi_adapt_venc_config_h264_vbr_attr(&rc_attr->vbr_attr, &h264RcAttr->h264_vbr);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            h264RcAttr->rc_mode = OT_VENC_RC_MODE_H264_QVBR;
            mapi_adapt_venc_config_h264_qvbr_attr(&rc_attr->qvbr_attr, &h264RcAttr->h264_qvbr);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            h264RcAttr->rc_mode = OT_VENC_RC_MODE_H264_CVBR;
            mapi_adapt_venc_config_h264_cvbr_attr(&rc_attr->cvbr_attr, &h264RcAttr->h264_cvbr);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            h264RcAttr->rc_mode = OT_VENC_RC_MODE_H264_AVBR;
            mapi_adapt_venc_config_h264_avbr_attr(&rc_attr->avbr_attr, &h264RcAttr->h264_avbr);
            break;

        default:
            h264RcAttr->rc_mode = OT_VENC_RC_MODE_H264_CBR;
            mapi_adapt_venc_config_h264_cbr_attr(&rc_attr->cbr_attr, &h264RcAttr->h264_cbr);
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC,
                "RC mode only support CBR or VBR or QVBR or CVBR or AVBR, default use CBR!\n");
            break;
    }

    return;
}

static td_void mapi_adapt_venc_config_h265_rc_attr(const hi_mapi_venc_rc_attr *rc_attr,
    ot_venc_rc_attr *h265RcAttr)
{
    switch (rc_attr->rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            h265RcAttr->rc_mode = OT_VENC_RC_MODE_H265_CBR;
            mapi_adapt_venc_config_h265_cbr_attr(&rc_attr->cbr_attr, &h265RcAttr->h265_cbr);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            h265RcAttr->rc_mode = OT_VENC_RC_MODE_H265_VBR;
            mapi_adapt_venc_config_h265_vbr_attr(&rc_attr->vbr_attr, &h265RcAttr->h265_vbr);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            h265RcAttr->rc_mode = OT_VENC_RC_MODE_H265_QVBR;
            mapi_adapt_venc_config_h265_qvbr_attr(&rc_attr->qvbr_attr, &h265RcAttr->h265_qvbr);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            h265RcAttr->rc_mode = OT_VENC_RC_MODE_H265_CVBR;
            mapi_adapt_venc_config_h265_cvbr_attr(&rc_attr->cvbr_attr, &h265RcAttr->h265_cvbr);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            h265RcAttr->rc_mode = OT_VENC_RC_MODE_H265_AVBR;
            mapi_adapt_venc_config_h265_avbr_attr(&rc_attr->avbr_attr, &h265RcAttr->h265_avbr);
            break;

        default:
            h265RcAttr->rc_mode = OT_VENC_RC_MODE_H265_CBR;
            mapi_adapt_venc_config_h265_cbr_attr(&rc_attr->cbr_attr, &h265RcAttr->h265_cbr);
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC,
                "RC mode only support CBR or VBR or QVBR or CVBR or AVBR, default use CBR!\n");
            break;
    }

    return;
}

#ifdef SUPPORT_SVAC3
static td_void mapi_adapt_venc_config_svac3_rc_attr(const hi_mapi_venc_rc_attr *rc_attr,
    ot_venc_rc_attr *svac3RcAttr)
{
    switch (rc_attr->rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            svac3RcAttr->rc_mode = OT_VENC_RC_MODE_SVAC3_CBR;
            mapi_adapt_venc_config_svac3_cbr_attr(&rc_attr->cbr_attr, &svac3RcAttr->svac3_cbr);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            svac3RcAttr->rc_mode = OT_VENC_RC_MODE_SVAC3_VBR;
            mapi_adapt_venc_config_svac3_vbr_attr(&rc_attr->vbr_attr, &svac3RcAttr->svac3_vbr);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            svac3RcAttr->rc_mode = OT_VENC_RC_MODE_SVAC3_QVBR;
            mapi_adapt_venc_config_svac3_qvbr_attr(&rc_attr->qvbr_attr, &svac3RcAttr->svac3_qvbr);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            svac3RcAttr->rc_mode = OT_VENC_RC_MODE_SVAC3_CVBR;
            mapi_adapt_venc_config_svac3_cvbr_attr(&rc_attr->cvbr_attr, &svac3RcAttr->svac3_cvbr);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            svac3RcAttr->rc_mode = OT_VENC_RC_MODE_SVAC3_AVBR;
            mapi_adapt_venc_config_svac3_avbr_attr(&rc_attr->avbr_attr, &svac3RcAttr->svac3_avbr);
            break;

        default:
            svac3RcAttr->rc_mode = OT_VENC_RC_MODE_SVAC3_CBR;
            mapi_adapt_venc_config_svac3_cbr_attr(&rc_attr->cbr_attr, &svac3RcAttr->svac3_cbr);
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC,
                "RC mode only support CBR or VBR or QVBR or CVBR or AVBR, default use CBR!\n");
            break;
    }

    return;
}
#endif

static td_void mapi_adapt_venc_config_jpeg_attr(const hi_mapi_venc_jpeg_attr *jpeg_attr, ot_venc_jpeg_attr *mpi_jpege_attr)
{
    td_u32 i;

    mpi_jpege_attr->dcf_en = jpeg_attr->enable_dcf;
    mpi_jpege_attr->mpf_cfg.large_thumbnail_num = jpeg_attr->mpf_attr.large_thumb_nail_num;
    mpi_jpege_attr->recv_mode = (ot_venc_pic_recv_mode)jpeg_attr->receive_mode;

    for (i = 0; i < jpeg_attr->mpf_attr.large_thumb_nail_num; i++) {
        mpi_jpege_attr->mpf_cfg.large_thumbnail_size[i].height = jpeg_attr->mpf_attr.large_thumb_nail_size[i].height;
        mpi_jpege_attr->mpf_cfg.large_thumbnail_size[i].width = jpeg_attr->mpf_attr.large_thumb_nail_size[i].width;
    }

    return;
}

static td_void mapi_adapt_venc_config_mjpeg_rc_attr(const hi_mapi_venc_rc_attr *rc_attr,
    ot_venc_rc_attr *mjpegRcAttr)
{
    switch (rc_attr->rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            mjpegRcAttr->rc_mode = OT_VENC_RC_MODE_MJPEG_CBR;
            mapi_adapt_venc_config_mjpeg_cbr_attr(&rc_attr->cbr_attr, &mjpegRcAttr->mjpeg_cbr);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            mjpegRcAttr->rc_mode = OT_VENC_RC_MODE_MJPEG_VBR;
            mapi_adapt_venc_config_mjpeg_vbr_attr(&rc_attr->vbr_attr, &mjpegRcAttr->mjpeg_vbr);
            break;

        default:
            mjpegRcAttr->rc_mode = OT_VENC_RC_MODE_MJPEG_CBR;
            mapi_adapt_venc_config_mjpeg_cbr_attr(&rc_attr->cbr_attr, &mjpegRcAttr->mjpeg_cbr);
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "RC mode only support CBR or VBR, default use CBR!\n");
            break;
    }

    return;
}

td_s32 mapi_adapt_venc_config_attr(const hi_mapi_venc_attr *venc_attr, mapi_adapt_venc_chn_attr *vencChnAttr,
    td_bool rcnRefShareBuf)
{
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_attr);
    CHECK_MAPI_VENC_NULL_PTR_RET(vencChnAttr);

    vencChnAttr->gop_attr.gop_mode = OT_VENC_GOP_MODE_NORMAL_P;
    vencChnAttr->gop_attr.normal_p.ip_qp_delta = 2; /* 2: Recommended value from PQ tool debugging */
    vencChnAttr->venc_attr.is_by_frame = venc_attr->payload_type_attr.by_frame;
    vencChnAttr->venc_attr.buf_size = ALIGN_LENGTH_64BYTE(venc_attr->payload_type_attr.buf_size);
    vencChnAttr->venc_attr.max_pic_height = venc_attr->payload_type_attr.height;
    vencChnAttr->venc_attr.max_pic_width = venc_attr->payload_type_attr.width;
    vencChnAttr->venc_attr.pic_height = venc_attr->payload_type_attr.height;
    vencChnAttr->venc_attr.pic_width = venc_attr->payload_type_attr.width;
    vencChnAttr->venc_attr.profile = venc_attr->payload_type_attr.profile;

    switch (venc_attr->payload_type_attr.type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            vencChnAttr->venc_attr.type = OT_PT_H264;
            vencChnAttr->venc_attr.h264_attr.rcn_ref_share_buf_en = rcnRefShareBuf;
            vencChnAttr->venc_attr.h264_attr.frame_buf_ratio = FRAME_BUF_RATIO;
            mapi_adapt_venc_config_h264_rc_attr(&venc_attr->rc_attr, &vencChnAttr->rc_attr);
            break;

        case HI_MAPI_PAYLOAD_TYPE_H265:
            vencChnAttr->venc_attr.type = OT_PT_H265;
            vencChnAttr->venc_attr.h265_attr.rcn_ref_share_buf_en = rcnRefShareBuf;
            vencChnAttr->venc_attr.h265_attr.frame_buf_ratio = FRAME_BUF_RATIO;
            mapi_adapt_venc_config_h265_rc_attr(&venc_attr->rc_attr, &vencChnAttr->rc_attr);
            break;

#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            vencChnAttr->venc_attr.type = OT_PT_SVAC3;
            vencChnAttr->venc_attr.svac3_attr.rcn_ref_share_buf_en = rcnRefShareBuf;
            vencChnAttr->venc_attr.svac3_attr.frame_buf_ratio = FRAME_BUF_RATIO;
            mapi_adapt_venc_config_svac3_rc_attr(&venc_attr->rc_attr, &vencChnAttr->rc_attr);
            break;
#endif

        case HI_MAPI_PAYLOAD_TYPE_JPEG:
            vencChnAttr->venc_attr.type = OT_PT_JPEG;
            mapi_adapt_venc_config_jpeg_attr(&venc_attr->payload_type_attr.jpeg_attr, &vencChnAttr->venc_attr.jpeg_attr);
            break;

        case HI_MAPI_PAYLOAD_TYPE_MJPEG:
            vencChnAttr->venc_attr.type = OT_PT_MJPEG;
            mapi_adapt_venc_config_mjpeg_rc_attr(&venc_attr->rc_attr, &vencChnAttr->rc_attr);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type,enType:%d\n",
                           venc_attr->payload_type_attr.type);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_create_chn(td_handle venc_hdl, const hi_mapi_venc_attr *venc_attr,
    td_bool rcnRefShareBuf)
{
    ot_venc_chn_attr vencChnAttr;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_attr);

    td_s32 ret = memset_s(&vencChnAttr, sizeof(ot_venc_chn_attr), 0, sizeof(ot_venc_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = mapi_adapt_venc_config_attr(venc_attr, &vencChnAttr, rcnRefShareBuf);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_config_attr", ret);

    ret = ss_mpi_venc_create_chn(venc_hdl, &vencChnAttr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_create_chn", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_destroy_chn(td_handle venc_hdl)
{
    return ss_mpi_venc_destroy_chn(venc_hdl);
}

static td_void mapi_adapt_venc_close_h264_reencode(hi_mapi_venc_rc_mode rc_mode, ot_venc_rc_param *venc_rc_param)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            venc_rc_param->h264_cbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            venc_rc_param->h264_vbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            venc_rc_param->h264_qvbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            venc_rc_param->h264_cvbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            venc_rc_param->h264_avbr_param.max_reencode_times = 0;
            break;

        default:
            venc_rc_param->h264_cbr_param.max_reencode_times = 0;
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC,
                "RC mode only support CBR or VBR or QVBR or CVBR or AVBR, default use CBR!\n");
            break;
    }

    return;
}

static td_void mapi_adapt_venc_close_h265_reencode(hi_mapi_venc_rc_mode rc_mode, ot_venc_rc_param *venc_rc_param)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            venc_rc_param->h265_cbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            venc_rc_param->h265_vbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            venc_rc_param->h265_qvbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            venc_rc_param->h265_cvbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            venc_rc_param->h265_avbr_param.max_reencode_times = 0;
            break;

        default:
            venc_rc_param->h265_cbr_param.max_reencode_times = 0;
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC,
                "RC mode only support CBR or VBR or QVBR or CVBR or AVBR, default use CBR!\n");
            break;
    }

    return;
}

#ifdef SUPPORT_SVAC3
static td_void mapi_adapt_venc_close_svac3_reencode(hi_mapi_venc_rc_mode rc_mode, ot_venc_rc_param *venc_rc_param)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            venc_rc_param->svac3_cbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            venc_rc_param->svac3_vbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            venc_rc_param->svac3_qvbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            venc_rc_param->svac3_cvbr_param.max_reencode_times = 0;
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            venc_rc_param->svac3_avbr_param.max_reencode_times = 0;
            break;

        default:
            venc_rc_param->svac3_cbr_param.max_reencode_times = 0;
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC,
                "RC mode only support CBR or VBR or QVBR or CVBR or AVBR, default use CBR!\n");
            break;
    }

    return;
}
#endif

td_s32 mapi_adapt_venc_close_reencode(td_handle venc_hdl, hi_mapi_payload_type payload_type,
    hi_mapi_venc_rc_mode rc_mode)
{
    ot_venc_rc_param venc_rc_param;

    /* only H264 or H265 support config */
    if ((payload_type != HI_MAPI_PAYLOAD_TYPE_H264) && (payload_type != HI_MAPI_PAYLOAD_TYPE_H265) &&
        (payload_type != HI_MAPI_PAYLOAD_TYPE_SVAC3)) {
        return TD_SUCCESS;
    }

    td_s32 ret = ss_mpi_venc_get_rc_param(venc_hdl, &venc_rc_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_rc_param", ret);

    switch (payload_type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            mapi_adapt_venc_close_h264_reencode(rc_mode, &venc_rc_param);
            break;
        case HI_MAPI_PAYLOAD_TYPE_H265:
            mapi_adapt_venc_close_h265_reencode(rc_mode, &venc_rc_param);
            break;
#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            mapi_adapt_venc_close_svac3_reencode(rc_mode, &venc_rc_param);
            break;
#endif
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "payload_type[%u] not support config!\n", payload_type);
            return TD_SUCCESS;
}

    ret = ss_mpi_venc_set_rc_param(venc_hdl, &venc_rc_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_rc_param", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_scene_mode(td_handle venc_hdl, hi_mapi_venc_scene_mode scene_mode)
{
    ot_venc_scene_mode mode = (ot_venc_scene_mode)VENC_SCENEMODE_TO_MPI(scene_mode);
    return ss_mpi_venc_set_scene_mode(venc_hdl, mode);
}

td_s32 mapi_adapt_venc_set_h265_trans(td_handle venc_hdl)
{
    ot_venc_h265_trans h265Trans;
    td_s32 ret = ss_mpi_venc_get_h265_trans(venc_hdl, &h265Trans);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_h265_trans", ret);

    h265Trans.scaling_list_en = TD_FALSE;
    ret = ss_mpi_venc_set_h265_trans(venc_hdl, &h265Trans);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_h265_trans", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_jpeg_param(td_handle venc_hdl, const hi_mapi_venc_jpeg_attr *jpeg_attr)
{
    ot_venc_jpeg_param vencParamJpeg;
    ot_venc_jpeg_enc_mode jpegSnapMode;
    CHECK_MAPI_VENC_NULL_PTR_RET(jpeg_attr);

    td_s32 ret = ss_mpi_venc_get_jpeg_param(venc_hdl, &vencParamJpeg);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_jpeg_param", ret);

    vencParamJpeg.qfactor = jpeg_attr->qfactor;
    ret = ss_mpi_venc_set_jpeg_param(venc_hdl, &vencParamJpeg);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_jpeg_param", ret);

    jpegSnapMode = jpeg_attr->jpeg_encode_mode;
    ret = ss_mpi_venc_set_jpeg_enc_mode(venc_hdl, jpegSnapMode);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_jpeg_enc_mode", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_stream_max_cnt(td_handle venc_hdl)
{
    ot_venc_chn_param vencParamChn;

    td_s32 ret = ss_mpi_venc_get_chn_param(venc_hdl, &vencParamChn);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_chn_param", ret);

    vencParamChn.max_stream_cnt = MAX_STREAM_CNT;
    ret = ss_mpi_venc_set_chn_param(venc_hdl, &vencParamChn);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_chn_param", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_start_recv_frame(td_handle venc_hdl, td_s32 frame_cnt)
{
    ot_venc_start_param recvParam;
    recvParam.recv_pic_num = frame_cnt;
    return ss_mpi_venc_start_chn(venc_hdl, &recvParam);
}

td_s32 mapi_adapt_venc_stop_recv_frame(td_handle venc_hdl)
{
    return ss_mpi_venc_stop_chn(venc_hdl);
}

td_s32 mapi_adapt_venc_reset_chn(td_handle venc_hdl)
{
    return ss_mpi_venc_reset_chn(venc_hdl);
}

td_s32 mapi_adapt_venc_set_attr(td_handle venc_hdl, hi_mapi_venc_rc_mode originalRcMode, const hi_mapi_venc_attr *venc_attr)
{
    ot_venc_chn_attr chnAttr;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_attr);

    td_s32 ret = memset_s(&chnAttr, sizeof(ot_venc_chn_attr), 0x0, sizeof(ot_venc_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = ss_mpi_venc_get_chn_attr(venc_hdl, &chnAttr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_chn_attr", ret);

    ot_venc_rc_param vencRcPara;
    ret = memset_s(&vencRcPara, sizeof(ot_venc_rc_param), 0x0, sizeof(ot_venc_rc_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    hi_mapi_payload_type type = venc_attr->payload_type_attr.type;
    if ((type == HI_MAPI_PAYLOAD_TYPE_H264) || (type == HI_MAPI_PAYLOAD_TYPE_H265) ||
        (type == HI_MAPI_PAYLOAD_TYPE_MJPEG)) {
        ret = ss_mpi_venc_get_rc_param(venc_hdl, &vencRcPara);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_rc_param", ret);
    }

#ifdef SUPPORT_SVAC3
    if (type == HI_MAPI_PAYLOAD_TYPE_SVAC3) {
        ret = ss_mpi_venc_get_rc_param(venc_hdl, &vencRcPara);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_rc_param", ret);
    }
#endif

    td_bool rcnRefShareBuf = TD_FALSE; /* only h264 and h265 is Valid value */
    if (chnAttr.venc_attr.type == OT_PT_H264) {
        rcnRefShareBuf = chnAttr.venc_attr.h264_attr.rcn_ref_share_buf_en;
    } else if (chnAttr.venc_attr.type == OT_PT_H265) {
        rcnRefShareBuf = chnAttr.venc_attr.h265_attr.rcn_ref_share_buf_en;
    }

#ifdef SUPPORT_SVAC3
    if (chnAttr.venc_attr.type == OT_PT_SVAC3) {
        rcnRefShareBuf = chnAttr.venc_attr.svac3_attr.rcn_ref_share_buf_en;
    }
#endif

    ret = mapi_adapt_venc_config_attr(venc_attr, &chnAttr, rcnRefShareBuf);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_config_attr", ret);

    ret = ss_mpi_venc_set_chn_attr(venc_hdl, &chnAttr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_chn_attr", ret);

    /* default rc_mode is  HI_MAPI_VENC_RC_MODE_CBR */
    if ((originalRcMode != venc_attr->rc_attr.rc_mode) && (venc_attr->rc_attr.rc_mode <= HI_MAPI_VENC_RC_MODE_BUTT)) {
        ret = mapi_adapt_venc_close_reencode(venc_hdl, venc_attr->payload_type_attr.type, venc_attr->rc_attr.rc_mode);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_venc_close_reencode", ret);
    } else {
        if ((type == HI_MAPI_PAYLOAD_TYPE_H264) || (type == HI_MAPI_PAYLOAD_TYPE_H265) ||
            (type == HI_MAPI_PAYLOAD_TYPE_MJPEG)) {
            ret = ss_mpi_venc_set_rc_param(venc_hdl, &vencRcPara);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_rc_param", ret);
        }

#ifdef SUPPORT_SVAC3
        if (type == HI_MAPI_PAYLOAD_TYPE_SVAC3) {
            ret = ss_mpi_venc_set_rc_param(venc_hdl, &vencRcPara);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_rc_param", ret);
        }
#endif
    }

    if (venc_attr->payload_type_attr.type == HI_MAPI_PAYLOAD_TYPE_JPEG) {
        ret = mapi_adapt_venc_set_jpeg_param(venc_hdl, &venc_attr->payload_type_attr.jpeg_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_set_jpeg_param", ret);
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_request_idr(td_handle venc_hdl)
{
    return ss_mpi_venc_request_idr(venc_hdl, TD_TRUE);
}

static td_void mapi_adapt_venc_h264_cbr_param2_mapi(const ot_venc_h264_cbr_param *h264Cbr,
    hi_mapi_venc_h264_cbr_param *h264_cbr_param)
{
    h264_cbr_param->min_ip_ratio = h264Cbr->min_i_proportion;
    h264_cbr_param->max_ip_ratio = h264Cbr->max_i_proportion;
    h264_cbr_param->max_qp = h264Cbr->max_qp;
    h264_cbr_param->min_qp = h264Cbr->min_qp;
    h264_cbr_param->max_i_qp = h264Cbr->max_i_qp;
    h264_cbr_param->min_i_qp = h264Cbr->min_i_qp;
    h264_cbr_param->max_reencode_times = h264Cbr->max_reencode_times;
    h264_cbr_param->qpmap_en = h264Cbr->qpmap_en;

    return;
}

static td_void mapi_adapt_venc_h264_vbr_param2_mapi(const ot_venc_h264_vbr_param *h264Vbr,
    hi_mapi_venc_h264_vbr_param *h264_vbr_param)
{
    h264_vbr_param->change_pos = h264Vbr->chg_pos;
    h264_vbr_param->min_ip_ratio = h264Vbr->min_i_proportion;
    h264_vbr_param->max_ip_ratio = h264Vbr->max_i_proportion;
    h264_vbr_param->max_reencode_times = h264Vbr->max_reencode_times;
    h264_vbr_param->qpmap_en = h264Vbr->qpmap_en;
    h264_vbr_param->max_qp = h264Vbr->max_qp;
    h264_vbr_param->min_qp = h264Vbr->min_qp;
    h264_vbr_param->max_i_qp = h264Vbr->max_i_qp;
    h264_vbr_param->min_i_qp = h264Vbr->min_i_qp;

    return;
}

static td_void mapi_adapt_venc_h264_qvbr_param2_mapi(const ot_venc_h264_qvbr_param *h264Qvbr,
    hi_mapi_venc_h264_qvbr_param *h264_qvbr_param)
{
    h264_qvbr_param->min_ip_ratio = h264Qvbr->min_i_proportion;
    h264_qvbr_param->max_ip_ratio = h264Qvbr->max_i_proportion;
    h264_qvbr_param->max_reencode_times = h264Qvbr->max_reencode_times;
    h264_qvbr_param->qpmap_en = h264Qvbr->qpmap_en;
    h264_qvbr_param->max_qp = h264Qvbr->max_qp;
    h264_qvbr_param->min_qp = h264Qvbr->min_qp;
    h264_qvbr_param->max_i_qp = h264Qvbr->max_i_qp;
    h264_qvbr_param->min_i_qp = h264Qvbr->min_i_qp;
    h264_qvbr_param->bit_percent_ul = h264Qvbr->max_bit_percent;
    h264_qvbr_param->bit_percent_ll = h264Qvbr->min_bit_percent;
    h264_qvbr_param->psnr_fluctuate_ul = h264Qvbr->max_psnr_fluctuate;
    h264_qvbr_param->psnr_fluctuate_ll = h264Qvbr->min_psnr_fluctuate;

    return;
}

static td_void mapi_adapt_venc_h264_cvbr_param2_mapi(const ot_venc_h264_cvbr_param *h264Cvbr,
    hi_mapi_venc_h264_cvbr_param *h264_cvbr_param)
{
    h264_cvbr_param->min_ip_ratio = h264Cvbr->min_i_proportion;
    h264_cvbr_param->max_ip_ratio = h264Cvbr->max_i_proportion;
    h264_cvbr_param->max_reencode_times = h264Cvbr->max_reencode_times;
    h264_cvbr_param->qpmap_en = h264Cvbr->qpmap_en;
    h264_cvbr_param->max_qp = h264Cvbr->max_qp;
    h264_cvbr_param->min_qp = h264Cvbr->min_qp;
    h264_cvbr_param->max_i_qp = h264Cvbr->max_i_qp;
    h264_cvbr_param->min_i_qp = h264Cvbr->min_i_qp;
    h264_cvbr_param->min_qp_delta = h264Cvbr->min_qp_delta;
    h264_cvbr_param->max_qp_delta = h264Cvbr->max_qp_delta;
    h264_cvbr_param->extra_bit_percent = h264Cvbr->extra_bit_percent;
    h264_cvbr_param->long_term_stat_time_unit = h264Cvbr->long_term_stats_time_unit;

    return;
}

static td_void mapi_adapt_venc_h264_avbr_param2_mapi(const ot_venc_h264_avbr_param *h264Avbr,
    hi_mapi_venc_h264_avbr_param *h264_avbr_param)
{
    h264_avbr_param->change_pos = h264Avbr->chg_pos;
    h264_avbr_param->min_ip_ratio = h264Avbr->min_i_proportion;
    h264_avbr_param->max_ip_ratio = h264Avbr->max_i_proportion;
    h264_avbr_param->max_reencode_times = h264Avbr->max_reencode_times;
    h264_avbr_param->qpmap_en = h264Avbr->qpmap_en;
    h264_avbr_param->min_still_percent = h264Avbr->min_still_percent;
    h264_avbr_param->max_still_qp = h264Avbr->max_still_qp;
    h264_avbr_param->min_still_psnr = h264Avbr->min_still_psnr;
    h264_avbr_param->max_qp = h264Avbr->max_qp;
    h264_avbr_param->min_qp = h264Avbr->min_qp;
    h264_avbr_param->max_i_qp = h264Avbr->max_i_qp;
    h264_avbr_param->min_i_qp = h264Avbr->min_i_qp;
    h264_avbr_param->min_qp_delta = h264Avbr->min_qp_delta;
    h264_avbr_param->motion_sensitivity = h264Avbr->motion_sensitivity;

    return;
}

static td_s32 mapi_adapt_venc_h264_rc_param2_mapi(hi_mapi_venc_rc_mode rc_mode, const ot_venc_rc_param *param,
    hi_mapi_venc_rc_param *rcParam)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            mapi_adapt_venc_h264_cbr_param2_mapi(&param->h264_cbr_param, &rcParam->h264_cbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            mapi_adapt_venc_h264_vbr_param2_mapi(&param->h264_vbr_param, &rcParam->h264_vbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            mapi_adapt_venc_h264_qvbr_param2_mapi(&param->h264_qvbr_param, &rcParam->h264_qvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            mapi_adapt_venc_h264_cvbr_param2_mapi(&param->h264_cvbr_param, &rcParam->h264_cvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            mapi_adapt_venc_h264_avbr_param2_mapi(&param->h264_avbr_param, &rcParam->h264_avbr_param);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, rc_mode:%d\n", rc_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_void mapi_adapt_venc_h265_cbr_param2_mapi(const ot_venc_h265_cbr_param *h265Cbr,
    hi_mapi_venc_h265_cbr_param *h265_cbr_param)
{
    h265_cbr_param->min_ip_ratio = h265Cbr->min_i_proportion;
    h265_cbr_param->max_ip_ratio = h265Cbr->max_i_proportion;
    h265_cbr_param->max_qp = h265Cbr->max_qp;
    h265_cbr_param->min_qp = h265Cbr->min_qp;
    h265_cbr_param->max_i_qp = h265Cbr->max_i_qp;
    h265_cbr_param->min_i_qp = h265Cbr->min_i_qp;
    h265_cbr_param->max_reencode_times = h265Cbr->max_reencode_times;
    h265_cbr_param->qpmap_en = h265Cbr->qpmap_en;
    h265_cbr_param->qpmap_mode = h265Cbr->qpmap_mode;

    return;
}

static td_void mapi_adapt_venc_h265_vbr_param2_mapi(const ot_venc_h265_vbr_param *h265Vbr,
    hi_mapi_venc_h265_vbr_param *h265_vbr_param)
{
    h265_vbr_param->change_pos = h265Vbr->chg_pos;
    h265_vbr_param->min_ip_ratio = h265Vbr->min_i_proportion;
    h265_vbr_param->max_ip_ratio = h265Vbr->max_i_proportion;
    h265_vbr_param->max_reencode_times = h265Vbr->max_reencode_times;
    h265_vbr_param->max_qp = h265Vbr->max_qp;
    h265_vbr_param->min_qp = h265Vbr->min_qp;
    h265_vbr_param->max_i_qp = h265Vbr->max_i_qp;
    h265_vbr_param->min_i_qp = h265Vbr->min_i_qp;
    h265_vbr_param->qpmap_en = h265Vbr->qpmap_en;
    h265_vbr_param->qpmap_mode = h265Vbr->qpmap_mode;

    return;
}

static td_void mapi_adapt_venc_h265_qvbr_param2_mapi(const ot_venc_h265_qvbr_param *h265Qvbr,
    hi_mapi_venc_h265_qvbr_param *h265_qvbr_param)
{
    h265_qvbr_param->min_ip_ratio = h265Qvbr->min_i_proportion;
    h265_qvbr_param->max_ip_ratio = h265Qvbr->max_i_proportion;
    h265_qvbr_param->max_reencode_times = h265Qvbr->max_reencode_times;
    h265_qvbr_param->qpmap_en = h265Qvbr->qpmap_en;
    h265_qvbr_param->qpmap_mode = h265Qvbr->qpmap_mode;
    h265_qvbr_param->max_qp = h265Qvbr->max_qp;
    h265_qvbr_param->min_qp = h265Qvbr->min_qp;
    h265_qvbr_param->max_i_qp = h265Qvbr->max_i_qp;
    h265_qvbr_param->min_i_qp = h265Qvbr->min_i_qp;
    h265_qvbr_param->bit_percent_ul = h265Qvbr->max_bit_percent;
    h265_qvbr_param->bit_percent_ll = h265Qvbr->min_bit_percent;
    h265_qvbr_param->psnr_fluctuate_ul = h265Qvbr->max_psnr_fluctuate;
    h265_qvbr_param->psnr_fluctuate_ll = h265Qvbr->min_psnr_fluctuate;

    return;
}

static td_void mapi_adapt_venc_h265_cvbr_param2_mapi(const ot_venc_h265_cvbr_param *h265Cvbr,
    hi_mapi_venc_h265_cvbr_param *h265_cvbr_param)
{
    h265_cvbr_param->min_ip_ratio = h265Cvbr->min_i_proportion;
    h265_cvbr_param->max_ip_ratio = h265Cvbr->max_i_proportion;
    h265_cvbr_param->max_reencode_times = h265Cvbr->max_reencode_times;
    h265_cvbr_param->qpmap_en = h265Cvbr->qpmap_en;
    h265_cvbr_param->qpmap_mode = h265Cvbr->qpmap_mode;
    h265_cvbr_param->max_qp = h265Cvbr->max_qp;
    h265_cvbr_param->min_qp = h265Cvbr->min_qp;
    h265_cvbr_param->max_i_qp = h265Cvbr->max_i_qp;
    h265_cvbr_param->min_i_qp = h265Cvbr->min_i_qp;
    h265_cvbr_param->min_qp_delta = h265Cvbr->min_qp_delta;
    h265_cvbr_param->max_qp_delta = h265Cvbr->max_qp_delta;
    h265_cvbr_param->extra_bit_percent = h265Cvbr->extra_bit_percent;
    h265_cvbr_param->long_term_stat_time_unit = h265Cvbr->long_term_stats_time_unit;

    return;
}

static td_void mapi_adapt_venc_h265_avbr_param2_mapi(const ot_venc_h265_avbr_param *h265Avbr,
    hi_mapi_venc_h265_avbr_param *h265_avbr_param)
{
    h265_avbr_param->change_pos = h265Avbr->chg_pos;
    h265_avbr_param->min_ip_ratio = h265Avbr->min_i_proportion;
    h265_avbr_param->max_ip_ratio = h265Avbr->max_i_proportion;
    h265_avbr_param->max_reencode_times = h265Avbr->max_reencode_times;
    h265_avbr_param->min_still_percent = h265Avbr->min_still_percent;
    h265_avbr_param->max_still_qp = h265Avbr->max_still_qp;
    h265_avbr_param->min_still_psnr = h265Avbr->min_still_psnr;
    h265_avbr_param->max_qp = h265Avbr->max_qp;
    h265_avbr_param->min_qp = h265Avbr->min_qp;
    h265_avbr_param->max_i_qp = h265Avbr->max_i_qp;
    h265_avbr_param->min_i_qp = h265Avbr->min_i_qp;
    h265_avbr_param->min_qp_delta = h265Avbr->min_qp_delta;
    h265_avbr_param->motion_sensitivity = h265Avbr->motion_sensitivity;
    h265_avbr_param->qpmap_en = h265Avbr->qpmap_en;
    h265_avbr_param->qpmap_mode = h265Avbr->qpmap_mode;

    return;
}

static td_s32 mapi_adapt_venc_h265_rc_param2_mapi(hi_mapi_venc_rc_mode rc_mode, const ot_venc_rc_param *param,
    hi_mapi_venc_rc_param *rcParam)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            mapi_adapt_venc_h265_cbr_param2_mapi(&param->h265_cbr_param, &rcParam->h265_cbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            mapi_adapt_venc_h265_vbr_param2_mapi(&param->h265_vbr_param, &rcParam->h265_vbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            mapi_adapt_venc_h265_qvbr_param2_mapi(&param->h265_qvbr_param, &rcParam->h265_qvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            mapi_adapt_venc_h265_cvbr_param2_mapi(&param->h265_cvbr_param, &rcParam->h265_cvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            mapi_adapt_venc_h265_avbr_param2_mapi(&param->h265_avbr_param, &rcParam->h265_avbr_param);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, rc_mode:%d\n", rc_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

#ifdef SUPPORT_SVAC3
static td_void mapi_adapt_venc_svac3_cbr_param2_mapi(const ot_venc_svac3_cbr_param *svac3Cbr,
    hi_mapi_venc_svac3_cbr_param *svac3_cbr_param)
{
    svac3_cbr_param->min_ip_ratio = svac3Cbr->min_i_proportion;
    svac3_cbr_param->max_ip_ratio = svac3Cbr->max_i_proportion;
    svac3_cbr_param->max_qp = svac3Cbr->max_qp;
    svac3_cbr_param->min_qp = svac3Cbr->min_qp;
    svac3_cbr_param->max_i_qp = svac3Cbr->max_i_qp;
    svac3_cbr_param->min_i_qp = svac3Cbr->min_i_qp;
    svac3_cbr_param->max_reencode_times = svac3Cbr->max_reencode_times;
    svac3_cbr_param->qpmap_en = svac3Cbr->qpmap_en;
    svac3_cbr_param->qpmap_mode = svac3Cbr->qpmap_mode;

    return;
}

static td_void mapi_adapt_venc_svac3_vbr_param2_mapi(const ot_venc_svac3_vbr_param *svac3Vbr,
    hi_mapi_venc_svac3_vbr_param *svac3_vbr_param)
{
    svac3_vbr_param->change_pos = svac3Vbr->chg_pos;
    svac3_vbr_param->min_ip_ratio = svac3Vbr->min_i_proportion;
    svac3_vbr_param->max_ip_ratio = svac3Vbr->max_i_proportion;
    svac3_vbr_param->max_reencode_times = svac3Vbr->max_reencode_times;
    svac3_vbr_param->max_qp = svac3Vbr->max_qp;
    svac3_vbr_param->min_qp = svac3Vbr->min_qp;
    svac3_vbr_param->max_i_qp = svac3Vbr->max_i_qp;
    svac3_vbr_param->min_i_qp = svac3Vbr->min_i_qp;
    svac3_vbr_param->qpmap_en = svac3Vbr->qpmap_en;
    svac3_vbr_param->qpmap_mode = svac3Vbr->qpmap_mode;

    return;
}

static td_void mapi_adapt_venc_svac3_qvbr_param2_mapi(const ot_venc_svac3_qvbr_param *svac3Qvbr,
    hi_mapi_venc_svac3_qvbr_param *svac3_qvbr_param)
{
    svac3_qvbr_param->min_ip_ratio = svac3Qvbr->min_i_proportion;
    svac3_qvbr_param->max_ip_ratio = svac3Qvbr->max_i_proportion;
    svac3_qvbr_param->max_reencode_times = svac3Qvbr->max_reencode_times;
    svac3_qvbr_param->qpmap_en = svac3Qvbr->qpmap_en;
    svac3_qvbr_param->qpmap_mode = svac3Qvbr->qpmap_mode;
    svac3_qvbr_param->max_qp = svac3Qvbr->max_qp;
    svac3_qvbr_param->min_qp = svac3Qvbr->min_qp;
    svac3_qvbr_param->max_i_qp = svac3Qvbr->max_i_qp;
    svac3_qvbr_param->min_i_qp = svac3Qvbr->min_i_qp;
    svac3_qvbr_param->bit_percent_ul = svac3Qvbr->max_bit_percent;
    svac3_qvbr_param->bit_percent_ll = svac3Qvbr->min_bit_percent;
    svac3_qvbr_param->psnr_fluctuate_ul = svac3Qvbr->max_psnr_fluctuate;
    svac3_qvbr_param->psnr_fluctuate_ll = svac3Qvbr->min_psnr_fluctuate;

    return;
}

static td_void mapi_adapt_venc_svac3_cvbr_param2_mapi(const ot_venc_svac3_cvbr_param *svac3Cvbr,
    hi_mapi_venc_svac3_cvbr_param *svac3_cvbr_param)
{
    svac3_cvbr_param->min_ip_ratio = svac3Cvbr->min_i_proportion;
    svac3_cvbr_param->max_ip_ratio = svac3Cvbr->max_i_proportion;
    svac3_cvbr_param->max_reencode_times = svac3Cvbr->max_reencode_times;
    svac3_cvbr_param->qpmap_en = svac3Cvbr->qpmap_en;
    svac3_cvbr_param->qpmap_mode = svac3Cvbr->qpmap_mode;
    svac3_cvbr_param->max_qp = svac3Cvbr->max_qp;
    svac3_cvbr_param->min_qp = svac3Cvbr->min_qp;
    svac3_cvbr_param->max_i_qp = svac3Cvbr->max_i_qp;
    svac3_cvbr_param->min_i_qp = svac3Cvbr->min_i_qp;
    svac3_cvbr_param->min_qp_delta = svac3Cvbr->min_qp_delta;
    svac3_cvbr_param->max_qp_delta = svac3Cvbr->max_qp_delta;
    svac3_cvbr_param->extra_bit_percent = svac3Cvbr->extra_bit_percent;
    svac3_cvbr_param->long_term_stat_time_unit = svac3Cvbr->long_term_stats_time_unit;

    return;
}

static td_void mapi_adapt_venc_svac3_avbr_param2_mapi(const ot_venc_svac3_avbr_param *svac3Avbr,
    hi_mapi_venc_svac3_avbr_param *svac3_avbr_param)
{
    svac3_avbr_param->change_pos = svac3Avbr->chg_pos;
    svac3_avbr_param->min_ip_ratio = svac3Avbr->min_i_proportion;
    svac3_avbr_param->max_ip_ratio = svac3Avbr->max_i_proportion;
    svac3_avbr_param->max_reencode_times = svac3Avbr->max_reencode_times;
    svac3_avbr_param->min_still_percent = svac3Avbr->min_still_percent;
    svac3_avbr_param->max_still_qp = svac3Avbr->max_still_qp;
    svac3_avbr_param->min_still_psnr = svac3Avbr->min_still_psnr;
    svac3_avbr_param->max_qp = svac3Avbr->max_qp;
    svac3_avbr_param->min_qp = svac3Avbr->min_qp;
    svac3_avbr_param->max_i_qp = svac3Avbr->max_i_qp;
    svac3_avbr_param->min_i_qp = svac3Avbr->min_i_qp;
    svac3_avbr_param->min_qp_delta = svac3Avbr->min_qp_delta;
    svac3_avbr_param->motion_sensitivity = svac3Avbr->motion_sensitivity;
    svac3_avbr_param->qpmap_en = svac3Avbr->qpmap_en;
    svac3_avbr_param->qpmap_mode = svac3Avbr->qpmap_mode;

    return;
}

static td_s32 mapi_adapt_venc_svac3_rc_param2_mapi(hi_mapi_venc_rc_mode rc_mode, const ot_venc_rc_param *param,
    hi_mapi_venc_rc_param *rcParam)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            mapi_adapt_venc_svac3_cbr_param2_mapi(&param->svac3_cbr_param, &rcParam->svac3_cbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            mapi_adapt_venc_svac3_vbr_param2_mapi(&param->svac3_vbr_param, &rcParam->svac3_vbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            mapi_adapt_venc_svac3_qvbr_param2_mapi(&param->svac3_qvbr_param, &rcParam->svac3_qvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            mapi_adapt_venc_svac3_cvbr_param2_mapi(&param->svac3_cvbr_param, &rcParam->svac3_cvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            mapi_adapt_venc_svac3_avbr_param2_mapi(&param->svac3_avbr_param, &rcParam->svac3_avbr_param);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, rc_mode:%d\n", rc_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}
#endif

static td_s32 mapi_adapt_venc_mjpeg_rc_param2_mapi(hi_mapi_venc_rc_mode rc_mode, const ot_venc_rc_param *param,
    hi_mapi_venc_rc_param *rcParam)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            rcParam->mjpeg_cbr_param.max_qfactor = param->mjpeg_cbr_param.max_qfactor;
            rcParam->mjpeg_cbr_param.min_qfactor = param->mjpeg_cbr_param.min_qfactor;
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            rcParam->mjpeg_vbr_param.change_pos = param->mjpeg_vbr_param.chg_pos;
            rcParam->mjpeg_vbr_param.max_qfactor = param->mjpeg_vbr_param.max_qfactor;
            rcParam->mjpeg_vbr_param.min_qfactor = param->mjpeg_vbr_param.min_qfactor;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, rc_mode:%d\n", rc_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static  td_s32 mapi_adapt_venc_rc_param2_mapi(hi_mapi_venc_rc_mode rc_mode, hi_mapi_payload_type type,
    const ot_venc_rc_param *param, hi_mapi_venc_rc_param *rcParam)
{
    td_s32 ret;

    for (td_u32 i = 0; i < OT_VENC_TEXTURE_THRESHOLD_SIZE; i++) {
        rcParam->thrd_i[i] = param->threshold_i[i];
        rcParam->thrd_p[i] = param->threshold_p[i];
        rcParam->thrd_b[i] = param->threshold_b[i];
    }
    rcParam->direction_thrd = param->direction;
    rcParam->row_qp_delta = param->row_qp_delta;
    rcParam->first_frame_start_qp = param->first_frame_start_qp;
    rcParam->scene_change_detect.detect_scene_change = param->scene_chg_detect.detect_scene_chg_en;
    rcParam->scene_change_detect.adaptive_insert_idr_frame = param->scene_chg_detect.adapt_insert_idr_frame_en;

    switch (type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            ret = mapi_adapt_venc_h264_rc_param2_mapi(rc_mode, param, rcParam);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_h264_rc_param2_mapi", ret);
            break;

        case HI_MAPI_PAYLOAD_TYPE_H265:
            ret = mapi_adapt_venc_h265_rc_param2_mapi(rc_mode, param, rcParam);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_h265_rc_param2_mapi", ret);
            break;

#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            ret = mapi_adapt_venc_svac3_rc_param2_mapi(rc_mode, param, rcParam);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_svac3_rc_param2_mapi", ret);
            break;
#endif

        case HI_MAPI_PAYLOAD_TYPE_MJPEG:
            ret = mapi_adapt_venc_mjpeg_rc_param2_mapi(rc_mode, param, rcParam);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "HI_MAPI_PAYLOAD_TYPE_MJPEG", ret);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type,enType:%d\n", type);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_rc_param(td_handle venc_hdl, hi_mapi_venc_rc_mode rc_mode,
    hi_mapi_payload_type type, hi_mapi_venc_rc_param *rcParam)
{
    ot_venc_rc_param param;
    CHECK_MAPI_VENC_NULL_PTR_RET(rcParam);

    td_s32 ret = memset_s(&param, sizeof(ot_venc_rc_param), 0, sizeof(ot_venc_rc_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = ss_mpi_venc_get_rc_param(venc_hdl, &param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_rc_param", ret);

    ret = mapi_adapt_venc_rc_param2_mapi(rc_mode, type, &param, rcParam);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_rc_param2_mapi", ret);

    return TD_SUCCESS;
}

static td_void mapi_adapt_venc_h264_cbr_param2_mpi(const hi_mapi_venc_h264_cbr_param *h264_cbr_param,
    ot_venc_h264_cbr_param *h264Cbr)
{
    h264Cbr->min_i_proportion = h264_cbr_param->min_ip_ratio;
    h264Cbr->max_i_proportion = h264_cbr_param->max_ip_ratio;
    h264Cbr->max_qp = h264_cbr_param->max_qp;
    h264Cbr->min_qp = h264_cbr_param->min_qp;
    h264Cbr->max_i_qp = h264_cbr_param->max_i_qp;
    h264Cbr->min_i_qp = h264_cbr_param->min_i_qp;
    h264Cbr->max_reencode_times = h264_cbr_param->max_reencode_times;
    h264Cbr->qpmap_en = h264_cbr_param->qpmap_en;

    return;
}

static td_void mapi_adapt_venc_h264_vbr_param2_mpi(const hi_mapi_venc_h264_vbr_param *h264_vbr_param,
    ot_venc_h264_vbr_param *h264Vbr)
{
    h264Vbr->chg_pos = h264_vbr_param->change_pos;
    h264Vbr->min_i_proportion = h264_vbr_param->min_ip_ratio;
    h264Vbr->max_i_proportion = h264_vbr_param->max_ip_ratio;
    h264Vbr->max_reencode_times = h264_vbr_param->max_reencode_times;
    h264Vbr->qpmap_en = h264_vbr_param->qpmap_en;
    h264Vbr->max_qp = h264_vbr_param->max_qp;
    h264Vbr->min_qp = h264_vbr_param->min_qp;
    h264Vbr->max_i_qp = h264_vbr_param->max_i_qp;
    h264Vbr->min_i_qp = h264_vbr_param->min_i_qp;

    return;
}

static td_void mapi_adapt_venc_h264_qvbr_param2_mpi(const hi_mapi_venc_h264_qvbr_param *h264_qvbr_param,
    ot_venc_h264_qvbr_param *h264Qvbr)
{
    h264Qvbr->min_i_proportion = h264_qvbr_param->min_ip_ratio;
    h264Qvbr->max_i_proportion = h264_qvbr_param->max_ip_ratio;
    h264Qvbr->max_reencode_times = h264_qvbr_param->max_reencode_times;
    h264Qvbr->qpmap_en = h264_qvbr_param->qpmap_en;
    h264Qvbr->max_qp = h264_qvbr_param->max_qp;
    h264Qvbr->min_qp = h264_qvbr_param->min_qp;
    h264Qvbr->max_i_qp = h264_qvbr_param->max_i_qp;
    h264Qvbr->min_i_qp = h264_qvbr_param->min_i_qp;
    h264Qvbr->max_bit_percent = h264_qvbr_param->bit_percent_ul;
    h264Qvbr->min_bit_percent = h264_qvbr_param->bit_percent_ll;
    h264Qvbr->max_psnr_fluctuate = h264_qvbr_param->psnr_fluctuate_ul;
    h264Qvbr->min_psnr_fluctuate = h264_qvbr_param->psnr_fluctuate_ll;

    return;
}

static td_void mapi_adapt_venc_h264_cvbr_param2_mpi(const hi_mapi_venc_h264_cvbr_param *h264_cvbr_param,
    ot_venc_h264_cvbr_param *h264Cvbr)
{
    h264Cvbr->min_i_proportion = h264_cvbr_param->min_ip_ratio;
    h264Cvbr->max_i_proportion = h264_cvbr_param->max_ip_ratio;
    h264Cvbr->max_reencode_times = h264_cvbr_param->max_reencode_times;
    h264Cvbr->qpmap_en = h264_cvbr_param->qpmap_en;
    h264Cvbr->max_qp = h264_cvbr_param->max_qp;
    h264Cvbr->min_qp = h264_cvbr_param->min_qp;
    h264Cvbr->max_i_qp = h264_cvbr_param->max_i_qp;
    h264Cvbr->min_i_qp = h264_cvbr_param->min_i_qp;
    h264Cvbr->min_qp_delta = h264_cvbr_param->min_qp_delta;
    h264Cvbr->max_qp_delta = h264_cvbr_param->max_qp_delta;
    h264Cvbr->extra_bit_percent = h264_cvbr_param->extra_bit_percent;
    h264Cvbr->long_term_stats_time_unit = h264_cvbr_param->long_term_stat_time_unit;

    return;
}

static td_void mapi_adapt_venc_h264_avbr_param2_mpi(const hi_mapi_venc_h264_avbr_param *h264_avbr_param,
    ot_venc_h264_avbr_param *h264Avbr)
{
    h264Avbr->chg_pos = h264_avbr_param->change_pos;
    h264Avbr->min_i_proportion = h264_avbr_param->min_ip_ratio;
    h264Avbr->max_i_proportion = h264_avbr_param->max_ip_ratio;
    h264Avbr->max_reencode_times = h264_avbr_param->max_reencode_times;
    h264Avbr->qpmap_en = h264_avbr_param->qpmap_en;
    h264Avbr->min_still_percent = h264_avbr_param->min_still_percent;
    h264Avbr->max_still_qp = h264_avbr_param->max_still_qp;
    h264Avbr->min_still_psnr = h264_avbr_param->min_still_psnr;
    h264Avbr->max_qp = h264_avbr_param->max_qp;
    h264Avbr->min_qp = h264_avbr_param->min_qp;
    h264Avbr->max_i_qp = h264_avbr_param->max_i_qp;
    h264Avbr->min_i_qp = h264_avbr_param->min_i_qp;
    h264Avbr->min_qp_delta = h264_avbr_param->min_qp_delta;
    h264Avbr->motion_sensitivity = h264_avbr_param->motion_sensitivity;

    return;
}

static td_s32 mapi_adapt_venc_h264_rc_param2_mpi(hi_mapi_venc_rc_mode rc_mode, const hi_mapi_venc_rc_param *rcParam,
    ot_venc_rc_param *param)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            mapi_adapt_venc_h264_cbr_param2_mpi(&rcParam->h264_cbr_param, &param->h264_cbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            mapi_adapt_venc_h264_vbr_param2_mpi(&rcParam->h264_vbr_param, &param->h264_vbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            mapi_adapt_venc_h264_qvbr_param2_mpi(&rcParam->h264_qvbr_param, &param->h264_qvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            mapi_adapt_venc_h264_cvbr_param2_mpi(&rcParam->h264_cvbr_param, &param->h264_cvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            mapi_adapt_venc_h264_avbr_param2_mpi(&rcParam->h264_avbr_param, &param->h264_avbr_param);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, rc_mode:%d\n", rc_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_void mapi_adapt_venc_h265_cbr_param2_mpi(const hi_mapi_venc_h265_cbr_param *h265_cbr_param,
    ot_venc_h265_cbr_param *h265Cbr)
{
    h265Cbr->min_i_proportion = h265_cbr_param->min_ip_ratio;
    h265Cbr->max_i_proportion = h265_cbr_param->max_ip_ratio;
    h265Cbr->max_qp = h265_cbr_param->max_qp;
    h265Cbr->min_qp = h265_cbr_param->min_qp;
    h265Cbr->max_i_qp = h265_cbr_param->max_i_qp;
    h265Cbr->min_i_qp = h265_cbr_param->min_i_qp;
    h265Cbr->max_reencode_times = h265_cbr_param->max_reencode_times;
    h265Cbr->qpmap_en = h265_cbr_param->qpmap_en;
    h265Cbr->qpmap_mode = h265_cbr_param->qpmap_mode;

    return;
}

static td_void mapi_adapt_venc_h265_vbr_param2_mpi(const hi_mapi_venc_h265_vbr_param *h265_vbr_param,
    ot_venc_h265_vbr_param *h265Vbr)
{
    h265Vbr->chg_pos = h265_vbr_param->change_pos;
    h265Vbr->min_i_proportion = h265_vbr_param->min_ip_ratio;
    h265Vbr->max_i_proportion = h265_vbr_param->max_ip_ratio;
    h265Vbr->max_reencode_times = h265_vbr_param->max_reencode_times;
    h265Vbr->max_qp = h265_vbr_param->max_qp;
    h265Vbr->min_qp = h265_vbr_param->min_qp;
    h265Vbr->max_i_qp = h265_vbr_param->max_i_qp;
    h265Vbr->min_i_qp = h265_vbr_param->min_i_qp;
    h265Vbr->qpmap_en = h265_vbr_param->qpmap_en;
    h265Vbr->qpmap_mode = h265_vbr_param->qpmap_mode;

    return;
}

static td_void mapi_adapt_venc_h265_qvbr_param2_mpi(const hi_mapi_venc_h265_qvbr_param *h265_qvbr_param,
    ot_venc_h265_qvbr_param *h265Qvbr)
{
    h265Qvbr->min_i_proportion = h265_qvbr_param->min_ip_ratio;
    h265Qvbr->max_i_proportion = h265_qvbr_param->max_ip_ratio;
    h265Qvbr->max_reencode_times = h265_qvbr_param->max_reencode_times;
    h265Qvbr->qpmap_en = h265_qvbr_param->qpmap_en;
    h265Qvbr->qpmap_mode = h265_qvbr_param->qpmap_mode;
    h265Qvbr->max_qp = h265_qvbr_param->max_qp;
    h265Qvbr->min_qp = h265_qvbr_param->min_qp;
    h265Qvbr->max_i_qp = h265_qvbr_param->max_i_qp;
    h265Qvbr->min_i_qp = h265_qvbr_param->min_i_qp;
    h265Qvbr->max_bit_percent = h265_qvbr_param->bit_percent_ul;
    h265Qvbr->min_bit_percent = h265_qvbr_param->bit_percent_ll;
    h265Qvbr->max_psnr_fluctuate = h265_qvbr_param->psnr_fluctuate_ul;
    h265Qvbr->min_psnr_fluctuate = h265_qvbr_param->psnr_fluctuate_ll;

    return;
}

static td_void mapi_adapt_venc_h265_cvbr_param2_mpi(const hi_mapi_venc_h265_cvbr_param *h265_cvbr_param,
    ot_venc_h265_cvbr_param *h265Cvbr)
{
    h265Cvbr->min_i_proportion = h265_cvbr_param->min_ip_ratio;
    h265Cvbr->max_i_proportion = h265_cvbr_param->max_ip_ratio;
    h265Cvbr->max_reencode_times = h265_cvbr_param->max_reencode_times;
    h265Cvbr->qpmap_en = h265_cvbr_param->qpmap_en;
    h265Cvbr->qpmap_mode = h265_cvbr_param->qpmap_mode;
    h265Cvbr->max_qp = h265_cvbr_param->max_qp;
    h265Cvbr->min_qp = h265_cvbr_param->min_qp;
    h265Cvbr->max_i_qp = h265_cvbr_param->max_i_qp;
    h265Cvbr->min_i_qp = h265_cvbr_param->min_i_qp;
    h265Cvbr->min_qp_delta = h265_cvbr_param->min_qp_delta;
    h265Cvbr->max_qp_delta = h265_cvbr_param->max_qp_delta;
    h265Cvbr->extra_bit_percent = h265_cvbr_param->extra_bit_percent;
    h265Cvbr->long_term_stats_time_unit = h265_cvbr_param->long_term_stat_time_unit;

    return;
}

static td_void mapi_adapt_venc_h265_avbr_param2_mpi(const hi_mapi_venc_h265_avbr_param *h265_avbr_param,
    ot_venc_h265_avbr_param *h265Avbr)
{
    h265Avbr->chg_pos = h265_avbr_param->change_pos;
    h265Avbr->min_i_proportion = h265_avbr_param->min_ip_ratio;
    h265Avbr->max_i_proportion = h265_avbr_param->max_ip_ratio;
    h265Avbr->max_reencode_times = h265_avbr_param->max_reencode_times;
    h265Avbr->min_still_percent = h265_avbr_param->min_still_percent;
    h265Avbr->max_still_qp = h265_avbr_param->max_still_qp;
    h265Avbr->min_still_psnr = h265_avbr_param->min_still_psnr;
    h265Avbr->max_qp = h265_avbr_param->max_qp;
    h265Avbr->min_qp = h265_avbr_param->min_qp;
    h265Avbr->max_i_qp = h265_avbr_param->max_i_qp;
    h265Avbr->min_i_qp = h265_avbr_param->min_i_qp;
    h265Avbr->min_qp_delta = h265_avbr_param->min_qp_delta;
    h265Avbr->motion_sensitivity = h265_avbr_param->motion_sensitivity;
    h265Avbr->qpmap_en = h265_avbr_param->qpmap_en;
    h265Avbr->qpmap_mode = h265_avbr_param->qpmap_mode;

    return;
}

static td_s32 mapi_adapt_venc_h265_rc_param2_mpi(hi_mapi_venc_rc_mode rc_mode, const hi_mapi_venc_rc_param *rcParam,
    ot_venc_rc_param *param)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            mapi_adapt_venc_h265_cbr_param2_mpi(&rcParam->h265_cbr_param, &param->h265_cbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            mapi_adapt_venc_h265_vbr_param2_mpi(&rcParam->h265_vbr_param, &param->h265_vbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            mapi_adapt_venc_h265_qvbr_param2_mpi(&rcParam->h265_qvbr_param, &param->h265_qvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            mapi_adapt_venc_h265_cvbr_param2_mpi(&rcParam->h265_cvbr_param, &param->h265_cvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            mapi_adapt_venc_h265_avbr_param2_mpi(&rcParam->h265_avbr_param, &param->h265_avbr_param);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, rc_mode:%d\n", rc_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

#ifdef SUPPORT_SVAC3
static td_void mapi_adapt_venc_svac3_cbr_param2_mpi(const hi_mapi_venc_svac3_cbr_param *svac3_cbr_param,
    ot_venc_svac3_cbr_param *svac3Cbr)
{
    svac3Cbr->min_i_proportion = svac3_cbr_param->min_ip_ratio;
    svac3Cbr->max_i_proportion = svac3_cbr_param->max_ip_ratio;
    svac3Cbr->max_qp = svac3_cbr_param->max_qp;
    svac3Cbr->min_qp = svac3_cbr_param->min_qp;
    svac3Cbr->max_i_qp = svac3_cbr_param->max_i_qp;
    svac3Cbr->min_i_qp = svac3_cbr_param->min_i_qp;
    svac3Cbr->max_reencode_times = svac3_cbr_param->max_reencode_times;
    svac3Cbr->qpmap_en = svac3_cbr_param->qpmap_en;
    svac3Cbr->qpmap_mode = svac3_cbr_param->qpmap_mode;

    return;
}

static td_void mapi_adapt_venc_svac3_vbr_param2_mpi(const hi_mapi_venc_svac3_vbr_param *svac3_vbr_param,
    ot_venc_svac3_vbr_param *svac3Vbr)
{
    svac3Vbr->chg_pos = svac3_vbr_param->change_pos;
    svac3Vbr->min_i_proportion = svac3_vbr_param->min_ip_ratio;
    svac3Vbr->max_i_proportion = svac3_vbr_param->max_ip_ratio;
    svac3Vbr->max_reencode_times = svac3_vbr_param->max_reencode_times;
    svac3Vbr->max_qp = svac3_vbr_param->max_qp;
    svac3Vbr->min_qp = svac3_vbr_param->min_qp;
    svac3Vbr->max_i_qp = svac3_vbr_param->max_i_qp;
    svac3Vbr->min_i_qp = svac3_vbr_param->min_i_qp;
    svac3Vbr->qpmap_en = svac3_vbr_param->qpmap_en;
    svac3Vbr->qpmap_mode = svac3_vbr_param->qpmap_mode;

    return;
}

static td_void mapi_adapt_venc_svac3_qvbr_param2_mpi(const hi_mapi_venc_svac3_qvbr_param *svac3_qvbr_param,
    ot_venc_svac3_qvbr_param *svac3Qvbr)
{
    svac3Qvbr->min_i_proportion = svac3_qvbr_param->min_ip_ratio;
    svac3Qvbr->max_i_proportion = svac3_qvbr_param->max_ip_ratio;
    svac3Qvbr->max_reencode_times = svac3_qvbr_param->max_reencode_times;
    svac3Qvbr->qpmap_en = svac3_qvbr_param->qpmap_en;
    svac3Qvbr->qpmap_mode = svac3_qvbr_param->qpmap_mode;
    svac3Qvbr->max_qp = svac3_qvbr_param->max_qp;
    svac3Qvbr->min_qp = svac3_qvbr_param->min_qp;
    svac3Qvbr->max_i_qp = svac3_qvbr_param->max_i_qp;
    svac3Qvbr->min_i_qp = svac3_qvbr_param->min_i_qp;
    svac3Qvbr->max_bit_percent = svac3_qvbr_param->bit_percent_ul;
    svac3Qvbr->min_bit_percent = svac3_qvbr_param->bit_percent_ll;
    svac3Qvbr->max_psnr_fluctuate = svac3_qvbr_param->psnr_fluctuate_ul;
    svac3Qvbr->min_psnr_fluctuate = svac3_qvbr_param->psnr_fluctuate_ll;

    return;
}

static td_void mapi_adapt_venc_svac3_cvbr_param2_mpi(const hi_mapi_venc_svac3_cvbr_param *svac3_cvbr_param,
    ot_venc_svac3_cvbr_param *svac3Cvbr)
{
    svac3Cvbr->min_i_proportion = svac3_cvbr_param->min_ip_ratio;
    svac3Cvbr->max_i_proportion = svac3_cvbr_param->max_ip_ratio;
    svac3Cvbr->max_reencode_times = svac3_cvbr_param->max_reencode_times;
    svac3Cvbr->qpmap_en = svac3_cvbr_param->qpmap_en;
    svac3Cvbr->qpmap_mode = svac3_cvbr_param->qpmap_mode;
    svac3Cvbr->max_qp = svac3_cvbr_param->max_qp;
    svac3Cvbr->min_qp = svac3_cvbr_param->min_qp;
    svac3Cvbr->max_i_qp = svac3_cvbr_param->max_i_qp;
    svac3Cvbr->min_i_qp = svac3_cvbr_param->min_i_qp;
    svac3Cvbr->min_qp_delta = svac3_cvbr_param->min_qp_delta;
    svac3Cvbr->max_qp_delta = svac3_cvbr_param->max_qp_delta;
    svac3Cvbr->extra_bit_percent = svac3_cvbr_param->extra_bit_percent;
    svac3Cvbr->long_term_stats_time_unit = svac3_cvbr_param->long_term_stat_time_unit;

    return;
}

static td_void mapi_adapt_venc_svac3_avbr_param2_mpi(const hi_mapi_venc_svac3_avbr_param *svac3_avbr_param,
    ot_venc_svac3_avbr_param *svac3Avbr)
{
    svac3Avbr->chg_pos = svac3_avbr_param->change_pos;
    svac3Avbr->min_i_proportion = svac3_avbr_param->min_ip_ratio;
    svac3Avbr->max_i_proportion = svac3_avbr_param->max_ip_ratio;
    svac3Avbr->max_reencode_times = svac3_avbr_param->max_reencode_times;
    svac3Avbr->min_still_percent = svac3_avbr_param->min_still_percent;
    svac3Avbr->max_still_qp = svac3_avbr_param->max_still_qp;
    svac3Avbr->min_still_psnr = svac3_avbr_param->min_still_psnr;
    svac3Avbr->max_qp = svac3_avbr_param->max_qp;
    svac3Avbr->min_qp = svac3_avbr_param->min_qp;
    svac3Avbr->max_i_qp = svac3_avbr_param->max_i_qp;
    svac3Avbr->min_i_qp = svac3_avbr_param->min_i_qp;
    svac3Avbr->min_qp_delta = svac3_avbr_param->min_qp_delta;
    svac3Avbr->motion_sensitivity = svac3_avbr_param->motion_sensitivity;
    svac3Avbr->qpmap_en = svac3_avbr_param->qpmap_en;
    svac3Avbr->qpmap_mode = svac3_avbr_param->qpmap_mode;

    return;
}

static td_s32 mapi_adapt_venc_svac3_rc_param2_mpi(hi_mapi_venc_rc_mode rc_mode, const hi_mapi_venc_rc_param *rcParam,
    ot_venc_rc_param *param)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            mapi_adapt_venc_svac3_cbr_param2_mpi(&rcParam->svac3_cbr_param, &param->svac3_cbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            mapi_adapt_venc_svac3_vbr_param2_mpi(&rcParam->svac3_vbr_param, &param->svac3_vbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_QVBR:
            mapi_adapt_venc_svac3_qvbr_param2_mpi(&rcParam->svac3_qvbr_param, &param->svac3_qvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_CVBR:
            mapi_adapt_venc_svac3_cvbr_param2_mpi(&rcParam->svac3_cvbr_param, &param->svac3_cvbr_param);
            break;

        case HI_MAPI_VENC_RC_MODE_AVBR:
            mapi_adapt_venc_svac3_avbr_param2_mpi(&rcParam->svac3_avbr_param, &param->svac3_avbr_param);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, rc_mode:%d\n", rc_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}
#endif

static td_s32 mapi_adapt_venc_mjpeg_rc_param2_mpi(hi_mapi_venc_rc_mode rc_mode, const hi_mapi_venc_rc_param *rcParam,
    ot_venc_rc_param *param)
{
    switch (rc_mode) {
        case HI_MAPI_VENC_RC_MODE_CBR:
            param->mjpeg_cbr_param.max_qfactor = rcParam->mjpeg_cbr_param.max_qfactor;
            param->mjpeg_cbr_param.min_qfactor = rcParam->mjpeg_cbr_param.min_qfactor;
            break;

        case HI_MAPI_VENC_RC_MODE_VBR:
            param->mjpeg_vbr_param.chg_pos = rcParam->mjpeg_vbr_param.change_pos;
            param->mjpeg_vbr_param.max_qfactor = rcParam->mjpeg_vbr_param.max_qfactor;
            param->mjpeg_vbr_param.min_qfactor = rcParam->mjpeg_vbr_param.min_qfactor;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, rc_mode:%d\n", rc_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_venc_rc_param2_mpi(hi_mapi_venc_rc_mode rc_mode, hi_mapi_payload_type type,
    const hi_mapi_venc_rc_param *rcParam, ot_venc_rc_param *param)
{
    td_s32 ret;

    for (td_u32 i = 0; i < OT_VENC_TEXTURE_THRESHOLD_SIZE; i++) {
        param->threshold_i[i] = rcParam->thrd_i[i];
        param->threshold_p[i] = rcParam->thrd_p[i];
        param->threshold_b[i] = rcParam->thrd_b[i];
    }
    param->direction = rcParam->direction_thrd;
    param->row_qp_delta = rcParam->row_qp_delta;
    param->first_frame_start_qp = rcParam->first_frame_start_qp;
    param->scene_chg_detect.detect_scene_chg_en = rcParam->scene_change_detect.detect_scene_change;
    param->scene_chg_detect.adapt_insert_idr_frame_en = rcParam->scene_change_detect.adaptive_insert_idr_frame;

    switch (type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            ret = mapi_adapt_venc_h264_rc_param2_mpi(rc_mode, rcParam, param);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_h264_rc_param2_mapi", ret);
            break;

        case HI_MAPI_PAYLOAD_TYPE_H265:
            ret = mapi_adapt_venc_h265_rc_param2_mpi(rc_mode, rcParam, param);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_h265_rc_param2_mapi", ret);
            break;

#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            ret = mapi_adapt_venc_svac3_rc_param2_mpi(rc_mode, rcParam, param);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_svac3_rc_param2_mapi", ret);
            break;
#endif

        case HI_MAPI_PAYLOAD_TYPE_MJPEG:
            ret = mapi_adapt_venc_mjpeg_rc_param2_mpi(rc_mode, rcParam, param);
            CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_mjpeg_rc_param2_mpi", ret);
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type,enType:%d\n", type);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_rc_param(td_handle venc_hdl, hi_mapi_venc_rc_mode rc_mode,
    hi_mapi_payload_type type, const hi_mapi_venc_rc_param *rcParam)
{
    CHECK_MAPI_VENC_NULL_PTR_RET(rcParam);
    ot_venc_rc_param venc_rc_param = { 0 };

    td_s32 ret = ss_mpi_venc_get_rc_param(venc_hdl, &venc_rc_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_rc_param", ret);

    ret = mapi_adapt_venc_rc_param2_mpi(rc_mode, type, rcParam, &venc_rc_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_rc_param2_mpi", ret);

    ret = ss_mpi_venc_set_rc_param(venc_hdl, &venc_rc_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_rc_param", ret);

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_venc_gop_attr2_mpi(const hi_mapi_venc_gop_attr *venc_gop_attr,
    ot_venc_gop_attr *venc_chn_gop_attr)
{
    switch (venc_gop_attr->gop_mode) {
        case HI_MAPI_VENC_GOPMODE_NORMALP:
            venc_chn_gop_attr->gop_mode = OT_VENC_GOP_MODE_NORMAL_P;
            venc_chn_gop_attr->normal_p.ip_qp_delta = venc_gop_attr->normalp.ip_qp_delta;
            break;

        case HI_MAPI_VENC_GOPMODE_DUALP:
            venc_chn_gop_attr->gop_mode = OT_VENC_GOP_MODE_DUAL_P;
            venc_chn_gop_attr->dual_p.sp_interval = venc_gop_attr->dualp.sp_interval;
            venc_chn_gop_attr->dual_p.sp_qp_delta = venc_gop_attr->dualp.sp_qp_delta;
            venc_chn_gop_attr->dual_p.ip_qp_delta = venc_gop_attr->dualp.ip_qp_delta;
            break;

        case HI_MAPI_VENC_GOPMODE_SMARTP:
            venc_chn_gop_attr->gop_mode = OT_VENC_GOP_MODE_SMART_P;
            venc_chn_gop_attr->smart_p.bg_qp_delta = venc_gop_attr->smartp.bg_qp_delta;
            venc_chn_gop_attr->smart_p.vi_qp_delta = venc_gop_attr->smartp.vi_qp_delta;
            venc_chn_gop_attr->smart_p.bg_interval = venc_gop_attr->smartp.bg_interval;
            break;

        case HI_MAPI_VENC_GOPMODE_BIPREDB:
            venc_chn_gop_attr->gop_mode = OT_VENC_GOP_MODE_BIPRED_B;
            venc_chn_gop_attr->bipred_b.b_frame_num = venc_gop_attr->bipredb.b_frm_num;
            venc_chn_gop_attr->bipred_b.b_qp_delta = venc_gop_attr->bipredb.b_qp_delta;
            venc_chn_gop_attr->bipred_b.ip_qp_delta = venc_gop_attr->bipredb.ip_qp_delta;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "not support mapi gop_mode:%d\n", venc_gop_attr->gop_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_venc_gop_attr2_mapi(const ot_venc_gop_attr *gop_attr, hi_mapi_venc_gop_attr *venc_gop_attr)
{
    switch (gop_attr->gop_mode) {
        case OT_VENC_GOP_MODE_NORMAL_P:
            venc_gop_attr->gop_mode = HI_MAPI_VENC_GOPMODE_NORMALP;
            venc_gop_attr->normalp.ip_qp_delta = gop_attr->normal_p.ip_qp_delta;
            break;

        case OT_VENC_GOP_MODE_DUAL_P:
            venc_gop_attr->gop_mode = HI_MAPI_VENC_GOPMODE_DUALP;
            venc_gop_attr->dualp.sp_interval = gop_attr->dual_p.sp_interval;
            venc_gop_attr->dualp.sp_qp_delta = gop_attr->dual_p.sp_qp_delta;
            venc_gop_attr->dualp.ip_qp_delta = gop_attr->dual_p.ip_qp_delta;
            break;

        case OT_VENC_GOP_MODE_SMART_P:
            venc_gop_attr->gop_mode = HI_MAPI_VENC_GOPMODE_SMARTP;
            venc_gop_attr->smartp.bg_qp_delta = gop_attr->smart_p.bg_qp_delta;
            venc_gop_attr->smartp.vi_qp_delta = gop_attr->smart_p.vi_qp_delta;
            venc_gop_attr->smartp.bg_interval = gop_attr->smart_p.bg_interval;
            break;

        case OT_VENC_GOP_MODE_BIPRED_B:
            venc_gop_attr->gop_mode = HI_MAPI_VENC_GOPMODE_BIPREDB;
            venc_gop_attr->bipredb.b_frm_num = gop_attr->bipred_b.b_frame_num;
            venc_gop_attr->bipredb.b_qp_delta = gop_attr->bipred_b.b_qp_delta;
            venc_gop_attr->bipredb.ip_qp_delta = gop_attr->bipred_b.ip_qp_delta;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "not support mpi enGopMode:%d\n", gop_attr->gop_mode);
            return HI_MAPI_VENC_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_gop_attr(td_handle venc_hdl, const hi_mapi_venc_gop_attr *venc_gop_attr)
{
    ot_venc_rc_param vencRcPara;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_gop_attr);

    td_s32 ret = memset_s(&vencRcPara, sizeof(ot_venc_rc_param), 0x0, sizeof(ot_venc_rc_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ot_venc_chn_attr chnAttr;
    ret = memset_s(&chnAttr, sizeof(ot_venc_chn_attr), 0x0, sizeof(ot_venc_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = ss_mpi_venc_get_chn_attr(venc_hdl, &chnAttr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_chn_attr", ret);

    ot_payload_type type = chnAttr.venc_attr.type;
    if ((type == OT_PT_H264) || (type == OT_PT_H265)) {
        ret = ss_mpi_venc_get_rc_param(venc_hdl, &vencRcPara);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_rc_param", ret);
    }

#ifdef SUPPORT_SVAC3
    if (type == OT_PT_SVAC3) {
        ret = ss_mpi_venc_get_rc_param(venc_hdl, &vencRcPara);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_rc_param", ret);
    }
#endif

    ret = mapi_adapt_venc_gop_attr2_mpi(venc_gop_attr, &chnAttr.gop_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_gop_attr2_mpi", ret);

    ret = ss_mpi_venc_set_chn_attr(venc_hdl, &chnAttr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_chn_attr", ret);
    if ((type == OT_PT_H264) || (type == OT_PT_H265)) {
        ret = ss_mpi_venc_set_rc_param(venc_hdl, &vencRcPara);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_rc_param", ret);
    }

#ifdef SUPPORT_SVAC3
    if (type == OT_PT_SVAC3) {
        ret = ss_mpi_venc_set_rc_param(venc_hdl, &vencRcPara);
        CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_rc_param", ret);
    }
#endif

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_gop_attr(td_handle venc_hdl, hi_mapi_venc_gop_attr *venc_gop_attr)
{
    ot_venc_chn_attr chnAttr;
    CHECK_MAPI_VENC_NULL_PTR_RET(venc_gop_attr);

    td_s32 ret = memset_s(&chnAttr, sizeof(ot_venc_chn_attr), 0x0, sizeof(ot_venc_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = ss_mpi_venc_get_chn_attr(venc_hdl, &chnAttr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_chn_attr", ret);

    ret = mapi_adapt_venc_gop_attr2_mapi(&chnAttr.gop_attr, venc_gop_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "mapi_adapt_venc_gop_attr2_mapi", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_intra_refresh(td_handle venc_hdl, const hi_mapi_venc_intra_refresh *intraRefresh)
{
    ot_venc_intra_refresh vencIntraRefresh;
    CHECK_MAPI_VENC_NULL_PTR_RET(intraRefresh);

    vencIntraRefresh.enable = intraRefresh->refresh_enable;
    vencIntraRefresh.mode = intraRefresh->intra_refresh_mode;
    vencIntraRefresh.refresh_num = intraRefresh->refresh_num;
    vencIntraRefresh.request_i_qp = intraRefresh->req_i_qp;
    td_s32 ret = ss_mpi_venc_set_intra_refresh(venc_hdl, &vencIntraRefresh);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_intra_refresh", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_intra_refresh(td_handle venc_hdl, hi_mapi_venc_intra_refresh *intraRefresh)
{
    ot_venc_intra_refresh vencIntraRefresh;
    CHECK_MAPI_VENC_NULL_PTR_RET(intraRefresh);

    td_s32 ret = ss_mpi_venc_get_intra_refresh(venc_hdl, &vencIntraRefresh);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_intra_refresh", ret);

    intraRefresh->refresh_enable = vencIntraRefresh.enable;
    intraRefresh->intra_refresh_mode = vencIntraRefresh.mode;
    intraRefresh->refresh_num = vencIntraRefresh.refresh_num;
    intraRefresh->req_i_qp = vencIntraRefresh.request_i_qp;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_frame_rate(td_handle venc_hdl, const hi_mapi_frame_rate_ctrl *vencFrameRate)
{
    ot_venc_chn_param vencParamChn;
    CHECK_MAPI_VENC_NULL_PTR_RET(vencFrameRate);

    td_s32 ret = memset_s(&vencParamChn, sizeof(ot_venc_chn_param), 0x0, sizeof(ot_venc_chn_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = ss_mpi_venc_get_chn_param(venc_hdl, &vencParamChn);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_chn_param", ret);

    vencParamChn.frame_rate.src_frame_rate = vencFrameRate->src_frame_rate;
    vencParamChn.frame_rate.dst_frame_rate = vencFrameRate->dst_frame_rate;
    ret = ss_mpi_venc_set_chn_param(venc_hdl, &vencParamChn);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_chn_param", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_frame_rate(td_handle venc_hdl, hi_mapi_frame_rate_ctrl *vencFrameRate)
{
    ot_venc_chn_param vencParamChn;
    CHECK_MAPI_VENC_NULL_PTR_RET(vencFrameRate);

    td_s32 ret = memset_s(&vencParamChn, sizeof(ot_venc_chn_param), 0x0, sizeof(ot_venc_chn_param));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = ss_mpi_venc_get_chn_param(venc_hdl, &vencParamChn);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_chn_param", ret);

    vencFrameRate->src_frame_rate = vencParamChn.frame_rate.src_frame_rate;
    vencFrameRate->dst_frame_rate = vencParamChn.frame_rate.dst_frame_rate;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_hierarchical_qp(td_handle venc_hdl, const hi_mapi_venc_hierarchical_qp *hierarchicalQp)
{
    ot_venc_hierarchical_qp vencHierarchicalQp;
    CHECK_MAPI_VENC_NULL_PTR_RET(hierarchicalQp);

    vencHierarchicalQp.enable = hierarchicalQp->hierarchical_qp_en;
    for (td_u32 i = 0; i < HI_MAPI_VENC_HIERARCHICAL_QP_NUM; i++) {
        vencHierarchicalQp.qp_delta[i] = hierarchicalQp->hierarchical_qp_delta[i];
        vencHierarchicalQp.frame_num[i] = hierarchicalQp->hierarchical_frame_num[i];
    }
    td_s32 ret = ss_mpi_venc_set_hierarchical_qp(venc_hdl, &vencHierarchicalQp);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_hierarchical_qp", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_hierarchical_qp(td_handle venc_hdl, hi_mapi_venc_hierarchical_qp *hierarchicalQp)
{
    ot_venc_hierarchical_qp vencHierarchicalQp;
    CHECK_MAPI_VENC_NULL_PTR_RET(hierarchicalQp);

    td_s32 ret = ss_mpi_venc_get_hierarchical_qp(venc_hdl, &vencHierarchicalQp);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_hierarchical_qp", ret);

    hierarchicalQp->hierarchical_qp_en = vencHierarchicalQp.enable;
    for (td_u32 i = 0; i < HI_MAPI_VENC_HIERARCHICAL_QP_NUM; i++) {
        hierarchicalQp->hierarchical_qp_delta[i] = vencHierarchicalQp.qp_delta[i];
        hierarchicalQp->hierarchical_frame_num[i] = vencHierarchicalQp.frame_num[i];
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_set_frame_lost_strategy(td_handle venc_hdl, const td_bool *isOpenFrmLost)
{
    ot_venc_frame_lost_strategy frmLostParam;
    CHECK_MAPI_VENC_NULL_PTR_RET(isOpenFrmLost);

    td_s32 ret = memset_s(&frmLostParam, sizeof(ot_venc_frame_lost_strategy), 0, sizeof(ot_venc_frame_lost_strategy));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s\n", ret);

    ret = ss_mpi_venc_get_frame_lost_strategy(venc_hdl, &frmLostParam);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_frame_lost_strategy", ret);

    MAPI_INFO_TRACE(HI_MAPI_MOD_VENC,
        "default FrameLostStrategy:\n bFrmLostOpen(%d), u32FrmLostBpsThr(%u), enFrmLostMode(%d), u32EncFrmGaps(%u)\n",
        frmLostParam.enable, frmLostParam.bit_rate_threshold, frmLostParam.mode,
        frmLostParam.frame_gap);

    frmLostParam.enable = *isOpenFrmLost;
    frmLostParam.bit_rate_threshold = VENC_FRAME_LOST_BPS_THRESHOLD;  /* bits per second */
    frmLostParam.mode = OT_VENC_FRAME_LOST_NORMAL;
    frmLostParam.frame_gap = 0;

    MAPI_INFO_TRACE(HI_MAPI_MOD_VENC,
        "update FrameLostStrategy:\n bFrmLostOpen(%d), u32FrmLostBpsThr(%u),enFrmLostMode(%d), u32EncFrmGaps(%u)\n",
        frmLostParam.enable, frmLostParam.bit_rate_threshold, frmLostParam.mode,
        frmLostParam.frame_gap);

    ret = ss_mpi_venc_set_frame_lost_strategy(venc_hdl, &frmLostParam);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_set_frame_lost_strategy", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_frame_lost_strategy(td_handle venc_hdl, td_bool *isOpenFrmLost)
{
    ot_venc_frame_lost_strategy frmLostParam;
    CHECK_MAPI_VENC_NULL_PTR_RET(isOpenFrmLost);

    td_s32 ret = memset_s(&frmLostParam, sizeof(ot_venc_frame_lost_strategy), 0, sizeof(ot_venc_frame_lost_strategy));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s\n", ret);

    ret = ss_mpi_venc_get_frame_lost_strategy(venc_hdl, &frmLostParam);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_frame_lost_strategy", ret);

    MAPI_INFO_TRACE(HI_MAPI_MOD_VENC,
        "current FrameLostStrategy:\n bFrmLostOpen(%d), u32FrmLostBpsThr(%u), enFrmLostMode(%d), u32EncFrmGaps(%u)\n",
        frmLostParam.enable, frmLostParam.bit_rate_threshold, frmLostParam.mode,
        frmLostParam.frame_gap);

    *isOpenFrmLost = frmLostParam.enable;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_send_frame(td_handle venc_hdl, const hi_mapi_frame_data *frame_data,
    td_u32 time_ref, td_s32 timeout)
{
    ot_video_frame_info video_frame;
    CHECK_MAPI_VENC_NULL_PTR_RET(frame_data);

    td_s32 ret = memset_s(&video_frame, sizeof(ot_video_frame_info), 0, sizeof(ot_video_frame_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    mapi_adapt_comm_frame_info_to_mpi(frame_data, &video_frame);
    video_frame.mod_id = OT_ID_VGS;
    video_frame.pool_id = frame_data->pool_id;
    video_frame.video_frame.time_ref = time_ref;

    ret = ss_mpi_venc_send_frame(venc_hdl, &video_frame, timeout);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_send_frame", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_stream_buf_info(td_handle venc_hdl, mapi_adapt_venc_stream_buf_info *streamBufInfo)
{
    ot_venc_stream_buf_info getStreamBufInfo;
    CHECK_MAPI_VENC_NULL_PTR_RET(streamBufInfo);

    td_s32 ret = memset_s(&getStreamBufInfo, sizeof(ot_venc_stream_buf_info), 0, sizeof(ot_venc_stream_buf_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VENC, "memset_s", ret);

    ret = ss_mpi_venc_get_stream_buf_info(venc_hdl, &getStreamBufInfo);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_stream_buf_info", ret);

    for (td_u32 i = 0; i < MAPI_ADAPT_VENC_MAX_TILE_NUM; i++) {
        streamBufInfo->phy_addr[i] = getStreamBufInfo.phys_addr[i];
        streamBufInfo->userAddr[i] = getStreamBufInfo.user_addr[i];
        streamBufInfo->buf_size[i] = getStreamBufInfo.buf_size[i];
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_query_status(td_handle venc_hdl, mapi_adapt_venc_status *status)
{
    ot_venc_chn_attr vencChnAttr;
    ot_venc_chn_status vencChnStat;
    CHECK_MAPI_VENC_NULL_PTR_RET(status);

    td_s32 ret = ss_mpi_venc_get_chn_attr(venc_hdl, &vencChnAttr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_get_chn_attr", ret);

    ret = ss_mpi_venc_query_status(venc_hdl, &vencChnStat);
    CHECK_MAPI_RET(HI_MAPI_MOD_VENC, "ss_mpi_venc_query_status", ret);

    status->left_pics = vencChnStat.left_pics;
    status->left_stream_frames = vencChnStat.left_stream_frames;
    status->curPacks = vencChnStat.cur_packs;
    status->leftRecvPics = vencChnStat.left_recv_pics;
    status->leftEncPics = vencChnStat.left_enc_pics;
    status->jpegSnapEnd = vencChnStat.is_jpeg_snap_end;
    switch (vencChnAttr.venc_attr.type) {
        case OT_PT_H264:
            status->type = HI_MAPI_PAYLOAD_TYPE_H264;
            break;

        case OT_PT_H265:
            status->type = HI_MAPI_PAYLOAD_TYPE_H265;
            break;

#ifdef SUPPORT_SVAC3
        case OT_PT_SVAC3:
            status->type = HI_MAPI_PAYLOAD_TYPE_SVAC3;
            break;
#endif

        case OT_PT_JPEG:
            status->type = HI_MAPI_PAYLOAD_TYPE_JPEG;
            break;

        case OT_PT_MJPEG:
            status->type = HI_MAPI_PAYLOAD_TYPE_MJPEG;
            break;

        default: {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "VENC not support payload type, enType:%d\n",
                           vencChnAttr.venc_attr.type);
        }
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_get_fd(td_handle venchdl)
{
    td_s32 ret = ss_mpi_venc_get_fd(venchdl);
    if (ret != TD_SUCCESS) {
        return ret;
    }
    return ret;
}

td_s32 mapi_adapt_venc_get_stream(td_handle venc_hdl, mapi_adapt_venc_pack *streamPack, td_u32 pack_count,
    mapi_adapt_venc_stream *stream)
{
    CHECK_MAPI_VENC_NULL_PTR_RET(stream);

    stream->pack = streamPack;
    stream->pack_cnt = pack_count;
    td_s32 ret = ss_mpi_venc_get_stream(venc_hdl, stream, 0); /* 0: Non-blocking access to the code stream */
    if (ret != TD_SUCCESS) {
        return ret;
    }

    if (stream->pack_cnt == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "error stream->u32PackCount:%d\n", stream->pack_cnt);
        (td_void)ss_mpi_venc_release_stream(venc_hdl, stream);
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_venc_release_stream(td_handle venc_hdl, mapi_adapt_venc_stream *stream)
{
    return ss_mpi_venc_release_stream(venc_hdl, stream);
}


static td_void mapi_adapt_venc_config_stream_info(hi_mapi_payload_type type, const mapi_adapt_venc_stream *stream,
    hi_mapi_venc_stream_info *stream_info)
{
    switch (type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            stream_info->ref_type = stream->h264_info.ref_type;
            stream_info->start_qp = stream->h264_info.start_qp;
            break;

        case HI_MAPI_PAYLOAD_TYPE_H265:
            stream_info->ref_type = stream->h265_info.ref_type;
            stream_info->start_qp = stream->h265_info.start_qp;
            break;

#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            stream_info->ref_type = stream->svac3_info.ref_type;
            stream_info->start_qp = stream->svac3_info.start_qp;
            break;
#endif

        case HI_MAPI_PAYLOAD_TYPE_JPEG:
            break;

        case HI_MAPI_PAYLOAD_TYPE_MJPEG:
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "not support encode format,the curr is:%d\n", type);
            break;
    }
}

static td_void mapi_adapt_venc_get_packet_type(hi_mapi_payload_type type, const ot_venc_data_type *data_type,
    hi_mapi_venc_data_type *venc_data_type)
{
    venc_data_type->payload_type = type;
    switch (type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            venc_data_type->h264e_type = data_type->h264_type;
            break;

        case HI_MAPI_PAYLOAD_TYPE_H265:
            venc_data_type->h265e_type = data_type->h265_type;
            break;

#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            venc_data_type->svac3e_type = data_type->svac3_type;
            break;
#endif

        case HI_MAPI_PAYLOAD_TYPE_JPEG:
            venc_data_type->jpeg_type = data_type->jpeg_type;
            break;

        case HI_MAPI_PAYLOAD_TYPE_MJPEG:
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "not support encode format,the curr is:%d\n", type);
            break;
    }
}


td_s32 mapi_adapt_venc_config_out_stream_data(hi_mapi_payload_type type,
    const mapi_adapt_venc_stream_buf_info *streamBufInfo, const mapi_adapt_venc_stream *stream,
    hi_mapi_venc_data_attr *outVStream)
{
    CHECK_MAPI_VENC_NULL_PTR_RET(stream);
    CHECK_MAPI_VENC_NULL_PTR_RET(stream->pack);
    CHECK_MAPI_VENC_NULL_PTR_RET(outVStream);

    outVStream->pack_count = stream->pack_cnt;
    outVStream->seq = stream->seq;

    mapi_adapt_venc_config_stream_info(type, stream, &outVStream->stream_info);

    for (td_u32 i = 0; i < stream->pack_cnt; i++) {
        outVStream->data_pack[i].vir_addr[0] = stream->pack[i].addr;
        outVStream->data_pack[i].len[0] = stream->pack[i].len;
        outVStream->data_pack[i].vir_addr[1] = TD_NULL;
        outVStream->data_pack[i].len[1] = 0;
        outVStream->data_pack[i].phy_addr[0] = stream->pack[i].phys_addr;
        outVStream->data_pack[i].phy_addr[1] = TD_NULL;
        outVStream->data_pack[i].offset = stream->pack[i].offset;
        outVStream->data_pack[i].time_stamp = stream->pack[i].pts;
        if (streamBufInfo != TD_NULL) {
            outVStream->data_pack[i].vir_addr[1] = (td_u8 *)streamBufInfo->userAddr[0];
            outVStream->data_pack[i].phy_addr[1] = streamBufInfo->phy_addr[0];
            CHECK_MAPI_UINT_MAX_VAL_RET(HI_MAPI_MOD_VENC, streamBufInfo->buf_size[0]);
            outVStream->data_pack[i].len[1] = (td_u32)streamBufInfo->buf_size[0];
        }

        mapi_adapt_venc_get_packet_type(type, &stream->pack[i].data_type,
            &outVStream->data_pack[i].data_type);
    }

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */
