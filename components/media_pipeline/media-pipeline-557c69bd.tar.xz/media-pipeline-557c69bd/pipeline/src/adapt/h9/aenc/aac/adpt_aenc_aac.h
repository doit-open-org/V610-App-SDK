/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ADPT_AENC_AAC_H
#define ADPT_AENC_AAC_H

#include "hi_mapi_aenc_adpt.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     AENC ADPT */
/** @{ */ /** <!-- [AENC ADPT] */


typedef enum {
    MAPI_AACENC_BITRATE_16000 = 16000,
    MAPI_AACENC_BITRATE_24000 = 24000,
    MAPI_AACENC_BITRATE_32000 = 32000,
    MAPI_AACENC_BITRATE_44000 = 44000,
    MAPI_AACENC_BITRATE_48000 = 48000,
    MAPI_AACENC_BITRATE_64000 = 64000,
    MAPI_AACENC_BITRATE_96000 = 96000,
    MAPI_AACENC_BITRATE_128000 = 128000,
    MAPI_AACENC_BITRATE_132000 = 132000,
    MAPI_AACENC_BITRATE_144000 = 144000,
    MAPI_AACENC_BITRATE_192000 = 192000,
    MAPI_AACENC_BITRATE_256000 = 256000,
    MAPI_AACENC_BITRATE_265000 = 265000,
    MAPI_AACENC_BITRATE_288000 = 288000,
    MAPI_AACENC_BITRATE_320000 = 320000,
} MAPI_AACENC_BitRate;

typedef struct {
    ot_aac_encoder *aacEncoderHdl;
    hi_mapi_aenc_aac_attr aacAttr; /* AAC Attr */
} MAPI_AENC_AacEncoder;

/**
 * @brief    get aenc aac encoder struct
 * @param[out] pstAacEncoder
 * @return 0 success,non-zero error code.
 * @exception    None
 * @date      2017/12/15
 */
td_s32 ADPT_AENC_GetAacEncoder(ot_aenc_encoder *aacEncoder);

/** @} */ /** <!-- ==== AENC ADPT End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
