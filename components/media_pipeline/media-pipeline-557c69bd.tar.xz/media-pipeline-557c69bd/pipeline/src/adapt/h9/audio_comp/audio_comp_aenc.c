/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/audio_comp_aenc.h"
#include "audio_comp/audio_comp_opus.h"
#include "adpt_aenc_aac.h"
#ifdef ENABLE_MP3
#include "adpt_aenc_mp3.h"
#endif
#include "mapi_aenc_inner.h"
#include "mapi_comm_inner.h"
#include "ot_common_aio.h"
#include "ss_mpi_audio.h"
#include "ss_mpi_sys.h"
#include "ot_common_aenc.h"
#include "ss_audio_opus_adp.h"
#include "ot_audio_opus_adp.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 audio_comp_aenc_create_chn(td_handle aenc_hdl, const hi_mapi_aenc_attr *aenc_attr)
{
    ot_aenc_chn_attr aenc_chn_attr;
    CHECK_MAPI_AENC_NULL_PTR_RET(aenc_attr);
    CHECK_MAPI_AENC_NULL_PTR_RET(aenc_attr->value);

    ot_aenc_attr_opus opus_attr = {0};
    td_s32 ret = memset_s(&aenc_chn_attr, sizeof(ot_aenc_chn_attr), 0, sizeof(ot_aenc_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_AENC, "memset_s", ret);

    switch (aenc_attr->aenc_format) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            aenc_chn_attr.type = OT_PT_AAC;
            break;

        case HI_MAPI_AUDIO_FORMAT_G711A:
            aenc_chn_attr.type = OT_PT_G711A;
            break;

        case HI_MAPI_AUDIO_FORMAT_G711U:
            aenc_chn_attr.type = OT_PT_G711U;
            break;

        case HI_MAPI_AUDIO_FORMAT_OPUS:
            aenc_chn_attr.type = OT_PT_OPUS;
            if (aenc_attr->value_len != sizeof(hi_mapi_aenc_opus_attr)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid opus attr size:%u\n", aenc_attr->value_len);
                return HI_MAPI_AENC_EILLPARAM;
            }
            const hi_mapi_aenc_opus_attr *mapi_opus_attr =
                (const hi_mapi_aenc_opus_attr *)aenc_attr->value;
            opus_attr.sample_rate = (ot_audio_sample_rate)mapi_opus_attr->sample_rate;
            opus_attr.bit_width = (ot_audio_bit_width)mapi_opus_attr->bit_width;
            opus_attr.snd_mode = (ot_audio_snd_mode)mapi_opus_attr->sound_mode;
            opus_attr.bit_rate = (ot_opus_bps)mapi_opus_attr->bit_rate;
            opus_attr.app = (ot_opus_application)mapi_opus_attr->application;
            aenc_chn_attr.value = &opus_attr;
            break;

#ifdef ENABLE_MP3
        case HI_MAPI_AUDIO_FORMAT_MP3:
            aenc_chn_attr.type = OT_PT_MP3;
            break;
#endif

        case HI_MAPI_AUDIO_FORMAT_LPCM:
            aenc_chn_attr.type = OT_PT_LPCM;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "not support aenc format, the curr is:%d\n", aenc_attr->aenc_format);
            return HI_MAPI_AENC_EILLPARAM;
    }
    aenc_chn_attr.buf_size = OT_MAX_AUDIO_FRAME_NUM;
    aenc_chn_attr.point_num_per_frame = aenc_attr->pt_num_per_frm;
    if (aenc_attr->aenc_format != HI_MAPI_AUDIO_FORMAT_OPUS) {
        aenc_chn_attr.value = aenc_attr->value;
    }

    ret = ss_mpi_aenc_create_chn(aenc_hdl, &aenc_chn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "ss_mpi_aenc_create_chn fail,ret:%x\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 audio_comp_aenc_destroy_chn(td_handle aenc_hdl)
{
    return ss_mpi_aenc_destroy_chn(aenc_hdl);
}

td_s32 audio_comp_aenc_register_audio_encoder(td_s32 *encoder_hdl, hi_mapi_audio_format audio_format)
{
    CHECK_MAPI_AENC_NULL_PTR_RET(encoder_hdl);
    ot_aenc_encoder aenc_encoder;
    td_s32 ret;

    switch (audio_format) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            ret = ADPT_AENC_GetAacEncoder(&aenc_encoder);
            CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "ADPT_AENC_GetAacEncoder", ret);
            break;
#ifdef ENABLE_MP3
        case HI_MAPI_AUDIO_FORMAT_MP3:
            ret = ADPT_AENC_ConfigMp3Encoder(&aenc_encoder);
            CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "ADPT_AENC_ConfigMp3Encoder", ret);
            break;
#endif
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "Unsupported audio format\n");
            return HI_MAPI_AENC_EILLPARAM;
    }

    ret = ss_mpi_aenc_register_encoder(encoder_hdl, &aenc_encoder);
    CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "ss_mpi_aenc_register_encoder", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_aenc_unregister_audio_encoder(td_s32 encoder_hdl)
{
    return ss_mpi_aenc_unregister_encoder(encoder_hdl);
}

td_s32 audio_comp_aenc_send_frame(td_handle aenc_hdl, const hi_mapi_audio_frame *audio_frm)
{
    ot_audio_frame frm;
    CHECK_MAPI_AENC_NULL_PTR_RET(audio_frm);

    frm.bit_width = audio_frm->bit_width;
    frm.snd_mode = audio_frm->snd_mode;
    frm.time_stamp = audio_frm->time_stamp;
    frm.seq = audio_frm->seq;
    frm.len = audio_frm->len;
    for (td_s32 i = 0; i < HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i++) {
        frm.virt_addr[i] = audio_frm->virt_addr[i];
        frm.phys_addr[i] = audio_frm->phys_addr[i];
        frm.pool_id[i] = audio_frm->pool_id[i];
    }

    td_s32 ret = ss_mpi_aenc_send_frame(aenc_hdl, &frm, NULL);
    CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "ss_mpi_aenc_send_frame", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_aenc_get_fd(td_handle aenc_hdl)
{
    return ss_mpi_aenc_get_fd(aenc_hdl);
}

td_s32 audio_comp_aenc_get_stream(td_handle aenc_hdl, hi_mapi_audio_stream *stream,
                                   hi_mapi_audio_payload_format payload_format)
{
    ot_audio_stream audio_stream;
    CHECK_MAPI_AENC_NULL_PTR_RET(stream);

    td_s32 ret = ss_mpi_aenc_get_stream(aenc_hdl, &audio_stream, TD_FALSE);
    if (ret == OT_ERR_AENC_BUF_EMPTY) {
        ret = HI_MAPI_AENC_BUF_EMPTY;
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "no data in buffer for aenc");
        return ret;
    }
    CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "ss_mpi_aenc_get_stream", ret);

    stream->stream = audio_stream.stream;
    stream->phy_addr = audio_stream.phys_addr;
    stream->len = audio_stream.len;
    stream->time_stamp = audio_stream.time_stamp;
    stream->seq = audio_stream.seq;

    /* STANDARD: strip the Hisi-private 8-byte length header so the caller sees
     * a bare RFC 7587 OPUS RTP payload.  Original (unshifted) pointer is
     * reconstructed in audio_comp_aenc_release_stream by adding -8 back. */
    if (payload_format == HI_MAPI_AUDIO_PAYLOAD_STANDARD) {
        if (stream->stream == TD_NULL || stream->len < AUDIO_COMP_OPUS_HEADER_SIZE) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC,
                "AENC stream too short (%u) for header strip; releasing back to SDK\n", stream->len);
            (td_void)ss_mpi_aenc_release_stream(aenc_hdl, &audio_stream);
            return HI_MAPI_AENC_EILLPARAM;
        }
        stream->stream  = stream->stream + AUDIO_COMP_OPUS_HEADER_SIZE;
        stream->len     = stream->len    - AUDIO_COMP_OPUS_HEADER_SIZE;
        stream->phy_addr = stream->phy_addr + AUDIO_COMP_OPUS_HEADER_SIZE;
    }

    return TD_SUCCESS;
}

td_s32 audio_comp_aenc_release_stream(td_handle aenc_hdl, const hi_mapi_audio_stream *stream,
                                       hi_mapi_audio_payload_format payload_format)
{
    ot_audio_stream audio_stream;
    CHECK_MAPI_AENC_NULL_PTR_RET(stream);

    audio_stream.stream = stream->stream;
    audio_stream.phys_addr = stream->phy_addr;
    audio_stream.len = stream->len;
    audio_stream.time_stamp = stream->time_stamp;
    audio_stream.seq = stream->seq;

    /* STANDARD: restore the original SDK pointer/length/phys_addr by adding
     * back the 8-byte header offset that get_stream stripped.  HI_NATIVE
     * passes through unchanged. */
    if (payload_format == HI_MAPI_AUDIO_PAYLOAD_STANDARD) {
        audio_stream.stream    = audio_stream.stream    - AUDIO_COMP_OPUS_HEADER_SIZE;
        audio_stream.len       = audio_stream.len       + AUDIO_COMP_OPUS_HEADER_SIZE;
        audio_stream.phys_addr = audio_stream.phys_addr - AUDIO_COMP_OPUS_HEADER_SIZE;
    }

    td_s32 ret = ss_mpi_aenc_release_stream(aenc_hdl, &audio_stream);
    CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "ss_mpi_aenc_release_stream", ret);

    return TD_SUCCESS;
}

td_s32 audio_comp_aenc_get_stream_buf_info(td_handle aenc_hdl, td_u64 *phys_addr, td_u32 *size)
{
    return ss_mpi_aenc_get_stream_buf_info(aenc_hdl, (td_phys_addr_t *)phys_addr, size);
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
