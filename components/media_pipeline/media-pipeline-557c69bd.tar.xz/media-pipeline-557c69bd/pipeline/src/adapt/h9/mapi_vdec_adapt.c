/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_vdec_adapt.h"
#include "mapi_comm_adapt.h"
#include "mapi_comm_inner.h"
#include "ss_mpi_vdec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static td_s32 mapi_adapt_vdec_attr_to_mpi(ot_vdec_chn_attr *vdec_chn_attr, const hi_mapi_vdec_attr *vdec_attr)
{
    switch (vdec_attr->type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            vdec_chn_attr->type = OT_PT_H264;
            break;

        case HI_MAPI_PAYLOAD_TYPE_H265:
            vdec_chn_attr->type = OT_PT_H265;
            break;

#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            vdec_chn_attr->type = OT_PT_SVAC3;
            break;
#endif

        case HI_MAPI_PAYLOAD_TYPE_MJPEG:
            vdec_chn_attr->type = OT_PT_MJPEG;
            break;

        case HI_MAPI_PAYLOAD_TYPE_JPEG:
            vdec_chn_attr->type = OT_PT_JPEG;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VDEC, "not supprot the type[%d]. \n", vdec_attr->type);
            return HI_MAPI_VDEC_EILLEGAL_PARAM;
    }

    vdec_chn_attr->mode = vdec_attr->mode;
    vdec_chn_attr->pic_width = vdec_attr->pic_width;
    vdec_chn_attr->pic_height = vdec_attr->pic_height;
    vdec_chn_attr->stream_buf_size = vdec_attr->stream_buf_size;
    vdec_chn_attr->frame_buf_size = vdec_attr->frame_buf_size;
    vdec_chn_attr->frame_buf_cnt = vdec_attr->frame_buf_cnt;
    vdec_chn_attr->video_attr.ref_frame_num = vdec_attr->vdec_video_attr.ref_frame_num;
    vdec_chn_attr->video_attr.temporal_mvp_en = vdec_attr->vdec_video_attr.temporal_mvp_enable;
    vdec_chn_attr->video_attr.tmv_buf_size = vdec_attr->vdec_video_attr.tmv_buf_size;

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_vdec_attr_to_mapi(hi_mapi_vdec_attr *vdec_attr, const ot_vdec_chn_attr *vdec_chn_attr)
{
    switch (vdec_chn_attr->type) {
        case OT_PT_H264:
            vdec_attr->type = HI_MAPI_PAYLOAD_TYPE_H264;
            break;

        case OT_PT_H265:
            vdec_attr->type = HI_MAPI_PAYLOAD_TYPE_H265;
            break;

#ifdef SUPPORT_SVAC3
        case OT_PT_SVAC3:
            vdec_attr->type = HI_MAPI_PAYLOAD_TYPE_SVAC3;
            break;
#endif

        case OT_PT_MJPEG:
            vdec_attr->type = HI_MAPI_PAYLOAD_TYPE_MJPEG;
            break;

        case OT_PT_JPEG:
            vdec_attr->type = HI_MAPI_PAYLOAD_TYPE_JPEG;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VDEC, "not supprot the type[%d]. \n", vdec_chn_attr->type);
            return HI_MAPI_VDEC_EILLEGAL_PARAM;
    }

    vdec_attr->mode = vdec_chn_attr->mode;
    vdec_attr->pic_width = vdec_chn_attr->pic_width;
    vdec_attr->pic_height = vdec_chn_attr->pic_height;
    vdec_attr->stream_buf_size = vdec_chn_attr->stream_buf_size;
    vdec_attr->frame_buf_size = vdec_chn_attr->frame_buf_size;
    vdec_attr->frame_buf_cnt = vdec_chn_attr->frame_buf_cnt;
    vdec_attr->vdec_video_attr.ref_frame_num = vdec_chn_attr->video_attr.ref_frame_num;
    vdec_attr->vdec_video_attr.temporal_mvp_enable = vdec_chn_attr->video_attr.temporal_mvp_en;
    vdec_attr->vdec_video_attr.tmv_buf_size = vdec_chn_attr->video_attr.tmv_buf_size;

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_vdec_config_status_info(hi_mapi_vdec_status *status, const ot_vdec_chn_status *chn_status)
{
    switch (chn_status->type) {
        case OT_PT_H264:
            status->type = HI_MAPI_PAYLOAD_TYPE_H264;
            break;

        case OT_PT_H265:
            status->type = HI_MAPI_PAYLOAD_TYPE_H265;
            break;

#ifdef SUPPORT_SVAC3
        case OT_PT_SVAC3:
            status->type = HI_MAPI_PAYLOAD_TYPE_SVAC3;
            break;
#endif

        case OT_PT_MJPEG:
            status->type = HI_MAPI_PAYLOAD_TYPE_MJPEG;
            break;

        case OT_PT_JPEG:
            status->type = HI_MAPI_PAYLOAD_TYPE_JPEG;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VDEC, "not supprot the type[%d]. \n", chn_status->type);
            return HI_MAPI_VDEC_EILLEGAL_PARAM;
    }

    status->left_stream_bytes = chn_status->left_stream_bytes;
    status->left_stream_frames = chn_status->left_stream_frames;
    status->left_pics = chn_status->left_decoded_frames;
    status->start_recv_stream = chn_status->is_started;
    status->recv_stream_frames = chn_status->recv_stream_frames;
    status->decode_stream_frames = chn_status->dec_stream_frames;
    status->width = chn_status->width;
    status->height = chn_status->height;

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_set_mod_param(td_void)
{
    ot_vdec_mod_param mod_param;
    td_s32 ret = ss_mpi_vdec_get_mod_param(&mod_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_get_mod_param", ret);

    mod_param.vb_src = OT_VB_SRC_PRIVATE;
    ret = ss_mpi_vdec_set_mod_param(&mod_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_set_mod_param", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_create_chn(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr)
{
    ot_vdec_chn_attr vdec_chn_attr;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_attr, HI_MAPI_VDEC_ENULL_PTR);

    td_s32 ret = mapi_adapt_vdec_attr_to_mpi(&vdec_chn_attr, vdec_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_attr_to_mpi", ret);

    ret = ss_mpi_vdec_create_chn(vdec_hdl, &vdec_chn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_create_chn", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_destroy_chn(td_handle vdec_hdl)
{
    return ss_mpi_vdec_destroy_chn(vdec_hdl);
}

td_s32 mapi_adapt_vdec_reset_chn(td_handle vdec_hdl)
{
    return ss_mpi_vdec_reset_chn(vdec_hdl);
}

td_s32 mapi_adapt_vdec_start(td_handle vdec_hdl)
{
    return ss_mpi_vdec_start_recv_stream(vdec_hdl);
}

td_s32 mapi_adapt_vdec_stop(td_handle vdec_hdl)
{
    return ss_mpi_vdec_stop_recv_stream(vdec_hdl);
}

td_s32 mapi_adapt_vdec_get_fd(td_handle vdec_hdl)
{
    return ss_mpi_vdec_get_fd(vdec_hdl);
}

td_s32 mapi_adapt_vdec_query_status(td_handle vdec_hdl, hi_mapi_vdec_status *status)
{
    ot_vdec_chn_status chn_status;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, status, HI_MAPI_VDEC_ENULL_PTR);

    td_s32 ret = ss_mpi_vdec_query_status(vdec_hdl, &chn_status);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_query_status", ret);

    ret = mapi_adapt_vdec_config_status_info(status, &chn_status);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_config_status_info", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_set_attr(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr)
{
    ot_vdec_chn_attr vdec_chn_attr;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_attr, HI_MAPI_VDEC_ENULL_PTR);

    td_s32 ret = mapi_adapt_vdec_attr_to_mpi(&vdec_chn_attr, vdec_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_attr_to_mpi", ret);

    ret = ss_mpi_vdec_set_chn_attr(vdec_hdl, &vdec_chn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_set_chn_attr", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_get_attr(td_handle vdec_hdl, hi_mapi_vdec_attr *vdec_attr)
{
    ot_vdec_chn_attr vdec_chn_attr;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_attr, HI_MAPI_VDEC_ENULL_PTR);

    td_s32 ret = ss_mpi_vdec_get_chn_attr(vdec_hdl, &vdec_chn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_get_chn_attr", ret);

    ret = mapi_adapt_vdec_attr_to_mapi(vdec_attr, &vdec_chn_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_attr_to_mapi", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_set_param(td_handle vdec_hdl, const hi_mapi_vdec_param *vdec_param)
{
    ot_vdec_chn_param vdec_chn_param;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_param, HI_MAPI_VDEC_ENULL_PTR);

    switch (vdec_param->type) {
        case HI_MAPI_PAYLOAD_TYPE_H264:
            vdec_chn_param.type = OT_PT_H264;
            break;

        case HI_MAPI_PAYLOAD_TYPE_H265:
            vdec_chn_param.type = OT_PT_H265;
            break;

#ifdef SUPPORT_SVAC3
        case HI_MAPI_PAYLOAD_TYPE_SVAC3:
            vdec_chn_param.type = OT_PT_SVAC3;
            break;
#endif

        case HI_MAPI_PAYLOAD_TYPE_MJPEG:
            vdec_chn_param.type = OT_PT_MJPEG;
            break;

        case HI_MAPI_PAYLOAD_TYPE_JPEG:
            vdec_chn_param.type = OT_PT_JPEG;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VDEC, "not supprot the type[%d]. \n", vdec_param->type);
            return HI_MAPI_VDEC_EILLEGAL_PARAM;
    }

    vdec_chn_param.display_frame_num = vdec_param->display_frame_num;

#ifdef SUPPORT_SVAC3
    if (vdec_chn_param.type == OT_PT_SVAC3) {
        vdec_chn_param.video_param.composite_dec_en = vdec_param->vdec_video_param.enable_composite_dec;
        vdec_chn_param.video_param.slice_input_en = vdec_param->vdec_video_param.enable_slice_input;
        vdec_chn_param.video_param.err_threshold = vdec_param->vdec_video_param.err_threshold;
        vdec_chn_param.video_param.dec_mode = vdec_param->vdec_video_param.dec_mode;
        vdec_chn_param.video_param.out_order = vdec_param->vdec_video_param.output_order;
        vdec_chn_param.video_param.compress_mode = vdec_param->vdec_video_param.compress_mode;
        vdec_chn_param.video_param.video_format = vdec_param->vdec_video_param.video_format;
        vdec_chn_param.video_param.quick_mark_mode = vdec_param->vdec_video_param.quick_mark_mode;
    }
#endif

    if ((vdec_chn_param.type == OT_PT_H264) || (vdec_chn_param.type == OT_PT_H265)) {
        vdec_chn_param.video_param.composite_dec_en = vdec_param->vdec_video_param.enable_composite_dec;
        vdec_chn_param.video_param.slice_input_en = vdec_param->vdec_video_param.enable_slice_input;
        vdec_chn_param.video_param.err_threshold = vdec_param->vdec_video_param.err_threshold;
        vdec_chn_param.video_param.dec_mode = vdec_param->vdec_video_param.dec_mode;
        vdec_chn_param.video_param.out_order = vdec_param->vdec_video_param.output_order;
        vdec_chn_param.video_param.compress_mode = vdec_param->vdec_video_param.compress_mode;
        vdec_chn_param.video_param.video_format = vdec_param->vdec_video_param.video_format;
        vdec_chn_param.video_param.quick_mark_mode = vdec_param->vdec_video_param.quick_mark_mode;
    } else if ((vdec_chn_param.type == OT_PT_MJPEG) || (vdec_chn_param.type == OT_PT_JPEG)) {
        vdec_chn_param.pic_param.pixel_format = vdec_param->vdec_picture_param.pxel_format;
        vdec_chn_param.pic_param.alpha = vdec_param->vdec_picture_param.alpha;
    }

    td_s32 ret = ss_mpi_vdec_set_chn_param(vdec_hdl, &vdec_chn_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_set_chn_param", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_get_param(td_handle vdec_hdl, hi_mapi_vdec_param *vdec_param)
{
    ot_vdec_chn_param vdec_chn_param;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_param, HI_MAPI_VDEC_ENULL_PTR);

    td_s32 ret = ss_mpi_vdec_get_chn_param(vdec_hdl, &vdec_chn_param);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_get_chn_param", ret);

    switch (vdec_chn_param.type) {
        case OT_PT_H264:
             vdec_param->type = HI_MAPI_PAYLOAD_TYPE_H264;
            break;

        case OT_PT_H265:
            vdec_param->type = HI_MAPI_PAYLOAD_TYPE_H265;
            break;

#ifdef SUPPORT_SVAC3
        case OT_PT_SVAC3:
            vdec_param->type = HI_MAPI_PAYLOAD_TYPE_SVAC3;
            break;
#endif

        case OT_PT_MJPEG:
            vdec_param->type = HI_MAPI_PAYLOAD_TYPE_MJPEG;
            break;

        case OT_PT_JPEG:
            vdec_param->type = HI_MAPI_PAYLOAD_TYPE_JPEG;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VDEC, "not supprot the type[%d]. \n", vdec_chn_param.type);
            return HI_MAPI_VDEC_EILLEGAL_PARAM;
    }

    vdec_param->display_frame_num = vdec_chn_param.display_frame_num;

#ifdef SUPPORT_SVAC3
    if (vdec_chn_param.type == OT_PT_SVAC3) {
        vdec_param->vdec_video_param.enable_composite_dec = vdec_chn_param.video_param.composite_dec_en;
        vdec_param->vdec_video_param.enable_slice_input = vdec_chn_param.video_param.slice_input_en;
        vdec_param->vdec_video_param.err_threshold = vdec_chn_param.video_param.err_threshold;
        vdec_param->vdec_video_param.dec_mode = vdec_chn_param.video_param.dec_mode;
        vdec_param->vdec_video_param.output_order = vdec_chn_param.video_param.out_order;
        vdec_param->vdec_video_param.compress_mode = vdec_chn_param.video_param.compress_mode;
        vdec_param->vdec_video_param.video_format = vdec_chn_param.video_param.video_format;
        vdec_param->vdec_video_param.quick_mark_mode = vdec_chn_param.video_param.quick_mark_mode;
    }
#endif

    if ((vdec_chn_param.type == OT_PT_H264) || (vdec_chn_param.type == OT_PT_H265)) {
        vdec_param->vdec_video_param.enable_composite_dec = vdec_chn_param.video_param.composite_dec_en;
        vdec_param->vdec_video_param.enable_slice_input = vdec_chn_param.video_param.slice_input_en;
        vdec_param->vdec_video_param.err_threshold = vdec_chn_param.video_param.err_threshold;
        vdec_param->vdec_video_param.dec_mode = vdec_chn_param.video_param.dec_mode;
        vdec_param->vdec_video_param.output_order = vdec_chn_param.video_param.out_order;
        vdec_param->vdec_video_param.compress_mode = vdec_chn_param.video_param.compress_mode;
        vdec_param->vdec_video_param.video_format = vdec_chn_param.video_param.video_format;
        vdec_param->vdec_video_param.quick_mark_mode = vdec_chn_param.video_param.quick_mark_mode;
    } else if ((vdec_chn_param.type == OT_PT_MJPEG) || (vdec_chn_param.type == OT_PT_JPEG)) {
        vdec_param->vdec_picture_param.pxel_format = vdec_chn_param.pic_param.pixel_format;
        vdec_param->vdec_picture_param.alpha = vdec_chn_param.pic_param.alpha;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_send_stream(td_handle vdec_hdl, const hi_mapi_vdec_stream *stream, td_s32 timeout)
{
    ot_vdec_stream send_stream;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, stream, HI_MAPI_VDEC_ENULL_PTR);

    send_stream.len = stream->stream_len;
    send_stream.pts = stream->time_stamp;
    send_stream.private_data = stream->private_data;
    send_stream.end_of_frame = stream->end_of_frame;
    send_stream.end_of_stream = stream->end_of_stream;
    send_stream.addr = stream->stream_addr;
    send_stream.need_display = stream->display;

    td_s32 ret = ss_mpi_vdec_send_stream(vdec_hdl, &send_stream, timeout);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_send_stream", ret);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_get_frame(td_handle vdec_hdl, hi_mapi_frame_data *frame_data, td_u32 timeout)
{
    ot_video_frame_info frame_info = {0};
    ot_vdec_supplement_info supplement = {0};
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, frame_data, HI_MAPI_VDEC_ENULL_PTR);

    td_s32 ret = ss_mpi_vdec_get_frame(vdec_hdl, &frame_info, &supplement, timeout);
    if (ret == OT_ERR_VDEC_BUF_EMPTY) {
        /* Unified error codes with the datafifo data is empty */
        ret = HI_MAPI_VDEC_EBUF_EMPTY;
    }
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_get_frame", ret);

    mapi_adapt_comm_frame_info_to_mapi(&frame_info, frame_data);

    return TD_SUCCESS;
}

td_s32 mapi_adapt_vdec_release_frame(td_handle vdec_hdl, const hi_mapi_frame_data *frame_data)
{
    ot_video_frame_info frame_info;
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, frame_data, HI_MAPI_VDEC_ENULL_PTR);

    mapi_adapt_comm_frame_info_to_mpi(frame_data, &frame_info);

    td_s32 ret = ss_mpi_vdec_release_frame(vdec_hdl, &frame_info);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_release_frame", ret);

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
