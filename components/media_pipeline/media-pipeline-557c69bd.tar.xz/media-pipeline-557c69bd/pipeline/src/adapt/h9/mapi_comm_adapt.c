/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_comm_adapt.h"
#include <dlfcn.h>
#include <unistd.h>
#include "ss_mpi_sys.h"
#include "ss_mpi_sys_mem.h"
#include "ss_mpi_vb.h"
#include "ss_mpi_vi.h"
#include "ot_common_sys.h"
#include "ot_common_vi.h"
#include "ot_buffer.h"
#include "securec.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

ot_pixel_format mapi_adapt_comm_pixel_format_convert(hi_mapi_pixel_format mapi_pixel_format)
{
    ot_pixel_format pixel_format = OT_PIXEL_FORMAT_YUV_SEMIPLANAR_420;
    switch (mapi_pixel_format) {
        case HI_MAPI_PIXEL_FORMAT_RGB_444:
            pixel_format = OT_PIXEL_FORMAT_RGB_444;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_555:
            pixel_format = OT_PIXEL_FORMAT_RGB_555;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_565:
            pixel_format = OT_PIXEL_FORMAT_RGB_565;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_888:
            pixel_format = OT_PIXEL_FORMAT_RGB_888;
            break;
        case HI_MAPI_PIXEL_FORMAT_BGR_444:
            pixel_format = OT_PIXEL_FORMAT_BGR_444;
            break;
        case HI_MAPI_PIXEL_FORMAT_BGR_555:
            pixel_format = OT_PIXEL_FORMAT_BGR_555;
            break;
        case HI_MAPI_PIXEL_FORMAT_BGR_565:
            pixel_format = OT_PIXEL_FORMAT_BGR_565;
            break;
        case HI_MAPI_PIXEL_FORMAT_BGR_888:
            pixel_format = OT_PIXEL_FORMAT_BGR_888;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_1555:
            pixel_format = OT_PIXEL_FORMAT_ARGB_1555;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_4444:
            pixel_format = OT_PIXEL_FORMAT_ARGB_4444;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_8565:
            pixel_format = OT_PIXEL_FORMAT_ARGB_8565;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_8888:
            pixel_format = OT_PIXEL_FORMAT_ARGB_8888;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_2BPP:
            pixel_format = OT_PIXEL_FORMAT_ARGB_2BPP;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_CLUT2:
            pixel_format = OT_PIXEL_FORMAT_ARGB_CLUT2;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_CLUT2_2X2:
            pixel_format = OT_PIXEL_FORMAT_ARGB_CLUT2_2X2;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_CLUT2_4X4:
            pixel_format = OT_PIXEL_FORMAT_ARGB_CLUT2_4X4;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_CLUT4:
            pixel_format = OT_PIXEL_FORMAT_ARGB_CLUT4;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_CLUT4_2X2:
            pixel_format = OT_PIXEL_FORMAT_ARGB_CLUT4_2X2;
            break;
        case HI_MAPI_PIXEL_FORMAT_ARGB_CLUT4_4X4:
            pixel_format = OT_PIXEL_FORMAT_ARGB_CLUT4_4X4;
            break;
        case HI_MAPI_PIXEL_FORMAT_ABGR_1555:
            pixel_format = OT_PIXEL_FORMAT_ABGR_1555;
            break;
        case HI_MAPI_PIXEL_FORMAT_ABGR_4444:
            pixel_format = OT_PIXEL_FORMAT_ABGR_4444;
            break;
        case HI_MAPI_PIXEL_FORMAT_ABGR_8565:
            pixel_format = OT_PIXEL_FORMAT_ABGR_8565;
            break;
        case HI_MAPI_PIXEL_FORMAT_ABGR_8888:
            pixel_format = OT_PIXEL_FORMAT_ABGR_8888;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_8BPP:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_8BPP;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_10BPP:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_10BPP;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_12BPP:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_12BPP;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_14BPP:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_14BPP;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_16BPP;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_H10:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_16BPP_H10;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_H12:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_16BPP_H12;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_H14:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_16BPP_H14;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_L10:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_16BPP_L10;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_L12:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_16BPP_L12;
            break;
        case HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_L14:
            pixel_format = OT_PIXEL_FORMAT_RGB_BAYER_16BPP_L14;
            break;
        case HI_MAPI_PIXEL_FORMAT_YVU_PLANAR_422:
            pixel_format = OT_PIXEL_FORMAT_YVU_PLANAR_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_YVU_PLANAR_420:
            pixel_format = OT_PIXEL_FORMAT_YVU_PLANAR_420;
            break;
        case HI_MAPI_PIXEL_FORMAT_YVU_PLANAR_444:
            pixel_format = OT_PIXEL_FORMAT_YVU_PLANAR_444;
            break;
        case HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_422:
            pixel_format = OT_PIXEL_FORMAT_YVU_SEMIPLANAR_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420:
            pixel_format = OT_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
            break;
        case HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_444:
            pixel_format = OT_PIXEL_FORMAT_YVU_SEMIPLANAR_444;
            break;
        case HI_MAPI_PIXEL_FORMAT_YUV_SEMIPLANAR_422:
            pixel_format = OT_PIXEL_FORMAT_YUV_SEMIPLANAR_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_YUV_SEMIPLANAR_420:
            pixel_format = OT_PIXEL_FORMAT_YUV_SEMIPLANAR_420;
            break;
        case HI_MAPI_PIXEL_FORMAT_YUV_SEMIPLANAR_444:
            pixel_format = OT_PIXEL_FORMAT_YUV_SEMIPLANAR_444;
            break;
        case HI_MAPI_PIXEL_FORMAT_YUYV_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_YUYV_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_YVYU_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_YVYU_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_UYVY_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_UYVY_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_VYUY_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_VYUY_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_YYUV_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_YYUV_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_YYVU_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_YYVU_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_UVYY_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_UVYY_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_VUYY_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_VUYY_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_VY1UY0_PACKAGE_422:
            pixel_format = OT_PIXEL_FORMAT_VY1UY0_PACKAGE_422;
            break;
        case HI_MAPI_PIXEL_FORMAT_YUV_400:
            pixel_format = OT_PIXEL_FORMAT_YUV_400;
            break;
        case HI_MAPI_PIXEL_FORMAT_UV_420:
            pixel_format = OT_PIXEL_FORMAT_UV_420;
            break;
        case HI_MAPI_PIXEL_FORMAT_BGR_888_PLANAR:
            pixel_format = OT_PIXEL_FORMAT_BGR_888_PLANAR;
            break;
        case HI_MAPI_PIXEL_FORMAT_HSV_888_PACKAGE:
            pixel_format = OT_PIXEL_FORMAT_HSV_888_PACKAGE;
            break;
        case HI_MAPI_PIXEL_FORMAT_HSV_888_PLANAR:
            pixel_format = OT_PIXEL_FORMAT_HSV_888_PLANAR;
            break;
        case HI_MAPI_PIXEL_FORMAT_LAB_888_PACKAGE:
            pixel_format = OT_PIXEL_FORMAT_LAB_888_PACKAGE;
            break;
        case HI_MAPI_PIXEL_FORMAT_LAB_888_PLANAR:
            pixel_format = OT_PIXEL_FORMAT_LAB_888_PLANAR;
            break;
        case HI_MAPI_PIXEL_FORMAT_S8C1:
            pixel_format = OT_PIXEL_FORMAT_S8C1;
            break;
        case HI_MAPI_PIXEL_FORMAT_S8C2_PACKAGE:
            pixel_format = OT_PIXEL_FORMAT_S8C2_PACKAGE;
            break;
        case HI_MAPI_PIXEL_FORMAT_S8C2_PLANAR:
            pixel_format = OT_PIXEL_FORMAT_S8C2_PLANAR;
            break;
        case HI_MAPI_PIXEL_FORMAT_S8C3_PLANAR:
            pixel_format = OT_PIXEL_FORMAT_S8C3_PLANAR;
            break;
        case HI_MAPI_PIXEL_FORMAT_S16C1:
            pixel_format = OT_PIXEL_FORMAT_S16C1;
            break;
        case HI_MAPI_PIXEL_FORMAT_U8C1:
            pixel_format = OT_PIXEL_FORMAT_U8C1;
            break;
        case HI_MAPI_PIXEL_FORMAT_U16C1:
            pixel_format = OT_PIXEL_FORMAT_U16C1;
            break;
        case HI_MAPI_PIXEL_FORMAT_S32C1:
            pixel_format = OT_PIXEL_FORMAT_S32C1;
            break;
        case HI_MAPI_PIXEL_FORMAT_U32C1:
            pixel_format = OT_PIXEL_FORMAT_U32C1;
            break;
        case HI_MAPI_PIXEL_FORMAT_U64C1:
            pixel_format = OT_PIXEL_FORMAT_U64C1;
            break;
        case HI_MAPI_PIXEL_FORMAT_S64C1:
            pixel_format = OT_PIXEL_FORMAT_S64C1;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "pixel_format %d not support! force to YUV_SEMIPLANAR_420\n", mapi_pixel_format);
            pixel_format = OT_PIXEL_FORMAT_YUV_SEMIPLANAR_420;
            break;
    }

    return pixel_format;
}

ot_video_format mapi_adapt_comm_video_format_convert(hi_mapi_video_format mapi_video_format)
{
    ot_video_format video_format = OT_VIDEO_FORMAT_LINEAR;
    switch (mapi_video_format) {
        case HI_MAPI_VIDEO_FORMAT_LINEAR:
            video_format = OT_VIDEO_FORMAT_LINEAR;
            break;
        case HI_MAPI_VIDEO_FORMAT_TILE_64x16:
            video_format = OT_VIDEO_FORMAT_TILE_64x16;
            break;
        case HI_MAPI_VIDEO_FORMAT_TILE_16x8:
            video_format = OT_VIDEO_FORMAT_TILE_16x8;
            break;
        case HI_MAPI_VIDEO_FORMAT_TILE_32x4:
            video_format = OT_VIDEO_FORMAT_TILE_32x4;
            break;            
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "video_format %d not support! force to 420\n", mapi_video_format);
            video_format = OT_VIDEO_FORMAT_LINEAR;
            break;
    }

    return video_format;
}

ot_compress_mode mapi_adapt_comm_compress_mode_convert(hi_mapi_compress_mode mapi_compress_mode)
{
    ot_compress_mode compress_mode = OT_COMPRESS_MODE_NONE;
    switch (mapi_compress_mode) {
        case HI_MAPI_COMPRESS_MODE_NONE:
            compress_mode = OT_COMPRESS_MODE_NONE;
            break;
        case HI_MAPI_COMPRESS_MODE_SEG:
            compress_mode = OT_COMPRESS_MODE_SEG;
            break;
        case HI_MAPI_COMPRESS_MODE_SEG_COMPACT:
            compress_mode = OT_COMPRESS_MODE_SEG_COMPACT;
            break;
        case HI_MAPI_COMPRESS_MODE_TILE:
            compress_mode = OT_COMPRESS_MODE_TILE;
            break;         
        case HI_MAPI_COMPRESS_MODE_LINE:
            compress_mode = OT_COMPRESS_MODE_LINE;
            break; 
        case HI_MAPI_COMPRESS_MODE_FRAME:
            compress_mode = OT_COMPRESS_MODE_FRAME;
            break; 
        case HI_MAPI_COMPRESS_MODE_FMAP:
            compress_mode = OT_COMPRESS_MODE_FMAP;
            break;                                        
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "compress_mode %d not support! force to NONE\n", mapi_compress_mode);
            compress_mode = OT_COMPRESS_MODE_NONE;
            break;
    }

    return compress_mode;
}


td_s32 mapi_adapt_comm_dlopen(td_void **lib_handle, td_char *lib_name)
{
    if (lib_handle == TD_NULL || lib_name == TD_NULL) {
        return TD_FAILURE;
    }

    *lib_handle = TD_NULL;
    *lib_handle = dlopen(lib_name, RTLD_LAZY | RTLD_LOCAL);

    if (*lib_handle == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "dlopen %s failed!\n", lib_name);
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_comm_dlsym(td_void **func_handle, td_void *lib_handle, td_char *func_name)
{
    if (lib_handle == TD_NULL || func_handle == TD_NULL || func_name == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "lib_handle or func_handle or func_name is empty!");
        return TD_FAILURE;
    }

    *func_handle = TD_NULL;
    *func_handle = dlsym(lib_handle, func_name);

    if (*func_handle == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "dlsym %s fail,error msg is %s!\n", func_name, dlerror());
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

td_s32 mapi_adapt_comm_dlclose(td_void *lib_handle)
{
    if (lib_handle == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "lib_handle is NULL!\n");
        return TD_FAILURE;
    }

    dlclose(lib_handle);

    return TD_SUCCESS;
}

td_void mapi_adapt_comm_frame_info_to_mapi(const ot_video_frame_info *frame_info, hi_mapi_frame_data *frame_data)
{
    if (frame_info == TD_NULL || frame_data == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "input is null!");
        return;
    }

    frame_data->mod_id = frame_info->mod_id;
    frame_data->pts = frame_info->video_frame.pts;
    frame_data->pool_id = frame_info->pool_id;
    frame_data->frame_data_type = HI_MAPI_FRAME_DATA_TYPE_YUV;
    frame_data->width = frame_info->video_frame.width;
    frame_data->height = frame_info->video_frame.height;
    frame_data->field = frame_info->video_frame.field;
    frame_data->pixel_format = frame_info->video_frame.pixel_format;
    frame_data->compress_mode = frame_info->video_frame.compress_mode;
    frame_data->video_format = frame_info->video_frame.video_format;
    frame_data->dynamic_range = frame_info->video_frame.dynamic_range;
    frame_data->color_gamut = frame_info->video_frame.color_gamut;
    frame_data->time_ref = frame_info->video_frame.time_ref;
    frame_data->frame_flag = frame_info->video_frame.frame_flag;

    for (td_u32 i = 0; i < HI_MAPI_FRAME_DATA_ADDR_NUM; i++) {
        frame_data->header_phys_addr[i] = frame_info->video_frame.header_phys_addr[i];
        frame_data->heade_virt_addr[i] = (td_u64)(uintptr_t)frame_info->video_frame.header_virt_addr[i];
        frame_data->heade_stride[i] = frame_info->video_frame.header_stride[i];
        frame_data->phy_addr[i] = frame_info->video_frame.phys_addr[i];
        frame_data->vir_addr[i] = (td_u64)(uintptr_t)frame_info->video_frame.virt_addr[i];
        frame_data->stride[i] = frame_info->video_frame.stride[i];
    }
    frame_data->video_supplement.misc_info_phys_addr = frame_info->video_frame.supplement.misc_info_phys_addr;
    frame_data->video_supplement.jpeg_dcf_phy_addr = frame_info->video_frame.supplement.jpeg_dcf_phys_addr;
    frame_data->video_supplement.isp_info_phy_addr = frame_info->video_frame.supplement.isp_info_phys_addr;
    frame_data->video_supplement.low_delay_phy_addr = frame_info->video_frame.supplement.low_delay_phys_addr;
    frame_data->video_supplement.bnr_mot_phy_addr = frame_info->video_frame.supplement.bnr_mot_phys_addr;
    frame_data->video_supplement.motion_data_phy_addr = frame_info->video_frame.supplement.motion_data_phys_addr;
    frame_data->video_supplement.frame_dng_phy_addr = frame_info->video_frame.supplement.frame_dng_phys_addr;

    frame_data->video_supplement.misc_info_vir_addr = frame_info->video_frame.supplement.misc_info_virt_addr;
    frame_data->video_supplement.jpeg_dcf_vir_addr = frame_info->video_frame.supplement.jpeg_dcf_virt_addr;
    frame_data->video_supplement.isp_info_vir_addr = frame_info->video_frame.supplement.isp_info_virt_addr;
    frame_data->video_supplement.low_delay_vir_addr = frame_info->video_frame.supplement.low_delay_virt_addr;
    frame_data->video_supplement.bnr_mot_virt_addr = frame_info->video_frame.supplement.bnr_mot_virt_addr;
    frame_data->video_supplement.motion_data_vir_addr = frame_info->video_frame.supplement.motion_data_virt_addr;
    frame_data->video_supplement.frame_dng_vir_addr = frame_info->video_frame.supplement.frame_dng_virt_addr;

    return;
}

td_void mapi_adapt_comm_frame_info_to_mpi(const hi_mapi_frame_data *frame_data, ot_video_frame_info *frame_info)
{
    if (frame_info == TD_NULL || frame_data == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "input is null!");
        return;
    }

    frame_info->pool_id = frame_data->pool_id;
    frame_info->mod_id = OT_ID_USER;
    frame_info->video_frame.width = frame_data->width;
    frame_info->video_frame.height = frame_data->height;
    frame_info->video_frame.field = OT_VIDEO_FIELD_FRAME;
    frame_info->video_frame.pixel_format = frame_data->pixel_format;
    frame_info->video_frame.video_format = frame_data->video_format;
    frame_info->video_frame.compress_mode = frame_data->compress_mode;
    frame_info->video_frame.dynamic_range = OT_DYNAMIC_RANGE_SDR8;
    frame_info->video_frame.color_gamut = OT_COLOR_GAMUT_BT709;

    for (td_u32 i = 0; i < HI_MAPI_FRAME_DATA_ADDR_NUM; i++) {
        frame_info->video_frame.header_stride[i] = 0;  /* Image compression header stride */
        frame_info->video_frame.header_phys_addr[i] = 0; /* image compression header phy_addr */
        frame_info->video_frame.header_virt_addr[i] = 0; /*  image compression header vir_addr */
        frame_info->video_frame.stride[i] = frame_data->stride[i];   /* image data stride */
        frame_info->video_frame.phys_addr[i] = frame_data->phy_addr[i]; /* image data phy_addr */
        frame_info->video_frame.virt_addr[i] = (td_void *)(uintptr_t)frame_data->vir_addr[i]; /* image data vir_addr */
    }
    frame_info->video_frame.time_ref = 0;
    frame_info->video_frame.pts = frame_data->pts;
    frame_info->video_frame.frame_flag = 0;

    frame_info->video_frame.supplement.misc_info_phys_addr = frame_data->video_supplement.misc_info_phys_addr;
    frame_info->video_frame.supplement.jpeg_dcf_phys_addr = frame_data->video_supplement.jpeg_dcf_phy_addr;
    frame_info->video_frame.supplement.isp_info_phys_addr = frame_data->video_supplement.isp_info_phy_addr;
    frame_info->video_frame.supplement.low_delay_phys_addr = frame_data->video_supplement.low_delay_phy_addr;
    frame_info->video_frame.supplement.bnr_mot_phys_addr = frame_data->video_supplement.bnr_mot_phy_addr;
    frame_info->video_frame.supplement.motion_data_phys_addr = frame_data->video_supplement.motion_data_phy_addr;
    frame_info->video_frame.supplement.frame_dng_phys_addr = frame_data->video_supplement.frame_dng_phy_addr;

    frame_info->video_frame.supplement.misc_info_virt_addr = frame_data->video_supplement.misc_info_vir_addr;
    frame_info->video_frame.supplement.jpeg_dcf_virt_addr = frame_data->video_supplement.jpeg_dcf_vir_addr;
    frame_info->video_frame.supplement.isp_info_virt_addr = frame_data->video_supplement.isp_info_vir_addr;
    frame_info->video_frame.supplement.low_delay_virt_addr = frame_data->video_supplement.low_delay_vir_addr;
    frame_info->video_frame.supplement.bnr_mot_virt_addr = frame_data->video_supplement.bnr_mot_virt_addr;
    frame_info->video_frame.supplement.motion_data_virt_addr = frame_data->video_supplement.motion_data_vir_addr;
    frame_info->video_frame.supplement.frame_dng_virt_addr = frame_data->video_supplement.frame_dng_vir_addr;

    return;
}

td_void *mapi_adapt_comm_mmap(td_u64 phy_addr, td_u32 size)
{
    return ss_mpi_sys_mmap(phy_addr, size);
}

td_void *mapi_adapt_comm_mmap_cached(td_u64 phy_addr, td_u32 size)
{
    return ss_mpi_sys_mmap_cached(phy_addr, size);
}

td_s32 mapi_adapt_comm_munmap(td_void *vir_addr, td_u32 size)
{
    return ss_mpi_sys_munmap(vir_addr, size);
}

td_u32 mapi_adapt_comm_create_vb_pool(ot_pic_buf_attr *frame_attr, td_u32 blk_cnt)
{
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_SYS, frame_attr, TD_FAILURE);
    ot_vb_calc_cfg vb_attr = {0};
    ot_vb_pool_cfg cfg = {0};

    ot_common_get_pic_buf_cfg(frame_attr, &vb_attr);
    cfg.blk_size = vb_attr.vb_size;
    cfg.blk_cnt = blk_cnt;
    cfg.remap_mode = OT_VB_REMAP_MODE_NONE;
    return ss_mpi_vb_create_pool(&cfg);
}

td_s32 mapi_adapt_comm_destroy_vb_pool(ot_vb_pool pool_id)
{
    if (pool_id == OT_VB_INVALID_POOL_ID) {
        return TD_SUCCESS;
    }

    td_s32 vb_exit_ret;
    for (td_u32 i = 0; i < MAPI_SYS_VB_EXIT_MAX_CNT; i++) {
        if (pool_id != OT_VB_INVALID_POOL_ID) {
            vb_exit_ret = ss_mpi_vb_destroy_pool(pool_id);
        } else {
            vb_exit_ret = TD_SUCCESS;
        }
        if (vb_exit_ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "ss_mpi_vb_destroy_pool failed:%#x.\n", vb_exit_ret);
            usleep(MAPI_SYS_VB_EXIT_USLEEP_TIME);
            continue;
        }

        break;
    }
    return vb_exit_ret;
}

static td_void mapi_buffer_attr_convert(const mapi_pic_buf_attr *mapi_buffer_attr, ot_pic_buf_attr *buffer_attr)
{
    buffer_attr->width = mapi_buffer_attr->width;
    buffer_attr->height = mapi_buffer_attr->height;
    buffer_attr->align = OT_DEFAULT_ALIGN;

    if (mapi_buffer_attr->bit_width == 8) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_8;
    } else if (mapi_buffer_attr->bit_width == 10) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_10;
    } else if (mapi_buffer_attr->bit_width == 12) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_12;
    } else if (mapi_buffer_attr->bit_width == 14) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_14;
    } else if (mapi_buffer_attr->bit_width == 16) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_16;		
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "bit_width %d not support! force to 8 bit\n", mapi_buffer_attr->bit_width);
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_8;
    }

    buffer_attr->pixel_format = mapi_adapt_comm_pixel_format_convert(mapi_buffer_attr->pixel_format);
    buffer_attr->compress_mode = mapi_adapt_comm_compress_mode_convert(mapi_buffer_attr->compress_mode);
    buffer_attr->video_format = mapi_adapt_comm_video_format_convert(mapi_buffer_attr->video_format);
}

static td_void mapi_vdec_buffer_attr_convert(const mapi_vdec_pic_buf_attr *mapi_buffer_attr, ot_pic_buf_attr *buffer_attr)
{
    buffer_attr->width = mapi_buffer_attr->width;
    buffer_attr->height = mapi_buffer_attr->height;
    buffer_attr->align = OT_DEFAULT_ALIGN;

    if (mapi_buffer_attr->bit_width == 8) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_8;
    } else if (mapi_buffer_attr->bit_width == 10) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_10;
    } else if (mapi_buffer_attr->bit_width == 12) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_12;
    } else if (mapi_buffer_attr->bit_width == 14) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_14;
    } else if (mapi_buffer_attr->bit_width == 16) {
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_16;		
    } else {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "bit_width %d not support! force to 8 bit\n", mapi_buffer_attr->bit_width);
        buffer_attr->bit_width = OT_DATA_BIT_WIDTH_8;
    }

    buffer_attr->pixel_format = mapi_adapt_comm_pixel_format_convert(mapi_buffer_attr->pixel_format);
    buffer_attr->compress_mode = mapi_adapt_comm_compress_mode_convert(mapi_buffer_attr->compress_mode);
    buffer_attr->video_format = mapi_adapt_comm_video_format_convert(mapi_buffer_attr->video_format);
}

static td_u32 mapi_adapt_comm_get_pic_common_vb_size(const td_void *attr, td_u32 attr_len)
{
    ot_pic_buf_attr buf_attr = {0};
    mapi_pic_buf_attr *mapi_buf_attr = TD_NULL;

    if (attr_len != sizeof(mapi_pic_buf_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "attr len %d not match, force return 0\n", attr_len);
        return 0;
    }

    mapi_buf_attr = (mapi_pic_buf_attr *)attr;
    mapi_buffer_attr_convert(mapi_buf_attr, &buf_attr);

    return ot_common_get_pic_buf_size(&buf_attr);
}

static td_u32 mapi_adapt_comm_get_vdec_pic_buf_size(const td_void *attr, td_u32 attr_len)
{
    ot_pic_buf_attr buf_attr = {0};
    mapi_vdec_pic_buf_attr *mapi_buf_attr = TD_NULL;

    if (attr_len != sizeof(mapi_vdec_pic_buf_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "attr len %d not match, force return 0\n", attr_len);
        return 0;
    }

    mapi_buf_attr = (mapi_vdec_pic_buf_attr *)attr;
    mapi_vdec_buffer_attr_convert(mapi_buf_attr, &buf_attr);

    return ot_vdec_get_pic_buf_size(mapi_buf_attr->type, &buf_attr);
}

static td_u32 mapi_adapt_comm_get_vdec_tmv_buf_size(const td_void *attr, td_u32 attr_len)
{
    mapi_vdec_pic_buf_attr *mapi_buf_attr = TD_NULL;

    if (attr_len != sizeof(mapi_vdec_pic_buf_attr)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "attr len %d not match, force return 0\n", attr_len);
        return 0;
    }

    mapi_buf_attr = (mapi_vdec_pic_buf_attr *)attr;

    return ot_vdec_get_tmv_buf_size(mapi_buf_attr->type, mapi_buf_attr->width, mapi_buf_attr->height);
}

td_u32 mapi_adapt_comm_vb_get_buffer_size(mapi_buf_type type, const td_void *attr, td_u32 attr_len)
{
    td_u32 buf_size = 0;
    if (attr == TD_NULL || attr_len == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "attr null ptr or attr_len is %d fail, force return 0\n", attr_len);
        return 0;
    }

    switch (type) {
        case MAPI_BUF_TYPE_PIC_COMMON_VB:
            buf_size = mapi_adapt_comm_get_pic_common_vb_size(attr, attr_len);
            break;
        case MAPI_BUF_TYPE_VDEC_PIC_BUF:
            buf_size = mapi_adapt_comm_get_vdec_pic_buf_size(attr, attr_len);
            break;
        case MAPI_BUF_TYPE_VDEC_TMV_BUF:
            buf_size = mapi_adapt_comm_get_vdec_tmv_buf_size(attr, attr_len);
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "buf type %d not support, force return 0\n", type);
            break;
    }

    return buf_size;
}

/* Fill a VPSS chn0 wrap (卷绕) buffer attr: 8-bit YVU420 SEG_COMPACT linear. */
td_void mapi_adapt_comm_set_vpss_wrap_buf_attr(mapi_pic_buf_attr *attr, td_u32 width, td_u32 height)
{
    if (attr == TD_NULL) {
        return;
    }
    attr->width = width;
    attr->height = height;
    attr->bit_width = 8; /* 8: wrap buffer bit width */
    attr->pixel_format = HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    attr->compress_mode = HI_MAPI_COMPRESS_MODE_SEG_COMPACT;
    attr->video_format = HI_MAPI_VIDEO_FORMAT_LINEAR;
}

/* VPSS chn0 wrap buf_line/buf_size (param->large=chn0, param->small=chn1). Either out may be TD_NULL. */
td_s32 mapi_adapt_comm_get_vpss_wrap_buf(const mapi_vpss_wrap_calc_param *param,
    td_u32 *buf_line, td_u32 *buf_size)
{
    ot_vpss_venc_wrap_param wrap_param = {0};
    ot_pic_buf_attr buf_attr = {0};
    td_u32 line = 0;

    if (param == TD_NULL || param->large_attr == TD_NULL) {
        return TD_FAILURE;
    }

    wrap_param.all_online = param->all_online;
    wrap_param.frame_rate = (param->frame_rate != 0) ? param->frame_rate : 30; /* 30: default fps */
    wrap_param.full_lines_std = param->full_lines_std;
    wrap_param.large_stream_size.width = param->large_attr->width;
    wrap_param.large_stream_size.height = param->large_attr->height;
    wrap_param.small_stream_size.width = param->small_size.width;
    wrap_param.small_stream_size.height = param->small_size.height;

    if (ss_mpi_sys_get_vpss_venc_wrap_buf_line(&wrap_param, &line) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "get vpss venc wrap buf line failed\n");
        return TD_FAILURE;
    }

    mapi_buffer_attr_convert(param->large_attr, &buf_attr);
    if (buf_line != TD_NULL) {
        *buf_line = line;
    }
    if (buf_size != TD_NULL) {
        *buf_size = ot_comm_get_vpss_venc_wrap_buf_size(&buf_attr, line);
    }
    return TD_SUCCESS;
}

/* VI wrap buf_line for dev_num independent sensors in one call (offline, is_slave=FALSE).
   Dual sensors share bandwidth, so all pipes must be computed together. */
td_s32 mapi_adapt_comm_get_vi_wrap_buf_lines(const hi_mapi_size *pipe_size, const td_u32 *full_lines_std,
    const td_u32 *frame_rate, td_u32 dev_num, td_u32 *buf_line_out)
{
    ot_vi_wrap_in_param in_param = {0};
    ot_vi_wrap_out_param out_param = {0};
    td_u32 i;

    if (pipe_size == TD_NULL || full_lines_std == TD_NULL || frame_rate == TD_NULL ||
        buf_line_out == TD_NULL || dev_num == 0) {
        return TD_FAILURE;
    }
    if (dev_num > OT_VI_MAX_PHYS_PIPE_NUM) {
        dev_num = OT_VI_MAX_PHYS_PIPE_NUM;
    }

    in_param.pipe_num = dev_num;
    in_param.is_slave = TD_FALSE; /* independent sensors */
    for (i = 0; i < dev_num; i++) {
        td_u32 fps = (frame_rate[i] != 0) ? frame_rate[i] : 30; /* 30: default fps */
        in_param.wrap_param[i].pipe_size.width = pipe_size[i].width;
        in_param.wrap_param[i].pipe_size.height = pipe_size[i].height;
        in_param.wrap_param[i].full_lines_std = full_lines_std[i];
        in_param.wrap_param[i].frame_rate_100x = fps * 100; /* 100: SDK expects 100x fps */
        in_param.wrap_param[i].slave_param.vi_vpss_online = TD_FALSE; /* VI offline path */
        in_param.wrap_param[i].slave_param.vpss_venc_wrap = TD_FALSE;
        in_param.wrap_param[i].slave_param.vpss_chn0_size.width = pipe_size[i].width;
        in_param.wrap_param[i].slave_param.vpss_chn0_size.height = pipe_size[i].height;
        in_param.wrap_param[i].slave_param.large_stream_size.width = pipe_size[i].width;
        in_param.wrap_param[i].slave_param.large_stream_size.height = pipe_size[i].height;
    }

    if (ss_mpi_sys_get_vi_wrap_buffer_line(&in_param, &out_param) != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "get vi wrap buffer line failed\n");
        return TD_FAILURE;
    }
    for (i = 0; i < dev_num; i++) {
        buf_line_out[i] = out_param.buf_line[i];
    }
    return TD_SUCCESS;
}


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
