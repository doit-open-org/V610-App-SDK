/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_OSD_ADAPT_DEFINE_H__
#define __MAPI_OSD_ADAPT_DEFINE_H__

#include "hi_mapi_comm_adapt_define.h"
#include "hi_mapi_osd_adapt_define.h"
#include "hi_mapi_vpss_adapt_define.h"
#include "mapi_osd_inner.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

typedef struct {
    hi_mapi_osd_bind_mod bind_module;
    td_s32 dev_id;
    td_s32 chn_id;
} mapi_adapt_osd_chn_bind_info;

typedef struct {
    mapi_osd_rgn_type rgn_type;
    hi_mapi_point start_pos;
    td_u32 content_width;
    td_u32 content_height;
    td_u32 content_color;
    mapi_adapt_osd_chn_bind_info chn_bind_info;
} mapi_adapt_osd_rgn_chn_attr;

typedef struct {
    mapi_osd_rgn_type type; /* region type */
    hi_mapi_size rgn_size;
    hi_mapi_pixel_format pixel_format;
    td_u32 color;
    hi_mapi_osd_type osd_type;
} mapi_adapt_osd_rgn_attr;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* __MAPI_OSD_ADAPT_DEFINE_H__ */
