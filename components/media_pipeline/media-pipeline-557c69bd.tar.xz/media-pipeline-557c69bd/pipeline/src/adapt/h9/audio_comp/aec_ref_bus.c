/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "audio_comp/aec_ref_bus.h"
#include "securec.h"
#include <pthread.h>

/* ~1s @16kHz mono，足以吸收 AO 播放的突发缓冲 */
#define AEC_REF_BUS_CAPACITY 16000

static int16_t g_ring[AEC_REF_BUS_CAPACITY];
static uint32_t g_head;    /* 读索引 */
static uint32_t g_count;   /* 当前可用样本数 */
static td_bool g_enabled = TD_FALSE;
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;

void aec_ref_bus_set_enabled(td_bool enable)
{
    (void)pthread_mutex_lock(&g_lock);
    g_enabled = enable;
    if (enable != TD_TRUE) {
        g_head = 0;
        g_count = 0;
    }
    (void)pthread_mutex_unlock(&g_lock);
}

td_bool aec_ref_bus_enabled(void)
{
    return g_enabled;
}

void aec_ref_bus_reset(void)
{
    (void)pthread_mutex_lock(&g_lock);
    g_head = 0;
    g_count = 0;
    (void)pthread_mutex_unlock(&g_lock);
}

void aec_ref_bus_write(const int16_t *pcm, uint32_t samples)
{
    if (pcm == NULL || samples == 0) {
        return;
    }
    (void)pthread_mutex_lock(&g_lock);
    if (g_enabled != TD_TRUE) {
        (void)pthread_mutex_unlock(&g_lock);
        return;
    }
    /* 单次写入超过环容量时，只保留最新的尾部 */
    if (samples >= AEC_REF_BUS_CAPACITY) {
        pcm += (samples - AEC_REF_BUS_CAPACITY);
        samples = AEC_REF_BUS_CAPACITY;
    }
    /* 空间不足则丢弃最旧样本（覆盖式，保持参考新鲜） */
    if (g_count + samples > AEC_REF_BUS_CAPACITY) {
        uint32_t drop = g_count + samples - AEC_REF_BUS_CAPACITY;
        g_head = (g_head + drop) % AEC_REF_BUS_CAPACITY;
        g_count -= drop;
    }
    uint32_t tail = (g_head + g_count) % AEC_REF_BUS_CAPACITY;
    uint32_t first = AEC_REF_BUS_CAPACITY - tail;
    if (first > samples) {
        first = samples;
    }
    (void)memcpy_s(&g_ring[tail], (AEC_REF_BUS_CAPACITY - tail) * sizeof(int16_t),
        pcm, first * sizeof(int16_t));
    if (samples > first) {
        (void)memcpy_s(&g_ring[0], AEC_REF_BUS_CAPACITY * sizeof(int16_t),
            pcm + first, (samples - first) * sizeof(int16_t));
    }
    g_count += samples;
    (void)pthread_mutex_unlock(&g_lock);
}

int aec_ref_bus_read(int16_t *out, uint32_t samples)
{
    if (out == NULL || samples == 0) {
        return -1;
    }
    (void)pthread_mutex_lock(&g_lock);
    if (g_enabled != TD_TRUE || g_count < samples) {
        (void)pthread_mutex_unlock(&g_lock);
        return -1;
    }
    uint32_t first = AEC_REF_BUS_CAPACITY - g_head;
    if (first > samples) {
        first = samples;
    }
    (void)memcpy_s(out, samples * sizeof(int16_t),
        &g_ring[g_head], first * sizeof(int16_t));
    if (samples > first) {
        (void)memcpy_s(out + first, (samples - first) * sizeof(int16_t),
            &g_ring[0], (samples - first) * sizeof(int16_t));
    }
    g_head = (g_head + samples) % AEC_REF_BUS_CAPACITY;
    g_count -= samples;
    (void)pthread_mutex_unlock(&g_lock);
    return 0;
}
