/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <pthread.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include "hi_mapi_acap.h"
#include "mapi_acap_inner.h"
#include "audio_comp/audio_comp_acodec.h"
#include "audio_comp/audio_comp_acap.h"
#include "audio_comp/audio_comp_afe.h"
#include "mapi_sys_adapt.h"
#include "mapi_comm_inner.h"
#include "hi_mapi_acap_arch.h"
#include "hi_mapi_ao_arch.h"
#include "mapi_acap_arch.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static td_bool g_acap_inited = TD_FALSE;
static mapi_acap_server_context g_acap_context[HI_MAPI_ACAP_DEV_MAX_NUM];
static td_s16 *g_acap_resample_ratebuff[HI_MAPI_ACAP_DEV_MAX_NUM][HI_MAPI_ACAP_CHN_MAX_NUM] = { NULL };
static pthread_mutex_t g_acap_func_lock[HI_MAPI_ACAP_DEV_MAX_NUM] = {
    [0 ... (HI_MAPI_ACAP_DEV_MAX_NUM - 1)] = PTHREAD_MUTEX_INITIALIZER
};

#define MAPI_ACAP_LEGACY_CHN_CNT 2
#define MAPI_ACAP_LEGACY_CLK_SHARE 1
#define MAPI_ACAP_TOPOLOGY_RESERVED_NUM 4

static td_s32 mapi_acap_set_default_afe(mapi_acap_server_context *ctx)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(ctx);

    td_s32 ret = strncpy_s(ctx->afe_provider_name, sizeof(ctx->afe_provider_name),
        "hisi", sizeof(ctx->afe_provider_name) - 1);
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "strncpy_s", ret);
    ctx->afe_attr.model_path = TD_NULL;
    return TD_SUCCESS;
}

static td_s32 mapi_acap_validate_input_topology(const hi_mapi_acap_input_topology *topology)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(topology);

    if (topology->enable == TD_FALSE) {
        return TD_SUCCESS;
    }
    if (topology->chn_cnt == 0 || topology->chn_cnt > HI_MAPI_ACAP_CHN_MAX_NUM ||
        topology->mic_chn_cnt == 0 || topology->mic_chn_cnt > HI_MAPI_ACAP_MIC_CHN_MAX_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "invalid input topology channel count\n");
        return HI_MAPI_ACAP_EILLPARAM;
    }

    for (td_u32 i = 0; i < topology->mic_chn_cnt; i++) {
        if (topology->mic_chn_hdl[i] < 0 || (td_u32)topology->mic_chn_hdl[i] >= topology->chn_cnt) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "invalid mic channel handle:%d\n", topology->mic_chn_hdl[i]);
            return HI_MAPI_ACAP_EILLPARAM;
        }
        for (td_u32 j = i + 1; j < topology->mic_chn_cnt; j++) {
            if (topology->mic_chn_hdl[i] == topology->mic_chn_hdl[j]) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "duplicate mic channel handle:%d\n",
                    topology->mic_chn_hdl[i]);
                return HI_MAPI_ACAP_EILLPARAM;
            }
        }
    }

    if (topology->ref_chn_hdl != OT_INVALID_HANDLE &&
        (topology->ref_chn_hdl < 0 || (td_u32)topology->ref_chn_hdl >= topology->chn_cnt)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "invalid reference channel handle:%d\n", topology->ref_chn_hdl);
        return HI_MAPI_ACAP_EILLPARAM;
    }
    if (topology->out_chn_hdl < 0 || (td_u32)topology->out_chn_hdl >= topology->chn_cnt) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "invalid output channel handle:%d\n", topology->out_chn_hdl);
        return HI_MAPI_ACAP_EILLPARAM;
    }
    for (td_u32 i = 0; i < MAPI_ACAP_TOPOLOGY_RESERVED_NUM; i++) {
        if (topology->reserved[i] != 0) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "input topology reserved fields must be zero\n");
            return HI_MAPI_ACAP_EILLPARAM;
        }
    }
    return TD_SUCCESS;
}

static td_void mapi_acap_apply_input_topology(mapi_acap_server_context *ctx,
    const hi_mapi_acap_input_topology *topology)
{
    if (topology->enable == TD_TRUE) {
        ctx->chn_cnt = topology->chn_cnt;
        ctx->clk_sel = topology->clk_share;
    } else {
        ctx->chn_cnt = MAPI_ACAP_LEGACY_CHN_CNT;
        ctx->clk_sel = MAPI_ACAP_LEGACY_CLK_SHARE;
    }
}

static td_bool mapi_acap_input_topology_equal(const hi_mapi_acap_input_topology *left,
    const hi_mapi_acap_input_topology *right)
{
    if (left->enable != right->enable) {
        return TD_FALSE;
    }
    if (left->enable == TD_FALSE) {
        return TD_TRUE;
    }
    return memcmp(left, right, sizeof(*left)) == 0 ? TD_TRUE : TD_FALSE;
}

static td_s32 mapi_acap_get_chn_num(hi_mapi_audio_sound_mode sound_mode, td_u32 *chn_num)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(chn_num);

    switch (sound_mode) {
        case HI_MAPI_AUDIO_SOUND_MODE_STEREO:
            *chn_num = HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT;
            break;
        case HI_MAPI_AUDIO_SOUND_MODE_MONO:
            *chn_num = HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "not support sound mode\n");
            return HI_MAPI_ACAP_EILLPARAM;
    }
    return TD_SUCCESS;
}

td_void mapi_acap_init_vqe_cfg(const hi_mapi_audio_vqe_attr *audio_vqe_cfg)
{
    if (audio_vqe_cfg != TD_NULL) {
        for (td_s32 i = 0; i < HI_MAPI_ACAP_DEV_MAX_NUM; i++) {
            g_acap_context[i].talk_vqe_attr.open_mask = audio_vqe_cfg->talk_vqe_attr.open_mask;
        }
    }
}

td_s32 mapi_acap_init(td_void)
{
    td_s32 i, j;
    td_s32 ret;

    if (g_acap_inited == TD_TRUE) {
        return TD_SUCCESS;
    }

    for (i = 0; i < HI_MAPI_ACAP_DEV_MAX_NUM; i++) {
        g_acap_context[i].acap_state = MAPI_ACAP_UNINITED;
        g_acap_context[i].chn_cnt = MAPI_ACAP_LEGACY_CHN_CNT;
        /* 1: frame sync clock and bit stream clock of AI device 0 multiplexing AO device 0 */
        g_acap_context[i].clk_sel = MAPI_ACAP_LEGACY_CLK_SHARE;
        /* 0: 8bit not expand 16bit */
        g_acap_context[i].expand_flag = 0;
        g_acap_context[i].frm_num = MAPI_ACAP_FRAME_CACHED_CNT;
        g_acap_context[i].acap_attr.i2s_type = HI_MAPI_AIO_I2STYPE_INNERCODEC;
        ret = mapi_acap_set_default_afe(&g_acap_context[i]);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "mapi_acap_set_default_afe", ret);
        ret = memset_s(g_acap_context[i].acap_chn_start, sizeof(td_bool) * HI_MAPI_ACAP_CHN_MAX_NUM, 0,
                       sizeof(td_bool) * HI_MAPI_ACAP_CHN_MAX_NUM);
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);

        for (j = 0; j < HI_MAPI_ACAP_CHN_MAX_NUM; j++) {
            g_acap_resample_ratebuff[i][j] = NULL;
        }
    }

    ret = mapi_acap_audio_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "mapi_acap_audio_init fail, ret:%x\n", ret);
        return ret;
    }

#ifdef AUDIO_COMP_AFE_HAS_HISI
    hisi_afe_provider_register();
#endif
#ifdef AUDIO_COMP_AFE_HAS_EXTERNAL
    external_afe_provider_register();
#endif

    /* inner acodec provider must be explicitly registered for static-link
     * builds where the constructor may be stripped by the linker. */
    inner_acodec_register();
#ifdef AUDIO_COMP_AFE_HAS_HISI
    (td_void)audio_comp_afe_set_active("hisi");
#elif defined(AUDIO_COMP_AFE_HAS_EXTERNAL)
    (td_void)audio_comp_afe_set_active("external");
#endif

    g_acap_inited = TD_TRUE;
    return TD_SUCCESS;
}

td_s32 mapi_acap_deinit(td_void)
{
    td_s32 i;
    td_s32 ret;

    if (g_acap_inited != TD_TRUE) {
        return TD_SUCCESS;
    }

    for (i = 0; i < HI_MAPI_ACAP_DEV_MAX_NUM; i++) {
        if (g_acap_context[i].acap_state != MAPI_ACAP_UNINITED) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACap is not Deinit, media can not deinit, try deinit acap\n");
            ret = hi_mapi_acap_deinit((td_handle)i);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "acap deinit handle:%d failed! ret:%x\n", i, ret);
            }
        }
    }

    if (audio_comp_acodec_get_active() != TD_NULL) {
        audio_comp_acodec_close();
    }

    for (i = 0; i < HI_MAPI_ACAP_DEV_MAX_NUM; i++) {
        ret = memset_s(&g_acap_context[i].acap_attr, sizeof(hi_mapi_acap_attr), 0, sizeof(hi_mapi_acap_attr));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);
        g_acap_context[i].acap_state = MAPI_ACAP_BUTT;
        ret = mapi_acap_set_default_afe(&g_acap_context[i]);
        CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "mapi_acap_set_default_afe", ret);
        ret = memset_s(g_acap_context[i].acap_chn_start, sizeof(td_bool) * HI_MAPI_ACAP_CHN_MAX_NUM, 0,
                       sizeof(td_bool) * HI_MAPI_ACAP_CHN_MAX_NUM);
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);
    }

    mapi_acap_audio_deinit();

    g_acap_inited = TD_FALSE;
    return TD_SUCCESS;
}

static td_s32 mapi_acap_dual_mono_to_stereo(const td_s16 *left_chn_data, const td_s16 *right_chn_data,
    td_u32 sample_num_per_chn, td_s16 *stereo_data, td_u32 data_array_len)
{
    if (sample_num_per_chn > (UINT32_MAX / HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "sample_num_per_chn too large to avoid overflow\n");
        return HI_MAPI_SYS_ARRAY_OUT_BOUNDS;
    }

    td_u64 required_size = (td_u64)sample_num_per_chn * HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT;
    if (data_array_len < required_size) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "data_array_len < %llu!\n", required_size);
        return HI_MAPI_SYS_ARRAY_OUT_BOUNDS;
    }

    for (td_u32 i = 0; i < sample_num_per_chn; i++) {
        td_u64 index = (td_u64)i * HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT;
        stereo_data[index] = left_chn_data[i];
        stereo_data[index + 1] = right_chn_data[i];
    }

    return TD_SUCCESS;
}

static td_s32 mapi_acap_stereo_to_dual_mono(td_s16 *left_chn_data, td_s16 *right_chn_data,
    td_u32 sample_num_per_chn, const td_s16 *stereo_data, td_u32 data_array_len)
{
    td_u32 i;

    if (sample_num_per_chn > (UINT32_MAX / HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "sample_num_per_chn too large to avoid overflow\n");
        return HI_MAPI_SYS_VALUE_OVERFLOW;
    }
    if (data_array_len < sample_num_per_chn * HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "data_array_len < %u!\n",
            sample_num_per_chn * HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT);
        return HI_MAPI_SYS_ARRAY_OUT_BOUNDS;
    }
    for (i = 0; i < sample_num_per_chn * HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i += 2) {
        left_chn_data[i / HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT] = stereo_data[i];
        right_chn_data[i / HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT] = stereo_data[i + 1];
    }

    return TD_SUCCESS;
}

static td_s32 mapi_acap_stop_all_chn(td_handle acap_hdl)
{
    td_s32 ret;
    td_u32 i;

    for (i = 0; i < HI_MAPI_ACAP_CHN_MAX_NUM; i++) {
        if (g_acap_context[acap_hdl].acap_chn_start[i] != TD_FALSE) {
            ret = hi_mapi_acap_stop(acap_hdl, i);
            if (ret != TD_SUCCESS) {
                return ret;
            }
        }
    }

    return TD_SUCCESS;
}

static td_s32 mapi_acap_open_resampler(const hi_mapi_acap_attr *acap_attr, mapi_acap_resample_info *acap_resmp_info)
{
    td_u32 chn_num = 0;
    td_s32 ret = mapi_acap_get_chn_num(acap_attr->sound_mode, &chn_num);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "mapi_acap_get_chn_num fail, ret:%x\n", ret);
        return ret;
    }

    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ACAP, "resampler create, in_sample_rate = %u, out_sample_rate = %u, chn_num = %u\n",
        acap_attr->sample_rate, acap_attr->resample_rate, chn_num);

    acap_resmp_info->acap_resampler = hal_mapi_acap_resampler_create(acap_attr->sample_rate,
        acap_attr->resample_rate, (td_s32)chn_num);
    if (acap_resmp_info->acap_resampler == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "hal_mapi_acap_resampler_create fail\n");
        return HI_MAPI_ACAP_EOPERATE;
    }

    ret = mapi_adapt_sys_alloc_mmz_buffer(&acap_resmp_info->res_mmz_phy_addr,
        (td_void **)&acap_resmp_info->res_mmz_vir_addr, (sizeof(td_u16) * MAPI_ACAP_RESAMPLE_BUFF_SIZE),
        "AcapResBuf", TD_FALSE);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "mapi_adapt_sys_alloc_mmz_buffer fail, ret:%x\n", ret);
        hal_mapi_acap_resampler_destroy(acap_resmp_info->acap_resampler);
        return ret;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_acap_close_resampler(const mapi_acap_resample_info *acap_resmp_info)
{
    hal_mapi_acap_resampler_destroy(acap_resmp_info->acap_resampler);

    td_s32 ret = mapi_adapt_sys_free_mmz_buffer(acap_resmp_info->res_mmz_phy_addr, acap_resmp_info->res_mmz_vir_addr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "mapi_adapt_sys_free_mmz_buffer fail, ret:%x\n", ret);
        return ret;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_acap_process_resampler_prepare(td_handle acap_hdl, td_handle acap_chn_hdl,
    const hi_mapi_audio_frame *audio_frm, mapi_acap_resample_data_attr *in_data_attr, td_u32 in_samples)
{
    td_s32 ret;
    (td_void)acap_chn_hdl;

    switch (g_acap_context[acap_hdl].acap_attr.sound_mode) {
        case HI_MAPI_AUDIO_SOUND_MODE_STEREO:
            ret = mapi_acap_dual_mono_to_stereo((td_s16 *)audio_frm->virt_addr[0], (td_s16 *)audio_frm->virt_addr[1],
                in_samples, in_data_attr->data_buf, (td_u32)in_data_attr->buf_len);
            CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "mapi_acap_dual_mono_to_stereo", ret);
            break;

        case HI_MAPI_AUDIO_SOUND_MODE_MONO:
            ret = memcpy_s(in_data_attr->data_buf, (size_t)in_data_attr->buf_len,
                audio_frm->virt_addr[0], (size_t)audio_frm->len);
            CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "memcpy_s", ret);
            break;

        default:
            break;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_acap_process_resampler(td_handle acap_hdl, td_handle acap_chn_hdl, hi_mapi_audio_frame *audio_frm)
{
    td_s16 in_buff[HI_MAPI_AIO_MAX_POINT_PER_FRAME * HI_MAPI_ACAP_CHN_MAX_NUM];

    g_acap_context[acap_hdl].acap_resmp_info.saved_frm_len = audio_frm->len;
    td_u32 in_samples = audio_frm->len / ((td_u32)g_acap_context[acap_hdl].acap_attr.bit_width + 1);

    mapi_acap_resample_data_attr in_data_attr, out_data_attr;
    in_data_attr.data_buf = in_buff;
    in_data_attr.buf_len = HI_MAPI_AIO_MAX_POINT_PER_FRAME * HI_MAPI_ACAP_CHN_MAX_NUM;
    td_s32 ret = mapi_acap_process_resampler_prepare(acap_hdl, acap_chn_hdl, audio_frm, &in_data_attr, in_samples);
    CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "mapi_acap_process_resampler_prepare", ret);

    out_data_attr.data_buf = g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl];
    out_data_attr.buf_len = MAPI_ACAP_RESAMPLE_BUFF_SIZE;

    td_s32 out_samples = hal_mapi_acap_resampler_process(g_acap_context[acap_hdl].acap_resmp_info.acap_resampler,
        &in_data_attr, (td_s32)in_samples, &out_data_attr);
    if (out_samples < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "hal_mapi_acap_resampler_process exec fail, ret:%x\n", out_samples);
        return HI_MAPI_ACAP_EOPERATE;
    }

    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ACAP, "resample out_samples:%d\n", out_samples);
    CHECK_MAPI_UINT_PRODUCT_OVERFLOW_RET(HI_MAPI_MOD_ACAP,
        (td_u32)g_acap_context[acap_hdl].acap_attr.bit_width + 1, out_samples);
    audio_frm->len = (td_u32)out_samples * ((td_u32)g_acap_context[acap_hdl].acap_attr.bit_width + 1);

    if (audio_frm->len > HI_MAPI_AIO_MAX_POINT_PER_FRAME * MAPI_ACAP_UP_RESAMPLE_MULTIPLE_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "audio_frm->len:%u > buf max len:%u!\n",
            HI_MAPI_AIO_MAX_POINT_PER_FRAME * MAPI_ACAP_UP_RESAMPLE_MULTIPLE_MAX, audio_frm->len);
        return HI_MAPI_SYS_ARRAY_OUT_BOUNDS;
    }

    switch (g_acap_context[acap_hdl].acap_attr.sound_mode) {
        case HI_MAPI_AUDIO_SOUND_MODE_STEREO:
            audio_frm->virt_addr[0] = (td_u8 *)g_acap_context[acap_hdl].acap_resmp_info.res_mmz_vir_addr;
            audio_frm->virt_addr[1] = (td_u8 *)g_acap_context[acap_hdl].acap_resmp_info.res_mmz_vir_addr +
                                       audio_frm->len;
            ret = mapi_acap_stereo_to_dual_mono((td_s16 *)audio_frm->virt_addr[0], (td_s16 *)audio_frm->virt_addr[1],
                (td_u32)out_samples, g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl], MAPI_ACAP_RESAMPLE_BUFF_SIZE);
            CHECK_MAPI_RET(HI_MAPI_MOD_ACAP, "mapi_acap_stereo_to_dual_mono", ret);
            break;

        case HI_MAPI_AUDIO_SOUND_MODE_MONO:
            audio_frm->virt_addr[0] = (td_u8 *)g_acap_context[acap_hdl].acap_resmp_info.res_mmz_vir_addr +
                HI_MAPI_AIO_MAX_POINT_PER_FRAME * MAPI_ACAP_UP_RESAMPLE_MULTIPLE_MAX * acap_chn_hdl;
            ret = memcpy_s(audio_frm->virt_addr[0], audio_frm->len,
                g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl], audio_frm->len);
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memcpy_s", ret);
            break;

        default:
            break;
    }

    return TD_SUCCESS;
}

static td_void mapi_acap_check_resample(const hi_mapi_acap_attr *acap_attr)
{
    if ((acap_attr->sample_rate > acap_attr->resample_rate) &&
        (acap_attr->resample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_16000)) {
        if (acap_attr->pt_num_per_frm % ((td_u32)acap_attr->sample_rate / (td_u32)acap_attr->resample_rate) != 0) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP,
                "acap sample_rate[%d] resample_rate[%d], pt_num_per_frm must be multiple of %d!\n",
                acap_attr->sample_rate, acap_attr->resample_rate,
                (td_u32)acap_attr->sample_rate / (td_u32)acap_attr->resample_rate);
        }
    }

    if ((acap_attr->sound_mode == HI_MAPI_AUDIO_SOUND_MODE_STEREO) &&
        (acap_attr->sample_rate == HI_MAPI_AUDIO_SAMPLE_RATE_16000) &&
        (acap_attr->resample_rate == HI_MAPI_AUDIO_SAMPLE_RATE_48000)) {
        if (acap_attr->pt_num_per_frm % 2 != 0) { /* 2: must be multiple of 2 */
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP,
                "acap sample_rate[%d] resample_rate[%d], pt_num_per_frm must be multiple of 2!\n",
                acap_attr->sample_rate, acap_attr->resample_rate);
        }
    }
}

td_s32 hi_mapi_acap_init(td_handle acap_hdl, const hi_mapi_acap_attr *acap_attr)
{
    td_s32 ret;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_NULL_PTR_RET(acap_attr);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACap is started, no need init acap repeatedly!\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return TD_SUCCESS;
    }

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_STOPED &&
        g_acap_context[acap_hdl].acap_attr.sample_rate == acap_attr->sample_rate &&
        g_acap_context[acap_hdl].acap_attr.bit_width == acap_attr->bit_width &&
        g_acap_context[acap_hdl].acap_attr.work_mode == acap_attr->work_mode &&
        g_acap_context[acap_hdl].acap_attr.pt_num_per_frm == acap_attr->pt_num_per_frm &&
        g_acap_context[acap_hdl].acap_attr.sound_mode == acap_attr->sound_mode &&
        g_acap_context[acap_hdl].acap_attr.mixer_mic_mode == acap_attr->mixer_mic_mode &&
        g_acap_context[acap_hdl].acap_attr.track_mode == acap_attr->track_mode &&
        g_acap_context[acap_hdl].acap_attr.resample_rate == acap_attr->resample_rate &&
        g_acap_context[acap_hdl].acap_attr.i2s_type == acap_attr->i2s_type &&
        mapi_acap_input_topology_equal(&g_acap_context[acap_hdl].acap_attr.input_topology,
            &acap_attr->input_topology) == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP, "ACAP attribute not change return successful\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return TD_SUCCESS;
    }

    mapi_acap_check_resample(acap_attr);

    ret = mapi_acap_validate_input_topology(&acap_attr->input_topology);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "mapi_acap_validate_input_topology", ret,
        g_acap_func_lock[acap_hdl]);

    mapi_acap_server_context config_context = g_acap_context[acap_hdl];
    mapi_acap_apply_input_topology(&config_context, &acap_attr->input_topology);
    ret = audio_comp_acap_set_ai_pub_attr(acap_hdl, &config_context, acap_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acap_set_ai_pub_attr", ret, g_acap_func_lock[acap_hdl]);
    g_acap_context[acap_hdl].chn_cnt = config_context.chn_cnt;
    g_acap_context[acap_hdl].clk_sel = config_context.clk_sel;

    if (acap_attr->resample_rate != acap_attr->sample_rate) {
        ret = mapi_acap_open_resampler(acap_attr, &g_acap_context[acap_hdl].acap_resmp_info);
        CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "mapi_acap_open_resampler", ret, g_acap_func_lock[acap_hdl]);
    }

    ret = memcpy_s(&g_acap_context[acap_hdl].acap_attr, sizeof(g_acap_context[acap_hdl].acap_attr),
        acap_attr, sizeof(hi_mapi_acap_attr));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "memcpy_s fail, return:[%#x]!\n", ret);
        (td_void)mapi_acap_close_resampler(&g_acap_context[acap_hdl].acap_resmp_info);
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    g_acap_context[acap_hdl].acap_state = MAPI_ACAP_STOPED;

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_deinit(td_handle acap_hdl)
{
    td_s32 ret;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_CHECK_INIT_RET(g_acap_inited);

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACap is started, you must stop ACap first, try stop\n");
        ret = mapi_acap_stop_all_chn(acap_hdl);
        if (ret != TD_SUCCESS) {
            return ret;
        }
    }

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_UNINITED) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP, "acap has already deinited, return success!\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return TD_SUCCESS;
    }

    if (g_acap_context[acap_hdl].acap_attr.resample_rate != g_acap_context[acap_hdl].acap_attr.sample_rate) {
        ret = mapi_acap_close_resampler(&g_acap_context[acap_hdl].acap_resmp_info);
        CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "mapi_acap_close_resampler", ret, g_acap_func_lock[acap_hdl]);
    }

    g_acap_context[acap_hdl].acap_attr.sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_BUTT;
    g_acap_context[acap_hdl].acap_attr.bit_width = HI_MAPI_AUDIO_BIT_WIDTH_BUTT;
    g_acap_context[acap_hdl].acap_attr.work_mode = HI_MAPI_AIO_MODE_BUTT;
    g_acap_context[acap_hdl].acap_attr.sound_mode = HI_MAPI_AUDIO_SOUND_MODE_BUTT;
    g_acap_context[acap_hdl].acap_attr.pt_num_per_frm = 0;
    g_acap_context[acap_hdl].acap_attr.mixer_mic_mode = HI_MAPI_ACODEC_MIXER_BUTT;
    g_acap_context[acap_hdl].acap_attr.track_mode = HI_MAPI_AUDIO_TRACK_BUTT;
    g_acap_context[acap_hdl].acap_attr.resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_BUTT;

    g_acap_context[acap_hdl].acap_state = MAPI_ACAP_UNINITED;

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

static td_s32 mapi_acap_malloc_resample_ratebuff(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    if (g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl] != TD_NULL) {
        return TD_SUCCESS;
    }

    /* Size constants are element counts; malloc/memset_s require bytes. */
    g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl] =
        (td_s16 *)malloc(sizeof(td_s16) * MAPI_ACAP_RESAMPLE_BUFF_SIZE);
    if (g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl] == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "malloc resample ratebuff failed!\n");
        return TD_FAILURE;
    }
    (td_void)memset_s(g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl],
        sizeof(td_s16) * MAPI_ACAP_RESAMPLE_BUFF_SIZE, 0,
        sizeof(td_s16) * MAPI_ACAP_RESAMPLE_BUFF_SIZE);
    return TD_SUCCESS;
}

static td_void mapi_acap_free_resample_ratebuff(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    if (g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl] == TD_NULL) {
        return;
    }
    free(g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl]);
    g_acap_resample_ratebuff[acap_hdl][acap_chn_hdl] = TD_NULL;
}

static td_s32 mapi_acap_start_software_afe(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_ops(g_acap_context[acap_hdl].afe_provider_name);
    if (afe == TD_NULL || !afe->software_process) {
        return TD_SUCCESS;
    }
    td_u32 chn_num = 0;
    td_s32 ret = mapi_acap_get_chn_num(g_acap_context[acap_hdl].acap_attr.sound_mode, &chn_num);
    if (ret != TD_SUCCESS) {
        return ret;
    }
    audio_comp_afe_attr_t attr = {
        .model_path = g_acap_context[acap_hdl].afe_attr.model_path,
        .vqe_mode = AUDIO_COMP_AFE_VQE_NONE,
        .ai_dev_id = acap_hdl,
        .ai_chn_id = acap_chn_hdl,
        .ref_ao_dev_id = OT_INVALID_HANDLE,
        .ref_ao_chn_id = OT_INVALID_HANDLE,
        .sample_rate = (uint32_t)g_acap_context[acap_hdl].acap_attr.sample_rate,
        .channels = (uint16_t)chn_num,
        .samples_per_frame = (uint16_t)g_acap_context[acap_hdl].acap_attr.pt_num_per_frm,
    };
    return afe->init(&attr);
}

td_s32 hi_mapi_acap_start(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    td_s32 ret;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_CHN_HANDLE_RANGE_RET(acap_chn_hdl);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "acap not been inited, can not start!\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }

    ret = mapi_acap_malloc_resample_ratebuff(acap_hdl, acap_chn_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "mapi_acap_malloc_resample_ratebuff", ret, g_acap_func_lock[acap_hdl]);

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_STARTED) {
        if (g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] != TD_TRUE) {
            ret = audio_comp_acap_enable_ai_chn(acap_hdl, acap_chn_hdl);
            CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_ACAP, "audio_comp_acap_enable_ai_chn", ret, fail);
            g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] = TD_TRUE;
            MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
            return TD_SUCCESS;
        }
        MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP, "ACap is already started, return success\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return TD_SUCCESS;
    }

    ret = audio_comp_acap_start(acap_hdl, acap_chn_hdl, &g_acap_context[acap_hdl].acap_attr);
    CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_ACAP, "audio_comp_acap_start", ret, fail);
    ret = mapi_acap_start_software_afe(acap_hdl, acap_chn_hdl);
    if (ret != TD_SUCCESS) {
        (td_void)audio_comp_acap_disable_ai_chn(acap_hdl, acap_chn_hdl);
        (td_void)audio_comp_acap_disable_ai(acap_hdl);
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return ret;
    }

    g_acap_context[acap_hdl].acap_state = MAPI_ACAP_STARTED;
    g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] = TD_TRUE;

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
fail:
    mapi_acap_free_resample_ratebuff(acap_hdl, acap_chn_hdl);
    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
    return ret;
}

td_s32 hi_mapi_acap_enable_vqe(td_handle acap_hdl, td_handle acap_chn_hdl,
                               hi_mapi_acap_vqe_type vqe_type, td_handle ref_ao_hdl)
{
    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_CHN_HANDLE_RANGE_RET(acap_chn_hdl);

    if (vqe_type >= HI_MAPI_ACAP_VQE_TYPE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "invalid vqe_type %d\n", vqe_type);
        return HI_MAPI_ACAP_EILLPARAM;
    }

    if (vqe_type == HI_MAPI_ACAP_VQE_TYPE_RECORD) {
        if (ref_ao_hdl != OT_INVALID_HANDLE) {
            MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP, "RECORD vqe expects ref_ao_hdl=OT_INVALID_HANDLE, ignore %d\n",
                ref_ao_hdl);
        }
    } else {
        if (ref_ao_hdl >= HI_MAPI_AO_DEV_MAX_NUM) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "AO handle out of range for TALK/TALKV2 vqe\n");
            return HI_MAPI_ACAP_EINVALIDHDL;
        }
    }

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    if ((g_acap_context[acap_hdl].acap_state != MAPI_ACAP_STARTED) ||
        (g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] != TD_TRUE)) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP, "ACap or Acap Chn not started, can not enable vqe\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }

    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_ops(g_acap_context[acap_hdl].afe_provider_name);
    if (afe == TD_NULL || afe->init == TD_NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "AFE provider '%s' unavailable\n",
            g_acap_context[acap_hdl].afe_provider_name);
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_EILLPARAM;
    }

    td_u32 chn_num = 0;
    td_s32 ret = mapi_acap_get_chn_num(g_acap_context[acap_hdl].acap_attr.sound_mode, &chn_num);
    if (ret != TD_SUCCESS) {
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return ret;
    }

    audio_comp_afe_vqe_mode_t vqe_mode = AUDIO_COMP_AFE_VQE_NONE;
    if (vqe_type == HI_MAPI_ACAP_VQE_TYPE_RECORD) {
        vqe_mode = AUDIO_COMP_AFE_VQE_RECORD;
    } else if (vqe_type == HI_MAPI_ACAP_VQE_TYPE_TALK) {
        vqe_mode = AUDIO_COMP_AFE_VQE_TALK;
    } else if (vqe_type == HI_MAPI_ACAP_VQE_TYPE_TALKV2) {
        vqe_mode = AUDIO_COMP_AFE_VQE_TALKV2;
    }

    td_u32 open_mask = 0;
#ifdef SUPPORT_TALKVQE
    if (vqe_type != HI_MAPI_ACAP_VQE_TYPE_RECORD) {
        hal_mapi_acap_get_talk_open_mask(&g_acap_context[acap_hdl].talk_vqe_attr, &open_mask);
    }
#endif
    audio_comp_afe_attr_t afe_attr = {
        .model_path = g_acap_context[acap_hdl].afe_attr.model_path,
        .vqe_mode = vqe_mode,
        .ai_dev_id = acap_hdl,
        .ai_chn_id = acap_chn_hdl,
        .ref_ao_dev_id = ref_ao_hdl,
        .ref_ao_chn_id = acap_chn_hdl,
        .talk_open_mask = open_mask,
        .sample_rate = (uint32_t)g_acap_context[acap_hdl].acap_attr.sample_rate,
        .channels = (uint16_t)chn_num,
        .samples_per_frame = (uint16_t)g_acap_context[acap_hdl].acap_attr.pt_num_per_frm,
    };

    ret = afe->init(&afe_attr);

    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "enable vqe(type=%d) fail, ret:%x\n", vqe_type, ret);
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return ret;
    }

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_disable_vqe(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_CHN_HANDLE_RANGE_RET(acap_chn_hdl);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "acap not been inited, can not disable_vqe\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_STOPED ||
        (g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] != TD_TRUE)) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP, "ACAP or ACAP CHN is stopped, return successful\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return TD_SUCCESS;
    }

    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_ops(g_acap_context[acap_hdl].afe_provider_name);
    if (afe != TD_NULL && afe->deinit != TD_NULL) {
        afe->deinit();
    }
    td_s32 ret = mapi_acap_set_default_afe(&g_acap_context[acap_hdl]);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "mapi_acap_set_default_afe", ret, g_acap_func_lock[acap_hdl]);

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_stop(td_handle acap_hdl, td_handle acap_chn_hdl)
{
    td_s32 ret;
    td_u32 i;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_CHN_HANDLE_RANGE_RET(acap_chn_hdl);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "acap not been inited, can not stop\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }

    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_STOPED) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP, "ACAP is stopped, return successful\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return TD_SUCCESS;
    }

    mapi_acap_free_resample_ratebuff(acap_hdl, acap_chn_hdl);

    if (g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] != TD_FALSE) {
        ret = audio_comp_acap_disable_ai_chn(acap_hdl, acap_chn_hdl);
        CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acap_disable_ai_chn", ret, g_acap_func_lock[acap_hdl]);
        g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] = TD_FALSE;
    }

    for (i = 0; i < HI_MAPI_ACAP_CHN_MAX_NUM; i++) {
        if (g_acap_context[acap_hdl].acap_chn_start[i] != TD_FALSE) {
            MAPI_WARN_TRACE(HI_MAPI_MOD_ACAP, "ACAP Chn[%u] is started, please check it needs to stop!\n", i);
            MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
            return TD_SUCCESS;
        }
    }

    const audio_comp_afe_ops_t *afe = audio_comp_afe_get_ops(g_acap_context[acap_hdl].afe_provider_name);
    if (afe != TD_NULL && afe->software_process && afe->deinit != TD_NULL) {
        afe->deinit();
    }
    ret = audio_comp_acap_disable_ai(acap_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acap_disable_ai", ret, g_acap_func_lock[acap_hdl]);

    g_acap_context[acap_hdl].acap_state = MAPI_ACAP_STOPED;

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_set_volume(td_handle acap_hdl, td_s32 audio_gain)
{
    td_s32 ret;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    if (audio_gain < HI_MAPI_ACAP_MIN_GAIN || audio_gain > HI_MAPI_ACAP_MAX_GAIN) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "Gain out of range\n");
        return HI_MAPI_ACAP_EILLPARAM;
    }

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    ret = audio_comp_acodec_set_ai_vol(audio_gain);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acodec_set_ai_vol", ret, g_acap_func_lock[acap_hdl]);

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_get_volume(td_handle acap_hdl, td_s32 *audio_gain)
{
    td_s32 ret;
    td_s32 vol;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_NULL_PTR_RET(audio_gain);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    ret = audio_comp_acodec_get_ai_vol(&vol);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acodec_get_ai_vol", ret, g_acap_func_lock[acap_hdl]);

    *audio_gain = vol;

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_mute(td_handle acap_hdl)
{
    td_s32 ret;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    ret = audio_comp_acodec_mute_ai();
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acodec_mute_ai", ret, g_acap_func_lock[acap_hdl]);

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_unmute(td_handle acap_hdl)
{
    td_s32 ret;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    ret = audio_comp_acodec_unmute_ai();
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acodec_unmute_ai", ret, g_acap_func_lock[acap_hdl]);

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_get_frame(td_handle acap_hdl, td_handle acap_chn_hdl, hi_mapi_audio_frame *audio_frm,
                              hi_mapi_aec_frame *aec_frm)
{
    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_CHN_HANDLE_RANGE_RET(acap_chn_hdl);
    CHECK_MAPI_ACAP_NULL_PTR_RET(audio_frm);
    CHECK_MAPI_ACAP_NULL_PTR_RET(aec_frm);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited, mapi media has not been inited in get frame\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    if ((g_acap_context[acap_hdl].acap_state != MAPI_ACAP_STARTED) ||
        (g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] != TD_TRUE)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACap or Acap Chn is not started, can not get frame!\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }

    td_s32 ret = audio_comp_acap_get_frame(acap_hdl, acap_chn_hdl,
        &g_acap_context[acap_hdl].acap_attr, audio_frm, aec_frm);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acap_get_frame", ret, g_acap_func_lock[acap_hdl]);

    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ACAP, "GetFrame: phy_addr0=%llu, phy_addr1=%llu, frame_len=%u\n",
        audio_frm->phys_addr[0], audio_frm->phys_addr[1], audio_frm->len);

    if (g_acap_context[acap_hdl].acap_attr.resample_rate != g_acap_context[acap_hdl].acap_attr.sample_rate) {
        ret = mapi_acap_process_resampler(acap_hdl, acap_chn_hdl, audio_frm);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "mapi_acap_process_resampler error:%#x!\n", ret);
            (td_void)audio_comp_acap_release_frame(acap_hdl, acap_chn_hdl, audio_frm, aec_frm);
            MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
            return ret;
        }
    }

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_release_frame(td_handle acap_hdl, td_handle acap_chn_hdl, const hi_mapi_audio_frame *audio_frm,
                                  const hi_mapi_aec_frame *aec_frm)
{
    td_s32 ret;
    hi_mapi_audio_frame release_frame;

    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_CHN_HANDLE_RANGE_RET(acap_chn_hdl);
    CHECK_MAPI_ACAP_NULL_PTR_RET(audio_frm);
    CHECK_MAPI_ACAP_NULL_PTR_RET(aec_frm);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP,
            "ACAP has not been pre inited, mapi media has not been inited in release frame\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }

    if ((g_acap_context[acap_hdl].acap_state != MAPI_ACAP_STARTED) ||
        (g_acap_context[acap_hdl].acap_chn_start[acap_chn_hdl] != TD_TRUE)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACap or Acap Chn is not started, can not release frame!\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }

    release_frame.bit_width = audio_frm->bit_width;
    release_frame.snd_mode = audio_frm->snd_mode;
    release_frame.time_stamp = audio_frm->time_stamp;
    release_frame.seq = audio_frm->seq;
    release_frame.len = audio_frm->len;
    for (td_u32 i = 0; i < HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT; i++) {
        /* prevent client addr error */
        release_frame.virt_addr[i] = (td_u8 *)(uintptr_t)audio_frm->phys_addr[i];
        release_frame.phys_addr[i] = audio_frm->phys_addr[i];
        release_frame.pool_id[i] = audio_frm->pool_id[i];
    }

    if (g_acap_context[acap_hdl].acap_attr.resample_rate != g_acap_context[acap_hdl].acap_attr.sample_rate) {
        release_frame.len = g_acap_context[acap_hdl].acap_resmp_info.saved_frm_len;
        ret = memset_s(g_acap_context[acap_hdl].acap_resmp_info.res_mmz_vir_addr,
            (sizeof(td_u16) * MAPI_ACAP_RESAMPLE_BUFF_SIZE), 0, (sizeof(td_u16) * MAPI_ACAP_RESAMPLE_BUFF_SIZE));
        CHECK_MAPI_PRINT(HI_MAPI_MOD_ACAP, "memset_s", ret);
    }

    ret = audio_comp_acap_release_frame(acap_hdl, acap_chn_hdl, &release_frame, aec_frm);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ACAP, "audio_comp_acap_release_frame", ret, g_acap_func_lock[acap_hdl]);

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
    return TD_SUCCESS;
}

td_s32 hi_mapi_acap_set_param(td_handle acap_hdl, hi_mapi_acap_cmd cmd,
                              const td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP has not been pre inited\n");
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }
    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "acap[%d] not inited\n", acap_hdl);
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }
    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "ACAP _CONFIG cmd must be set before start (acap_hdl=%d)\n", acap_hdl);
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }

    td_s32 ret = TD_SUCCESS;
    switch (cmd) {
        case HI_MAPI_ACAP_CMD_AFE_PROVIDER_CONFIG: {
            if (attr_len == 0 || attr_len >= MAPI_ACAP_AFE_PROVIDER_NAME_LEN) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "AFE provider name len:%u invalid\n", attr_len);
                ret = HI_MAPI_ACAP_EILLPARAM;
                break;
            }
            const td_char *name = (const td_char *)attr;
            if (memchr(name, '\0', attr_len) == TD_NULL) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "AFE provider name must be null-terminated\n");
                ret = HI_MAPI_ACAP_EILLPARAM;
                break;
            }
            if (audio_comp_afe_get_ops(name) == TD_NULL || audio_comp_afe_set_active(name) != 0) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "AFE provider '%s' is not registered or locked\n", name);
                ret = HI_MAPI_ACAP_EILLPARAM;
                break;
            }
            ret = strncpy_s(g_acap_context[acap_hdl].afe_provider_name,
                sizeof(g_acap_context[acap_hdl].afe_provider_name), name,
                sizeof(g_acap_context[acap_hdl].afe_provider_name) - 1);
            CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_ACAP, "strncpy_s", ret, g_acap_func_lock[acap_hdl]);
            break;
        }
        case HI_MAPI_ACAP_CMD_AFE_ATTR_CONFIG:
            if (attr_len < sizeof(hi_mapi_acap_afe_attr_t)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "AFE attr_len:%u too small\n", attr_len);
                ret = HI_MAPI_ACAP_EILLPARAM;
                break;
            }
            g_acap_context[acap_hdl].afe_attr = *(const hi_mapi_acap_afe_attr_t *)attr;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "unknown ACAP cmd=%d\n", cmd);
            ret = HI_MAPI_ACAP_EILLPARAM;
            break;
    }

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
    return ret;
}

td_s32 hi_mapi_acap_get_param(td_handle acap_hdl, hi_mapi_acap_cmd cmd,
                              td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_ACAP_HANDLE_RANGE_RET(acap_hdl);
    CHECK_MAPI_ACAP_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_acap_func_lock[acap_hdl]);

    if (!g_acap_inited) {
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ENOINITED;
    }
    if (g_acap_context[acap_hdl].acap_state == MAPI_ACAP_UNINITED) {
        MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
        return HI_MAPI_ACAP_ESTATEERR;
    }

    td_s32 ret = TD_SUCCESS;
    switch (cmd) {
        case HI_MAPI_ACAP_CMD_AFE_PROVIDER_CONFIG: {
            size_t name_len = strnlen(g_acap_context[acap_hdl].afe_provider_name,
                sizeof(g_acap_context[acap_hdl].afe_provider_name));
            if (attr_len <= name_len) {
                ret = HI_MAPI_ACAP_EILLPARAM;
                break;
            }
            ret = strncpy_s((td_char *)attr, attr_len, g_acap_context[acap_hdl].afe_provider_name, name_len);
            if (ret != EOK) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "strncpy_s fail, ret:%x\n", ret);
                ret = HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
            }
            break;
        }
        case HI_MAPI_ACAP_CMD_AFE_ATTR_CONFIG:
            if (attr_len < sizeof(hi_mapi_acap_afe_attr_t)) {
                ret = HI_MAPI_ACAP_EILLPARAM;
                break;
            }
            *(hi_mapi_acap_afe_attr_t *)attr = g_acap_context[acap_hdl].afe_attr;
            break;
        default:
            ret = HI_MAPI_ACAP_EILLPARAM;
            break;
    }

    MAPI_MUTEX_UNLOCK(g_acap_func_lock[acap_hdl]);
    return ret;
}

td_s32 hi_mapi_acap_get_default_attr(hi_mapi_audio_sample_rate sample_rate,
                                     hi_mapi_audio_sound_mode sound_mode,
                                     hi_mapi_acap_attr *acap_attr)
{
    CHECK_MAPI_ACAP_NULL_PTR_RET(acap_attr);

    if (sample_rate >= HI_MAPI_AUDIO_SAMPLE_RATE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "invalid sample_rate %d\n", sample_rate);
        return HI_MAPI_ACAP_EILLPARAM;
    }
    if (sound_mode >= HI_MAPI_AUDIO_SOUND_MODE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "invalid sound_mode %d\n", sound_mode);
        return HI_MAPI_ACAP_EILLPARAM;
    }

    td_s32 ret = memset_s(acap_attr, sizeof(*acap_attr), 0, sizeof(*acap_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ACAP, "memset_s", ret);

    acap_attr->sample_rate    = sample_rate;
    acap_attr->bit_width      = HI_MAPI_AUDIO_BIT_WIDTH_16;
    acap_attr->sound_mode     = sound_mode;
    acap_attr->track_mode     = HI_MAPI_AUDIO_TRACK_NORMAL;
    acap_attr->work_mode      = HI_MAPI_AIO_MODE_I2S_MASTER;
    acap_attr->pt_num_per_frm = 1024; /* sample default */
    acap_attr->mixer_mic_mode = HI_MAPI_ACODEC_MIXER_IN0;
    acap_attr->resample_rate  = sample_rate;
    acap_attr->i2s_type       = HI_MAPI_AIO_I2STYPE_INNERCODEC;
    acap_attr->input_topology.ref_chn_hdl = OT_INVALID_HANDLE;
    acap_attr->input_topology.out_chn_hdl = OT_INVALID_HANDLE;

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
