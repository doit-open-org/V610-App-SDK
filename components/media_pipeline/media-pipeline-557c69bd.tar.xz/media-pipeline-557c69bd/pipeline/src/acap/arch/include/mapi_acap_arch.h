/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_ACAP_ARCH_H__
#define __MAPI_ACAP_ARCH_H__

#include "mapi_acap_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32  hal_mapi_acap_register_vqe_module(td_void);
td_void *hal_mapi_acap_resampler_create(td_s32 in_rate, td_s32 out_rate, td_s32 chans);
td_void hal_mapi_acap_resampler_destroy(td_void *inst);
td_s32  hal_mapi_acap_resampler_process(td_void *inst, const mapi_acap_resample_data_attr *in_data_attr,
                                        td_s32 in_samps, const mapi_acap_resample_data_attr *out_data_attr);

#ifdef SUPPORT_TALKVQE
td_void hal_mapi_acap_get_talk_open_mask(const hi_mapi_audio_talk_vqe_attr *talk_vqe_attr, td_u32 *open_mask);
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_ACAP_ARCH_H__ */
