/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_acap_arch.h"
#include "mapi_comm_inner.h"
#include "audio_comp/audio_comp_acap.h"
#include "mapi_comm_adapt.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define VQE_RES_LIB_NAME "libvqe_res.so"

typedef td_void *(*mapi_acap_resampler_create_callback)(td_s32 in_rate, td_s32 out_rate, td_s32 chans);
typedef td_s32 (*mapi_acap_resampler_process_callback)(td_void *inst, td_s16 *in_buf, td_s32 in_samps,
    td_s16 *out_buf);
typedef td_void (*mapi_acap_resampler_destroy_callback)(td_void *inst);

typedef struct {
    td_void *lib_handle;
    mapi_acap_resampler_create_callback  resampler_create;
    mapi_acap_resampler_process_callback resampler_process;
    mapi_acap_resampler_destroy_callback resampler_destroy;
} mapi_acap_resampler_func_info;

static mapi_acap_resampler_func_info g_resampler_func_info = {0};

static td_void mapi_acap_deinit_resampler_func(td_void)
{
    if (g_resampler_func_info.lib_handle != TD_NULL) {
        mapi_acap_dlclose(g_resampler_func_info.lib_handle);
        (td_void)memset_s(&g_resampler_func_info, sizeof(g_resampler_func_info), 0, sizeof(g_resampler_func_info));
    }
}

static td_s32 mapi_acap_arch_dlsym(mapi_acap_resampler_func_info *resampler_func_info)
{
    td_s32 ret = mapi_acap_dlsym((td_void **)&(resampler_func_info->resampler_create),
        resampler_func_info->lib_handle, "ot_resample_create");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "find ot_resample_create symbol error!\n");
        return TD_FAILURE;
    }

    ret = mapi_acap_dlsym((td_void **)&(resampler_func_info->resampler_process),
        resampler_func_info->lib_handle, "ot_resample_process");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "find ot_resample_process symbol error!\n");
        return TD_FAILURE;
    }

    ret = mapi_acap_dlsym((td_void **)&(resampler_func_info->resampler_destroy),
        resampler_func_info->lib_handle, "ot_resample_destroy");
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "find ot_resample_destroy symbol error!\n");
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_acap_init_resampler_func(td_void)
{
    mapi_acap_resampler_func_info resampler_func_info;
    (td_void)memset_s(&resampler_func_info, sizeof(resampler_func_info), 0, sizeof(resampler_func_info));

    mapi_acap_deinit_resampler_func();
    td_s32 ret = mapi_acap_dlopen(&(resampler_func_info.lib_handle), VQE_RES_LIB_NAME);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "dlopen lib %s error!\n", VQE_RES_LIB_NAME);
        return TD_FAILURE;
    }

    ret = mapi_acap_arch_dlsym(&resampler_func_info);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "find resample symbol fail:%#x\n", ret);
        mapi_acap_dlclose(resampler_func_info.lib_handle);
        return TD_FAILURE;
    }

    ret = memcpy_s(&g_resampler_func_info, sizeof(g_resampler_func_info),
        &resampler_func_info, sizeof(resampler_func_info));
    if (ret != TD_SUCCESS) {
        (td_void)mapi_acap_dlclose(resampler_func_info.lib_handle);
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "memcpy_s error%#x!\n", ret);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    return TD_SUCCESS;
}

td_void *hal_mapi_acap_resampler_create(td_s32 in_rate, td_s32 out_rate, td_s32 chans)
{
    if (g_resampler_func_info.lib_handle == NULL) {
        td_s32 ret = mapi_acap_init_resampler_func();
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "init resample func failed:%#x!\n", ret);
            return NULL;
        }
    }

    td_void *acap_resampler = g_resampler_func_info.resampler_create(in_rate, out_rate, chans);
    if (acap_resampler == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "init resample func failed!\n");
        mapi_acap_deinit_resampler_func();
    }

    return acap_resampler;
}

td_void hal_mapi_acap_resampler_destroy(td_void *inst)
{
    if (g_resampler_func_info.lib_handle != NULL) {
        g_resampler_func_info.resampler_destroy(inst);
        mapi_acap_deinit_resampler_func();
    }
}

td_s32 hal_mapi_acap_resampler_process(td_void *inst, const mapi_acap_resample_data_attr *in_data_attr,
    td_s32 in_samps, const mapi_acap_resample_data_attr *out_data_attr)
{
    if (g_resampler_func_info.lib_handle == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ACAP, "please init resample func firstly!\n");
        return TD_FAILURE;
    }

    return g_resampler_func_info.resampler_process(inst, in_data_attr->data_buf, in_samps, out_data_attr->data_buf);
}

#ifdef SUPPORT_TALKVQE
td_void hal_mapi_acap_get_talk_open_mask(const hi_mapi_audio_talk_vqe_attr *talk_vqe_attr, td_u32 *open_mask)
{
    if ((open_mask != TD_NULL) && (talk_vqe_attr != TD_NULL)) {
        *open_mask = talk_vqe_attr->open_mask;
    }
}
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
