/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <stdio.h>
#include <fcntl.h>
#include <time.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <errno.h>
#include <math.h>

#include "hi_mapi_comm_define.h"
#include "ss_mpi_vpss.h"
#include "securec.h"
#include "hi_mapi_vcap_define.h"
#include "mapi_comm_inner.h"
#include "mapi_vcap_inner.h"
#include "mapi_vcap_arch.h"
#include "mapi_vcap_adapt.h"
#include "mapi_comm_adapt.h"

/* mapi_vcap_1sec2usec is the unit of seconds to microseconds,
Used to calculate the time of a frame 1(s) = 1000000(us) */

#define MAPI_VCAP_WDR_DUMP_REPEAT_MAX_CNT               10

#define MAPI_VCAP_COLOR_TEMPERATURE_VALUE 5000 /* unit: Kelvin */
#define MAPI_VCAP_EXPOSURE_MAX_TIME_US    10000
#define MIPI_NUM 3

#define MAPI_VCAP_ISP_RUN_START_WAIT_US   1000  /* settle time to detect ISP firmware start failure */

static pthread_mutex_t g_vcap_lock = PTHREAD_MUTEX_INITIALIZER;
static mapi_vcap_glob_attr g_vcap_glob_attr;
static hi_mapi_vcap_ext_data g_mipi_ext_data_type_default_attr = {
    .devno = 0,
    .num = MIPI_NUM,
    .ext_data_bit_width = {12, 12, 12},
    .ext_data_type = {0x2c, 0x2c, 0x2c}
};

hi_mapi_compress_mode mapi_vcap_get_default_pipe_compress_mode(td_void) 
 { 
     return hal_mapi_vcap_get_default_pipe_compress_mode(); 
 } 
 
 
 hi_mapi_compress_mode mapi_vcap_get_default_chn_compress_mode(td_void) 
 { 
     return hal_mapi_vcap_get_default_chn_compress_mode(); 
 }

static td_void mapi_vcap_reset_dev_status(td_void)
{
    td_s32 i, j;
    td_s32 ret;

    /* init vcap dev global param. dev:sensor 1:1 after refactor:
     * removed multi-sensor switch fields (bind_serdes_id / switch_mode / sns_cnt /
     * sns_vaild_index / switch_sns_info). */
    for (i = 0; i < HI_MAPI_VCAP_MAX_DEV_NUM; i++) {
        g_vcap_glob_attr.glob_dev_attr[i].dev_status = VCAP_STATUS_NOTINIT;
        g_vcap_glob_attr.glob_dev_attr[i].is_sns_init = TD_FALSE;
        g_vcap_glob_attr.glob_dev_attr[i].sns_reset = TD_FALSE;
        g_vcap_glob_attr.glob_dev_attr[i].sns_scene = HI_MAPI_VCAP_SENSOR_SCENE_NORMAL;
        g_vcap_glob_attr.glob_dev_attr[i].pipe_bind_num = 0;
        g_vcap_glob_attr.glob_dev_attr[i].ob_height = 0;

        ret = memset_s(&g_vcap_glob_attr.glob_dev_attr[i].sensor_attr, sizeof(hi_mapi_vcap_sensor_attr), 0,
            sizeof(hi_mapi_vcap_sensor_attr));
        CHECK_MAPI_PRINT(HI_MAPI_MOD_VCAP, "memset_s", ret);

        g_vcap_glob_attr.glob_dev_attr[i].master_isp_id = OT_INVALID_HANDLE;

        for (j = 0; j < HI_MAPI_VCAP_MAX_PIPE_NUM; j++) {
            g_vcap_glob_attr.glob_dev_attr[i].pipe_id_bind[j] = OT_INVALID_HANDLE;
        }
    }
}

static td_void mapi_vcap_reset_pipe_status(td_handle vcap_pipe_hdl)
{
    td_s32 ret;

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_init = TD_FALSE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run = TD_FALSE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create = TD_FALSE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_start = TD_FALSE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl = OT_INVALID_HANDLE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_vc_num = OT_INVALID_HANDLE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_hdl = vcap_pipe_hdl;

    ret = memset_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr,
        sizeof(mapi_vcap_isp_init_attr), 0, sizeof(mapi_vcap_isp_init_attr));
    CHECK_MAPI_PRINT(HI_MAPI_MOD_VCAP, "memset_s", ret);

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr.is_isp_attr_init = TD_FALSE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_wb_attr.op_type = HI_MAPI_VCAP_OP_TYPE_AUTO;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_wb_attr.wb_mode.color_temp = 5000; /* 5000: default wb */

    ret = memset_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr,
        sizeof(mapi_vcap_pipe_attr), 0, sizeof(mapi_vcap_pipe_attr));
    CHECK_MAPI_PRINT(HI_MAPI_MOD_VCAP, "memset_s", ret);

#if 0
    /* RAW dump (external 6 APIs deleted, kept under #if 0 for future restore) */
    for (td_u32 i = 0; i < MAPI_VCAP_DUMP_SCENE_NUM; i++) {
        ret = memset_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].dump_raw_info[i],
            sizeof(mapi_vcap_dump_raw_data_info), 0, sizeof(mapi_vcap_dump_raw_data_info));
        CHECK_MAPI_PRINT(HI_MAPI_MOD_VCAP, "memset_s", ret);
        pthread_mutex_init(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].dump_raw_info[i].vcap_dump_sync_lock, NULL);
        pthread_condattr_t sync_cond_attr;
        pthread_condattr_init(&sync_cond_attr);
        pthread_condattr_setclock(&sync_cond_attr, CLOCK_MONOTONIC);
        (td_void)pthread_cond_init(
            &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].dump_raw_info[i].vcap_dump_sync_cond, &sync_cond_attr);
        (td_void)pthread_condattr_destroy(&sync_cond_attr);
    }
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].dump_pix_fmt = HI_MAPI_PIXEL_FORMAT_BUTT;
#endif
}

static td_void mapi_vcap_reset_chn_status(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl)
{
    td_s32 ret;

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_enable = TD_FALSE;
    ret = memset_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr,
        sizeof(hi_mapi_vcap_pipe_chn_attr), 0, sizeof(hi_mapi_vcap_pipe_chn_attr));
    CHECK_MAPI_PRINT(HI_MAPI_MOD_VCAP, "memset_s", ret);

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].flip = TD_FALSE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].mirror = TD_FALSE;
}

static td_void mapi_vcap_reset_status(td_void)
{
    td_s32 i, j;

    mapi_vcap_reset_dev_status();

    /* init vcap pipe and chn global param */
    for (i = 0; i < HI_MAPI_VCAP_MAX_PIPE_NUM; i++) {
        mapi_vcap_reset_pipe_status((td_handle)i);

        for (j = 0; j < HI_MAPI_VCAP_PIPE_MAX_CHN_NUM; j++) {
            mapi_vcap_reset_chn_status((td_handle)i, (td_handle)j);
        }
    }
}

mapi_vcap_glob_dev_attr *mapi_vcap_get_dev_attr(td_handle vcap_dev_hdl)
{
    return &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl];
}

mapi_vcap_glob_attr *mapi_vcap_get_glob_attr(td_void)
{
    return &g_vcap_glob_attr;
}

td_s32 mapi_isp_init_mode_param(const hi_mapi_isp_param_mode *isp_mod_param)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_NULL_PTR_RET(isp_mod_param);

    if (isp_mod_param->param_valid != TD_TRUE) {
        MAPI_INFO_TRACE(HI_MAPI_MOD_VCAP, "isp set mod param not need\n");
        return TD_SUCCESS;
    }

    ret = mapi_adapt_vcap_set_isp_mode_param(isp_mod_param);
    CHECK_MAPI_VCAP_RET(ret, "set isp mod param fail\n");

    return TD_SUCCESS;
}

td_s32 mapi_vcap_init(td_void)
{
    td_s32 ret;

    ret = memset_s(&g_vcap_glob_attr, sizeof(g_vcap_glob_attr), 0, sizeof(mapi_vcap_glob_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    g_vcap_glob_attr.vcap_inited = TD_FALSE;

    /* sensor SDK loading is dropped after refactor: dev:sensor 1:1, sensor module
     * registers itself directly via hi_mapi_vcap_sensor_attr / sensor_obj. */
    mapi_vcap_reset_status();

    g_vcap_glob_attr.vcap_inited = TD_TRUE;
    return TD_SUCCESS;
}

td_s32 mapi_vcap_deinit(td_void)
{
    if (g_vcap_glob_attr.vcap_inited == TD_FALSE) {
        return TD_SUCCESS;
    }

    mapi_vcap_reset_status();

#if 0
    /* RAW dump (external 6 APIs deleted, kept under #if 0 for future restore) */
    for (td_s32 i = 0; i < HI_MAPI_VCAP_MAX_PIPE_NUM; i++) {
        for (td_s32 j = 0; j < MAPI_VCAP_DUMP_SCENE_NUM; j++) {
            (td_void)pthread_mutex_destroy(&g_vcap_glob_attr.glob_pipe_attr[i].dump_raw_info[j].vcap_dump_sync_lock);
            (td_void)pthread_cond_destroy(&g_vcap_glob_attr.glob_pipe_attr[i].dump_raw_info[j].vcap_dump_sync_cond);
        }
    }
#endif

    g_vcap_glob_attr.vcap_inited = TD_FALSE;

    return TD_SUCCESS;
}

/*
 * Sensor multi-mode switch state-machine (mapi_vcap_check_sensor_mode_change /
 * mapi_vcap_judge_switch_mode / mapi_vcap_get_current_sensor_mode_seq /
 * mapi_vcap_set_lane_mode / mapi_vcap_load_mipi_img_rect / mapi_vcap_find_sns_vaild_index /
 * mapi_vcap_load_mipi_config) is removed under demand 1: dev:sensor 1:1 with no
 * runtime sensor cfg lookup. Sensor object is fed in directly via hi_mapi_vcap_sensor_attr.
 */

static td_s32 mapi_vcap_check_vi_vpss_work_mode(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    hi_mapi_vi_vpss_mode vi_vpss_mode;

    ret = mapi_adapt_vcap_get_vi_vpss_mode(vcap_pipe_hdl, &vi_vpss_mode);
    CHECK_MAPI_VCAP_RET(ret, "get vi vpss mode failed,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    if (vi_vpss_mode == HI_MAPI_VI_OFFLINE_VPSS_ONLINE ||
        vi_vpss_mode == HI_MAPI_VI_ONLINE_VPSS_ONLINE) {
        return HI_MAPI_VCAP_ENOTSUPPORT;
    }
    return TD_SUCCESS;
}

/* VI pipe wrap (卷绕): VICAP-VPROC offline path only. */
static td_s32 mapi_vcap_check_wrap_work_mode(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    hi_mapi_vi_vpss_mode vi_vpss_mode;

    ret = mapi_adapt_vcap_get_vi_vpss_mode(vcap_pipe_hdl, &vi_vpss_mode);
    CHECK_MAPI_VCAP_RET(ret, "get vi vpss mode failed,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    if (vi_vpss_mode != HI_MAPI_VI_OFFLINE_VPSS_OFFLINE && vi_vpss_mode != HI_MAPI_VI_OFFLINE_VPSS_ONLINE) {
        return HI_MAPI_VCAP_ENOTSUPPORT;
    }
    return TD_SUCCESS;
}

/* VI wrap buf_line = value precomputed for this dev at media-init (indexed by dev). */
static td_s32 mapi_vcap_calc_buf_wrap(td_handle vcap_pipe_hdl, mapi_vcap_buf_wrap_info *info)
{
    mapi_comm_wrap_cfg wrap_cfg;
    td_handle dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;

    if (dev_hdl >= HI_MAPI_VCAP_MAX_DEV_NUM) {
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }
    mapi_comm_get_wrap_cfg(&wrap_cfg);
    info->buf_line = wrap_cfg.vi_buf_line[dev_hdl];
    if (info->buf_line == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "vi wrap buf_line not set for dev[%d], need base_attr.vi_wrap_en\n",
            dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }
    return TD_SUCCESS;
}

/*
 * Build a combo_dev_attr_t from an hi_mapi_vcap_sensor_attr (dev:sensor 1:1).
 * The full mipi_attr/lvds_attr is now expected to be filled by sensor object. We only
 * patch the dev-specific fields (devno, lane_id, input_data_type) here.
 */
static td_s32 mapi_vcap_build_combo_dev_attr(td_handle vcap_dev_hdl,
    const hi_mapi_vcap_sensor_attr *sensor_attr, combo_dev_attr_t *combo_dev_attr)
{
    td_s32 ret;

    ret = memset_s(combo_dev_attr, sizeof(*combo_dev_attr), 0, sizeof(*combo_dev_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    combo_dev_attr->devno = (combo_dev_t)vcap_dev_hdl;
    combo_dev_attr->img_rect.x = 0;
    combo_dev_attr->img_rect.y = 0;
    combo_dev_attr->img_rect.width = sensor_attr->size.width;
    combo_dev_attr->img_rect.height = sensor_attr->size.height + g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].ob_height;

    if (sensor_attr->sns_dev_attr.data_rate == HI_MAPI_VCAP_MIPI_DATA_RATE_X1) {
        combo_dev_attr->data_rate = MIPI_DATA_RATE_X1;
    } else {
        combo_dev_attr->data_rate = MIPI_DATA_RATE_X2;
    }

    /* input_mode / input_data_type / lane_id are filled by hal layer */
    ret = hal_mapi_vcap_load_mipi_config(combo_dev_attr, sensor_attr);
    CHECK_MAPI_VCAP_RET(ret, "hal load mipi config fail, dev[%d]\n", vcap_dev_hdl);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_set_lane_mode(td_s32 fd, hi_mapi_vcap_lane_divide_mode lane_id_mode)
{
    td_s32 i;
    td_s32 ret;

    lane_divide_mode_t hs_mode = (lane_divide_mode_t)lane_id_mode;

    for (i = 0; i < HI_MAPI_VCAP_MAX_DEV_NUM; i++) {
        if (g_vcap_glob_attr.glob_dev_attr[i].is_sns_init) {
            /* some sensors already inited, so no need to set lanemode again */
            break;
        }

        /* need to set lane mode in the first time */
        if (i == HI_MAPI_VCAP_MAX_DEV_NUM - 1) {
            ret = ioctl(fd, OT_MIPI_SET_HS_MODE, &hs_mode);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "set mipi divide mode failed\n");
                return TD_FAILURE;
            }
        }
    }

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_start_mipi(td_handle vcap_dev_hdl, const combo_dev_attr_t *combo_dev_attr,
    const hi_mapi_vcap_combo_dev_attr *comm_dev_attr, td_bool reset_sensor)
{
    td_s32 fd = open(MIPI_DEV_NODE, O_RDWR);
    if (fd < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "open mipi dev fail\n");
        return HI_MAPI_VCAP_EINVALID_FD;
    }

    /* 1.Setting Lane Distribution Mode for MIPI Rx has no effect on SLVS */
    td_s32 ret = mapi_vcap_set_lane_mode(fd, comm_dev_attr->lane_id_mode);
    CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_VCAP, "set lane mode failed.\n", ret, CLOSE_MIPI_DEV_NODE_ERR);

    /* 2.Enable MIPI_Rx/slvds clock and reset MIPI_Rx/slvds (mipi/lvds same clock) */
    ret = hal_mapi_vcap_enable_mipi_clock(fd, combo_dev_attr);
    CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_VCAP, "enable mipi clock failed\n", ret, CLOSE_MIPI_DEV_NODE_ERR);

    /* 3.Enable sensor clock */
    ret = ioctl(fd, OT_MIPI_ENABLE_SENSOR_CLOCK, &comm_dev_attr->sns_clk_source);
    CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_VCAP, "enable sensor clock failed\n", ret, ENABLE_MIPI_CLOCK_ERR);

    if (reset_sensor == TD_TRUE) {
        /* 4.Reset the sensor */
        ret = ioctl(fd, OT_MIPI_RESET_SENSOR, &comm_dev_attr->sns_rst_source);
        CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_VCAP, "reset sensor failed\n",
            ret, ENABLE_SENSOR_CLOCK_ERR);
    }

    /* 5.Set MIPI properties */
    ret = ioctl(fd, OT_MIPI_SET_DEV_ATTR, combo_dev_attr);
    CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_VCAP, "set mipi attr failed\n", ret, ENABLE_SENSOR_CLOCK_ERR);

    ret = ioctl(fd, OT_MIPI_SET_EXT_DATA_TYPE, &g_mipi_ext_data_type_default_attr);
    CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_VCAP, "set mipi ext data failed\n", ret, ENABLE_SENSOR_CLOCK_ERR);

    /* 6.unreset MIPI_Rx/slvds */
    ret = hal_mapi_vcap_reset_mipi_clock(fd, combo_dev_attr);
    CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_VCAP, "reset mipi clock failed\n", ret, ENABLE_SENSOR_CLOCK_ERR);

    if (reset_sensor == TD_TRUE) {
        /* 7.unreset sensor */
        ret = ioctl(fd, OT_MIPI_UNRESET_SENSOR, &comm_dev_attr->sns_rst_source);
        CHECK_MAPI_RET_GOTO(HI_MAPI_MOD_VCAP, "ureset sensor failed\n",
            ret, ENABLE_SENSOR_CLOCK_ERR);
    }

    close(fd);
    return TD_SUCCESS;

ENABLE_SENSOR_CLOCK_ERR:
    if (reset_sensor == TD_TRUE) {
        (td_void)ioctl(fd, OT_MIPI_DISABLE_SENSOR_CLOCK, &comm_dev_attr->sns_clk_source);
    }

ENABLE_MIPI_CLOCK_ERR:
    (td_void)hal_mapi_vcap_disable_mipi_clock(combo_dev_attr->devno, fd, combo_dev_attr->input_mode);
CLOSE_MIPI_DEV_NODE_ERR:
    close(fd);
    return ret;
}

static td_s32 mapi_vcap_stop_mipi(td_handle vcap_dev_hdl, const combo_dev_attr_t *combo_dev_attr,
    const hi_mapi_vcap_combo_dev_attr *comm_dev_attr, td_bool reset_sensor)
{
    td_s32 fd = open(MIPI_DEV_NODE, O_RDWR);
    td_s32 ret;
    if (fd < 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "open mipi dev fail\n");
        return HI_MAPI_VCAP_EINVALID_FD;
    }

    if (mapi_adapt_vcap_is_bt656_mode(combo_dev_attr->input_mode)) {
        close(fd);
        return TD_SUCCESS;
    }

    if (reset_sensor == TD_TRUE) {
        /* reset sensor */
        ret = ioctl(fd, OT_MIPI_RESET_SENSOR, &comm_dev_attr->sns_rst_source);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "reset sensor failed\n");
            goto CLOSE_MIPI_DEV_NODE_ERR;
        }

        /* disable sensor clock */
        ret = ioctl(fd, OT_MIPI_DISABLE_SENSOR_CLOCK, &comm_dev_attr->sns_clk_source);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "disable sensor clock failed\n");
            goto CLOSE_MIPI_DEV_NODE_ERR;
        }
    }

    /* reset MIPI_Rx/slvds and disable MIPI_Rx clock */
    ret = hal_mapi_vcap_disable_mipi_clock((td_handle)vcap_dev_hdl, fd, combo_dev_attr->input_mode);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "disable mipi clock failed\n");
    }

CLOSE_MIPI_DEV_NODE_ERR:
    close(fd);
    return ret;
}

static td_bool mapi_vcap_is_dev_pipe_bind_change(td_handle vcap_dev_hdl, const hi_mapi_vcap_attr *vcap_attr)
{
    td_u32 i;

    if (vcap_attr->pipe_bind_num != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num) {
        return TD_TRUE;
    }

    for (i = 0; i < vcap_attr->pipe_bind_num; i++) {
        if (vcap_attr->pipe_id_bind[i] != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[i]) {
            return TD_TRUE;
        }
    }

    return TD_FALSE;
}

static td_bool mapi_vcap_is_dev_attr_change(td_handle vcap_dev_hdl, const hi_mapi_vcap_dev_attr *vcap_dev_attr)
{
    const hi_mapi_vcap_dev_attr *glob_dev_attr_ptr;

    glob_dev_attr_ptr = (const hi_mapi_vcap_dev_attr *)&g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr;

    if (glob_dev_attr_ptr->wdr_mode != vcap_dev_attr->wdr_mode) {
        return TD_TRUE;
    }

    return TD_FALSE;
}

static td_bool mapi_vcap_is_pipe_static_attr_change(td_handle vcap_pipe_hdl,
                                                    const mapi_vcap_pipe_attr *vcap_pipe_attr)
{
    const mapi_vcap_pipe_attr *glob_pipe_attr_ptr;

    glob_pipe_attr_ptr = (const mapi_vcap_pipe_attr *)&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr;

    if (glob_pipe_attr_ptr->pipe_type != vcap_pipe_attr->pipe_type) {
        return TD_TRUE;
    }

    return TD_FALSE;
}

static td_bool mapi_vcap_is_pipe_dynamic_attr_change(td_handle vcap_pipe_hdl,
    const mapi_vcap_pipe_attr *vcap_pipe_attr)
{
    const mapi_vcap_pipe_attr *glob_pipe_attr_ptr;

    glob_pipe_attr_ptr = (const mapi_vcap_pipe_attr *)&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr;

    if ((glob_pipe_attr_ptr->frame_rate_ctrl.src_frame_rate != vcap_pipe_attr->frame_rate_ctrl.src_frame_rate) ||
        (glob_pipe_attr_ptr->frame_rate_ctrl.dst_frame_rate != vcap_pipe_attr->frame_rate_ctrl.dst_frame_rate)) {
        return TD_TRUE;
    }

    return TD_FALSE;
}

static td_bool mapi_vcap_is_chn_static_attr_change(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_pipe_chn_attr *vcap_chn_attr)
{
    const hi_mapi_vcap_pipe_chn_attr *glob_chn_attr;

    glob_chn_attr = (const hi_mapi_vcap_pipe_chn_attr *)
                     &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr;

    if (glob_chn_attr->pixel_format != vcap_chn_attr->pixel_format) {
        return TD_TRUE;
    }

    return TD_FALSE;
}

static td_bool mapi_vcap_is_chn_dynamic_attr_change(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_pipe_chn_attr *vcap_chn_attr)
{
    const hi_mapi_vcap_pipe_chn_attr *glob_chn_attr;

    glob_chn_attr = (const hi_mapi_vcap_pipe_chn_attr *)
                     &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr;

    if ((glob_chn_attr->dest_size.height != vcap_chn_attr->dest_size.height) ||
        (glob_chn_attr->dest_size.width != vcap_chn_attr->dest_size.width) ||
        (glob_chn_attr->frame_rate_ctrl.src_frame_rate != vcap_chn_attr->frame_rate_ctrl.src_frame_rate) ||
        (glob_chn_attr->frame_rate_ctrl.dst_frame_rate != vcap_chn_attr->frame_rate_ctrl.dst_frame_rate)) {
        return TD_TRUE;
    }

    return TD_FALSE;
}

static td_bool mapi_vcap_is_isp_static_pub_attr_change(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_pipe_isp_attr *vcap_isp_attr)
{
    const hi_mapi_vcap_pipe_isp_attr *glob_isp_attr;

    glob_isp_attr = &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr;

    if ((glob_isp_attr->size.width != vcap_isp_attr->size.width) ||
        (glob_isp_attr->size.height != vcap_isp_attr->size.height) ||
        (glob_isp_attr->bayer != vcap_isp_attr->bayer)) {
        return TD_TRUE;
    }

    return TD_FALSE;
}

static td_bool mapi_vcap_is_isp_dynamic_pub_attr_change(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_pipe_isp_attr *vcap_isp_attr)
{
    const hi_mapi_vcap_pipe_isp_attr *glob_isp_attr;

    glob_isp_attr = &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr;

    /* comparison between floats: equal if delta below MAPI_FLOAT_EPSINON */
    if (fabs(glob_isp_attr->frame_rate - vcap_isp_attr->frame_rate) > MAPI_FLOAT_EPSINON) {
        return TD_TRUE;
    }

    return TD_FALSE;
}

/*
 * BindISPToSensor: in the new architecture sensor obj is registered into adapt
 * directly via combo_dev_attr_t built by mapi_vcap_build_combo_dev_attr.
 * Bus type / bus id are picked from sensor_attr.input_attr.
 */
static td_s32 mapi_vcap_bind_isp_to_sensor(td_handle vcap_dev_hdl, td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    td_s32 sns_bus_id;
    hi_mapi_vcap_sensor_comm_bus_type sns_comm_bus_type;

    sns_comm_bus_type = sensor_attr->sns_dev_attr.input_attr.comm_bus_type;
    if ((sns_comm_bus_type != HI_MAPI_SENSOR_COMMBUS_TYPE_I2C) &&
        (sns_comm_bus_type != HI_MAPI_SENSOR_COMMBUS_TYPE_SPI)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "wrong sensor commbus type[%d]\n", sns_comm_bus_type);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    /* dev:sensor 1:1: master isp == pipe; bus_id comes from the externally provided combo_dev_attr. */
    sns_bus_id = sensor_attr->combo_dev_attr.bus_id;

    mapi_adapt_vcap_set_sns_bus_info(vcap_pipe_hdl, sns_comm_bus_type, sns_bus_id);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_adapt_pipe_pix_fmt_from_sensor(const hi_mapi_vcap_sensor_attr *vcap_sensor_attr,
    mapi_vcap_pipe_attr *vcap_pipe_attr)
{
    switch (vcap_sensor_attr->input_dev_attr.input_data_type) {
        case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_8BIT:
            vcap_pipe_attr->pix_fmt = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_8BPP;
            break;
        case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_10BIT:
            vcap_pipe_attr->pix_fmt = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_10BPP;
            break;
        case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_12BIT:
            vcap_pipe_attr->pix_fmt = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_12BPP;
            break;
        case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_14BIT:
            vcap_pipe_attr->pix_fmt = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_14BPP;
            break;
        case HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_16BIT:
            vcap_pipe_attr->pix_fmt = HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "sensor not support input data type:%d!\n",
                vcap_sensor_attr->input_dev_attr.input_data_type);
            return TD_FAILURE;
    }

    vcap_pipe_attr->bit_width = MAPI_VCAP_DATA_BITWIDTH_8;
    return TD_SUCCESS;
}

static td_s32 mapi_vcap_adapt_pipe_attr(td_handle vcap_pipe_hdl, mapi_vcap_pipe_attr *vcap_pipe_attr)
{
    td_s32 ret;
    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    /* dev:sensor 1:1, fixed sensor index 0 */
    const hi_mapi_vcap_sensor_attr *vcap_sensor_attr =
        &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr;

    ret = mapi_vcap_adapt_pipe_pix_fmt_from_sensor(vcap_sensor_attr, vcap_pipe_attr);
    CHECK_MAPI_VCAP_RET(ret, "adapt pipe[%d] pix fmt from sensor fail.\n", vcap_pipe_hdl);
    return TD_SUCCESS;
}

static td_s32 mapi_vcap_query_isp_inner_state(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    mapi_vcap_isp_inner_state isp_inner_state_info;

    ret = memset_s(&isp_inner_state_info, sizeof(isp_inner_state_info), 0x00, sizeof(isp_inner_state_info));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = mapi_adapt_vcap_query_isp_state(vcap_pipe_hdl, &isp_inner_state_info);
    CHECK_MAPI_VCAP_RET(ret, "query isp inner state fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
#if 0  // fix me!!!! 
    if (g_vcapGlobAttr.globDevAttr[bind_dev_hdl].switchMode == SWITCH_MODE_WDR_LINER_SWITCH) {
        /* wdr switch to liner */
        if (ispInnerStateInfo.wdrSwitchFinish) {
            g_vcapGlobAttr.globDevAttr[bind_dev_hdl].switchMode = SWITCH_MODE_NO_SENSOR_SWITCH;
            return TD_SUCCESS;
        }
    } else if (g_vcapGlobAttr.globDevAttr[bind_dev_hdl].switchMode == SWITCH_MODE_RESOLUTION_SWITCH) {
        /* res switch */
        if (ispInnerStateInfo.resSwitchFinish) {
            g_vcapGlobAttr.globDevAttr[bind_dev_hdl].switchMode = SWITCH_MODE_NO_SENSOR_SWITCH;
            return TD_SUCCESS;
        }
    } else if (g_vcapGlobAttr.globDevAttr[bind_dev_hdl].switchMode == SWITCH_MODE_NO_SENSOR_SWITCH) {
        /* switch not res and wdr */
        return TD_SUCCESS;
    } else {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "the switch mode is not support to check.\n");
        return TD_SUCCESS;
    }
#endif

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_set_isp_comm_param(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_isp_pub_attr *vcap_isp_pub_attr)
{
    td_s32 i = 0;
    td_s32 ret;
    td_handle bind_dev_hdl;

    bind_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;

    ret = mapi_adapt_vcap_set_isp_pub_attr(vcap_pipe_hdl, vcap_isp_pub_attr);
    CHECK_MAPI_VCAP_RET(ret, "call mapi_adapt_vcap_set_isp_pub_attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    /* set isp pubattr in isp running status, query inner state info to make sure
     * the set operation is finished. */
    if ((g_vcap_glob_attr.glob_dev_attr[bind_dev_hdl].sns_scene == HI_MAPI_VCAP_SENSOR_SCENE_STANDBY) &&
        (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run == TD_TRUE)) {
        while (i < VCAP_ISP_QUERY_SWITCHSTATE_MAX_TIMES) {
            ret = mapi_vcap_query_isp_inner_state(vcap_pipe_hdl);
            if (ret == TD_SUCCESS) {
                break;
            }
            usleep(VCAP_ISP_QUERY_SWITCHSTATE_SLEEP_TIMES);
            i++;
        }

        if (i == VCAP_ISP_QUERY_SWITCHSTATE_MAX_TIMES) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "switch scene operation time out (%d)us!!\n",
                (VCAP_ISP_QUERY_SWITCHSTATE_SLEEP_TIMES * i));
            return HI_MAPI_VCAP_ENOT_PERM;
        }
    }

    /* When the high frame rate function is used (>120 fps), reduce ISP statistics update
     * frequency by setting stat_intvl to lower CPU usage. */
    td_u32 stat_intvl;
    if (vcap_isp_pub_attr->frame_rate >= 240) { /* 240 fps */
        stat_intvl = 4; /* 4 */
    } else if (vcap_isp_pub_attr->frame_rate >= 180) { /* 180 fps */
        stat_intvl = 3; /* 3 */
    } else if (vcap_isp_pub_attr->frame_rate > 120) { /* 120 fps */
        stat_intvl = 2; /* 2 */
    } else {
        stat_intvl = 1; /* 1 */
    }

    ret = mapi_adapt_vcap_set_isp_interval(vcap_pipe_hdl, stat_intvl);
    CHECK_MAPI_VCAP_RET(ret, "set isp interval fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_set_isp_pub_attr(td_handle vcap_dev_hdl, td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    hi_mapi_vcap_isp_pub_attr vcap_isp_pub_attr;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init,
        "sensor has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    ret = memset_s(&vcap_isp_pub_attr, sizeof(vcap_isp_pub_attr), 0, sizeof(vcap_isp_pub_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    /* dev:sensor 1:1, sensor index fixed to 0 */
    const hi_mapi_vcap_sensor_attr *vcap_sensor_attr =
        &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr;
    const hi_mapi_vcap_pipe_isp_attr *user_isp_pub = &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr;

    /* bayer: if user did not set or set out of range, fall back to sensor input attr. */
    if (user_isp_pub->bayer >= HI_MAPI_VCAP_BAYER_BUTT) {
        vcap_isp_pub_attr.bayer = vcap_sensor_attr->sns_dev_attr.input_attr.bayer_format;
    } else {
        vcap_isp_pub_attr.bayer = user_isp_pub->bayer;
    }

    vcap_isp_pub_attr.sns_mode = (td_u8)vcap_sensor_attr->sns_mode;
    vcap_isp_pub_attr.wdr_mode = vcap_sensor_attr->wdr_mode;
    vcap_isp_pub_attr.frame_rate = user_isp_pub->frame_rate;
    vcap_isp_pub_attr.wnd_rect.x = 0;
    vcap_isp_pub_attr.wnd_rect.y = 0;
    vcap_isp_pub_attr.wnd_rect.height = user_isp_pub->size.height;
    vcap_isp_pub_attr.wnd_rect.width = user_isp_pub->size.width;
    vcap_isp_pub_attr.sns_size.height = vcap_sensor_attr->size.height;
    vcap_isp_pub_attr.sns_size.width = vcap_sensor_attr->size.width;

    ret = mapi_vcap_set_isp_comm_param(vcap_pipe_hdl, &vcap_isp_pub_attr);
    CHECK_MAPI_VCAP_RET(ret, "set isp[%d] comm param fail!\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_reset_isp(td_handle vcap_dev_hdl, td_handle vcap_pipe_hdl)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init,
        "sensor has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    /* sensor_set_init,reset AWB\AE */
    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr.is_isp_attr_init) {
        const hi_mapi_vcap_sensor_attr *sns_attr = &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr;

        ret = mapi_adapt_vcap_set_isp_sns_init(vcap_pipe_hdl, sns_attr);
        CHECK_MAPI_VCAP_RET(ret, "set isp init attr fail,sensor[%d],ISP[%d]\n", vcap_dev_hdl, vcap_pipe_hdl);
    }

    /* reset pub attr */
    ret = mapi_vcap_set_isp_pub_attr(vcap_dev_hdl, vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET(ret, "set isp pub attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

static td_void *mapi_vcap_isp_run_proc(td_void *pipe_handle)
{
    td_s32 ret;
    td_handle vcap_pipe_hdl;
    td_char thread_name[HI_MAPI_PTHREAD_NAME_LEN] = {0};

    vcap_pipe_hdl = (td_handle)*((td_s32 *)pipe_handle);

    ret = snprintf_s(thread_name, HI_MAPI_PTHREAD_NAME_LEN, HI_MAPI_PTHREAD_NAME_LEN - 1,
        "pTIspRun%u", vcap_pipe_hdl);
    if (ret == TD_FAILURE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "snprintf_s error:[%#x]", ret);
        return TD_NULL;
    }
    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)thread_name, 0, 0, 0);

    ret = mapi_adapt_vcap_start_isp(vcap_pipe_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "isp[%d] firmware start abnormally\n", vcap_pipe_hdl);
        /* mark the run thread as exited so hi_mapi_vcap_start_isp can detect the start failure */
        MAPI_MUTEX_LOCK(g_vcap_lock);
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_exited = TD_TRUE;
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return TD_NULL;
    }

    return TD_NULL;
}

static td_handle mapi_vcap_get_master_isp_id(td_handle vcap_dev_hdl, td_u32 sns_index)
{
    td_u32 i;
    td_s32 ret;
    td_handle master_isp;
    td_handle pipe_id_bind[HI_MAPI_VCAP_MAX_PIPE_NUM];

    td_u32 pipe_bind_num = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num;
    ret = memcpy_s(pipe_id_bind, sizeof(pipe_id_bind), g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind,
        sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "memcpy fail\n");
        return OT_INVALID_HANDLE;
    }

    if (pipe_bind_num < 1 || pipe_bind_num > HI_MAPI_VCAP_MAX_PIPE_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "vcap dev[%u] bind is wrong\n", vcap_dev_hdl);
        return OT_INVALID_HANDLE;
    }

    /* get master isp:
     *   single-pipe scene -> master isp == this pipe.
     *   multi-pipe scene  -> video pipe is master isp.
     */
    if (pipe_bind_num == 1) {
        return pipe_id_bind[0];
    }
    for (i = 0; i < pipe_bind_num; i++) {
        master_isp = pipe_id_bind[i];
        if ((g_vcap_glob_attr.glob_pipe_attr[master_isp].bind_vc_num == sns_index) &&
            (g_vcap_glob_attr.glob_pipe_attr[master_isp].pipe_attr.pipe_type == HI_MAPI_VCAP_PIPE_TYPE_VIDEO)) {
            return master_isp;
        }
    }

    MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "vcap dev[%d] bind is wrong\n", vcap_dev_hdl);
    return OT_INVALID_HANDLE;
}

static td_s32 mapi_vcap_dynamic_set_pipe_attr(td_handle vcap_pipe_hdl, const hi_mapi_vcap_attr *vcap_attr)
{
    td_s32 ret;
    /* Build an inner pipe-attr view from the public pipe attr for the change-detection helpers. */
    mapi_vcap_pipe_attr inner_pipe_attr;
    const hi_mapi_vcap_pipe_attr *user_pipe_attr = &vcap_attr->vcap_pipe_attr[vcap_pipe_hdl];

    ret = memset_s(&inner_pipe_attr, sizeof(inner_pipe_attr), 0, sizeof(inner_pipe_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);
    inner_pipe_attr.pipe_type = user_pipe_attr->pipe_type;
    inner_pipe_attr.frame_rate_ctrl = user_pipe_attr->frame_rate_ctrl;
    inner_pipe_attr.vb_pool_blk_cnt = user_pipe_attr->vb_pool_blk_cnt;
	//fix me!!!!!!!

    CHECK_MAPI_VCAP_TRUE_RET(!mapi_vcap_is_pipe_static_attr_change(vcap_pipe_hdl, &inner_pipe_attr),
        "don't support modify pipe's static attributes in the running status", HI_MAPI_VCAP_ENOT_PERM);

    if (!mapi_vcap_is_pipe_dynamic_attr_change(vcap_pipe_hdl, &inner_pipe_attr)) {
        MAPI_INFO_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d]'s dynamic attrs is no change!\n", vcap_pipe_hdl);
        return TD_SUCCESS;
    }

    ret = mapi_adapt_vcap_set_pipe_dynamic_attr(vcap_pipe_hdl, user_pipe_attr);
    CHECK_MAPI_VCAP_RET(ret, "set pipe dynamic attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    /* update dynamic pipe attr.
     * compress_mode kept-commented: was a public field potentially removed by user.
     * g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.compress_mode = user_pipe_attr->compress_mode;
     */
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.frame_rate_ctrl.src_frame_rate =
        user_pipe_attr->frame_rate_ctrl.src_frame_rate;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.frame_rate_ctrl.dst_frame_rate =
        user_pipe_attr->frame_rate_ctrl.dst_frame_rate;

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_dynamic_set_isp_attr(td_handle vcap_pipe_hdl, const hi_mapi_vcap_attr *vcap_attr)
{
    td_s32 ret;
    const hi_mapi_vcap_pipe_isp_attr *vcap_isp_attr = &vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].isp_pub_attr;

    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_isp_attr);
    CHECK_MAPI_VCAP_TRUE_RET(!mapi_vcap_is_isp_static_pub_attr_change(vcap_pipe_hdl, vcap_isp_attr),
        "don't support modify isp pub static attributes in the dev running status", HI_MAPI_VCAP_ENOT_PERM);

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run == TD_FALSE) {
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr.frame_rate = vcap_isp_attr->frame_rate;
        return TD_SUCCESS;
    }

    if (!mapi_vcap_is_isp_dynamic_pub_attr_change(vcap_pipe_hdl, vcap_isp_attr)) {
        MAPI_INFO_TRACE(HI_MAPI_MOD_VCAP, "isp's dynamic attrs is no change!\n");
        return TD_SUCCESS;
    }

    hi_mapi_vcap_isp_pub_attr isp_pub_attr;
    ret = memset_s(&isp_pub_attr, sizeof(isp_pub_attr), 0, sizeof(isp_pub_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = mapi_adapt_vcap_get_isp_pub_attr(vcap_pipe_hdl, &isp_pub_attr);
    CHECK_MAPI_VCAP_RET(ret, "get isp pub attr fail,vcap_pipe_hdl[%u]\n", vcap_pipe_hdl);

    isp_pub_attr.frame_rate = vcap_isp_attr->frame_rate;
    ret = mapi_vcap_set_isp_comm_param(vcap_pipe_hdl, &isp_pub_attr);
    CHECK_MAPI_VCAP_RET(ret, "set isp comm param fail,vcap_pipe_hdl[%u]\n", vcap_pipe_hdl);

    /* update dynamic isp pub attr */
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr.frame_rate = vcap_isp_attr->frame_rate;

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_dynamic_set_chn_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_attr *vcap_attr)
{
    td_s32 ret;
    const hi_mapi_vcap_pipe_chn_attr *vcap_chn_attr =
        &vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl];

    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_chn_attr);

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_enable == TD_FALSE) {
        ret = memcpy_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr,
            sizeof(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr),
            vcap_chn_attr, sizeof(hi_mapi_vcap_pipe_chn_attr));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);
        return TD_SUCCESS;
    }

    CHECK_MAPI_VCAP_TRUE_RET(!mapi_vcap_is_chn_static_attr_change(vcap_pipe_hdl, pipe_chn_hdl, vcap_chn_attr),
        "don't support modify chn's static attributes in the running status", HI_MAPI_VCAP_ENOT_PERM);

    if (!mapi_vcap_is_chn_dynamic_attr_change(vcap_pipe_hdl, pipe_chn_hdl, vcap_chn_attr)) {
        MAPI_INFO_TRACE(HI_MAPI_MOD_VCAP, "chn's dynamic attrs is no change!\n");
        return TD_SUCCESS;
    }

    ret = mapi_adapt_vcap_set_chn_dynamic_attr(vcap_pipe_hdl, pipe_chn_hdl, vcap_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "set chn dynamic attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    /* update dynamic chn attr */
    ret = memcpy_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr,
        sizeof(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr),
        vcap_chn_attr, sizeof(hi_mapi_vcap_pipe_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_static_set_dev_attr(td_handle vcap_dev_hdl, const hi_mapi_vcap_attr *vcap_attr)
{
    td_s32 ret;
    combo_dev_attr_t combo_dev_attr;

    /* dev:sensor 1:1, sensor index fixed to 0 */
    const hi_mapi_vcap_sensor_attr *sensor_attr = &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr;

    ret = mapi_vcap_build_combo_dev_attr(vcap_dev_hdl, sensor_attr, &combo_dev_attr);
    CHECK_MAPI_VCAP_RET(ret, "build combo dev attr fail,dev[%d]\n", vcap_dev_hdl);

    /* judge data rate */
    if (combo_dev_attr.data_rate >= MIPI_DATA_RATE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "error data_rate %d\n", combo_dev_attr.data_rate);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }
    if ((combo_dev_attr.data_rate == MIPI_DATA_RATE_X2) && (vcap_dev_hdl != VCAP_DEV_0)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "only dev[0] support MIPI_DATA_RATE_X2,now the dev is [%d]\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOTSUPPORT;
    }

    ret = mapi_adapt_vcap_set_dev_static_attr(vcap_dev_hdl, vcap_attr, &combo_dev_attr);
    CHECK_MAPI_VCAP_RET(ret, "set vcap[%d] dev static attr fail\n", vcap_dev_hdl);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_static_set_pipe_attr(const hi_mapi_vcap_attr *vcap_attr)
{
    td_u32 i, j;
    td_s32 ret;

    for (i = 0; i < vcap_attr->pipe_bind_num; i++) {
        td_handle vcap_pipe_hdl = vcap_attr->pipe_id_bind[i];

        /* dev:sensor 1:1: bind_vc_num is forced to 0; bind_vc_num is no longer
         * a public field of hi_mapi_vcap_pipe_attr. */
        mapi_vcap_glob_pipe_attr *vcap_pipe_attr = &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl];
        const hi_mapi_vcap_pipe_attr *user_pipe = &vcap_attr->vcap_pipe_attr[vcap_pipe_hdl];

        vcap_pipe_attr->bind_vc_num = 0;
        vcap_pipe_attr->pipe_attr.pipe_type = user_pipe->pipe_type;
        /* fields removed from public hi_mapi_vcap_pipe_attr; filled with internal defaults
         * so the SDK media pipeline can still be brought up. */
        vcap_pipe_attr->pipe_attr.compress_mode    = hal_mapi_vcap_get_default_pipe_compress_mode();
        vcap_pipe_attr->pipe_attr.isp_bypass       = TD_FALSE;
        vcap_pipe_attr->pipe_attr.pipe_bypass_mode = HI_MAPI_VCAP_PIPE_BYPASS_NONE;
        vcap_pipe_attr->pipe_attr.frame_int_attr.int_type   = HI_MAPI_VCAP_FRAME_INTERRUPT_START;
        vcap_pipe_attr->pipe_attr.frame_int_attr.early_line = 0;

        ret = memcpy_s(&vcap_pipe_attr->pipe_attr.frame_rate_ctrl, sizeof(vcap_pipe_attr->pipe_attr.frame_rate_ctrl),
            &user_pipe->frame_rate_ctrl, sizeof(user_pipe->frame_rate_ctrl));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

        ret = memcpy_s(&vcap_pipe_attr->isp_pub_attr, sizeof(vcap_pipe_attr->isp_pub_attr),
            &user_pipe->isp_pub_attr, sizeof(user_pipe->isp_pub_attr));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

        vcap_pipe_attr->pipe_attr.vb_pool_blk_cnt = user_pipe->vb_pool_blk_cnt;
        vcap_pipe_attr->pipe_pool_id = OT_VB_INVALID_POOL_ID;

        /* save chn user attr and flag */
        for (j = 0; j < HI_MAPI_VCAP_PIPE_MAX_CHN_NUM; j++) {
            ret = memcpy_s(&vcap_pipe_attr->pipe_chn_attr[j].chn_attr,
                sizeof(vcap_pipe_attr->pipe_chn_attr[j].chn_attr),
                &user_pipe->pipe_chn_attr[j], sizeof(user_pipe->pipe_chn_attr[j]));
            
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

            vcap_pipe_attr->pipe_chn_attr[j].compress_mode = hal_mapi_vcap_get_default_chn_compress_mode();
            vcap_pipe_attr->pipe_chn_attr[j].vb_pool_blk_cnt = user_pipe->pipe_chn_attr[j].vb_pool_blk_cnt;
            vcap_pipe_attr->pipe_chn_pool_id[j] = OT_VB_INVALID_POOL_ID;
        }
    }
    return TD_SUCCESS;
}

static td_s32 mapi_vcap_static_set_attr(td_handle vcap_dev_hdl, const hi_mapi_vcap_attr *vcap_attr)
{
    td_u32 i;
    td_s32 ret;

    /* 1. set vi dev attr */
    ret = mapi_vcap_static_set_dev_attr(vcap_dev_hdl, vcap_attr);
    CHECK_MAPI_VCAP_RET(ret, "set vcap[%d] dev static attr fail\n", vcap_dev_hdl);

    /* save vcap attr and flag */
    if (vcap_attr->pipe_bind_num > HI_MAPI_VCAP_MAX_PIPE_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe_bind_num[%u] is error\n", vcap_attr->pipe_bind_num);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num = vcap_attr->pipe_bind_num;
    for (i = 0; i < vcap_attr->pipe_bind_num; i++) {
        if (vcap_attr->pipe_id_bind[i] > HI_MAPI_VCAP_MAX_PIPE_NUM - 1) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe_bind_hdl[%u] is error\n", vcap_attr->pipe_id_bind[i]);
            return HI_MAPI_VCAP_EILLEGAL_PARA;
        }
    }

    ret = memcpy_s(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind,
        sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind),
        vcap_attr->pipe_id_bind, sizeof(vcap_attr->pipe_id_bind));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    ret = memcpy_s(&g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr,
        sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr),
        &vcap_attr->vcap_dev_attr, sizeof(vcap_attr->vcap_dev_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    /* wdr_attr defaults: only wdr_mode comes from public hdr; the rest are internal defaults */
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].wdr_attr.wdr_mode   = vcap_attr->vcap_dev_attr.wdr_mode;
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].wdr_attr.cache_line = 0;
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].wdr_attr.reverse    = TD_FALSE;
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].wdr_attr.fusion_grp = 0;

    /* 2. save vi pipe attr */
    ret = mapi_vcap_static_set_pipe_attr(vcap_attr);
    CHECK_MAPI_VCAP_RET(ret, "set vcap[%d] pipe static attr fail\n", vcap_dev_hdl);

    /* dev:sensor 1:1: only one master_isp_id slot is meaningful (index 0). */
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].master_isp_id = mapi_vcap_get_master_isp_id(vcap_dev_hdl, 0);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_set_exposure(td_handle vcap_pipe_hdl, const hi_mapi_vcap_exposure_attr *vcap_exposure)
{
    td_s32 ret;
    hi_mapi_vcap_isp_pub_attr vcap_isp_pub_attr;

    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_exposure);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    td_handle master_isp_hdl = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].master_isp_id;

    switch (vcap_exposure->op_type) {
        case HI_MAPI_VCAP_OP_TYPE_DISABLE:
            break;

        case HI_MAPI_VCAP_OP_TYPE_AUTO:
            if (vcap_exposure->auto_exposure_mode.sys_gain_range.min < HI_MAPI_VCAP_SYSGAIN_MIN ||
                vcap_exposure->auto_exposure_mode.sys_gain_range.max < HI_MAPI_VCAP_SYSGAIN_MIN) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
                    "SysGainRange Min or Max less than %u\n", HI_MAPI_VCAP_SYSGAIN_MIN);
                return HI_MAPI_VCAP_EILLEGAL_PARA;
            }

            if (vcap_exposure->auto_exposure_mode.sys_gain_range.max <
                vcap_exposure->auto_exposure_mode.sys_gain_range.min) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
                    "SysGainRange Max:%d can not less than Min:%d\n",
                    vcap_exposure->auto_exposure_mode.sys_gain_range.max,
                    vcap_exposure->auto_exposure_mode.sys_gain_range.min);
                return HI_MAPI_VCAP_EILLEGAL_PARA;
            }

            break;

        case HI_MAPI_VCAP_OP_TYPE_MANUAL:
            /* get the realtime framerate */
            ret = mapi_adapt_vcap_get_isp_pub_attr(master_isp_hdl, &vcap_isp_pub_attr);
            CHECK_MAPI_VCAP_RET(ret, "get ispPubAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

            /* check para, check exposure time of AE */
            if ((vcap_isp_pub_attr.frame_rate != 0) &&
                (vcap_exposure->manu_exposure_mode.exposure_time >
                    (MAPI_SEC2USEC_SCALE / vcap_isp_pub_attr.frame_rate))) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "manual exposure time can not greater than %f\n",
                    (MAPI_SEC2USEC_SCALE / vcap_isp_pub_attr.frame_rate));
                return HI_MAPI_VCAP_EILLEGAL_PARA;
            }

            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "not support exposure optype.\n");
            return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ret = mapi_adapt_vcap_set_exposure(master_isp_hdl, vcap_exposure);
    CHECK_MAPI_VCAP_RET(ret, "set exposure attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_get_exposure(td_handle vcap_pipe_hdl, hi_mapi_vcap_exposure_attr *vcap_exposure)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_exposure);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    td_handle master_isp_hdl = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].master_isp_id;

    ret = mapi_adapt_vcap_get_exposure(master_isp_hdl, vcap_exposure);
    CHECK_MAPI_VCAP_RET(ret, "get exposure attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_set_wb(td_handle vcap_pipe_hdl, const hi_mapi_vcap_wb_attr *vcap_wb_attr)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_wb_attr);

    if (vcap_wb_attr->op_type == HI_MAPI_VCAP_OP_TYPE_MANUAL) {
        if (vcap_wb_attr->wb_mode.color_temp < HI_MAPI_VCAP_MIN_COLORTEMP ||
            vcap_wb_attr->wb_mode.color_temp > HI_MAPI_VCAP_MAX_COLORTEMP) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "WBColorValue:%d,[%d,%d]\n", vcap_wb_attr->wb_mode.color_temp,
                           HI_MAPI_VCAP_MIN_COLORTEMP, HI_MAPI_VCAP_MAX_COLORTEMP);
            return HI_MAPI_VCAP_EILLEGAL_PARA;
        }
    }

    ret = mapi_adapt_vcap_set_wb(vcap_pipe_hdl, vcap_wb_attr);
    CHECK_MAPI_VCAP_RET(ret, "set wb fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_wb_attr.op_type = vcap_wb_attr->op_type;
    if (vcap_wb_attr->op_type == HI_MAPI_VCAP_OP_TYPE_MANUAL) {
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_wb_attr.wb_mode.color_temp =
            vcap_wb_attr->wb_mode.color_temp;
    } else if (vcap_wb_attr->op_type == HI_MAPI_VCAP_OP_TYPE_AUTO) {
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_wb_attr.wb_mode.color_temp =
            MAPI_VCAP_COLOR_TEMPERATURE_VALUE;
    } else {
        /* The value is invalid */
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_wb_attr.wb_mode.color_temp = 0xFFFF;
    }

    return TD_SUCCESS;
}

td_s32 mapi_vcap_set_chn_depth(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_chn_depth *chn_depth)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_NULL_PTR_RET(chn_depth);

    ret = mapi_adapt_vcap_set_chn_depth(vcap_pipe_hdl, pipe_chn_hdl, chn_depth->depth);
    CHECK_MAPI_VCAP_RET(ret, "set chn depth fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_vcap_get_chn_depth(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_vcap_chn_depth *chn_depth)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_NULL_PTR_RET(chn_depth);

    ret = mapi_adapt_vcap_get_chn_depth(vcap_pipe_hdl, pipe_chn_hdl, &chn_depth->depth);
    CHECK_MAPI_VCAP_RET(ret, "get chn depth fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}


#if 0  /* LDC internal helpers disabled (adapt-layer ldc APIs removed) */
static td_s32 mapi_vcap_set_ldc(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, const hi_mapi_vcap_ldc_attr *vcapLdcAttr)
{
    td_s32 ret;
    mapi_vcap_pipe_chn_attr vcap_chn_attr;

    /* para check */
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_enable,
        "chn has not been start", HI_MAPI_VCAP_ENOT_PERM);
    CHECK_MAPI_VCAP_MIN_VAL_RET("centerXOffset", vcapLdcAttr->ldcAttr.centerXOffset,
        HI_MAPI_VCAP_MIN_LDC_CENTERX_OFFSET);
    CHECK_MAPI_VCAP_MAX_VAL_RET("centerXOffset", vcapLdcAttr->ldcAttr.centerXOffset,
        HI_MAPI_VCAP_MAX_LDC_CENTERX_OFFSET);
    CHECK_MAPI_VCAP_MIN_VAL_RET("centerYOffset", vcapLdcAttr->ldcAttr.centerYOffset,
        HI_MAPI_VCAP_MIN_LDC_CENTERY_OFFSET);
    CHECK_MAPI_VCAP_MAX_VAL_RET("centerYOffset", vcapLdcAttr->ldcAttr.centerYOffset,
        HI_MAPI_VCAP_MAX_LDC_CENTERY_OFFSET);
    CHECK_MAPI_VCAP_MIN_VAL_RET("xyRatio", vcapLdcAttr->ldcAttr.xyRatio, HI_MAPI_VCAP_MIN_LDC_RATIO_XY);
    CHECK_MAPI_VCAP_MAX_VAL_RET("xyRatio", vcapLdcAttr->ldcAttr.xyRatio, HI_MAPI_VCAP_MAX_LDC_RATIO_XY);
    CHECK_MAPI_VCAP_MIN_VAL_RET("xRatio", vcapLdcAttr->ldcAttr.xRatio, HI_MAPI_VCAP_MIN_LDC_RATIO_X);
    CHECK_MAPI_VCAP_MAX_VAL_RET("xRatio", vcapLdcAttr->ldcAttr.xRatio, HI_MAPI_VCAP_MAX_LDC_RATIO_X);
    CHECK_MAPI_VCAP_MIN_VAL_RET("yRatio", vcapLdcAttr->ldcAttr.yRatio, HI_MAPI_VCAP_MIN_LDC_RATIO_Y);
    CHECK_MAPI_VCAP_MAX_VAL_RET("yRatio", vcapLdcAttr->ldcAttr.yRatio, HI_MAPI_VCAP_MAX_LDC_RATIO_Y);
    CHECK_MAPI_VCAP_MIN_VAL_RET("distortionRatio,", vcapLdcAttr->ldcAttr.distortionRatio,
        HI_MAPI_VCAP_MIN_LDC_RATIO_DISTORTION);
    CHECK_MAPI_VCAP_MAX_VAL_RET("distortionRatio", vcapLdcAttr->ldcAttr.distortionRatio,
        HI_MAPI_VCAP_MAX_LDC_RATIO_DISTORTION);

    ret = mapi_vcap_check_vi_vpss_work_mode(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET(ret,
        "don't support LDC when the vi_vpss work mode is online or parallel,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    ret = memset_s(&vcap_chn_attr, sizeof(vcap_chn_attr), 0, sizeof(vcap_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    ret = mapi_adapt_vcap_get_chn_attr(vcap_pipe_hdl, pipe_chn_hdl, &vcap_chn_attr);
    CHECK_MAPI_VCAP_RET(ret, "get chn attr failed,vcap_pipe_hdl[%d],PipeChn[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    if (vcap_chn_attr.videoFormat == HI_MAPI_VIDEO_FORMAT_TILE_16x8) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "don't support LDC when the VideoFormat is VIDEO_FORMAT_TILE_16x8\n");
        return HI_MAPI_VCAP_ENOTSUPPORT;
    }

    ret = MAPI_ADAPT_VCAP_SetLDCAttr(vcap_pipe_hdl, pipe_chn_hdl, vcapLdcAttr);
    CHECK_MAPI_VCAP_RET(ret, "set chn LDC attr failed,vcap_pipe_hdl[%d],PipeChn[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_get_ldc(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_ldc_attr *vcapLdcAttr)
{
    td_s32 ret;

    ret = mapi_vcap_check_vi_vpss_work_mode(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET(ret,
        "don't support LDC when the vpss work mode is online or parallel,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

    ret = MAPI_ADAPT_VCAP_GetLDCAttr(vcap_pipe_hdl, pipe_chn_hdl, vcapLdcAttr);
    CHECK_MAPI_VCAP_RET(ret, "get Chn LDC attr failed,vcap_pipe_hdl[%d],PipeChn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}
#endif  /* LDC v1 internal helpers */

static td_s32 mapi_vcap_set_mirror_flip(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_mirror_flip_attr *mirror_flip_attr)
{
    td_s32 ret;

    ret = mapi_vcap_check_vi_vpss_work_mode(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET(ret,
        "don't support mirror/flip when vi-vpss work mode is online or parallel, vcap_pipe_hdl[%d],pipe_chn_hdl[%d].\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    ret = mapi_adapt_vcap_set_mirror_flip(vcap_pipe_hdl, pipe_chn_hdl, mirror_flip_attr);
    CHECK_MAPI_VCAP_RET(ret,
        "call mapi_adapt_vcap_set_mirror_flip fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d].\n", vcap_pipe_hdl, pipe_chn_hdl);

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].flip = mirror_flip_attr->flip;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].mirror = mirror_flip_attr->mirror;

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_enter_standby(td_handle vcap_pipe_hdl)
{
    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "vcap has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "you must set Vcap Attrs and start dev[%d] firstly before enter standBy mode\n",
            vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "pipe:[%d] isp is not started, no need to enter standby mode\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_scene == HI_MAPI_VCAP_SENSOR_SCENE_STANDBY) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "you have entered standby mode already\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_scene = HI_MAPI_VCAP_SENSOR_SCENE_STANDBY;
    /* dev:sensor 1:1, build combo_dev_attr from saved sensor_attr (demand 1) */

    mapi_adapt_vcap_enter_standby(vcap_pipe_hdl, &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_exit_standby(td_handle vcap_pipe_hdl)
{
    td_handle vcap_dev_hdl;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "vcap has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "you must set Vcap Attrs and start dev[%d] first before exit standBy.\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run != TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "Pipe:[%d] isp is not started, no need to exit standby mode\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_scene != HI_MAPI_VCAP_SENSOR_SCENE_STANDBY) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "you should enter standby mode firstly.\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_scene = HI_MAPI_VCAP_SENSOR_SCENE_NORMAL;

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_restart_sensor(td_handle vcap_pipe_hdl)
{
    //td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "vcap has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "you must set Vcap Attrs and start dev[%d] first before RestartSensor.\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run != TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP,
            "pipe:[%d] isp is not started, no need to enter restart sensor.\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_scene != HI_MAPI_VCAP_SENSOR_SCENE_STANDBY) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "you should enter standby mode first\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    /* dev:sensor 1:1, build combo_dev_attr from saved sensor_attr (demand 1) */
    mapi_adapt_vcap_restart_sensor(vcap_pipe_hdl, &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr);

    return TD_SUCCESS;
}

/*
 * mapi_vcap_set_frame_int_attr: frame_int_attr was a public field of hi_mapi_vcap_pipe_attr that
 * has been removed from the new public hdr. The inner pipe attr keeps it with default values so
 * the SDK frame-interrupt setup still happens on supported VI/VPSS modes.
 */
static td_s32 mapi_vcap_set_frame_int_attr(td_handle vcap_pipe_hdl,
    const hi_mapi_vcap_frame_interrupt_attr *frame_int_attr)
{
    td_s32 ret;
    td_handle vcap_dev_hdl;
    hi_mapi_vi_vpss_mode vi_vpss_mode;

    vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;

    /* in WDR mode, the non-master pipe doesn't need to be set */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr.wdr_mode != HI_MAPI_VCAP_WDR_MODE_NONE &&
        vcap_pipe_hdl != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[0]) {
        return TD_SUCCESS;
    }

    ret = mapi_adapt_vcap_get_vi_vpss_mode(vcap_pipe_hdl, &vi_vpss_mode);
    CHECK_MAPI_VCAP_RET(ret, "get vi_vpss_mode failed,pipe[%d]\n", vcap_pipe_hdl);

    if ((vi_vpss_mode == HI_MAPI_VI_OFFLINE_VPSS_OFFLINE) ||
        (vi_vpss_mode == HI_MAPI_VI_OFFLINE_VPSS_ONLINE) ||
        (vi_vpss_mode == HI_MAPI_VI_PARALLEL_VPSS_PARALLEL)) {
        ret = mapi_adapt_vcap_set_frame_int_attr(vcap_pipe_hdl, frame_int_attr);
        CHECK_MAPI_VCAP_RET(ret, "set frame int attr fail,pipe[%d]\n", vcap_pipe_hdl);
    }

    return TD_SUCCESS;
}

static td_bool mapi_vcap_is_sensor_change(td_handle vcap_dev_hdl, const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    /* dev:sensor 1:1: only compare the single (index 0) sensor slot. */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init == TD_FALSE) {
        return TD_TRUE;
    }

    const hi_mapi_vcap_sensor_attr *cur = &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr;
    if ((cur->wdr_mode != sensor_attr->wdr_mode) ||
        (cur->sns_mode != sensor_attr->sns_mode) ||
        (cur->size.width != sensor_attr->size.width) ||
        (cur->size.height != sensor_attr->size.height)) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "dev[%d] sensor mode changed\n", vcap_dev_hdl);
        return TD_TRUE;
    }

    MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "dev[%d] sensor mode not change\n", vcap_dev_hdl);
    return TD_FALSE;
}

static td_void mapi_vcap_save_sensor_attr(td_handle vcap_dev_hdl,
    const hi_mapi_vcap_sensor_attr *sensor_attr, const combo_dev_attr_t *combo_dev_attr)
{
    td_s32 ret;

    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init = TD_TRUE;

    /* dev:sensor 1:1: store full sensor_attr at index 0 */
    ret = memcpy_s(&g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr,
        sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr),
        sensor_attr, sizeof(*sensor_attr));
    CHECK_MAPI_PRINT(HI_MAPI_MOD_VCAP, "memcpy_s", ret);
}

static td_s32 mapi_adapt_pipe_create_vb_pool(td_handle vcap_pipe_hdl,
    const mapi_vcap_pipe_attr *vcap_pipe_attr)
{
    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.vb_pool_blk_cnt == 0) {
        return TD_SUCCESS;
    }
    ot_pic_buf_attr frame_attr = {0};
    frame_attr.width = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr.size.width;
    frame_attr.height = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr.size.height;
    frame_attr.align = OT_DEFAULT_ALIGN;
    frame_attr.bit_width = (ot_data_bit_width)vcap_pipe_attr->bit_width;
    frame_attr.pixel_format = vcap_pipe_attr->pix_fmt;
    /* compress_mode removed from public pipe attr; use internal default value */
    frame_attr.compress_mode = (ot_compress_mode)vcap_pipe_attr->compress_mode;
#if (defined __HI3519DV500__ || defined __HI3516DV500__ || defined __HI3516CV610__)
    frame_attr.video_format =
        (ot_video_format)g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[0].chn_attr.video_format;
#endif
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id = 
		mapi_adapt_comm_create_vb_pool(&frame_attr,
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.vb_pool_blk_cnt);
    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id == OT_VB_INVALID_POOL_ID) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] create pool failed cnt[%u]!\n",
            vcap_pipe_hdl, g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.vb_pool_blk_cnt);
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

/* Apply VI wrap (卷绕) before ss_mpi_vi_create_pipe. Enable from set_config ctx; offline only. */
static td_s32 mapi_vcap_apply_pipe_wrap(td_handle vcap_pipe_hdl)
{
    td_s32 ret;

    if (!g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].buf_wrap_attr.enable) {
        return TD_SUCCESS;
    }
    if (mapi_vcap_check_wrap_work_mode(vcap_pipe_hdl) != TD_SUCCESS) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "vi wrap needs VICAP-VPROC offline, skip pipe[%d]\n", vcap_pipe_hdl);
        return TD_SUCCESS;
    }

    mapi_vcap_buf_wrap_info info = { .enable = TD_TRUE };
    ret = mapi_vcap_calc_buf_wrap(vcap_pipe_hdl, &info);
    CHECK_MAPI_VCAP_RET(ret, "calc pipe buf wrap fail,pipe[%d]\n", vcap_pipe_hdl);
    ret = mapi_adapt_vcap_set_pipe_buf_wrap(vcap_pipe_hdl, &info);
    CHECK_MAPI_VCAP_RET(ret, "set pipe buf wrap fail,pipe[%d]\n", vcap_pipe_hdl);
    MAPI_INFO_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] wrap applied: buf_line=%u\n", vcap_pipe_hdl, info.buf_line);
    return TD_SUCCESS;
}

static td_s32 mapi_vcap_create_pipe(td_handle vcap_dev_hdl, td_u32 pipe_bind_num, const td_handle pipe_id_bind[],
    td_u32 array_len)
{
    td_s32 ret;
    mapi_vcap_pipe_attr pipe_attr_local;

    if (pipe_bind_num > array_len) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "input pipe bind num err!\n");
        return TD_FAILURE;
    }
    CHECK_MAPI_VCAP_TRUE_RET(vcap_dev_hdl < HI_MAPI_VCAP_MAX_DEV_NUM, "vcap_dev_hdl error",
        HI_MAPI_VCAP_EILLEGAL_PARA);

    for (td_u32 i = 0; i < pipe_bind_num; i++) {
        td_handle vcap_pipe_hdl = pipe_id_bind[i];

        ret = memset_s(&pipe_attr_local, sizeof(pipe_attr_local), 0, sizeof(pipe_attr_local));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);
        mapi_vcap_pipe_attr *pipe_attr = &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr;

        /* fields removed from public pipe attr; read internal defaults set by mapi_vcap_static_set_pipe_attr */
        pipe_attr_local.isp_bypass       = pipe_attr->isp_bypass;
        pipe_attr_local.pipe_bypass_mode = pipe_attr->pipe_bypass_mode;
        pipe_attr_local.compress_mode    = pipe_attr->compress_mode;
        pipe_attr_local.frame_int_attr   = pipe_attr->frame_int_attr;
        pipe_attr_local.frame_rate_ctrl.src_frame_rate = pipe_attr->frame_rate_ctrl.src_frame_rate;
        pipe_attr_local.frame_rate_ctrl.dst_frame_rate = pipe_attr->frame_rate_ctrl.dst_frame_rate;
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl = vcap_dev_hdl;

        ret = mapi_vcap_adapt_pipe_attr(vcap_pipe_hdl, &pipe_attr_local);
        CHECK_MAPI_VCAP_RET(ret, "adapt pipe attr fail,pipe[%d]\n", vcap_pipe_hdl);

        ret = mapi_adapt_pipe_create_vb_pool(vcap_pipe_hdl, &pipe_attr_local);
        CHECK_MAPI_VCAP_RET(ret, "pipe[%d] create vb pool fail\n", vcap_pipe_hdl);

        /* buffer wrap (卷绕): must be set before create_pipe */
        ret = mapi_vcap_apply_pipe_wrap(vcap_pipe_hdl);
        CHECK_MAPI_VCAP_RET(ret, "pipe[%d] apply buf wrap fail\n", vcap_pipe_hdl);

        ret = mapi_adapt_vcap_create_pipe(vcap_pipe_hdl, &pipe_attr_local);
        CHECK_MAPI_VCAP_RET(ret, "pipe[%d] create pipe fail\n", vcap_pipe_hdl);

        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create = TD_TRUE;
        /* dev:sensor 1:1: VC number is fixed (0); the multi-sensor SetPipeVCNumber path is removed. */
    }

    return TD_SUCCESS;
}

static td_void mapi_vcap_destroy_pipe(td_handle vcap_dev_hdl, td_u32 pipe_bind_num, const td_handle pipe_id_bind[],
    td_u32 array_len)
{
    td_u32 i;
    td_s32 ret;
    td_handle vcap_pipe_hdl;

    if (pipe_bind_num > array_len) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "input pipe bind num err!\n");
        return;
    }

    for (i = 0; i < pipe_bind_num; i++) {
        vcap_pipe_hdl = pipe_id_bind[i];

        if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create == TD_TRUE) {
            ret = mapi_adapt_vcap_destroy_pipe(vcap_dev_hdl, vcap_pipe_hdl);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "destroy pipe fail,ret:%#x!\n", ret);
                continue;
            }
            if (mapi_adapt_comm_destroy_vb_pool(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id)
                != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "destroy vb pool failed\n");
            } else {
                g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id = OT_VB_INVALID_POOL_ID;
            }
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create = TD_FALSE;
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl = OT_INVALID_HANDLE;
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_vc_num = OT_INVALID_HANDLE;
        }
    }
}

static td_s32 mapi_vcap_stop_bind_pipe(td_handle vcap_pipe_hdl)
{
    td_s32 ret;

    /* dev:sensor 1:1: only video pipe path remains. */
    if ((g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.pipe_type == HI_MAPI_VCAP_PIPE_TYPE_VIDEO) &&
        (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_start == TD_TRUE)) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "pipe[%d] has not been disabled yet\n", vcap_pipe_hdl);
        ret = mapi_adapt_vcap_stop_pipe(vcap_pipe_hdl, g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id);
        CHECK_MAPI_VCAP_RET(ret, "stop pipe fail,pipe[%d]\n", vcap_pipe_hdl);
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_start = TD_FALSE;
    }
    return TD_SUCCESS;
}

static td_s32 mapi_vcap_reset_bind_pipe(td_handle vcap_pipe_hdl)
{
    td_s32 ret;

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl = OT_INVALID_HANDLE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_vc_num = OT_INVALID_HANDLE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create = TD_FALSE;

    ret = memset_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr, sizeof(mapi_vcap_pipe_attr),
        0, sizeof(mapi_vcap_pipe_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);
    return TD_SUCCESS;
}

static td_s32 mapi_vcap_stop_bind_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl)
{
    td_s32 ret;

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_enable == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "chn[%d] has not been disabled yet\n", pipe_chn_hdl);

        ret = mapi_adapt_vcap_stop_chn(vcap_pipe_hdl, pipe_chn_hdl,
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl]);
        CHECK_MAPI_VCAP_RET(ret, "stop chn fail,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_enable = TD_FALSE;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl] != OT_VB_INVALID_POOL_ID) {
        ret = mapi_adapt_comm_destroy_vb_pool(
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl]);
        CHECK_MAPI_VCAP_RET(ret, "destroy vb pool failed");
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl] = OT_VB_INVALID_POOL_ID;
    }

    ret = memset_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr,
        sizeof(hi_mapi_vcap_pipe_chn_attr), 0, sizeof(hi_mapi_vcap_pipe_chn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    return TD_SUCCESS;
}

/* New public API: dev:sensor 1:1, accept hi_mapi_vcap_sensor_attr directly. */
td_s32 hi_mapi_vcap_init_sensor(td_handle vcap_dev_hdl, const hi_mapi_vcap_sensor_attr *sensor_attr,
    td_bool reset_sensor)
{
    td_s32 ret;
    combo_dev_attr_t combo_dev_attr;
    td_bool tmp_reset_sensor = reset_sensor;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(sensor_attr);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    /* 1. check whether sensor attr is changed */
    if (mapi_vcap_is_sensor_change(vcap_dev_hdl, sensor_attr) == TD_FALSE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "dev[%d] sensor mode not change\n", vcap_dev_hdl);
        return TD_SUCCESS;
    }

    /* 2. if vi dev has been started, then can't change sensor attrs */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status == VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "you must stop vcap dev[%u] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    /* 3. build combo_dev_attr_t directly from sensor_attr (no runtime sensor cfg lookup). */
    ret = mapi_vcap_build_combo_dev_attr(vcap_dev_hdl, sensor_attr, &combo_dev_attr);
    CHECK_MAPI_VCAP_RET(ret, "build combo dev attr fail,dev[%d]\n", vcap_dev_hdl);

    /* 4. record reset flag; sensor scene may force-disable reset path. */
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_reset = reset_sensor;
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_scene != HI_MAPI_VCAP_SENSOR_SCENE_NORMAL) {
        tmp_reset_sensor = TD_FALSE;
    }

    /* 5. start mipi (sensor power/clock managed by sensor obj outside this layer). */
    if (sensor_attr->input_dev_attr.input_mode == HI_MAPI_VCAP_INPUT_MODE_MIPI) {
        ret = mapi_vcap_start_mipi(vcap_dev_hdl, &combo_dev_attr, &sensor_attr->combo_dev_attr, tmp_reset_sensor);
        CHECK_MAPI_VCAP_RET(ret, "start mipi fail,sensor[%d]\n", vcap_dev_hdl);
    }

#if 0 /// fix me!!!
    /* 7.judge sensor switch mode */
    MAPI_VCAP_JudgeSwitchMode(vcapDevHdl, sensorInfo);
#endif

    /* 6. save sensor mode and flag */
    mapi_vcap_save_sensor_attr(vcap_dev_hdl, sensor_attr, &combo_dev_attr);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_deinit_sensor(td_handle vcap_dev_hdl)
{
    td_s32 ret;
    td_bool reset_sensor;
    combo_dev_attr_t combo_dev_attr;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    /* 1. dev must be stopped */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status == VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "vcap is running, you should stop vcap dev first\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "sensor[%u] is already deinit\n", vcap_dev_hdl);
        return TD_SUCCESS;
    }

    /* sns_scene non-normal -> never reset sensor; otherwise honor the saved reset flag. */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_scene != HI_MAPI_VCAP_SENSOR_SCENE_NORMAL) {
        reset_sensor = TD_FALSE;
    } else {
        reset_sensor = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sns_reset;
    }

    /* 2. stop mipi */
    const hi_mapi_vcap_sensor_attr *cur_sns = &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr;
    if (cur_sns->input_dev_attr.input_mode == HI_MAPI_VCAP_INPUT_MODE_MIPI) {
        ret = mapi_vcap_build_combo_dev_attr(vcap_dev_hdl, cur_sns, &combo_dev_attr);
        CHECK_MAPI_VCAP_RET(ret, "build combo dev attr fail,dev[%u]\n", vcap_dev_hdl);

        ret = mapi_vcap_stop_mipi(vcap_dev_hdl, &combo_dev_attr, &cur_sns->combo_dev_attr, reset_sensor);
        CHECK_MAPI_VCAP_RET(ret, "stop mipi fail,dev[%u]\n", vcap_dev_hdl);
    }

    /* 3. clear sensor slot */
    ret = memset_s(&g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr,
        sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr),
        0, sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init = TD_FALSE;

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_set_sensor_frame_rate(td_handle vcap_dev_hdl, td_float frame_rate)
{
    td_s32 ret;
    td_handle vcap_pipe_hdl;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init,
        "sensor has not been inited", HI_MAPI_VCAP_ENOT_PERM);

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "need to start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    /* dev:sensor 1:1: master isp slot 0. */
    vcap_pipe_hdl = mapi_vcap_get_master_isp_id(vcap_dev_hdl, 0);
    CHECK_MAPI_VCAP_HANDLE_RET("master isp id", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));

    ret = mapi_adapt_vcap_set_frame_rate(vcap_pipe_hdl, frame_rate);
    CHECK_MAPI_VCAP_RET(ret, "set frame rate fail,dev[%d],pipe[%d]\n", vcap_dev_hdl, vcap_pipe_hdl);

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr.frame_rate = frame_rate;
    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_get_sensor_frame_rate(td_handle vcap_dev_hdl, td_float *frame_rate)
{
    td_handle vcap_pipe_hdl;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(frame_rate);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init,
        "sensor has not been inited", HI_MAPI_VCAP_ENOT_PERM);

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "need to start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    vcap_pipe_hdl = mapi_vcap_get_master_isp_id(vcap_dev_hdl, 0);
    CHECK_MAPI_VCAP_HANDLE_RET("master isp id", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));

    *frame_rate = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr.frame_rate;
    return TD_SUCCESS;
}

#if 0
/*
 * Removed-from-public APIs (kept under #if 0 for future restore):
 *   HI_MAPI_VCAP_GetSensorCnt / HI_MAPI_VCAP_GetSensorAttr
 *   HI_MAPI_VCAP_GetSensorModesCnt / HI_MAPI_VCAP_GetSensorAllModes
 * Reason: dev:sensor 1:1 + sensor obj registers itself, no runtime cfg query needed.
 */
td_s32 HI_MAPI_VCAP_GetSensorCnt(td_handle vcap_dev_hdl, td_u32 *sns_cnt) { return HI_MAPI_VCAP_ENOTSUPPORT; }
td_s32 HI_MAPI_VCAP_GetSensorAttr(td_handle vcap_dev_hdl, td_u32 sns_index,
    hi_mapi_vcap_sensor_attr *vcapSensorAttr) { return HI_MAPI_VCAP_ENOTSUPPORT; }
td_s32 HI_MAPI_VCAP_GetSensorModesCnt(td_handle vcap_dev_hdl, hi_mapi_vcap_sensor_type snsType,
    td_s32 *modesCnt) { return HI_MAPI_VCAP_ENOTSUPPORT; }
td_s32 HI_MAPI_VCAP_GetSensorAllModes(td_handle vcap_dev_hdl, hi_mapi_vcap_sensor_type snsType,
    td_s32 modesCnt, hi_mapi_vcap_sensor_mode *vcapSensorModes) { return HI_MAPI_VCAP_ENOTSUPPORT; }
#endif

/*
 1. Resolution constraints: sensor >=  Vi dev >= ISP >= PIPE >= CHN
 2. Frame rate constraints: sensor >=  Vi dev >= ISP >= PIPE >= CHN
*/
td_s32 hi_mapi_vcap_set_attr(td_handle vcap_dev_hdl, const hi_mapi_vcap_attr *vcap_attr)
{
    td_u32 i, j;
    td_s32 ret;
    td_handle vcap_pipe_hdl;
    td_handle pipe_chn_hdl;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_attr);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init,
        "sensor has not been inited", HI_MAPI_VCAP_ENOT_PERM);

    /* 1. set some dynamic attrs at dev running status */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status == VCAP_STATUS_RUNNING) {
        CHECK_MAPI_VCAP_TRUE_RET(!mapi_vcap_is_dev_attr_change(vcap_dev_hdl, &vcap_attr->vcap_dev_attr),
            "don't support modify vcap dev attributes in the running status", HI_MAPI_VCAP_ENOT_PERM);

        if (vcap_attr->pipe_bind_num > HI_MAPI_VCAP_MAX_PIPE_NUM) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe_bind_num[%u] is error\n", vcap_attr->pipe_bind_num);
            return HI_MAPI_VCAP_EILLEGAL_PARA;
        }
        CHECK_MAPI_VCAP_TRUE_RET(!mapi_vcap_is_dev_pipe_bind_change(vcap_dev_hdl, vcap_attr),
            "don't support modify dev pipe-bind in the running status", HI_MAPI_VCAP_ENOT_PERM);

        for (i = 0; i < g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num; i++) {
            vcap_pipe_hdl = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[i];

            ret = mapi_vcap_dynamic_set_pipe_attr(vcap_pipe_hdl, vcap_attr);
            CHECK_MAPI_VCAP_RET(ret, "set vcap pipe dynamic attr fail,pipe[%d]\n", vcap_pipe_hdl);

            ret = mapi_vcap_dynamic_set_isp_attr(vcap_pipe_hdl, vcap_attr);
            CHECK_MAPI_VCAP_RET(ret, "set isp pub dynamic attr fail,pipe[%d]\n", vcap_pipe_hdl);

            for (j = 0; j < HI_MAPI_VCAP_PIPE_MAX_CHN_NUM; j++) {
                pipe_chn_hdl = PIPE_CHN_0 + j;
                ret = mapi_vcap_dynamic_set_chn_attr(vcap_pipe_hdl, pipe_chn_hdl, vcap_attr);
                CHECK_MAPI_VCAP_RET(ret, "set chn dynamic attr fail,pipe[%d],chn[%d]\n",
                    vcap_pipe_hdl, pipe_chn_hdl);
            }
        }
    } else {
        /* 2. static set all vcap attrs at dev INIT or NOTINIT status */
        ret = mapi_vcap_static_set_attr(vcap_dev_hdl, vcap_attr);
        CHECK_MAPI_VCAP_RET(ret, "set vcap attr fail,dev[%d]\n", vcap_dev_hdl);

        /* SUPPORT_SERDES branch removed (demand 4); bind_serdes_id no longer maintained.
         * g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].bind_serdes_id = OT_INVALID_HANDLE;
         */
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status = VCAP_STATUS_INIT;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_get_attr(td_handle vcap_dev_hdl, hi_mapi_vcap_attr *vcap_attr)
{
    td_u32 i, j;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_attr);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status == VCAP_STATUS_NOTINIT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "please config vcap attr first\n");
        return HI_MAPI_VCAP_ENOT_CONFIG;
    }

    vcap_attr->pipe_bind_num = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num;
    td_s32 ret = memcpy_s(vcap_attr->pipe_id_bind, sizeof(vcap_attr->pipe_id_bind),
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind,
        sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    ret = memcpy_s(&vcap_attr->vcap_dev_attr, sizeof(vcap_attr->vcap_dev_attr),
        &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr,
        sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    for (i = 0; i < g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num; i++) {
        td_handle vcap_pipe_hdl = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[i];
        mapi_vcap_glob_pipe_attr *glob_pipe_attr = &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl];

        vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].pipe_type = glob_pipe_attr->pipe_attr.pipe_type;
        /* removed-from-public fields kept-commented:
         * vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].bind_vc_num = glob_pipe_attr->bind_vc_num;
         * vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].isp_bypass = glob_pipe_attr->pipe_attr.isp_bypass;
         * vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].pipe_bypass_mode = glob_pipe_attr->pipe_attr.pipe_bypass_mode;
         * vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].compress_mode = glob_pipe_attr->pipe_attr.compress_mode;
         * (void)memcpy_s(&vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].frame_int_attr,
         *     sizeof(vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].frame_int_attr),
         *     &glob_pipe_attr->pipe_attr.frame_int_attr, sizeof(glob_pipe_attr->pipe_attr.frame_int_attr));
         */

        ret = memcpy_s(&vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].frame_rate_ctrl,
            sizeof(vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].frame_rate_ctrl),
            &glob_pipe_attr->pipe_attr.frame_rate_ctrl, sizeof(glob_pipe_attr->pipe_attr.frame_rate_ctrl));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

        ret = memcpy_s(&vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].isp_pub_attr,
            sizeof(vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].isp_pub_attr),
            &glob_pipe_attr->isp_pub_attr, sizeof(glob_pipe_attr->isp_pub_attr));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

        for (j = 0; j < HI_MAPI_VCAP_PIPE_MAX_CHN_NUM; j++) {
            td_handle pipe_chn_hdl = PIPE_CHN_0 + j;
            ret = memcpy_s(&vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl],
                sizeof(vcap_attr->vcap_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl]),
                &glob_pipe_attr->pipe_chn_attr[pipe_chn_hdl].chn_attr,
                sizeof(glob_pipe_attr->pipe_chn_attr[pipe_chn_hdl].chn_attr));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);
        }
    }

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_set_wdr_fusion_grp_info(const mapi_vcap_glob_dev_attr *glob_dev_attr)
{
    if (glob_dev_attr->pipe_bind_num > OT_VI_MAX_WDR_FRAME_NUM ||
        glob_dev_attr->wdr_attr.fusion_grp > OT_VI_MAX_WDR_FUSION_GRP_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe_bind_num[%u] or fusion_grp[%u] error\n",
            glob_dev_attr->pipe_bind_num, glob_dev_attr->wdr_attr.fusion_grp);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    ot_vi_wdr_fusion_grp_attr wdr_attr = {0};
    wdr_attr.wdr_mode = glob_dev_attr->wdr_attr.wdr_mode;
    wdr_attr.cache_line = glob_dev_attr->wdr_attr.cache_line;
    wdr_attr.pipe_reverse = glob_dev_attr->wdr_attr.reverse;
    for (td_u32 i = 0; i < glob_dev_attr->pipe_bind_num; i++) {
        wdr_attr.pipe_id[i] = (ot_vi_pipe)glob_dev_attr->pipe_id_bind[i];
    }

    td_s32 ret = ss_mpi_vi_set_wdr_fusion_grp_attr((ot_vi_grp)glob_dev_attr->wdr_attr.fusion_grp, &wdr_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "vi set wdr fusion grp attr failed\n");
    }
    return ret;
}

static td_s32 mapi_vcap_check_dev_param(td_handle vcap_dev_hdl)
{
    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init,
        "sensor has not been inited, operation not allowed", HI_MAPI_VCAP_ENOT_PERM);

    /* must call hi_mapi_vcap_set_attr() before hi_mapi_vcap_start_dev() */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status == VCAP_STATUS_NOTINIT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "please config vcap attr first,current dev is[%d]\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_CONFIG;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_start_dev(td_handle vcap_dev_hdl)
{
    td_s32 ret = mapi_vcap_check_dev_param(vcap_dev_hdl);
    CHECK_MAPI_VCAP_RET(ret, "check dev param fail, vcap_dev_hdl[%d]\n", vcap_dev_hdl);

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status == VCAP_STATUS_RUNNING) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "vcap dev[%d] is already been started\n", vcap_dev_hdl);
        return TD_SUCCESS;
    }

    ret = mapi_adapt_vcap_start_dev(vcap_dev_hdl);
    CHECK_MAPI_VCAP_RET(ret, "start dev fail, vcap_dev_hdl[%d]", vcap_dev_hdl);

    /* 2. check bind attr (constraint check is done in SDK; here just collect handles). */
    td_handle pipe_id_bind[HI_MAPI_VCAP_MAX_PIPE_NUM] = {0};
    td_u32 pipe_bind_num = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num;
    for (td_u32 i = 0; i < HI_MAPI_VCAP_MAX_PIPE_NUM; i++) {
        pipe_id_bind[i] = i < pipe_bind_num ?
            g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[i] : OT_INVALID_HANDLE;
    }

    /* 3. bind vi and PIPE */
    ret = mapi_adapt_vcap_set_dev_bind_pipe(vcap_dev_hdl, pipe_bind_num, pipe_id_bind, HI_MAPI_VCAP_MAX_PIPE_NUM);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "set dev_bind_pipe fail,ret:%#x\n", ret);
        goto VCAP_START_DEV_ERR;
    }

    /* WDR fusion grp setup: only invoked when WDR is enabled (wdr_mode != NONE).
     * Internal wdr_attr is populated by mapi_vcap_static_set_attr() with safe defaults. */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].wdr_attr.wdr_mode != HI_MAPI_VCAP_WDR_MODE_NONE) {
        ret = mapi_vcap_set_wdr_fusion_grp_info(&g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl]);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "set wdrfusion failed,dev[%d]\n", vcap_dev_hdl);
            goto VCAP_CREATE_PIPE_ERR;
        }
    }

    /* 4. create PIPE, and set properties, do not support duplicate create */
    ret = mapi_vcap_create_pipe(vcap_dev_hdl, pipe_bind_num, pipe_id_bind, HI_MAPI_VCAP_MAX_PIPE_NUM);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "create pipe failed,vcap_dev_hdl[%d]", vcap_dev_hdl);
        goto VCAP_CREATE_PIPE_ERR;
    }

    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status = VCAP_STATUS_RUNNING;

    /* AHD peripheral start sequence removed (demand 4: AHD/SERDES purge). */

    return TD_SUCCESS;

VCAP_CREATE_PIPE_ERR:
    mapi_vcap_destroy_pipe(vcap_dev_hdl, pipe_bind_num, pipe_id_bind, HI_MAPI_VCAP_MAX_PIPE_NUM);

VCAP_START_DEV_ERR:
    (td_void)mapi_adapt_vcap_stop_dev(vcap_dev_hdl);
    return HI_MAPI_VCAP_EOPERATE_FAIL;
}

/*
<1> Turn off the constraints of the path:
A. If you want to disable dev, then to ensure that the pipe bound to dev stop and destroy
B. If you want to destroy the pipe, then to ensure that the pipe is closed,
   and the two CHNs on the PIPE have been closed
C.pipe start (enable) / stop (disable) does not depend on the chn enable and disable

<2>Closing is done by closing all CHNs on the pipe-> closing all pipes bound to dev (vcap_dev_hdl) ->
deactivating the specified (vcap_dev_hdl)dev */
td_s32 hi_mapi_vcap_stop_dev(td_handle vcap_dev_hdl)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_dev_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "vcap dev[%d] is already been stopped\n", vcap_dev_hdl);
        return TD_SUCCESS;
    }

    for (td_u32 i = 0; i < g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num; i++) {
        td_handle vcap_pipe_hdl = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[i];

        /* 1. stop all chns on this pipe */
        for (td_u32 j = 0; j < HI_MAPI_VCAP_PIPE_MAX_CHN_NUM; j++) {
            td_handle pipe_chn_hdl = PIPE_CHN_0 + j;
            ret = mapi_vcap_stop_bind_chn(vcap_pipe_hdl, pipe_chn_hdl);
            CHECK_MAPI_VCAP_RET(ret, "stop bind chn fail,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);
        }

        /* 2. stop all pipes (video) bound to the device */
        ret = mapi_vcap_stop_bind_pipe(vcap_pipe_hdl);
        CHECK_MAPI_VCAP_RET(ret, "stop bind pipes fail,pipe[%d]\n", vcap_pipe_hdl);

        /* 3. destroy pipe */
        ret = mapi_adapt_vcap_destroy_pipe(vcap_dev_hdl, vcap_pipe_hdl);
        CHECK_MAPI_VCAP_RET(ret, "destroy pipe fail,pipe[%d]\n", vcap_pipe_hdl);

        if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id != OT_VB_INVALID_POOL_ID) {
            if (mapi_adapt_comm_destroy_vb_pool(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id)
                != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "destroy vb pool failed\n");
            } else {
                g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id = OT_VB_INVALID_POOL_ID;
            }
        }

        /* 4. clear pipes global status */
        ret = mapi_vcap_reset_bind_pipe(vcap_pipe_hdl);
        CHECK_MAPI_VCAP_RET(ret, "reset bind pipes status fail,pipe[%d]\n", vcap_pipe_hdl);
    }

    /* 5. disable dev */
    ret = mapi_adapt_vcap_stop_dev(vcap_dev_hdl);
    CHECK_MAPI_VCAP_RET(ret, "stop dev fail,dev[%d]\n", vcap_dev_hdl);

    /* 6. clear dev global params; user must set_attr again */
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].master_isp_id = OT_INVALID_HANDLE;
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status = VCAP_STATUS_NOTINIT;
    g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num = 0;

    (td_void)memset_s(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind,
        sizeof(td_handle) * HI_MAPI_VCAP_MAX_PIPE_NUM, 0, sizeof(td_handle) * HI_MAPI_VCAP_MAX_PIPE_NUM);

    (td_void)memset_s(&g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr,
        sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr),
        0, sizeof(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr));

    /* AHD peripheral stop sequence removed (demand 4). */
    return TD_SUCCESS;
}

#if 0
/*
 * HI_MAPI_VCAP_SetPipeVCNumber / HI_MAPI_VCAP_GetPipeVCNumber: deprecated with multi-sensor.
 * dev:sensor 1:1: VC number is fixed (0). Kept under #if 0 for future restoration.
 */
td_s32 HI_MAPI_VCAP_SetPipeVCNumber(td_handle vcap_pipe_hdl, td_u32 vcNumber) { return HI_MAPI_VCAP_ENOTSUPPORT; }
td_s32 HI_MAPI_VCAP_GetPipeVCNumber(td_handle vcap_pipe_hdl, td_u32 *vcNumber) { return HI_MAPI_VCAP_ENOTSUPPORT; }
#endif

td_s32 hi_mapi_vcap_start_pipe(td_handle vcap_pipe_hdl)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if (vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1) ||
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "do not permit, you must set vcap attrs and start dev[%d] first.\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_start == TD_FALSE) {
        if ((g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num == 1) ||
            (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.pipe_type == HI_MAPI_VCAP_PIPE_TYPE_VIDEO)) {
            /* frame_int_attr removed from public hdr; configured via internal defaults */
            /* wrap (卷绕) has its own interrupt; the pipe frame interrupt conflicts with it, skip */
            if (!g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].buf_wrap_attr.enable) {
                ret = mapi_vcap_set_frame_int_attr(vcap_pipe_hdl,
                    &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.frame_int_attr);
                CHECK_MAPI_VCAP_RET(ret, "set frame int attr fail,dev[%d],pipe[%d]\n", vcap_dev_hdl, vcap_pipe_hdl);
            }

            ret = mapi_adapt_vcap_start_pipe(vcap_pipe_hdl,
                g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id);
            CHECK_MAPI_VCAP_RET(ret, "start pipe fail,dev[%d],pipe[%d]\n", vcap_dev_hdl, vcap_pipe_hdl);
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_start = TD_TRUE;
        }
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_stop_pipe(td_handle vcap_pipe_hdl)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if (vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1) ||
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "do not permit, you must set vcap attrs and start dev[%d] first.\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if ((g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_bind_num == 1) ||
        (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.pipe_type == HI_MAPI_VCAP_PIPE_TYPE_VIDEO)) {
        ret = mapi_adapt_vcap_stop_pipe(vcap_pipe_hdl, g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_pool_id);
        CHECK_MAPI_VCAP_RET(ret, "stop pipe fail,dev[%d],pipe[%d]\n", vcap_dev_hdl, vcap_pipe_hdl);
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_start = TD_FALSE;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_chn_create_vb_pool(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl)
{
    hi_mapi_vcap_pipe_chn_attr *vcap_chn_attr =
        &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_attr;

    if (vcap_chn_attr->vb_pool_blk_cnt > 0) {
        ot_pic_buf_attr frame_attr = {0};
        frame_attr.width = vcap_chn_attr->dest_size.width;
        frame_attr.height = vcap_chn_attr->dest_size.height;
        frame_attr.align = OT_DEFAULT_ALIGN;
        frame_attr.bit_width =
            (ot_data_bit_width)g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_attr.bit_width;
        frame_attr.pixel_format = vcap_chn_attr->pixel_format;
        /* compress_mode removed from public chn attr; default to no compression.
         * video_format is still kept in inner chn struct. */
        frame_attr.compress_mode = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].compress_mode;
        frame_attr.video_format =
            (ot_video_format)g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].video_format;
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl] =
            mapi_adapt_comm_create_vb_pool(&frame_attr, vcap_chn_attr->vb_pool_blk_cnt);
        if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl] == OT_VB_INVALID_POOL_ID) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "vcap chn pool[%d] create pool failed! cnt[%u]\n",
                pipe_chn_hdl, vcap_chn_attr->vb_pool_blk_cnt);
            return TD_FAILURE;
        }
    }
    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_start_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl)
{
    td_s32 ret;
    hi_mapi_vi_vpss_mode vi_vpss_mode;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if (vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1) ||
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "do not permit, you must set vcap attrs and start dev[%d] first.\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    /* In WDR mode, only the CHN of the master PIPE need to be started */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr.wdr_mode != HI_MAPI_VCAP_WDR_MODE_NONE &&
        vcap_pipe_hdl != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[0]) {
        return TD_SUCCESS;
    }

    ret = mapi_adapt_vcap_set_chn_attr(vcap_pipe_hdl, pipe_chn_hdl);
    CHECK_MAPI_VCAP_RET(ret, "set chn attr fail,dev[%d],pipe[%d],chn[%d]\n",
        vcap_dev_hdl, vcap_pipe_hdl, pipe_chn_hdl);

    /* if isp is running, reset isp (active during sensor switching). */
    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run) {
        ret = mapi_vcap_reset_isp(vcap_dev_hdl, vcap_pipe_hdl);
        CHECK_MAPI_VCAP_RET(ret, "reset isp,dev[%d],isp[%d]\n", vcap_dev_hdl, vcap_pipe_hdl);
    }

    ret = mapi_adapt_vcap_get_vi_vpss_mode(vcap_pipe_hdl, &vi_vpss_mode);
    CHECK_MAPI_VCAP_RET(ret, "get vi_vpss_mode fail,dev[%d],pipe[%d],chn[%d]\n",
        vcap_dev_hdl, vcap_pipe_hdl, pipe_chn_hdl);

    /* Only VPSS offline mode needs to enable CHN */
    if ((vi_vpss_mode == HI_MAPI_VI_OFFLINE_VPSS_ONLINE) ||
        (vi_vpss_mode == HI_MAPI_VI_ONLINE_VPSS_ONLINE)) {
        return TD_SUCCESS;
    }

    ret = mapi_adapt_chn_create_vb_pool(vcap_pipe_hdl, pipe_chn_hdl);
    CHECK_MAPI_VCAP_RET(ret, "create vbpool fail,dev[%d],pipe[%d],chn[%d]\n",
        vcap_dev_hdl, vcap_pipe_hdl, pipe_chn_hdl);

    ret = mapi_adapt_vcap_start_chn(vcap_pipe_hdl, pipe_chn_hdl,
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl]);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "start chn fail,dev[%u],pipe[%u],chn[%u]\n", vcap_dev_hdl, vcap_pipe_hdl, pipe_chn_hdl);
        (td_void)mapi_adapt_comm_destroy_vb_pool(
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl]);
        return ret;
    }
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_enable = TD_TRUE;

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_stop_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if (vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1) ||
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "do not permit, you must set vcap attrs and start dev[%d] first.\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = mapi_adapt_vcap_stop_chn(vcap_pipe_hdl, pipe_chn_hdl,
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl]);
    CHECK_MAPI_VCAP_RET(ret, "stop chn fail,dev[%d],pipe[%d],chn[%d]\n",
        vcap_dev_hdl, vcap_pipe_hdl, pipe_chn_hdl);
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_enable = TD_FALSE;

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl] != OT_VB_INVALID_POOL_ID) {
        ret = mapi_adapt_comm_destroy_vb_pool(
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl]);
        CHECK_MAPI_VCAP_RET(ret, "destroy vb pool fail,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_pool_id[pipe_chn_hdl] = OT_VB_INVALID_POOL_ID;
    }

    return TD_SUCCESS;
}

td_s32 mapi_vcap_get_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_frame_data *frame_data, td_s32 milli_sec)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(frame_data);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].pipe_chn_attr[pipe_chn_hdl].chn_enable,
        "please start vcap chn first", HI_MAPI_VCAP_ENOT_PERM);

    ret = mapi_adapt_vcap_get_chn_frame(vcap_pipe_hdl, pipe_chn_hdl, frame_data, milli_sec);
    CHECK_MAPI_VCAP_RET(ret, "get chn frame fail,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

td_s32 mapi_vcap_release_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_frame_data *frame_data)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(frame_data);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    ret = mapi_adapt_vcap_release_chn_frame(vcap_pipe_hdl, pipe_chn_hdl, frame_data);
    CHECK_MAPI_VCAP_RET(ret, "release chn frame fail,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_get_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_frame_data *frame_data)
{
    td_s32 ret;

    ret = mapi_vcap_get_chn_frame(vcap_pipe_hdl, pipe_chn_hdl, frame_data, MAPI_VCAP_GET_CHN_FRAME_TIMEOUT);
    CHECK_MAPI_VCAP_RET(ret, "get chn frame fail,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_release_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_frame_data *frame_data)
{
    td_s32 ret;

    ret = mapi_vcap_release_chn_frame(vcap_pipe_hdl, pipe_chn_hdl, frame_data);
    CHECK_MAPI_VCAP_RET(ret, "release chn frame fail,pipe[%d],chn[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

static td_s32 mapi_vcap_init_isp(td_handle vcap_pipe_hdl)
{
    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    /* dev:sensor 1:1: sensor index fixed to 0; build combo_dev_attr from saved sensor_attr. */
    const hi_mapi_vcap_sensor_attr *sensor_attr = &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr;
    td_s32 ret;

    /* 1. register isp sensor callback */
    ret = mapi_adapt_vcap_reg_isp_sns_callback(vcap_pipe_hdl, sensor_attr);
    CHECK_MAPI_VCAP_RET(ret, "dev[%u] register isp callback failed,isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);

    /* 2. bind isp to sensor (i2c/spi bus id) */
    ret = mapi_vcap_bind_isp_to_sensor(vcap_dev_hdl, vcap_pipe_hdl, sensor_attr);
    if (ret != TD_SUCCESS) {
        mapi_adapt_vcap_unreg_isp_sns_callback(vcap_pipe_hdl, sensor_attr);
        CHECK_MAPI_VCAP_RET(ret, "bind isp to sensor fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);
    }

    /* 3. register 3A */
    ret = mapi_adapt_vcap_register_isp_3a(vcap_pipe_hdl);
    if (ret != TD_SUCCESS) {
        mapi_adapt_vcap_unreg_isp_sns_callback(vcap_pipe_hdl, sensor_attr);
        CHECK_MAPI_VCAP_RET(ret, "register isp 3a fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);
    }

    /* 4. set isp init attribute (AE/AWB), must be called before mpi_isp_mem_init */
    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr.is_isp_attr_init == TD_TRUE) {
        ret = mapi_adapt_vcap_set_isp_sns_init(vcap_pipe_hdl, sensor_attr);
        CHECK_MAPI_VCAP_RET_GOTO_FAIL(ret, "set isp init attr fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);
    }

    /* 5. mem init */
    ret = mapi_adapt_vcap_init_isp_mem(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET_GOTO_FAIL(ret, "isp mem init failed,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);

    /* 6. set pub attr */
    ret = mapi_vcap_set_isp_pub_attr(vcap_dev_hdl, vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET_GOTO_FAIL(ret, "set isp pub attr fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);

    /* 7. isp init */
    ret = mapi_adapt_vcap_init_isp(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET_GOTO_FAIL(ret, "isp init fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);

    /* 8. set sensor mirror/flip */
    mapi_adapt_vcap_set_sns_mirror_flip(vcap_pipe_hdl,
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_pub_attr.sns_mirror_flip, sensor_attr);

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_init = TD_TRUE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_exited = TD_FALSE;
    return ret;
FAIL:
    (td_void)mapi_adapt_vcap_stop_isp(vcap_pipe_hdl);
    (td_void)mapi_adapt_vcap_unreg_isp_sns_callback(vcap_pipe_hdl, sensor_attr);
    (td_void)mapi_adapt_vcap_unregister_isp_3a(vcap_pipe_hdl);
    return ret;
}

td_s32 hi_mapi_vcap_init_isp(td_handle vcap_pipe_hdl)
{
    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;

    /* 1. check dev and sensor status */
    if (vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1) ||
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "do not permit, you must set vcap attrs and start dev[%u] first.\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].is_sns_init,
        "sensor has not been inited", HI_MAPI_VCAP_ENOT_PERM);

    /* 2. in WDR mode, only the master pipe's isp need be inited */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr.wdr_mode != HI_MAPI_VCAP_WDR_MODE_NONE &&
        vcap_pipe_hdl != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[0]) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP,
            "in wdr mode, only the master pipe's isp need to be inited.\n");
        return TD_SUCCESS;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_init == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "isp[%d] is already been inited\n", vcap_pipe_hdl);
        return TD_SUCCESS;
    }

    /* 3. register ISP */
    td_s32 ret = mapi_vcap_init_isp(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET(ret, "mapi_vcap_init_isp fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_deinit_isp(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    td_handle vcap_dev_hdl;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run == TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "isp is still in start, stop it firstly.\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_init == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "isp is not init.\n");
        return TD_SUCCESS;
    }

    /* check dev status */
    vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if (vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1) ||
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "do not permit, you must set vcap attrs and start dev[%u] firstly.\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    /* ISP exit: skip if stop_isp already did it, avoid double sensor cmos exit */
    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_exited == TD_FALSE) {
        ret = mapi_adapt_vcap_stop_isp(vcap_pipe_hdl);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "isp firmware abnormally exit with %#x!\n", ret);
            return ret;
        }
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_exited = TD_TRUE;
    }

    /* 3A unregister */
    ret = mapi_adapt_vcap_unregister_isp_3a(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET(ret, "unregister isp 3a fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);

    /* unreg sensor callback (dev:sensor 1:1, use saved sensor_attr instead of sensor cfg lookup). */
    const hi_mapi_vcap_sensor_attr *sensor_attr = &g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].sensor_attr;
    ret = mapi_adapt_vcap_unreg_isp_sns_callback(vcap_pipe_hdl, sensor_attr);
    CHECK_MAPI_VCAP_RET(ret, "unregister sensor callback fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr.is_isp_attr_init = TD_FALSE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_init = TD_FALSE;

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_start_isp(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    td_handle vcap_dev_hdl;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    MAPI_MUTEX_LOCK(g_vcap_lock);
    vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;

    if (vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1) ||
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "do not permit, you must set vcap attrs and start dev[%u] first\n", vcap_dev_hdl);
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr.wdr_mode != HI_MAPI_VCAP_WDR_MODE_NONE &&
        vcap_pipe_hdl != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[0]) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP,
            "in wdr mode, only the master pipe's isp need to be started.\n");
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return TD_SUCCESS;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_init == TD_FALSE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "isp[%u] need to be inited firstly\n", vcap_pipe_hdl);
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run == TD_TRUE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "isp[%u] is already been started\n", vcap_pipe_hdl);
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return TD_SUCCESS;
    }

    ret = pthread_create(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_run_thread, TD_NULL,
        mapi_vcap_isp_run_proc, (td_void *)&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP,
            "isp running thread create failed,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return ret;
    }

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run = TD_TRUE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_exited = TD_FALSE;
    MAPI_MUTEX_UNLOCK(g_vcap_lock);

    usleep(MAPI_VCAP_ISP_RUN_START_WAIT_US);

    MAPI_MUTEX_LOCK(g_vcap_lock);
    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_exited == TD_TRUE) {
        (td_void)pthread_join(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_run_thread, TD_NULL);
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_run_thread = (pthread_t)-1;
        g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run = TD_FALSE;
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "isp[%u] firmware failed to start\n", vcap_pipe_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }
    MAPI_MUTEX_UNLOCK(g_vcap_lock);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_stop_isp(td_handle vcap_pipe_hdl)
{
    td_s32 ret;
    td_handle vcap_dev_hdl;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vcap_lock);
    if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run == TD_FALSE) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_VCAP, "isp is already been stopped.\n");
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return TD_SUCCESS;
    }

    vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if (vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1) ||
        g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "do not permit, you must set vcap attrs and start dev[%u] firstly.\n", vcap_dev_hdl);
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = mapi_adapt_vcap_stop_isp(vcap_pipe_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "isp firmware abnormally exit with %#x!\n", ret);
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return ret;
    }

    ret = pthread_join(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_run_thread, NULL);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "call pthread_join fail,dev[%u],isp[%u]\n", vcap_dev_hdl, vcap_pipe_hdl);
        MAPI_MUTEX_UNLOCK(g_vcap_lock);
        return ret;
    }

    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].isp_run_thread = (pthread_t)-1;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_run = TD_FALSE;
    g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_isp_exited = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_vcap_lock);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_set_param(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_cmd command,
    const td_void *cmd_attr, td_u32 len)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_MAX_VAL_RET("command", command, (HI_MAPI_VCAP_CMD_BUTT - 1));
    if ((command != HI_MAPI_VCAP_CMD_ENTER_STANDBY) &&
        (command != HI_MAPI_VCAP_CMD_EXIT_STANDBY) &&
        (command != HI_MAPI_VCAP_CMD_RESTART_SENSOR)) {
        CHECK_MAPI_VCAP_NULL_PTR_RET(cmd_attr);
        CHECK_MAPI_VCAP_ZERO_VAL_RET("len", len);
    }

    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "must set vcap attrs and start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    /* In WDR mode, only the CHN of the master PIPE need to be set,
       and the first pipe bound to dev is the master pipe. */
    if ((g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr.wdr_mode != HI_MAPI_VCAP_WDR_MODE_NONE) &&
        (vcap_pipe_hdl != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[0])) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "In WDR mode, only the chn of the master pipe need to be set.\n");
        return TD_SUCCESS;
    }

    /* dev:sensor 1:1, sns_index always 0 */
    td_handle master_isp = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].master_isp_id;

    switch (command) {
        case HI_MAPI_VCAP_CMD_ISP_EXPOURSEATTR: {
            hi_mapi_vcap_exposure_attr *vcap_exposure = (hi_mapi_vcap_exposure_attr *)cmd_attr;

            ret = mapi_vcap_set_exposure(vcap_pipe_hdl, vcap_exposure);
            CHECK_MAPI_VCAP_RET(ret, "set Exposure fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_WBATTR: {
            hi_mapi_vcap_wb_attr *vcap_wb_attr = (hi_mapi_vcap_wb_attr *)cmd_attr;

            ret = mapi_vcap_set_wb(vcap_pipe_hdl, vcap_wb_attr);
            CHECK_MAPI_VCAP_RET(ret, "set WB fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

            break;
        }

        case HI_MAPI_VCAP_CMD_ROTATE: {
            ret = mapi_vcap_check_vi_vpss_work_mode(vcap_pipe_hdl);
            CHECK_MAPI_VCAP_RET(ret,
                "don't support rotate when vpss work mode is online or parallel,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);

            hi_mapi_rotation *rotation = (hi_mapi_rotation *)cmd_attr;

            ret = mapi_adapt_vcap_set_rotation(vcap_pipe_hdl, pipe_chn_hdl, rotation);
            CHECK_MAPI_VCAP_RET(ret, "set Rotation fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
                vcap_pipe_hdl, pipe_chn_hdl);

            break;
        }

        case HI_MAPI_VCAP_CMD_MIRRORFLIP: {
            hi_mapi_vcap_mirror_flip_attr *vcap_mirror_flip = (hi_mapi_vcap_mirror_flip_attr *)cmd_attr;

            ret = mapi_vcap_set_mirror_flip(vcap_pipe_hdl, pipe_chn_hdl, vcap_mirror_flip);
            CHECK_MAPI_VCAP_RET(ret, "set mirrorFilp fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
                vcap_pipe_hdl, pipe_chn_hdl);

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_DNGCOLORPARAM: {
            hi_mapi_vcap_isp_dng_color_param *vcap_dng_color_param = (hi_mapi_vcap_isp_dng_color_param *)cmd_attr;

            ret = mapi_adapt_vcap_set_isp_dng_color_param(master_isp, vcap_dng_color_param);
            CHECK_MAPI_VCAP_RET(ret,
                "set Isp DngColor Param fail fail,MasterISP[%d],ISP[%d]\n", master_isp, vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_SET_AEDEBUG: {
            hi_mapi_vcap_isp_debug_info *vcap_isp_debug_info = (hi_mapi_vcap_isp_debug_info *)cmd_attr;

            ret = mapi_adapt_vcap_set_isp_debug(master_isp, command, vcap_isp_debug_info);
            CHECK_MAPI_VCAP_RET(ret,
                "set ISP AE Debug fail,MasterISP[%d],ISP[%d]\n", master_isp, vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_SET_AWBDEBUG: {
            hi_mapi_vcap_isp_debug_info *vcap_isp_debug_info = (hi_mapi_vcap_isp_debug_info *)cmd_attr;

            ret = mapi_adapt_vcap_set_isp_debug(master_isp, command, vcap_isp_debug_info);
            CHECK_MAPI_VCAP_RET(ret,
                "set ISP AWB Debug fail,MasterISP[%d],ISP[%d]\n", master_isp, vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_SATURATION: {
            ret = mapi_adapt_vcap_set_saturation(vcap_pipe_hdl, (hi_mapi_vcap_saturation *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "set Saturation fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_LUMA: {
            ret = mapi_adapt_vcap_set_luma(vcap_pipe_hdl, (hi_mapi_vcap_luma *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "set Luma fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_SHARPEN: {
            ret = mapi_adapt_vcap_set_sharpen(vcap_pipe_hdl, (hi_mapi_vcap_sharpen *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "set Sharpen fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_METERINGMODE: {
            ret = mapi_adapt_vcap_set_metering_mode(vcap_pipe_hdl, (hi_mapi_vcap_metering_mode *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "set MeteringMode fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_WDR: {
            hi_mapi_vcap_isp_wdr_fs_attr *vcap_wdr_fs_attr = (hi_mapi_vcap_isp_wdr_fs_attr *)cmd_attr;

            ret = mapi_adapt_vcap_set_isp_wdr_fs_attr(vcap_pipe_hdl, vcap_wdr_fs_attr);
            CHECK_MAPI_VCAP_RET(ret, "set FsWdr Attr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_PIPEDIFFATTR: {
            hi_mapi_vcap_isp_pipe_diff_attr *vcap_pipe_diff_attr = (hi_mapi_vcap_isp_pipe_diff_attr *)cmd_attr;

            ret = mapi_adapt_vcap_set_isp_pipe_diff_attr(vcap_pipe_hdl, vcap_pipe_diff_attr);
            CHECK_MAPI_VCAP_RET(ret, "set PipeDifferAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_CAC: {
            hi_mapi_vcap_isp_local_cac_attr *vcap_local_cac_attr = (hi_mapi_vcap_isp_local_cac_attr *)cmd_attr;

            ret = mapi_adapt_vcap_set_isp_local_cac_attr(vcap_pipe_hdl, vcap_local_cac_attr);
            CHECK_MAPI_VCAP_RET(ret, "set local CacAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ENTER_STANDBY: {
            ret = mapi_vcap_enter_standby(vcap_pipe_hdl);
            CHECK_MAPI_VCAP_RET(ret, "enter StandBy secne fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_EXIT_STANDBY: {
            ret = mapi_vcap_exit_standby(vcap_pipe_hdl);
            CHECK_MAPI_VCAP_RET(ret, "exit StandBy scene fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_RESTART_SENSOR: {
            ret = mapi_vcap_restart_sensor(vcap_pipe_hdl);
            CHECK_MAPI_VCAP_RET(ret, "restart Sensor fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_CONTRAST: {
            hi_mapi_vcap_contrast *contrast = (hi_mapi_vcap_contrast *)cmd_attr;
            ret = mapi_adapt_vcap_set_contrast(vcap_pipe_hdl, contrast);
            CHECK_MAPI_VCAP_RET(ret, "set contrast fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_CHN_DEPTH: {
            hi_mapi_vcap_chn_depth *chn_depth = (hi_mapi_vcap_chn_depth *)cmd_attr;

            ret = mapi_vcap_set_chn_depth(vcap_pipe_hdl, pipe_chn_hdl, chn_depth);
            CHECK_MAPI_VCAP_RET(ret, "set chn depth fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
                vcap_pipe_hdl, pipe_chn_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_PIPE_LOW_DELAY: {
            hi_mapi_vcap_low_delay_info *info = (hi_mapi_vcap_low_delay_info *)cmd_attr;

            ret = mapi_adapt_vcap_set_pipe_low_delay(vcap_pipe_hdl, info);
            CHECK_MAPI_VCAP_RET(ret, "set pipe low delay fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_CHN_LOW_DELAY: {
            hi_mapi_vcap_low_delay_info *info = (hi_mapi_vcap_low_delay_info *)cmd_attr;

            ret = mapi_adapt_vcap_set_chn_low_delay(vcap_pipe_hdl, pipe_chn_hdl, info);
            CHECK_MAPI_VCAP_RET(ret, "set chn low delay fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
                vcap_pipe_hdl, pipe_chn_hdl);
            break;
        }

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "unsupport attrEx command.\n");
            return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_get_param(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_cmd command,
    td_void *cmd_attr, td_u32 len)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(cmd_attr);
    CHECK_MAPI_VCAP_MAX_VAL_RET("command", command, (HI_MAPI_VCAP_CMD_BUTT - 1));
    CHECK_MAPI_VCAP_ZERO_VAL_RET("len", len);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "dot not permit,you must set Vcap Attrs and start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    td_handle vcap_pipe = vcap_pipe_hdl;
    /* 1.In WDR mode, only the CHN of the master PIPE need to be started */
    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr.wdr_mode != HI_MAPI_VCAP_WDR_MODE_NONE) {
        if (vcap_pipe_hdl != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[0]) {
            MAPI_INFO_TRACE(HI_MAPI_MOD_VCAP, "In WDR mode, only the CHN of the master PIPE will be get.\n");
            vcap_pipe = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[0];
        }
    }

    td_handle master_isp = g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].master_isp_id;

    switch (command) {
        case HI_MAPI_VCAP_CMD_ISP_EXPOURSEATTR: {
            ret = mapi_vcap_get_exposure(vcap_pipe, (hi_mapi_vcap_exposure_attr *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "get exposure fail,vcap_pipe_hdl[%d]\n", vcap_pipe);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_WBATTR: {
            ((hi_mapi_vcap_wb_attr *)cmd_attr)->op_type =
                g_vcap_glob_attr.glob_pipe_attr[vcap_pipe].vcap_isp_wb_attr.op_type;
            ((hi_mapi_vcap_wb_attr *)cmd_attr)->wb_mode.color_temp =
                g_vcap_glob_attr.glob_pipe_attr[vcap_pipe].vcap_isp_wb_attr.wb_mode.color_temp;
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_GET_EXPOURSEINFO: {
            ret = mapi_adapt_vcap_get_exposure_info(master_isp, (hi_mapi_vcap_exposure_info *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "get exposure Info fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_GET_AWBINFO: {
            ret = mapi_adapt_vcap_get_wb_info(master_isp, (hi_mapi_vcap_isp_wb_info *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "get WbInfo fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_ROTATE: {
            ret = mapi_vcap_check_vi_vpss_work_mode(vcap_pipe);
            CHECK_MAPI_VCAP_RET(ret,
                "don't support Rotate when vpss work mode is online or parallel,vcap_pipe_hdl[%d]\n", vcap_pipe);

            ret = mapi_adapt_vcap_get_rotation(vcap_pipe, pipe_chn_hdl, (hi_mapi_rotation *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "get Chn Rotation fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_MIRRORFLIP: {
            mapi_vcap_pipe_chn_attr vcap_chn_attr;

            ret = mapi_vcap_check_vi_vpss_work_mode(vcap_pipe);
            CHECK_MAPI_VCAP_RET(ret,
                "don't support Mirror when vpss work mode is online or parallel,vcap_pipe_hdl[%d]\n", vcap_pipe);

            ret = memset_s(&vcap_chn_attr, sizeof(mapi_vcap_pipe_chn_attr), 0, sizeof(mapi_vcap_pipe_chn_attr));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_chn_attr(vcap_pipe, pipe_chn_hdl, &vcap_chn_attr);
            CHECK_MAPI_VCAP_RET(ret, "get Chn attr fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n", vcap_pipe, pipe_chn_hdl);

            ((hi_mapi_vcap_mirror_flip_attr *)cmd_attr)->mirror = vcap_chn_attr.mirror;
            ((hi_mapi_vcap_mirror_flip_attr *)cmd_attr)->flip = vcap_chn_attr.flip;

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_GET_DNGIMAGESTATICINFO: {
            hi_mapi_vcap_dng_image_static_info *vcap_dng_info = (hi_mapi_vcap_dng_image_static_info *)cmd_attr;

            ret = memset_s(vcap_dng_info, sizeof(hi_mapi_vcap_dng_image_static_info),
                0x00, sizeof(hi_mapi_vcap_dng_image_static_info));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_dng_image_static_info(master_isp, vcap_dng_info);
            CHECK_MAPI_VCAP_RET(ret, "get Dng Image StaticInfo fail,MasterISP[%d],vcap_pipe_hdl[%d]\n",
                master_isp, vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_DNGCOLORPARAM: {
            hi_mapi_vcap_isp_dng_color_param *vcap_dng_color = (hi_mapi_vcap_isp_dng_color_param *)cmd_attr;

            ret = memset_s(vcap_dng_color, sizeof(hi_mapi_vcap_isp_dng_color_param),
                0x00, sizeof(hi_mapi_vcap_isp_dng_color_param));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_isp_dng_color_param(master_isp, vcap_dng_color);
            CHECK_MAPI_VCAP_RET(ret, "get Dng ColorParam fail,MasterISP[%d],vcap_pipe_hdl[%d]\n",
                master_isp, vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_SATURATION: {
            ret = mapi_adapt_vcap_get_saturation(vcap_pipe, (hi_mapi_vcap_saturation *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "get Saturation fail,vcap_pipe_hdl[%d]\n", vcap_pipe);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_LUMA: {
            ret = mapi_adapt_vcap_get_luma(vcap_pipe, (hi_mapi_vcap_luma *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "get Luma fail,vcap_pipe_hdl[%d]\n", vcap_pipe);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_SHARPEN: {
            ret = mapi_adapt_vcap_get_sharpen(vcap_pipe, (hi_mapi_vcap_sharpen *)cmd_attr);
            CHECK_MAPI_VCAP_RET(ret, "get Sharpen fail,vcap_pipe_hdl[%d]\n", vcap_pipe);
            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_METERINGMODE: {
            hi_mapi_vcap_metering_mode *vcap_metering_mode = (hi_mapi_vcap_metering_mode *)cmd_attr;

            ret = memset_s(vcap_metering_mode, sizeof(hi_mapi_vcap_metering_mode),
                0x00, sizeof(hi_mapi_vcap_metering_mode));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_metering_mode(vcap_pipe, vcap_metering_mode);
            CHECK_MAPI_VCAP_RET(ret, "get MeteringMode fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_WDR: {
            hi_mapi_vcap_isp_wdr_fs_attr *vcap_wdr_fs_attr = (hi_mapi_vcap_isp_wdr_fs_attr *)cmd_attr;

            ret = memset_s(vcap_wdr_fs_attr, sizeof(hi_mapi_vcap_isp_wdr_fs_attr),
                0x00, sizeof(hi_mapi_vcap_isp_wdr_fs_attr));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_isp_wdr_fs_attr(vcap_pipe, vcap_wdr_fs_attr);
            CHECK_MAPI_VCAP_RET(ret, "get FSWDRAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_PIPEDIFFATTR: {
            hi_mapi_vcap_isp_pipe_diff_attr *vcap_pipe_diff_attr = (hi_mapi_vcap_isp_pipe_diff_attr *)cmd_attr;

            ret = memset_s(vcap_pipe_diff_attr, sizeof(hi_mapi_vcap_isp_pipe_diff_attr),
                0x00, sizeof(hi_mapi_vcap_isp_pipe_diff_attr));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_isp_pipe_diff_attr(vcap_pipe, vcap_pipe_diff_attr);
            CHECK_MAPI_VCAP_RET(ret, "get PipeDifferAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_GET_PUBINFO: {
            hi_mapi_vcap_pipe_isp_attr *user_isp_attr = (hi_mapi_vcap_pipe_isp_attr *)cmd_attr;
            hi_mapi_vcap_isp_pub_attr adapt_isp_attr;

            ret = memset_s(user_isp_attr, sizeof(hi_mapi_vcap_pipe_isp_attr),
                0x00, sizeof(hi_mapi_vcap_pipe_isp_attr));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_isp_pub_attr(vcap_pipe, &adapt_isp_attr);
            CHECK_MAPI_VCAP_RET(ret, "get IspPubAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            user_isp_attr->frame_rate = adapt_isp_attr.frame_rate;
            user_isp_attr->bayer      = adapt_isp_attr.bayer;
            user_isp_attr->size       = adapt_isp_attr.sns_size;

            break;
        }

        case HI_MAPI_VCAP_CMD_ISP_CAC: {
            hi_mapi_vcap_isp_local_cac_attr *vcap_local_cac_attr = (hi_mapi_vcap_isp_local_cac_attr *)cmd_attr;

            ret = memset_s(vcap_local_cac_attr, sizeof(hi_mapi_vcap_isp_local_cac_attr),
                0x00, sizeof(hi_mapi_vcap_isp_local_cac_attr));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_isp_local_cac_attr(vcap_pipe, vcap_local_cac_attr);
            CHECK_MAPI_VCAP_RET(ret, "get LocalCacAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            break;
        }

        case HI_MAPI_VCAP_CMD_PIPE_GETCMPPARAM: {
            hi_mapi_vcap_cmp_param *vcap_cmp_param = (hi_mapi_vcap_cmp_param *)cmd_attr;

            ret = memset_s(vcap_cmp_param, sizeof(hi_mapi_vcap_cmp_param),
                0x00, sizeof(hi_mapi_vcap_cmp_param));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memset_s", ret);

            ret = mapi_adapt_vcap_get_cmp_param(vcap_pipe, vcap_cmp_param);
            CHECK_MAPI_VCAP_RET(ret, "get PipeCmpParam fail,vcap_pipe_hdl[%d]\n", vcap_pipe);

            break;
        }
#if (defined(__SS928V100__) || defined(__HI3516DV500__) || defined(__HI3519DV500__) || defined(__HI3516CV610__))
        case HI_MAPI_VCAP_CMD_ISP_CONTRAST: {
            hi_mapi_vcap_contrast *contrast = (hi_mapi_vcap_contrast *)cmd_attr;
            ret = mapi_adapt_vcap_get_contrast(vcap_pipe, contrast);
            break;
        }
#endif
        case HI_MAPI_VCAP_CMD_CHN_DEPTH: {
            hi_mapi_vcap_chn_depth *chn_depth = (hi_mapi_vcap_chn_depth *)cmd_attr;

            ret = mapi_vcap_get_chn_depth(vcap_pipe, pipe_chn_hdl, chn_depth);
            CHECK_MAPI_VCAP_RET(ret, "get chn depth fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
                vcap_pipe, pipe_chn_hdl);
            break;
        }

        case HI_MAPI_VCAP_CMD_PIPE_LOW_DELAY: {
            hi_mapi_vcap_low_delay_info *info = (hi_mapi_vcap_low_delay_info *)cmd_attr;

            ret = mapi_adapt_vcap_get_pipe_low_delay(vcap_pipe, info);
            CHECK_MAPI_VCAP_RET(ret, "get pipe low delay fail,vcap_pipe_hdl[%d]\n", vcap_pipe);
            break;
        }

        case HI_MAPI_VCAP_CMD_CHN_LOW_DELAY: {
            hi_mapi_vcap_low_delay_info *info = (hi_mapi_vcap_low_delay_info *)cmd_attr;

            ret = mapi_adapt_vcap_get_chn_low_delay(vcap_pipe, pipe_chn_hdl, info);
            CHECK_MAPI_VCAP_RET(ret, "get chn low delay fail,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
                vcap_pipe, pipe_chn_hdl);
            break;
        }

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "unsupport attrEx command.\n");
            return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_set_config(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_config_cmd command,
    const td_void *cmd_attr, td_u32 len)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_MAX_VAL_RET("command", command, (HI_MAPI_VCAP_CONFIG_CMD_BUTT - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(cmd_attr);
    CHECK_MAPI_VCAP_ZERO_VAL_RET("len", len);

    /* Static config: only requires the module inited. It may be called before start_dev,
       so do NOT check is_pipe_create or dev_status==RUNNING here. */
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    switch (command) {
        case HI_MAPI_VCAP_CONFIG_CMD_ISP_3AINIT: {
            /* In WDR mode, caller should pass the master pipe handle; only its ISP is inited. */
            ret = memcpy_s(&g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr.isp_init_attr,
                sizeof(hi_mapi_vcap_isp_init_attr), cmd_attr, len);
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr.is_isp_attr_init = TD_TRUE;
            break;
        }

        case HI_MAPI_VCAP_CONFIG_CMD_OB_HEIGHT: {
            /* handle arg is the dev handle (dev:sensor 1:1); call before init_sensor. */
            const hi_mapi_vcap_ob_height_cfg *ob_cfg = (const hi_mapi_vcap_ob_height_cfg *)cmd_attr;
            CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
            g_vcap_glob_attr.glob_dev_attr[vcap_pipe_hdl].ob_height = ob_cfg->ob_height;
            break;
        }

        case HI_MAPI_VCAP_CONFIG_CMD_PIPE_BUF_WRAP: {
            if (len < sizeof(hi_mapi_vcap_buf_wrap_attr)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe buf wrap len:%u small\n", len);
                return HI_MAPI_VCAP_EILLEGAL_PARA;
            }
            /* static: must be set before pipe creation, so reject once created */
            if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe buf wrap must be set before start_dev,pipe[%d]\n",
                    vcap_pipe_hdl);
                return HI_MAPI_VCAP_ENOT_PERM;
            }
            /* only 'enable' is honored; buf_line is computed internally at pipe creation */
            g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].buf_wrap_attr.enable =
                ((const hi_mapi_vcap_buf_wrap_attr *)cmd_attr)->enable;
            break;
        }

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "unsupport config command.\n");
            return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_get_config(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_config_cmd command,
    td_void *cmd_attr, td_u32 len)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_MAX_VAL_RET("command", command, (HI_MAPI_VCAP_CONFIG_CMD_BUTT - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(cmd_attr);
    CHECK_MAPI_VCAP_ZERO_VAL_RET("len", len);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);

    switch (command) {
        case HI_MAPI_VCAP_CONFIG_CMD_ISP_3AINIT: {
            ret = memcpy_s(cmd_attr, len,
                &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].vcap_isp_init_attr.isp_init_attr,
                sizeof(hi_mapi_vcap_isp_init_attr));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);
            break;
        }

        case HI_MAPI_VCAP_CONFIG_CMD_OB_HEIGHT: {
            CHECK_MAPI_VCAP_HANDLE_RET("vcap_dev_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_DEV_NUM - 1));
            ret = memcpy_s(cmd_attr, len,
                &g_vcap_glob_attr.glob_dev_attr[vcap_pipe_hdl].ob_height, sizeof(td_u32));
            CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);
            break;
        }

        case HI_MAPI_VCAP_CONFIG_CMD_PIPE_BUF_WRAP: {
            if (len < sizeof(hi_mapi_vcap_buf_wrap_attr)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "pipe buf wrap len:%u small\n", len);
                return HI_MAPI_VCAP_EILLEGAL_PARA;
            }
            hi_mapi_vcap_buf_wrap_attr *wrap = (hi_mapi_vcap_buf_wrap_attr *)cmd_attr;
            if (g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create) {
                /* after creation read the authoritative applied state from the SDK (only 'enable' exposed) */
                mapi_vcap_buf_wrap_info info = {0};
                ret = mapi_adapt_vcap_get_pipe_buf_wrap(vcap_pipe_hdl, &info);
                CHECK_MAPI_VCAP_RET(ret, "get pipe buf wrap fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
                wrap->enable = info.enable;
            } else {
                wrap->enable = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].buf_wrap_attr.enable;
            }
            break;
        }

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "unsupport config command.\n");
            return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_set_chn_crop_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    const hi_mapi_vcap_crop_info *vcap_crop_info)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_crop_info);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "dot not permit,you must set Vcap Attrs and start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = mapi_vcap_check_vi_vpss_work_mode(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET(ret,
        "don't support operate crop when vpss work mode is online or parallel,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    ret = mapi_adapt_vcap_set_chn_crop_attr(vcap_pipe_hdl, pipe_chn_hdl, vcap_crop_info);
    CHECK_MAPI_VCAP_RET(ret,
        "set Chn Crop failed,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_get_chn_crop_attr(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
    hi_mapi_vcap_crop_info *vcap_crop_info)
{
    td_s32 ret;
    td_handle vcap_dev_hdl;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_HANDLE_RET("pipe_chn_hdl", pipe_chn_hdl, (HI_MAPI_VCAP_PIPE_MAX_CHN_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcap_crop_info);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;

    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "dot not permit,you must set Vcap Attrs and start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = mapi_vcap_check_vi_vpss_work_mode(vcap_pipe_hdl);
    CHECK_MAPI_VCAP_RET(ret,
        "don't support operate crop when the vpss work mode is online or parallel,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n",
        vcap_pipe_hdl, pipe_chn_hdl);

    ret = mapi_adapt_vcap_get_chn_crop_attr(vcap_pipe_hdl, pipe_chn_hdl, vcap_crop_info);
    CHECK_MAPI_VCAP_RET(ret,
        "get ChnCrop failed,vcap_pipe_hdl[%d],pipe_chn_hdl[%d]\n", vcap_pipe_hdl, pipe_chn_hdl);

    return TD_SUCCESS;
}

#if 0  /* RAW dump public APIs disabled (demand 3) */
td_s32 HI_MAPI_VCAP_SetDumpRawAttr(td_handle vcap_pipe_hdl, const hi_mapi_vcap_dump_attr *vcapDumpAttr)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcapDumpAttr);
    CHECK_MAPI_VCAP_MAX_VAL_RET("pixFmt", vcapDumpAttr->pixFmt, HI_MAPI_PIXEL_FORMAT_BUTT);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;

    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "dot not permit,you must set Vcap Attrs and start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    if (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_attr.wdr_mode == HI_MAPI_VCAP_WDR_MODE_NONE) {
        ret = MAPI_VCAP_SetDumpRawAttr(vcap_pipe_hdl, vcapDumpAttr);
        CHECK_MAPI_VCAP_RET(ret, "set DumpRawAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
    } else {
        if (vcap_pipe_hdl != g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].pipe_id_bind[0]) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "The pipe is not the master pipe, vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
            return TD_SUCCESS;
        }

        ret = MAPI_VCAP_SetWdrDumpRawAttr(vcap_pipe_hdl, vcapDumpAttr);
        CHECK_MAPI_VCAP_RET(ret, "set WdrDumpRawAttr fail,vcap_pipe_hdl[%d]\n", vcap_pipe_hdl);
    }

    return TD_SUCCESS;
}

td_s32 HI_MAPI_VCAP_GetDumpRawAttr(td_handle vcap_pipe_hdl, hi_mapi_vcap_dump_attr *vcapDumpAttr)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_NULL_PTR_RET(vcapDumpAttr);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    hi_mapi_vcap_dump_attr *dumpNormRawAttr =
        &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].dumpRawInfo[MAPI_VCAP_NORMAL_RAW_INFO_ID].vcapDumpAttr;
    ret = memcpy_s(&vcapDumpAttr->dumpAttr, sizeof(vcapDumpAttr->dumpAttr),
        &dumpNormRawAttr->dumpAttr, sizeof(HI_MAPI_DumpAttr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    hi_mapi_vcap_dump_attr *dumpBnrRawAttr =
        &g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].dumpRawInfo[MAPI_VCAP_BNR_RAW_INFO_ID].vcapDumpAttr;
    ret = memcpy_s(&vcapDumpAttr->dumpBnrAttr, sizeof(vcapDumpAttr->dumpBnrAttr),
        &dumpBnrRawAttr->dumpBnrAttr, sizeof(HI_MAPI_BnrDumpAttr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_VCAP, "memcpy_s", ret);

    vcapDumpAttr->pixFmt = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].dumpPixFmt;

    return TD_SUCCESS;
}

td_s32 HI_MAPI_VCAP_StartDumpRaw(td_handle vcap_pipe_hdl, td_u32 count,
    const hi_mapi_vcap_raw_data_proc_cb_info *procRawDataInfo)
{
    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_MAX_VAL_RET("count", count, HI_MAPI_VCAP_RAWGROUP_MAX_NUM);
    CHECK_MAPI_VCAP_MIN_VAL_RET("count", count, 1);
    CHECK_MAPI_VCAP_NULL_PTR_RET(procRawDataInfo);
    CHECK_MAPI_VCAP_NULL_PTR_RET(procRawDataInfo->procRawDataCBFunc);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "dot not permit,you must set Vcap Attrs and start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    td_s32 ret = MAPI_VCAP_StartDump(vcap_pipe_hdl, count, procRawDataInfo, TD_FALSE);
    CHECK_MAPI_VCAP_RET(ret, "start dump raw fail,normal raw\n");

    return TD_SUCCESS;
}

td_s32 HI_MAPI_VCAP_StopDumpRaw(td_handle vcap_pipe_hdl)
{
    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_s32 ret = MAPI_VCAP_StopDump(vcap_pipe_hdl, TD_FALSE);
    CHECK_MAPI_VCAP_RET(ret, "stop dump raw fail,normal raw\n");

    return TD_SUCCESS;
}

td_s32 HI_MAPI_VCAP_StartDumpBnrRaw(td_handle vcap_pipe_hdl, td_u32 count,
    const hi_mapi_vcap_raw_data_proc_cb_info *procRawDataInfo)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_MAX_VAL_RET("count", count, HI_MAPI_VCAP_RAWGROUP_MAX_NUM);
    CHECK_MAPI_VCAP_MIN_VAL_RET("count", count, 1);
    CHECK_MAPI_VCAP_NULL_PTR_RET(procRawDataInfo);
    CHECK_MAPI_VCAP_NULL_PTR_RET(procRawDataInfo->procRawDataCBFunc);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    td_handle vcap_dev_hdl = g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].bind_dev_hdl;
    if ((vcap_dev_hdl > (HI_MAPI_VCAP_MAX_DEV_NUM - 1)) ||
        (g_vcap_glob_attr.glob_dev_attr[vcap_dev_hdl].dev_status != VCAP_STATUS_RUNNING)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP,
            "dot not permit,you must set Vcap Attrs and start dev[%d] first\n", vcap_dev_hdl);
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = MAPI_VCAP_StartDump(vcap_pipe_hdl, count, procRawDataInfo, TD_TRUE);
    CHECK_MAPI_VCAP_RET(ret, "start bnr dump raw fail,bnr raw\n");

    return TD_SUCCESS;
}

td_s32 HI_MAPI_VCAP_StopDumpBnrRaw(td_handle vcap_pipe_hdl)
{
    td_s32 ret;

    CHECK_MAPI_VCAP_HANDLE_RET("vcap_pipe_hdl", vcap_pipe_hdl, (HI_MAPI_VCAP_MAX_PIPE_NUM - 1));
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.vcap_inited, "media has not been inited", HI_MAPI_VCAP_ENOT_INITED);
    CHECK_MAPI_VCAP_TRUE_RET(g_vcap_glob_attr.glob_pipe_attr[vcap_pipe_hdl].is_pipe_create,
        "please start vcap device first", HI_MAPI_VCAP_ENOT_PERM);

    ret = MAPI_VCAP_StopDump(vcap_pipe_hdl, TD_TRUE);
    CHECK_MAPI_VCAP_RET(ret, "stop dump bnr raw fail,bnr raw\n");

    return TD_SUCCESS;
}
#endif  /* RAW dump public APIs */

#if 0
td_s32 hi_mapi_vcap_set_sensor_lib_path(const td_char *lib_path)
{
    CHECK_MAPI_VCAP_NULL_PTR_RET(lib_path);
    if (strlen(lib_path) == 0 || strlen(lib_path) >= PATH_MAX) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "[%s][%d] lib_path error\n", __FUNCTION__, __LINE__);
        return HI_MAPI_VCAP_EILLEGAL_PARA;
    }

    if (g_vcap_glob_attr.vcap_inited == TD_TRUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_SYS, "media has already been inited\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    /* sensor lib path is no longer maintained; sensor attr is now passed
     * directly via hi_mapi_vcap_init_sensor() (demand 1). */
    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_get_sensor_count(td_u32 *sensor_cnt)
{
    CHECK_MAPI_VCAP_NULL_PTR_RET(sensor_cnt);
    /* sensor list management removed (demand 1); always 0 */
    *sensor_cnt = 0;
    return TD_SUCCESS;
}

td_s32 hi_mapi_vcap_get_sensor(hi_mapi_vcap_sensor_describe_info *info_array, td_u32 sensor_cnt)
{
    CHECK_MAPI_VCAP_NULL_PTR_RET(info_array);
    (void)sensor_cnt;
    /* sensor list management removed (demand 1) */
    return HI_MAPI_VCAP_ENOTSUPPORT;
}
#endif
