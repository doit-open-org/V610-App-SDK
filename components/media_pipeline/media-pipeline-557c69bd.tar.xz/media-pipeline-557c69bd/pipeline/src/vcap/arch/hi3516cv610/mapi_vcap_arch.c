/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <sys/prctl.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "mapi_comm_inner.h"
#include "hi_mw_log.h"
#include "ot_common_vi.h"
#include "ot_mipi_rx.h"
#include "mapi_vcap_inner.h"
#include "mapi_vcap_adapt.h"
#include "securec.h"
#include "mapi_vcap_arch.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 hal_mapi_vcap_enable_mipi_clock(td_s32 mipi_fd, const combo_dev_attr_t *combo_dev_attr)
{
    td_s32 ret;
    CHECK_MAPI_VCAP_NULL_PTR_RET(combo_dev_attr);

    if (combo_dev_attr->input_mode != INPUT_MODE_MIPI) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "only support INPUT_MODE_MIPI\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = ioctl(mipi_fd, OT_MIPI_ENABLE_MIPI_CLOCK, &combo_dev_attr->devno);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "enable mipi failed\n");
        return ret;
    }

    ret = ioctl(mipi_fd, OT_MIPI_RESET_MIPI, &combo_dev_attr->devno);
    if (ret != TD_SUCCESS) {
        (td_void)ioctl(mipi_fd, OT_MIPI_DISABLE_MIPI_CLOCK, &combo_dev_attr->devno);
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "reset mipi failed\n");
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 hal_mapi_vcap_disable_mipi_clock(td_handle vcap_dev_hdl, td_s32 mipi_fd, input_mode_t input_mode)
{
    td_s32 ret;
    td_handle dev_no = vcap_dev_hdl;

    if (input_mode != INPUT_MODE_MIPI) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "only support INPUT_MODE_MIPI\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = ioctl(mipi_fd, OT_MIPI_RESET_MIPI, &dev_no);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "reset mipi failed\n");
        return ret;
    }

    ret = ioctl(mipi_fd, OT_MIPI_DISABLE_MIPI_CLOCK, &dev_no);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "disable mipi clock failed\n");
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 hal_mapi_vcap_reset_mipi_clock(td_s32 mipi_fd, const combo_dev_attr_t *combo_dev_attr)
{
    td_s32 ret;
    CHECK_MAPI_VCAP_NULL_PTR_RET(combo_dev_attr);

    if (combo_dev_attr->input_mode != INPUT_MODE_MIPI) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "only support INPUT_MODE_MIPI\n");
        return HI_MAPI_VCAP_ENOT_PERM;
    }

    ret = ioctl(mipi_fd, OT_MIPI_UNRESET_MIPI, &combo_dev_attr->devno);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "unreset mipi failed\n");
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 hal_mapi_vcap_load_mipi_config(combo_dev_attr_t *combo_dev_attr,
    const hi_mapi_vcap_sensor_attr *sensor_attr)
{
    td_s32 i;

    CHECK_MAPI_VCAP_NULL_PTR_RET(combo_dev_attr);
    CHECK_MAPI_VCAP_NULL_PTR_RET(sensor_attr);
    /*
     * After sensor refactor (demand 1): combo_dev_attr (mipi_attr/lvds_attr) is supplied directly
     * by the user via hi_mapi_vcap_sensor_attr. Here we only patch the per-platform lane_id and
     * input_data_type into combo_dev_attr.
     */
    switch (sensor_attr->input_dev_attr.input_mode) {
        case INPUT_MODE_LVDS:
            for (i = 0; i < LVDS_LANE_NUM; i++) {
                combo_dev_attr->lvds_attr.lane_id[i] = sensor_attr->sns_dev_attr.lane_id[i];
            }
            combo_dev_attr->lvds_attr.input_data_type = sensor_attr->input_dev_attr.input_data_type;
            break;
        case INPUT_MODE_MIPI:
            for (i = 0; i < MIPI_LANE_NUM; i++) {
                combo_dev_attr->mipi_attr.lane_id[i] = sensor_attr->sns_dev_attr.lane_id[i];
            }
            combo_dev_attr->mipi_attr.input_data_type = sensor_attr->input_dev_attr.input_data_type;
            break;
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_VCAP, "sensor input mode:%d not support\n",
                sensor_attr->input_dev_attr.input_mode);
            return HI_MAPI_VCAP_ENOTSUPPORT;
    }

    return TD_SUCCESS;
}

hi_mapi_compress_mode hal_mapi_vcap_get_default_pipe_compress_mode(td_void)
{
    return HI_MAPI_COMPRESS_MODE_LINE;
}

hi_mapi_compress_mode hal_mapi_vcap_get_default_chn_compress_mode(td_void)
{
    return HI_MAPI_COMPRESS_MODE_NONE;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
