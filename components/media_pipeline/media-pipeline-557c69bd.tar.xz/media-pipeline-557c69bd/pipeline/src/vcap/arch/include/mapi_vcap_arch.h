/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_VCAP_ARCH_H__
#define __MAPI_VCAP_ARCH_H__

#include "mapi_vcap_inner.h"
#include "hi_mapi_vcap_define.h"
#include "mapi_vcap_adapt.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 hal_mapi_vcap_enable_mipi_clock(td_s32 mipi_fd, const combo_dev_attr_t *combo_dev_attr);

td_s32 hal_mapi_vcap_reset_mipi_clock(td_s32 mipi_fd, const combo_dev_attr_t *combo_dev_attr);

td_s32 hal_mapi_vcap_disable_mipi_clock(td_handle vcap_dev_hdl, td_s32 mipi_fd, input_mode_t input_mode);

td_s32 hal_mapi_vcap_load_mipi_config(combo_dev_attr_t *combo_dev_attr,
    const hi_mapi_vcap_sensor_attr *sensor_attr);

hi_mapi_compress_mode hal_mapi_vcap_get_default_pipe_compress_mode(td_void);

hi_mapi_compress_mode hal_mapi_vcap_get_default_chn_compress_mode(td_void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_VCAP_ARCH_H__ */
