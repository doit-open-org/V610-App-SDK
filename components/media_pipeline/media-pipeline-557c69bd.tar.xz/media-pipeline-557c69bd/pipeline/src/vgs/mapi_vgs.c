/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "hi_mapi_vgs.h"
#include "mapi_comm_inner.h"
#include "mapi_vgs_adapt.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

static td_handle g_rgn_hdl[HI_MAPI_VGS_TASK_MAX_CNT] = {
    [0 ... (HI_MAPI_VGS_TASK_MAX_CNT - 1)] = OT_INVALID_HANDLE
};

td_s32 hi_mapi_vgs_begin_job(td_handle *vgs_hdl)
{
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, vgs_hdl, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    td_s32 ret = mapi_adapt_vgs_begin_job(vgs_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_begin_job", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vgs_add_scale_task(td_handle vgs_hdl, const hi_mapi_vgs_scale_task_attr *scale_task_attr)
{
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, scale_task_attr, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, vgs_hdl != (td_u32)OT_INVALID_HANDLE, HI_MAPI_VGS_EHANDLE_ILLEGAL);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    td_s32 ret = mapi_adapt_vgs_add_scale_task(vgs_hdl, scale_task_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_add_scale_task", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vgs_add_draw_line_task(td_handle vgs_hdl, const hi_mapi_vgs_draw_line_task_attr *draw_line_task_attr)
{
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, draw_line_task_attr, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, draw_line_task_attr->vgs_draw_line, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, vgs_hdl != (td_u32)OT_INVALID_HANDLE, HI_MAPI_VGS_EHANDLE_ILLEGAL);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, draw_line_task_attr->num <= HI_MAPI_VGS_TASK_MAX_CNT, HI_MAPI_VGS_EILLEGAL_PARAM);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, draw_line_task_attr->num > 0, HI_MAPI_VGS_EILLEGAL_PARAM);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    td_s32 ret = mapi_adapt_vgs_add_draw_line_task(vgs_hdl, draw_line_task_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_add_draw_line_task", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vgs_add_cover_task(td_handle vgs_hdl, const hi_mapi_vgs_cover_task_attr *cover_task_attr)
{
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, cover_task_attr, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, cover_task_attr->vgs_add_cover, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, vgs_hdl != (td_u32)OT_INVALID_HANDLE, HI_MAPI_VGS_EHANDLE_ILLEGAL);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, cover_task_attr->num <= HI_MAPI_VGS_TASK_MAX_CNT, HI_MAPI_VGS_EILLEGAL_PARAM);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, cover_task_attr->num > 0, HI_MAPI_VGS_EILLEGAL_PARAM);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    td_s32 ret = mapi_adapt_vgs_add_cover_task(vgs_hdl, cover_task_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_add_cover_task", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vgs_create_rgn(const hi_mapi_vgs_rgn_task_attr *rgn_task_attr)
{
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, rgn_task_attr, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, rgn_task_attr->num <= HI_MAPI_VGS_TASK_MAX_CNT, HI_MAPI_VGS_EILLEGAL_PARAM);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, rgn_task_attr->num > 0, HI_MAPI_VGS_EILLEGAL_PARAM);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    td_u32 i;
    for (i = 0; i < rgn_task_attr->num; i++) {
        td_s32 ret = mapi_adapt_vgs_create_rgn(i + HI_MAPI_OSD_MAX_CNT, &rgn_task_attr->rgn_attr[i]);
        if (ret != TD_SUCCESS) {
            (td_void)hi_mapi_vgs_destroy_rgn();
            MAPI_ERR_TRACE(HI_MAPI_MOD_VGS, "create rgn fail and return:[%#x]!!\n", ret);
            return ret;
        }

        g_rgn_hdl[i] = i + HI_MAPI_OSD_MAX_CNT;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vgs_destroy_rgn(td_void)
{
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    td_u32 i;
    td_s32 ret = TD_SUCCESS;
    for (i = 0; i < HI_MAPI_VGS_TASK_MAX_CNT; i++) {
        if (g_rgn_hdl[i] == (td_u32)OT_INVALID_HANDLE) {
            continue;
        }

        td_s32 destroy_ret = mapi_adapt_vgs_destroy_rgn(g_rgn_hdl[i]);
        if (destroy_ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VGS, "destroy rgn fail and return:[%#x]!!\n", destroy_ret);
            ret = destroy_ret; /* record the error code and continue to destroy the remaining rgn. */
        }

        g_rgn_hdl[i] = OT_INVALID_HANDLE;
    }

    if (i == 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VGS, "No region to be destroyed!!\n");
    }

    return ret;
}

td_s32 hi_mapi_vgs_add_osd_task(td_handle vgs_hdl, const hi_mapi_vgs_osd_task_attr *osd_task_attr)
{
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, osd_task_attr, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VGS, osd_task_attr->vgs_add_osd, HI_MAPI_VGS_ENULL_PTR);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, vgs_hdl != (td_u32)OT_INVALID_HANDLE, HI_MAPI_VGS_EHANDLE_ILLEGAL);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, osd_task_attr->num <= HI_MAPI_VGS_TASK_MAX_CNT, HI_MAPI_VGS_EILLEGAL_PARAM);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, osd_task_attr->num > 0, HI_MAPI_VGS_EILLEGAL_PARAM);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    const mapi_comm_font_mod_attr *font_mod_attr = mapi_sys_get_font_mod_attr();
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, font_mod_attr->is_init, HI_MAPI_VGS_ENOFONT);

    td_s32 ret = mapi_adapt_vgs_add_osd_task(vgs_hdl, osd_task_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_add_osd_task", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vgs_end_job(td_handle vgs_hdl)
{
    td_s32 ret;
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, vgs_hdl != (td_u32)OT_INVALID_HANDLE, HI_MAPI_VGS_EHANDLE_ILLEGAL);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    ret = mapi_adapt_vgs_end_job(vgs_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_end_job", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vgs_cancel_job(td_handle vgs_hdl)
{
    td_s32 ret;
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VGS, vgs_hdl != (td_u32)OT_INVALID_HANDLE, HI_MAPI_VGS_EHANDLE_ILLEGAL);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VGS_ENOINITED);

    ret = mapi_adapt_vgs_cancel_job(vgs_hdl);
    CHECK_MAPI_RET(HI_MAPI_MOD_VGS, "mapi_adapt_vgs_cancel_job", ret);

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
