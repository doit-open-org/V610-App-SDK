/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_AENC_OS_H__
#define __MAPI_AENC_OS_H__

#include "mapi_aenc_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_void mapi_aenc_os_init(td_void);
td_void mapi_aenc_os_deinit(td_void);
td_bool mapi_aenc_is_register_callback(td_handle aenc_hdl, const mapi_aenc_chn_config *aenc_chn_cfg);
td_s32  mapi_aenc_get_a_stream(td_handle aenc_hdl, const mapi_aenc_chn_config *aenc_chn_cfg);
td_void mapi_aenc_clear_datafifo(td_handle aenc_hdl);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_AENC_OS_H__ */
