/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_aenc_inner.h"
#include "mapi_comm_inner.h"
#include "audio_comp/audio_comp_aenc.h"
#include "mapi_aenc_os.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_void mapi_aenc_os_init(td_void)
{
}

td_void mapi_aenc_os_deinit(td_void)
{
}

td_void mapi_aenc_clear_datafifo(td_handle aenc_hdl)
{
    MAPI_UNUSED(aenc_hdl);
}

td_bool mapi_aenc_is_register_callback(td_handle aenc_hdl, const mapi_aenc_chn_config *aenc_chn_cfg)
{
    td_u32 i;

    if (aenc_chn_cfg == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "input is null\n");
        return TD_FALSE;
    }

    for (i = 0; i < HI_MAPI_AENC_CHN_CALLBACK_MAX_NUM; i++) {
        if (aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb != TD_NULL) {
            return TD_TRUE;
        }
    }
    return TD_FALSE;
}

static td_s32 mapi_aenc_proc_a_stream(td_handle aenc_hdl, hi_mapi_audio_stream *aenc_stream,
    const mapi_aenc_chn_config *aenc_chn_cfg)
{
    td_s32 ret;
    td_u32 i;

    for (i = 0; i < HI_MAPI_AENC_CHN_CALLBACK_MAX_NUM; i++) {
        if (aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb != TD_NULL) {
            ret = aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb(aenc_hdl, aenc_stream,
                aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].private_data);
            if (ret != TD_SUCCESS) {
                MAPI_INFO_TRACE(HI_MAPI_MOD_AENC, "aenc_reg_callbacks[%d].proc_data_cb fail, ret:%x\n", i, ret);
            }
        }
    }

    return TD_SUCCESS;
}

td_s32 mapi_aenc_get_a_stream(td_handle aenc_hdl, const mapi_aenc_chn_config *aenc_chn_cfg)
{
    td_s32 ret;
    hi_mapi_audio_stream aenc_stream;

    if (aenc_chn_cfg == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "input is null\n");
        return TD_FAILURE;
    }

    /* Apply per-channel payload_format on the business callback path:
     * STANDARD strips the OPUS 8-byte header before the callback sees the
     * stream; release_stream restores the SDK pointer. */
    hi_mapi_audio_payload_format payload_format = aenc_chn_cfg[aenc_hdl].payload_format;

    ret = audio_comp_aenc_get_stream(aenc_hdl, &aenc_stream, payload_format);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "audio_comp_aenc_get_stream err,ret:%x\n", ret);
        return ret;
    }

    ret = mapi_aenc_proc_a_stream(aenc_hdl, &aenc_stream, aenc_chn_cfg);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "mapi_aenc_proc_a_stream err,ret:%x\n", ret);
    }

    ret = audio_comp_aenc_release_stream(aenc_hdl, &aenc_stream, payload_format);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "audio_comp_aenc_release_stream err,ret:%x\n", ret);
    }

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
