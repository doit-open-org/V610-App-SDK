/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <pthread.h>
#include "hi_mapi_aenc.h"
#include "mapi_aenc_inner.h"
#ifdef ENABLE_MP3
#include "adpt_aenc_mp3.h"
#endif
#include "mapi_comm_inner.h"
#include "mapi_aenc_os.h"
#include "audio_comp/audio_comp_aenc.h"
#include <sys/select.h>

/* OPUS 16kHz sampling rate, 20ms frame = 320 samples */
#define OPUS_FRAME_SAMPLES_20MS 320
#include "hi_mapi_aenc_adpt.h"
#include "ss_audio_opus_adp.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static mapi_aenc_server_context g_aenc_context;
static td_s32 g_encoder_hdl[HI_MAPI_AUDIO_FORMAT_BUTT] = {OT_INVALID_HANDLE};
static pthread_mutex_t g_aenc_func_lock[HI_MAPI_AENC_CHN_MAX_NUM] = {
    [0 ... (HI_MAPI_AENC_CHN_MAX_NUM - 1)] = PTHREAD_MUTEX_INITIALIZER
};

/* Global encoder lock protects g_encoder_hdl[] and g_aenc_fmt_ref_cnt[], and
 * serializes cross-channel register/unregister. Lock order is channel lock -> encoder lock. */
static pthread_mutex_t g_aenc_encoder_lock = PTHREAD_MUTEX_INITIALIZER;
/* Per-format refcount: 0->1 registers, 1->0 unregisters. */
static td_u32 g_aenc_fmt_ref_cnt[HI_MAPI_AUDIO_FORMAT_BUTT] = {0};

static td_s32 mapi_aenc_register_audio_encoder(hi_mapi_audio_format audio_format);
static td_s32 mapi_aenc_unregister_audio_encoder(hi_mapi_audio_format audio_format);

static td_void mapi_aenc_get_a_data(td_handle aenc_hdl)
{
    td_s32 ret;

    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "data process\n");
    ret = mapi_aenc_get_a_stream(aenc_hdl, g_aenc_context.aenc_chn_cfg);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "mapi get data fail, ret:%x\n", ret);
    }
}

static td_s32 mapi_aenc_clear_stream_buf(td_handle aenc_hdl)
{
    td_s32 ret;
    hi_mapi_audio_stream aenc_stream;

    /* Drain path: stream is discarded immediately, no payload conversion needed. */
    while (g_aenc_context.aenc_chn_cfg[aenc_hdl].is_clear_buf) {
        ret = audio_comp_aenc_get_stream(aenc_hdl, &aenc_stream, HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE);
        if (ret == HI_MAPI_AENC_BUF_EMPTY) {
            break;
        }
        CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "get astream", ret);

        ret = audio_comp_aenc_release_stream(aenc_hdl, &aenc_stream, HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE);
        CHECK_MAPI_RET(HI_MAPI_MOD_AENC, "release astream", ret);
    }
    return TD_SUCCESS;
}

static td_void mapi_aenc_config_time_out(struct timeval *time_out_val)
{
    time_out_val->tv_sec = 0;
    time_out_val->tv_usec = AENCODE_GET_FRAME_THREAD_SLEECT_TIMEOUT_USEC;
}

static td_void mapi_aenc_pthread_cond_time_wait(td_handle chn_hdl)
{
    mapi_comm_cond_time_wait(&g_aenc_context.proc_a_data_thread[chn_hdl].proc_a_data_thd_cond,
        &g_aenc_context.proc_a_data_thread[chn_hdl].proc_a_data_thd_lock, AENCODE_GET_FRAME_THREAD_USLEEP_TIME);
}

static td_void *proc_a_stream_thread(td_void *arg)
{
    td_handle chn_hdl = *(td_handle *)arg;

    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)"proc_a_stream_thread", 0, 0, 0);
    MAPI_MUTEX_LOCK(g_aenc_context.proc_a_data_thread[chn_hdl].proc_a_data_thd_lock);
    while (g_aenc_context.proc_a_data_thread[chn_hdl].proc_a_data_thd_start_flg == TD_TRUE) {
        MAPI_MUTEX_LOCK(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_lock);
        /* chn not started, time wait for low power consumption */
        if (g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_state != MAPI_AENC_CHN_STARTED) {
            if (g_aenc_context.aenc_chn_cfg[chn_hdl].is_clear_buf) {
                td_s32 ret = mapi_aenc_clear_stream_buf(chn_hdl);
                CHECK_MAPI_PRINT(HI_MAPI_MOD_AENC, "mapi_aenc_clear_stream_buf", ret);

                g_aenc_context.aenc_chn_cfg[chn_hdl].is_clear_buf = TD_FALSE;
                MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_lock);
            } else {
                MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_lock);
                mapi_aenc_pthread_cond_time_wait(chn_hdl);
            }
            continue;
        }

        /* chn started */
        fd_set read_fds;
        FD_ZERO(&read_fds);
        td_s32 aenc_chn_fd = audio_comp_aenc_get_fd(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_hdl);
        FD_SET(aenc_chn_fd, &read_fds);
        MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_lock);
        struct timeval time_out_val;
        mapi_aenc_config_time_out(&time_out_val);

        td_s32 sel_ret = select(aenc_chn_fd + 1, &read_fds, NULL, NULL, &time_out_val);
        MAPI_MUTEX_LOCK(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_lock);
        if (sel_ret < 0) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "select error, ret:%x\n", sel_ret);
        } else if (sel_ret == 0) {
            mapi_aenc_clear_datafifo(chn_hdl);
            MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_lock);
            mapi_aenc_pthread_cond_time_wait(chn_hdl);
            continue;
        } else {
            if (mapi_aenc_is_register_callback(chn_hdl, g_aenc_context.aenc_chn_cfg) == TD_FALSE) {
                MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_lock);
                mapi_aenc_pthread_cond_time_wait(chn_hdl);
                continue;
            }

            if (g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_state == MAPI_AENC_CHN_STARTED) {
                mapi_aenc_get_a_data(chn_hdl);
            }
        }
        MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[chn_hdl].aenc_chn_lock);
    }
    MAPI_MUTEX_UNLOCK(g_aenc_context.proc_a_data_thread[chn_hdl].proc_a_data_thd_lock);

    return TD_NULL;
}

td_s32 mapi_aenc_init(td_void)
{
    td_u32 i;
    td_s32 ret;

    if (g_aenc_context.aenc_inited == TD_TRUE) {
        return TD_SUCCESS;
    }

    ret = memset_s(&g_aenc_context, sizeof(mapi_aenc_server_context), 0, sizeof(mapi_aenc_server_context));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_AENC, "memset_s", ret);

    mapi_aenc_os_init();

    for (i = 0; i < HI_MAPI_AENC_CHN_MAX_NUM; i++) {
        g_aenc_context.aenc_chn_cfg[i].is_clear_buf = TD_FALSE;
        g_aenc_context.aenc_chn_cfg[i].aenc_chn_state = MAPI_AENC_CHN_UNINITED;
        g_aenc_context.aenc_chn_cfg[i].aenc_chn_hdl = i;
    }

    for (i = 0; i < HI_MAPI_AUDIO_FORMAT_BUTT; i++) {
        g_encoder_hdl[i] = OT_INVALID_HANDLE;
    }
    MAPI_MUTEX_LOCK(g_aenc_encoder_lock);
    (td_void)memset_s(g_aenc_fmt_ref_cnt, sizeof(g_aenc_fmt_ref_cnt), 0, sizeof(g_aenc_fmt_ref_cnt));
    MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
    g_aenc_context.aenc_inited = TD_TRUE;

    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "mapi_aenc_init!\n");
    return TD_SUCCESS;
}

td_s32 mapi_aenc_deinit(td_void)
{
    td_u32 i;
    td_s32 ret;

    if (g_aenc_context.aenc_inited != TD_TRUE) {
        return TD_SUCCESS;
    }
    for (i = 0; i < HI_MAPI_AENC_CHN_MAX_NUM; i++) {
        if (g_aenc_context.aenc_chn_cfg[i].aenc_chn_state != MAPI_AENC_CHN_UNINITED) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC %d is not deinit, try deinit it now\n", i);
            ret = hi_mapi_aenc_deinit(i);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc deinit handle:%d failed! ret:%x\n", i, ret);
            }
        }
    }

    mapi_aenc_os_deinit();
    for (i = 0; i < HI_MAPI_AENC_CHN_MAX_NUM; i++) {
        ret = memset_s(&g_aenc_context.aenc_chn_cfg[i], sizeof(mapi_aenc_chn_config), 0,
                       sizeof(mapi_aenc_chn_config));
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_AENC, "memset_s", ret);
        g_aenc_context.aenc_chn_cfg[i].is_clear_buf = TD_FALSE;
        g_aenc_context.aenc_chn_cfg[i].aenc_chn_state = MAPI_AENC_CHN_BUTT;
    }

    for (i = 0; i < HI_MAPI_AUDIO_FORMAT_BUTT; i++) {
        g_encoder_hdl[i] = OT_INVALID_HANDLE;
    }
    MAPI_MUTEX_LOCK(g_aenc_encoder_lock);
    (td_void)memset_s(g_aenc_fmt_ref_cnt, sizeof(g_aenc_fmt_ref_cnt), 0, sizeof(g_aenc_fmt_ref_cnt));
    MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
    g_aenc_context.aenc_inited = TD_FALSE;

    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "mapi_aenc_deinit!\n");
    return TD_SUCCESS;
}

static td_s32 mapi_aenc_init_data_thread(td_handle aenc_hdl)
{
    MAPI_MUTEX_INIT_LOCK(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);
    pthread_condattr_t cond_attr;
    (td_void)pthread_condattr_init(&cond_attr);
    (td_void)pthread_condattr_setclock(&cond_attr, CLOCK_MONOTONIC);
    (td_void)pthread_cond_init(&g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_cond, &cond_attr);
    (td_void)pthread_condattr_destroy(&cond_attr);

    g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thread = (pthread_t)-1;

    MAPI_MUTEX_LOCK(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);
    g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_start_flg = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);

    td_s32 ret = pthread_create(&g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thread, TD_NULL,
        proc_a_stream_thread, &g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "pthread_create proc_a_stream_thread ret:%x\n", ret);

        MAPI_MUTEX_LOCK(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);
        g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_start_flg = TD_FALSE;
        MAPI_MUTEX_UNLOCK(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);

        MAPI_MUTEX_DESTROY(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);
        pthread_cond_destroy(&g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_cond);
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return ret;
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_aenc_init(td_handle aenc_hdl, const hi_mapi_aenc_attr *aenc_attr)
{
    td_s32 i;

    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);
    CHECK_MAPI_AENC_NULL_PTR_RET(aenc_attr);

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (!g_aenc_context.aenc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc is started, no need init aenc repeatedly!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return TD_SUCCESS;
    }
    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_STOPED &&
        aenc_attr->aenc_format == g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.aenc_format &&
        aenc_attr->pt_num_per_frm == g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.pt_num_per_frm) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_AENC, "aenc init attr is not change, return successful\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return TD_SUCCESS;
    }

    /* Release the old format reference before re-init changes format. */
    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_STOPED &&
        aenc_attr->aenc_format != g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.aenc_format) {
        (td_void)mapi_aenc_unregister_audio_encoder(
            g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.aenc_format);
    }

    /* register audio encoder internally before creating channel */
    td_s32 ret = mapi_aenc_register_audio_encoder(aenc_attr->aenc_format);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AENC, "mapi_aenc_register_audio_encoder", ret, g_aenc_func_lock[aenc_hdl]);

    ret = audio_comp_aenc_create_chn(aenc_hdl, aenc_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "audio_comp_aenc_create_chn fail, ret:%x\n", ret);
        (td_void)mapi_aenc_unregister_audio_encoder(aenc_attr->aenc_format);
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return ret;
    }

    ret = mapi_aenc_init_data_thread(aenc_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "mapi_aenc_init_data_thread fail, ret:%x\n", ret);
        (td_void)audio_comp_aenc_destroy_chn(aenc_hdl);
        (td_void)mapi_aenc_unregister_audio_encoder(aenc_attr->aenc_format);
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    MAPI_MUTEX_INIT_LOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);
    g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.aenc_format = aenc_attr->aenc_format;
    g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.pt_num_per_frm = aenc_attr->pt_num_per_frm;
    g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.value_len = aenc_attr->value_len;
    g_aenc_context.aenc_chn_cfg[aenc_hdl].payload_format = HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE;
    for (i = 0; i < HI_MAPI_AENC_CHN_CALLBACK_MAX_NUM; i++) {
        g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb = TD_NULL;
        g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].private_data = TD_NULL;
    }

    g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state = MAPI_AENC_CHN_STOPED;
    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "hi_mapi_aenc_init [%d]\n", aenc_hdl);
    return TD_SUCCESS;
}

td_s32 hi_mapi_aenc_deinit(td_handle aenc_hdl)
{
    td_s32 ret;

    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);
    CHECK_MAPI_AENC_CHECK_INIT_RET(g_aenc_context.aenc_inited);

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc is started, can not be deinit! try stop now\n");
        ret = hi_mapi_aenc_stop(aenc_hdl);
        CHECK_MAPI_PRINT(HI_MAPI_MOD_AENC, "hi_mapi_aenc_stop", ret);
    }

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_UNINITED) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_AENC, "aenc has already deinited, return successfull!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return TD_SUCCESS;
    }

    mapi_aenc_clear_datafifo(aenc_hdl);

    MAPI_MUTEX_LOCK(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);
    ret = audio_comp_aenc_destroy_chn(aenc_hdl);
    CHECK_MAPI_PRINT(HI_MAPI_MOD_AENC, "audio_comp_aenc_destroy_chn", ret);

    g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_start_flg = TD_FALSE;
    pthread_cond_signal(&g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_cond);
    MAPI_MUTEX_UNLOCK(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);

    if (g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thread != (pthread_t)-1) {
        ret = pthread_join(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thread, TD_NULL);
        CHECK_MAPI_PRINT(HI_MAPI_MOD_AENC, "pthread_join", ret);
    }

    MAPI_MUTEX_DESTROY(g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_lock);
    pthread_cond_destroy(&g_aenc_context.proc_a_data_thread[aenc_hdl].proc_a_data_thd_cond);

    MAPI_MUTEX_DESTROY(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);

    /* Unregister shared encoder only when the global refcount reaches zero. */
    (td_void)mapi_aenc_unregister_audio_encoder(
        g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.aenc_format);

    (td_void)memset_s(&g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr, sizeof(hi_mapi_aenc_attr), 0x0,
        sizeof(hi_mapi_aenc_attr));
    for (td_s32 i = 0; i < HI_MAPI_AENC_CHN_CALLBACK_MAX_NUM; i++) {
        g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb = TD_NULL;
        g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].private_data = TD_NULL;
    }

    g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state = MAPI_AENC_CHN_UNINITED;
    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "hi_mapi_aenc_deinit [%d]\n", aenc_hdl);
    return TD_SUCCESS;
}

td_s32 hi_mapi_aenc_start(td_handle aenc_hdl)
{
    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (!g_aenc_context.aenc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc is deinited, can not be start!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ESTATEERR;
    }

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_STARTED) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_AENC, "aenc has already started, return successfull!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return TD_SUCCESS;
    }

    MAPI_MUTEX_LOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);
    g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state = MAPI_AENC_CHN_STARTED;
    MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "hi_mapi_aenc_start [%d]\n", aenc_hdl);
    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
    return TD_SUCCESS;
}

td_s32 hi_mapi_aenc_stop(td_handle aenc_hdl)
{
    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (!g_aenc_context.aenc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc is deinited, can not be stop!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ESTATEERR;
    }

    hi_mapi_mpp_chn aenc_dst = { .mod_id = HI_MAPI_MOD_AENC, .dev_id = 0, .chn_id = (td_s32)aenc_hdl };
    hi_mapi_mpp_chn aenc_src = {0};
    if (mapi_sys_bind_get_src_by_dst(&aenc_dst, &aenc_src) == TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc is binded acap, can not be stop! try to unbind now!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_EBUSY;
    }

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_STOPED) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_AENC, "aenc has already inited with stoped, return successfull!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return TD_SUCCESS;
    }

    MAPI_MUTEX_LOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);
    g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state = MAPI_AENC_CHN_STOPED;
    MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);
    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
    MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "hi_mapi_aenc_stop [%d]\n", aenc_hdl);
    return TD_SUCCESS;
}

td_s32 hi_mapi_aenc_register_callback(td_handle aenc_hdl, const hi_mapi_aenc_callback *aenc_cb)
{
    td_u32 i;
    td_s32 null_idx = -1;

    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);
    CHECK_MAPI_AENC_NULL_PTR_RET(aenc_cb);

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (!g_aenc_context.aenc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc is deinit, can not reg callback func!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ESTATEERR;
    }

    for (i = 0; i < HI_MAPI_AENC_CHN_CALLBACK_MAX_NUM; i++) {
        if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb == TD_NULL) {
            null_idx = (td_s32)i;
        }

        if (aenc_cb->proc_data_cb == g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb &&
            aenc_cb->private_data == g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].private_data) {
            g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb = aenc_cb->proc_data_cb;
            g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].private_data = aenc_cb->private_data;
            MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "update register callback success!\n");
            MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
            return TD_SUCCESS;
        }
    }

    if (null_idx != -1) {
        g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[null_idx].proc_data_cb = aenc_cb->proc_data_cb;
        g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[null_idx].private_data = aenc_cb->private_data;
        MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "register new callback success!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return TD_SUCCESS;
    }

    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);

    return HI_MAPI_AENC_ERESFULL;
}

td_s32 hi_mapi_aenc_unregister_callback(td_handle aenc_hdl, const hi_mapi_aenc_callback *aenc_cb)
{
    td_u32 i;

    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);
    CHECK_MAPI_AENC_NULL_PTR_RET(aenc_cb);

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (!g_aenc_context.aenc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc is deinit, can not unreg callback func!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ESTATEERR;
    }

    for (i = 0; i < HI_MAPI_AENC_CHN_CALLBACK_MAX_NUM; i++) {
        if (aenc_cb->proc_data_cb == g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb &&
            aenc_cb->private_data == g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].private_data) {
            g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].proc_data_cb = TD_NULL;
            g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_reg_callbacks[i].private_data = TD_NULL;
            MAPI_DEBUG_TRACE(HI_MAPI_MOD_AENC, "hi_mapi_aenc_unregister_callback!\n");
            MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
            return TD_SUCCESS;
        }
    }

    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);

    return HI_MAPI_AENC_EUNEXIST;
}

static td_s32 mapi_aenc_register_audio_encoder(hi_mapi_audio_format audio_format)
{
    td_s32 ret;
    td_s32 *encoder_hdl = TD_NULL;
    if (audio_format == HI_MAPI_AUDIO_FORMAT_OPUS) {
#ifdef AUDIO_COMP_HAS_OPUS_SDK
        MAPI_MUTEX_LOCK(g_aenc_encoder_lock);
        if (g_aenc_fmt_ref_cnt[audio_format] == 0) {
            ret = ss_mpi_aenc_opus_init();
            if (ret != TD_SUCCESS) {
                MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
                MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "ss_mpi_aenc_opus_init fail, ret:%x\n", ret);
                return ret;
            }
        }
        g_aenc_fmt_ref_cnt[audio_format]++;
        MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
        return TD_SUCCESS;
#else
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "OPUS encoder not compiled in (AUDIO_COMP_HAS_OPUS_SDK not set)\n");
        return HI_MAPI_AENC_EILLPARAM;
#endif
    }

    switch (audio_format) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            encoder_hdl = &g_encoder_hdl[HI_MAPI_AUDIO_FORMAT_AACLC];
            break;

#ifdef ENABLE_MP3
        case HI_MAPI_AUDIO_FORMAT_MP3:
            encoder_hdl = &g_encoder_hdl[HI_MAPI_AUDIO_FORMAT_MP3];
            break;
#endif

        case HI_MAPI_AUDIO_FORMAT_G711A:
        case HI_MAPI_AUDIO_FORMAT_G711U:
        case HI_MAPI_AUDIO_FORMAT_LPCM:
            return TD_SUCCESS;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "not support format\n");
            return HI_MAPI_AENC_EILLPARAM;
    }

    /* Under global lock, only 0->1 performs real registration. */
    MAPI_MUTEX_LOCK(g_aenc_encoder_lock);
    if (g_aenc_fmt_ref_cnt[audio_format] == 0) {
        ret = audio_comp_aenc_register_audio_encoder(encoder_hdl, audio_format);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "audio_comp_aenc_register_audio_encoder fail, ret:%x\n", ret);
            MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
            return ret;
        }
    }
    g_aenc_fmt_ref_cnt[audio_format]++;
    MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);

    return TD_SUCCESS;
}

static td_s32 mapi_aenc_unregister_audio_encoder(hi_mapi_audio_format audio_format)
{
    td_s32 ret;
    td_s32 *encoder_hdl = TD_NULL;

    if (audio_format == HI_MAPI_AUDIO_FORMAT_OPUS) {
#ifdef AUDIO_COMP_HAS_OPUS_SDK
        MAPI_MUTEX_LOCK(g_aenc_encoder_lock);
        if (g_aenc_fmt_ref_cnt[audio_format] == 0) {
            MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
            return TD_SUCCESS;
        }
        if (--g_aenc_fmt_ref_cnt[audio_format] != 0) {
            MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
            return TD_SUCCESS;
        }
        ret = ss_mpi_aenc_opus_deinit();
        MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "ss_mpi_aenc_opus_deinit fail, ret:%x\n", ret);
            return ret;
        }
        return TD_SUCCESS;
#else
        return TD_SUCCESS;
#endif
    }

    switch (audio_format) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            encoder_hdl = &g_encoder_hdl[HI_MAPI_AUDIO_FORMAT_AACLC];
            break;
#ifdef ENABLE_MP3
        case HI_MAPI_AUDIO_FORMAT_MP3:
            encoder_hdl = &g_encoder_hdl[HI_MAPI_AUDIO_FORMAT_MP3];
            break;
#endif
        case HI_MAPI_AUDIO_FORMAT_G711A:
        case HI_MAPI_AUDIO_FORMAT_G711U:
        case HI_MAPI_AUDIO_FORMAT_LPCM:
            return TD_SUCCESS;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "not support format\n");
            return HI_MAPI_AENC_EILLPARAM;
    }

    /* Under global lock, only 1->0 performs real unregistration. */
    MAPI_MUTEX_LOCK(g_aenc_encoder_lock);
    if (g_aenc_fmt_ref_cnt[audio_format] == 0) {
        MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
        return TD_SUCCESS;
    }
    if (--g_aenc_fmt_ref_cnt[audio_format] != 0) {
        MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
        return TD_SUCCESS;
    }
    if (*encoder_hdl == OT_INVALID_HANDLE) {
        MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
        return TD_SUCCESS;
    }

    ret = audio_comp_aenc_unregister_audio_encoder(*encoder_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "audio_comp_aenc_unregister_audio_encoder fail, ret:%x\n", ret);
        MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
        return ret;
    }

#ifdef ENABLE_MP3
    if (audio_format == HI_MAPI_AUDIO_FORMAT_MP3) {
        ret = MP3ENC_DeinitFun();
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "MP3ENC_DeinitFun err, ret:%x\n", ret);
            *encoder_hdl = OT_INVALID_HANDLE;
            MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);
            return ret;
        }
    }
#endif

    *encoder_hdl = OT_INVALID_HANDLE;
    MAPI_MUTEX_UNLOCK(g_aenc_encoder_lock);

    return TD_SUCCESS;
}

td_s32 hi_mapi_aenc_send_frame(td_handle aenc_hdl, const hi_mapi_audio_frame *audio_frm)
{
    td_s32 ret;

    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);
    CHECK_MAPI_AENC_NULL_PTR_RET(audio_frm);

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (!g_aenc_context.aenc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc is deinit, can not send frame!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ESTATEERR;
    }

    hi_mapi_mpp_chn aenc_dst = { .mod_id = HI_MAPI_MOD_AENC, .dev_id = 0, .chn_id = (td_s32)aenc_hdl };
    hi_mapi_mpp_chn aenc_src = {0};
    if (mapi_sys_bind_get_src_by_dst(&aenc_dst, &aenc_src) == TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc have already bind, can not send frame!\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ESTATEERR;
    }

    ret = audio_comp_aenc_send_frame(aenc_hdl, audio_frm);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AENC, "audio_comp_aenc_send_frame", ret, g_aenc_func_lock[aenc_hdl]);

    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
    return ret;
}

td_s32 hi_mapi_aenc_get_default_attr(hi_mapi_audio_format aenc_format, hi_mapi_aenc_attr *aenc_attr)
{
    static hi_mapi_aenc_g711_attr s_g711_default = { 0 };
    static hi_mapi_aenc_lpcm_attr s_lpcm_default = { 0 };
    static hi_mapi_aenc_aac_attr s_aac_default = {
        .aac_type    = HI_MAPI_AAC_TYPE_AACLC,
        .bit_rate    = HI_MAPI_AAC_BPS_64K,
        .sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000,
        .bit_width   = HI_MAPI_AUDIO_BIT_WIDTH_16,
        .sound_mode  = HI_MAPI_AUDIO_SOUND_MODE_MONO,
        .trans_type  = HI_MAPI_AAC_TRANS_TYPE_ADTS,
        .band_width  = 0,
    };
    static hi_mapi_aenc_opus_attr s_opus_default = {
        .sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000,
        .bit_width = HI_MAPI_AUDIO_BIT_WIDTH_16,
        .sound_mode = HI_MAPI_AUDIO_SOUND_MODE_MONO,
        .bit_rate = HI_MAPI_OPUS_BPS_24K,
        .application = HI_MAPI_OPUS_APPLICATION_VOIP,
    };
#ifdef ENABLE_MP3
    static hi_mapi_aenc_mp3_attr s_mp3_default = {
        .sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000,
        .bit_width   = HI_MAPI_AUDIO_BIT_WIDTH_16,
        .sound_mode  = HI_MAPI_AUDIO_SOUND_MODE_MONO,
        .bit_rate    = HI_MAPI_MP3_BPS_64K,
        .quality     = 7,
    };
#endif

    CHECK_MAPI_AENC_NULL_PTR_RET(aenc_attr);

    aenc_attr->aenc_format = aenc_format;

    switch (aenc_format) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            aenc_attr->pt_num_per_frm = HI_MAPI_AENC_AACLC_SAMPLES_PER_FRAME;
            aenc_attr->value          = &s_aac_default;
            aenc_attr->value_len      = sizeof(s_aac_default);
            break;

        case HI_MAPI_AUDIO_FORMAT_G711A:
        case HI_MAPI_AUDIO_FORMAT_G711U:
            aenc_attr->pt_num_per_frm = 480; /* sample default for G711 */
            aenc_attr->value          = &s_g711_default;
            aenc_attr->value_len      = sizeof(s_g711_default);
            break;

        case HI_MAPI_AUDIO_FORMAT_LPCM:
            aenc_attr->pt_num_per_frm = 1024; /* sample default */
            aenc_attr->value          = &s_lpcm_default;
            aenc_attr->value_len      = sizeof(s_lpcm_default);
            break;

        case HI_MAPI_AUDIO_FORMAT_OPUS:
            aenc_attr->pt_num_per_frm = OPUS_FRAME_SAMPLES_20MS;
            aenc_attr->value = &s_opus_default;
            aenc_attr->value_len = sizeof(s_opus_default);
            break;

#ifdef ENABLE_MP3
        case HI_MAPI_AUDIO_FORMAT_MP3:
            aenc_attr->pt_num_per_frm = 1152; /* mp3 fixed samples per frame */
            aenc_attr->value          = &s_mp3_default;
            aenc_attr->value_len      = sizeof(s_mp3_default);
            break;
#endif

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "invalid aenc_format %d\n", aenc_format);
            return HI_MAPI_AENC_EILLPARAM;
    }

    return TD_SUCCESS;
}

/*
 * cmd-based extension parameter dispatch
 *
 * Suffix convention enforced here:
 *   _CONFIG : only allowed before hi_mapi_aenc_start. Returns HI_MAPI_AENC_ESTATEERR
 *             if called while channel is STARTED.
 *   _PARAM  : settable at any state (no _PARAM suffix cmds exist yet).
 *
 * PAYLOAD_FORMAT_CONFIG semantics:
 *   - Selects how the encoded OPUS bitstream is packaged on egress (callback path).
 *   - HI_NATIVE (default): SDK-native packing with an 8-byte big-endian length prefix.
 *   - STANDARD: bare RTP payload (RFC 7587 OPUS RTP payload format).
 *   - Only meaningful for HI_MAPI_AUDIO_FORMAT_OPUS; rejected on other formats.
 */
td_s32 hi_mapi_aenc_set_param(td_handle aenc_hdl, hi_mapi_aenc_cmd cmd,
                              const td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);
    CHECK_MAPI_AENC_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (!g_aenc_context.aenc_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "AENC has not been pre inited\n");
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }
    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "aenc[%d] not inited\n", aenc_hdl);
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    MAPI_MUTEX_LOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);

    td_s32 ret = TD_SUCCESS;
    switch (cmd) {
        case HI_MAPI_AENC_CMD_PAYLOAD_FORMAT_CONFIG: {
            if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_STARTED) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_AENC,
                    "PAYLOAD_FORMAT_CONFIG must be set before start (aenc_hdl=%d)\n", aenc_hdl);
                ret = HI_MAPI_AENC_ESTATEERR;
                break;
            }
            if (attr_len < sizeof(hi_mapi_audio_payload_format)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "attr_len:%u too small\n", attr_len);
                ret = HI_MAPI_AENC_EILLPARAM;
                break;
            }
            if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.aenc_format != HI_MAPI_AUDIO_FORMAT_OPUS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_AENC,
                    "PAYLOAD_FORMAT_CONFIG only valid for OPUS (current format=%d)\n",
                    g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_attr.aenc_format);
                ret = HI_MAPI_AENC_EILLPARAM;
                break;
            }
            hi_mapi_audio_payload_format payload = *(const hi_mapi_audio_payload_format *)attr;
            if (payload >= HI_MAPI_AUDIO_PAYLOAD_BUTT) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "payload_format=%d out of range\n", payload);
                ret = HI_MAPI_AENC_EILLPARAM;
                break;
            }
            g_aenc_context.aenc_chn_cfg[aenc_hdl].payload_format = payload;
            break;
        }
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_AENC, "unknown cmd=%d\n", cmd);
            ret = HI_MAPI_AENC_EILLPARAM;
            break;
    }

    MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);
    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
    return ret;
}

td_s32 hi_mapi_aenc_get_param(td_handle aenc_hdl, hi_mapi_aenc_cmd cmd,
                              td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_AENC_HANDLE_RANGE_RET(aenc_hdl);
    CHECK_MAPI_AENC_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_aenc_func_lock[aenc_hdl]);

    if (!g_aenc_context.aenc_inited) {
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }
    if (g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_state == MAPI_AENC_CHN_UNINITED) {
        MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
        return HI_MAPI_AENC_ENOTINITED;
    }

    MAPI_MUTEX_LOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);

    td_s32 ret = TD_SUCCESS;
    switch (cmd) {
        case HI_MAPI_AENC_CMD_PAYLOAD_FORMAT_CONFIG:
            if (attr_len < sizeof(hi_mapi_audio_payload_format)) {
                ret = HI_MAPI_AENC_EILLPARAM;
                break;
            }
            *(hi_mapi_audio_payload_format *)attr =
                g_aenc_context.aenc_chn_cfg[aenc_hdl].payload_format;
            break;
        default:
            ret = HI_MAPI_AENC_EILLPARAM;
            break;
    }

    MAPI_MUTEX_UNLOCK(g_aenc_context.aenc_chn_cfg[aenc_hdl].aenc_chn_lock);
    MAPI_MUTEX_UNLOCK(g_aenc_func_lock[aenc_hdl]);
    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
