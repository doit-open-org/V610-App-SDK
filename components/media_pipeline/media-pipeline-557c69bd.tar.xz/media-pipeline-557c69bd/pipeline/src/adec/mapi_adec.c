/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "hi_mapi_adec.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_adec_define.h"
#include "mapi_adec_inner.h"
#include "audio_comp/audio_comp_adec.h"
#include "adpt_adec_aac.h"
#include "ss_audio_opus_adp.h"
#ifdef ENABLE_MP3
#include "adpt_adec_mp3.h"
#endif
#include "mapi_comm_inner.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static mapi_adec_server_context g_adec_context = {
    .adec_inited = TD_FALSE,
    .adec_chn_cfg = {
        {0},
    },
};

pthread_mutex_t g_adec_func_lock[HI_MAPI_ADEC_CHN_MAX_NUM] = {
    [0 ... (HI_MAPI_ADEC_CHN_MAX_NUM - 1)] = PTHREAD_MUTEX_INITIALIZER
};

/* Global codec lock protects g_adec_fmt_ref_cnt[] and serializes cross-channel
 * decoder register/unregister. Lock order is channel lock -> codec lock. */
static pthread_mutex_t g_adec_codec_lock = PTHREAD_MUTEX_INITIALIZER;
/* Per-format refcount: 0->1 registers, 1->0 unregisters. */
static td_u32 g_adec_fmt_ref_cnt[HI_MAPI_AUDIO_FORMAT_BUTT] = {0};

static td_s32 mapi_adec_init(td_void)
{
    td_u32 i;
    td_s32 ret;

    if (g_adec_context.adec_inited == TD_TRUE) {
        return TD_SUCCESS;
    }

    ret = memset_s(&g_adec_context, sizeof(mapi_adec_server_context), 0, sizeof(mapi_adec_server_context));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ADEC, "memset_s", ret);

    for (i = 0; i < HI_MAPI_ADEC_CHN_MAX_NUM; i++) {
        g_adec_context.adec_chn_cfg[i].chn_inited = TD_FALSE;
        g_adec_context.adec_chn_cfg[i].adec_format = HI_MAPI_AUDIO_FORMAT_BUTT;
    }

    MAPI_MUTEX_LOCK(g_adec_codec_lock);
    (td_void)memset_s(g_adec_fmt_ref_cnt, sizeof(g_adec_fmt_ref_cnt), 0, sizeof(g_adec_fmt_ref_cnt));
    MAPI_MUTEX_UNLOCK(g_adec_codec_lock);

    g_adec_context.adec_inited = TD_TRUE;

    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ADEC, "mapi_adec_init!\n");
    return TD_SUCCESS;
}

static td_s32 mapi_adec_deinit(td_void)
{
    td_u32 i;
    td_s32 ret;

    ret = memset_s(&g_adec_context, sizeof(mapi_adec_server_context), 0, sizeof(mapi_adec_server_context));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_ADEC, "memset_s", ret);

    for (i = 0; i < HI_MAPI_ADEC_CHN_MAX_NUM; i++) {
        g_adec_context.adec_chn_cfg[i].chn_inited = TD_FALSE;
        g_adec_context.adec_chn_cfg[i].adec_format = HI_MAPI_AUDIO_FORMAT_BUTT;
    }

    MAPI_MUTEX_LOCK(g_adec_codec_lock);
    (td_void)memset_s(g_adec_fmt_ref_cnt, sizeof(g_adec_fmt_ref_cnt), 0, sizeof(g_adec_fmt_ref_cnt));
    MAPI_MUTEX_UNLOCK(g_adec_codec_lock);

    g_adec_context.adec_inited = TD_FALSE;

    MAPI_DEBUG_TRACE(HI_MAPI_MOD_ADEC, "mapi_adec_deinit!\n");
    return TD_SUCCESS;
}

static td_s32 mapi_adec_register_audio_decoder(hi_mapi_audio_format audio_format)
{
    td_s32 ret = TD_SUCCESS;

    /* Validate format before using it as a refcount array index. */
    if ((td_s32)audio_format < 0 || audio_format >= HI_MAPI_AUDIO_FORMAT_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "not support the audio_format in register audio_decoder!\n");
        return HI_MAPI_ADEC_EILLPARAM;
    }

    /* Under global lock, only 0->1 performs real registration. */
    MAPI_MUTEX_LOCK(g_adec_codec_lock);
    if (g_adec_fmt_ref_cnt[audio_format] == 0) {
        switch (audio_format) {
            case HI_MAPI_AUDIO_FORMAT_AACLC:
                ret = MAPI_ADEC_RegisterAac();
                break;
#ifdef ENABLE_MP3
            case HI_MAPI_AUDIO_FORMAT_MP3:
                ret = MAPI_ADEC_RegisterMp3();
                break;
#endif
            case HI_MAPI_AUDIO_FORMAT_G711A:
            case HI_MAPI_AUDIO_FORMAT_G711U:
            case HI_MAPI_AUDIO_FORMAT_LPCM:
                break;
            case HI_MAPI_AUDIO_FORMAT_OPUS:
#ifdef AUDIO_COMP_HAS_OPUS_SDK
                ret = ss_mpi_adec_opus_init();
#else
                MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "OPUS decoder not compiled in (AUDIO_COMP_HAS_OPUS_SDK not set)\n");
                ret = HI_MAPI_ADEC_EILLPARAM;
#endif
                break;

            default:
                MAPI_MUTEX_UNLOCK(g_adec_codec_lock);
                MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "not support the audio_format in register audio_decoder!\n");
                return HI_MAPI_ADEC_EILLPARAM;
        }
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "register audio_decoder failed, ret:%x\n", ret);
            MAPI_MUTEX_UNLOCK(g_adec_codec_lock);
            return ret;
        }
    }
    g_adec_fmt_ref_cnt[audio_format]++;
    MAPI_MUTEX_UNLOCK(g_adec_codec_lock);
    return TD_SUCCESS;
}

static td_s32 mapi_adec_unregister_audio_decoder(hi_mapi_audio_format audio_format)
{
    td_s32 ret = TD_SUCCESS;

    if ((td_s32)audio_format < 0 || audio_format >= HI_MAPI_AUDIO_FORMAT_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "not support the audio_format in unregister audio_decoder!\n");
        return HI_MAPI_ADEC_EILLPARAM;
    }

    /* Under global lock, only 1->0 performs real unregistration. */
    MAPI_MUTEX_LOCK(g_adec_codec_lock);
    if (g_adec_fmt_ref_cnt[audio_format] == 0) {
        MAPI_MUTEX_UNLOCK(g_adec_codec_lock);
        return TD_SUCCESS;
    }
    if (--g_adec_fmt_ref_cnt[audio_format] != 0) {
        MAPI_MUTEX_UNLOCK(g_adec_codec_lock);
        return TD_SUCCESS;
    }

    switch (audio_format) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            ret = MAPI_ADEC_UnRegisterAac();
            break;
#ifdef ENABLE_MP3
        case HI_MAPI_AUDIO_FORMAT_MP3:
            ret = MAPI_ADEC_UnRegisterMp3();
            break;
#endif
        case HI_MAPI_AUDIO_FORMAT_G711A:
        case HI_MAPI_AUDIO_FORMAT_G711U:
        case HI_MAPI_AUDIO_FORMAT_LPCM:
            break;
        case HI_MAPI_AUDIO_FORMAT_OPUS:
#ifdef AUDIO_COMP_HAS_OPUS_SDK
            ret = ss_mpi_adec_opus_deinit();
#endif
            break;

        default:
            break;
    }
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "unregister audio_decoder failed, ret:%d\n", ret);
        MAPI_MUTEX_UNLOCK(g_adec_codec_lock);
        return ret;
    }
    MAPI_MUTEX_UNLOCK(g_adec_codec_lock);
    return TD_SUCCESS;
}

td_s32 hi_mapi_adec_init(td_handle adec_hdl, const hi_mapi_adec_attr *adec_attr)
{
    td_s32 ret;

    CHECK_MAPI_ADEC_NULL_PTR_RET(adec_attr);
    CHECK_MAPI_ADEC_HANDLE_RANGE_RET(adec_hdl);
    CHECK_MAPI_ADEC_CHECK_INIT_RET(mapi_get_media_init_status());
    MAPI_MUTEX_LOCK(g_adec_func_lock[adec_hdl]);

    ret = mapi_adec_init();
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "mapi_adec_init error.\n");
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return ret;
    }

    if (g_adec_context.adec_chn_cfg[adec_hdl].chn_inited) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ADEC, "adec is inited, no need init adec repeatedly!.\n");
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return TD_SUCCESS;
    }

    ret = mapi_adec_register_audio_decoder(adec_attr->adec_format);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ADEC, "mapi_adec_register_audio_decoder", ret, g_adec_func_lock[adec_hdl]);

    ret = audio_comp_adec_create_chn(adec_hdl, adec_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "audio_comp_adec_create_chn error.\n");
        (td_void)mapi_adec_unregister_audio_decoder(adec_attr->adec_format);
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return ret;
    }

    g_adec_context.adec_chn_cfg[adec_hdl].chn_inited     = TD_TRUE;
    g_adec_context.adec_chn_cfg[adec_hdl].adec_format    = adec_attr->adec_format;
    g_adec_context.adec_chn_cfg[adec_hdl].payload_format = HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE;
    g_adec_context.adec_chn_cfg[adec_hdl].stream_started = TD_FALSE;
    MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);

    return ret;
}

td_s32 hi_mapi_adec_deinit(td_handle adec_hdl)
{
    td_u32 i;
    CHECK_MAPI_ADEC_HANDLE_RANGE_RET(adec_hdl);
    CHECK_MAPI_ADEC_CHECK_INIT_RET(mapi_get_media_init_status());

    MAPI_MUTEX_LOCK(g_adec_func_lock[adec_hdl]);

    if (!g_adec_context.adec_chn_cfg[adec_hdl].chn_inited) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ADEC, "adec has already deinited.\n");
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return TD_SUCCESS;
    }

    hi_mapi_audio_format adec_format = g_adec_context.adec_chn_cfg[adec_hdl].adec_format;
    td_s32 ret = audio_comp_adec_destroy_chn(adec_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ADEC, "audio_comp_adec_destroy_chn", ret, g_adec_func_lock[adec_hdl]);

    /* Always release this channel's format reference; the global refcount decides
     * whether this is the last user. */
    ret = mapi_adec_unregister_audio_decoder(adec_format);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "mapi_adec_unregister_audio_decoder error.\n");
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return ret;
    }

    g_adec_context.adec_chn_cfg[adec_hdl].chn_inited = TD_FALSE;
    g_adec_context.adec_chn_cfg[adec_hdl].adec_format = HI_MAPI_AUDIO_FORMAT_BUTT;

    /* Full context reset still requires all channels to be deinitialized. */
    for (i = 0; i < HI_MAPI_ADEC_CHN_MAX_NUM; i++) {
        if (g_adec_context.adec_chn_cfg[i].chn_inited == TD_TRUE) {
            break;
        }
    }
    if (i == HI_MAPI_ADEC_CHN_MAX_NUM) {
        ret = mapi_adec_deinit();
        CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ADEC, "mapi_adec_deinit", ret, g_adec_func_lock[adec_hdl]);
    }

    MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
    return TD_SUCCESS;
}

td_s32 hi_mapi_adec_send_stream(td_handle adec_hdl, const hi_mapi_audio_stream *adec_stream, td_bool block)
{
    CHECK_MAPI_ADEC_NULL_PTR_RET(adec_stream);
    CHECK_MAPI_ADEC_NULL_PTR_RET(adec_stream->stream);
    CHECK_MAPI_ADEC_HANDLE_RANGE_RET(adec_hdl);
    CHECK_MAPI_ADEC_CHECK_INIT_RET(mapi_get_media_init_status());

    MAPI_MUTEX_LOCK(g_adec_func_lock[adec_hdl]);

    if (!g_adec_context.adec_chn_cfg[adec_hdl].chn_inited) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ADEC, "ADEC has not been pre inited.\n");
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return HI_MAPI_ADEC_ESTATEERR;
    }
    /* Latch streaming state so subsequent hi_mapi_adec_set_param(_CONFIG) calls are rejected. */
    g_adec_context.adec_chn_cfg[adec_hdl].stream_started = TD_TRUE;
    hi_mapi_audio_payload_format payload_format = g_adec_context.adec_chn_cfg[adec_hdl].payload_format;
    MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);

    td_s32 ret = audio_comp_adec_send_stream(adec_hdl, adec_stream, block, payload_format);
    CHECK_MAPI_RET(HI_MAPI_MOD_ADEC, "audio_comp_adec_send_stream", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_adec_get_frame(td_handle adec_hdl, hi_mapi_audio_frame_info *audio_frame_info, td_bool block)
{
    td_s32 ret;

    CHECK_MAPI_ADEC_NULL_PTR_RET(audio_frame_info);
    CHECK_MAPI_ADEC_HANDLE_RANGE_RET(adec_hdl);
    CHECK_MAPI_ADEC_CHECK_INIT_RET(mapi_get_media_init_status());

    MAPI_MUTEX_LOCK(g_adec_func_lock[adec_hdl]);

    if (!g_adec_context.adec_chn_cfg[adec_hdl].chn_inited) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ADEC, "ADEC has not been pre inited.\n");
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return HI_MAPI_ADEC_ESTATEERR;
    }
    MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);

    ret = audio_comp_adec_get_frame(adec_hdl, audio_frame_info, block);
    CHECK_MAPI_RET(HI_MAPI_MOD_ADEC, "audio_comp_adec_get_frame", ret);

    return ret;
}

td_s32 hi_mapi_adec_release_frame(td_handle adec_hdl, const hi_mapi_audio_frame_info *audio_frame_info)
{
    CHECK_MAPI_ADEC_NULL_PTR_RET(audio_frame_info);
    CHECK_MAPI_ADEC_NULL_PTR_RET(audio_frame_info->frame);
    CHECK_MAPI_ADEC_HANDLE_RANGE_RET(adec_hdl);
    CHECK_MAPI_ADEC_CHECK_INIT_RET(mapi_get_media_init_status());

    MAPI_MUTEX_LOCK(g_adec_func_lock[adec_hdl]);

    if (!g_adec_context.adec_chn_cfg[adec_hdl].chn_inited) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ADEC, "ADEC has not been pre inited.\n");
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return HI_MAPI_ADEC_ESTATEERR;
    }

    td_s32 ret = audio_comp_adec_release_frame(adec_hdl, audio_frame_info);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ADEC, "audio_comp_adec_release_frame", ret, g_adec_func_lock[adec_hdl]);

    MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);

    return ret;
}

td_s32 hi_mapi_adec_send_end_of_stream(td_handle adec_hdl)
{
    td_s32 ret;
    CHECK_MAPI_ADEC_HANDLE_RANGE_RET(adec_hdl);
    CHECK_MAPI_ADEC_CHECK_INIT_RET(mapi_get_media_init_status());

    MAPI_MUTEX_LOCK(g_adec_func_lock[adec_hdl]);

    if (!g_adec_context.adec_chn_cfg[adec_hdl].chn_inited) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_ADEC, "ADEC has not been pre inited.\n");
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return HI_MAPI_ADEC_ESTATEERR;
    }

    ret = audio_comp_adec_send_end_of_stream(adec_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_ADEC, "audio_comp_adec_send_end_of_stream", ret, g_adec_func_lock[adec_hdl]);

    MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);

    return ret;
}

td_s32 hi_mapi_adec_get_default_attr(hi_mapi_audio_format adec_format, hi_mapi_adec_attr *adec_attr)
{
    CHECK_MAPI_ADEC_NULL_PTR_RET(adec_attr);

    /* Check both bounds because enum values are signed by default. */
    if ((td_s32)adec_format < 0 || adec_format >= HI_MAPI_AUDIO_FORMAT_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "invalid adec_format %d\n", adec_format);
        return HI_MAPI_ADEC_EILLPARAM;
    }

    adec_attr->adec_format = adec_format;
    /* Match adapter mode rules: LPCM uses PACK, other formats use STREAM. */
    adec_attr->adec_mode = (adec_format == HI_MAPI_AUDIO_FORMAT_LPCM)
                           ? HI_MAPI_ADEC_MODE_PACK
                           : HI_MAPI_ADEC_MODE_STREAM;

    return TD_SUCCESS;
}

/*
 * cmd-based extension parameter dispatch (mirrors hi_mapi_aenc_set_param / get_param).
 *
 * Suffix convention:
 *   _CONFIG : permitted only before the first hi_mapi_adec_send_stream call.
 *             Returns HI_MAPI_ADEC_ESTATEERR once streaming has started.
 *   _PARAM  : settable at any state (no _PARAM cmds exist yet).
 *
 * PAYLOAD_FORMAT_CONFIG semantics (input side):
 *   - HI_NATIVE (default): caller already prepends the 8-byte big-endian length header.
 *   - STANDARD: caller provides bare RTP payload; adapt layer prepends the header
 *               before forwarding to the SDK decoder.
 *   - Only meaningful for HI_MAPI_AUDIO_FORMAT_OPUS; rejected on other formats.
 */
td_s32 hi_mapi_adec_set_param(td_handle adec_hdl, hi_mapi_adec_cmd cmd,
                              const td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_ADEC_HANDLE_RANGE_RET(adec_hdl);
    CHECK_MAPI_ADEC_NULL_PTR_RET(attr);
    CHECK_MAPI_ADEC_CHECK_INIT_RET(mapi_get_media_init_status());

    MAPI_MUTEX_LOCK(g_adec_func_lock[adec_hdl]);

    if (!g_adec_context.adec_chn_cfg[adec_hdl].chn_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "adec[%d] not inited\n", adec_hdl);
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return HI_MAPI_ADEC_ESTATEERR;
    }

    td_s32 ret = TD_SUCCESS;
    switch (cmd) {
        case HI_MAPI_ADEC_CMD_PAYLOAD_FORMAT_CONFIG: {
            if (g_adec_context.adec_chn_cfg[adec_hdl].stream_started) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC,
                    "PAYLOAD_FORMAT_CONFIG must be set before first send_stream (adec_hdl=%d)\n", adec_hdl);
                ret = HI_MAPI_ADEC_ESTATEERR;
                break;
            }
            if (attr_len < sizeof(hi_mapi_audio_payload_format)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "attr_len:%u too small\n", attr_len);
                ret = HI_MAPI_ADEC_EILLPARAM;
                break;
            }
            if (g_adec_context.adec_chn_cfg[adec_hdl].adec_format != HI_MAPI_AUDIO_FORMAT_OPUS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC,
                    "PAYLOAD_FORMAT_CONFIG only valid for OPUS (current format=%d)\n",
                    g_adec_context.adec_chn_cfg[adec_hdl].adec_format);
                ret = HI_MAPI_ADEC_EILLPARAM;
                break;
            }
            hi_mapi_audio_payload_format payload = *(const hi_mapi_audio_payload_format *)attr;
            if (payload >= HI_MAPI_AUDIO_PAYLOAD_BUTT) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "payload_format=%d out of range\n", payload);
                ret = HI_MAPI_ADEC_EILLPARAM;
                break;
            }
            g_adec_context.adec_chn_cfg[adec_hdl].payload_format = payload;
            break;
        }
        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_ADEC, "unknown cmd=%d\n", cmd);
            ret = HI_MAPI_ADEC_EILLPARAM;
            break;
    }

    MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
    return ret;
}

td_s32 hi_mapi_adec_get_param(td_handle adec_hdl, hi_mapi_adec_cmd cmd,
                              td_void *attr, td_u32 attr_len)
{
    CHECK_MAPI_ADEC_HANDLE_RANGE_RET(adec_hdl);
    CHECK_MAPI_ADEC_NULL_PTR_RET(attr);
    CHECK_MAPI_ADEC_CHECK_INIT_RET(mapi_get_media_init_status());

    MAPI_MUTEX_LOCK(g_adec_func_lock[adec_hdl]);

    if (!g_adec_context.adec_chn_cfg[adec_hdl].chn_inited) {
        MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
        return HI_MAPI_ADEC_ESTATEERR;
    }

    td_s32 ret = TD_SUCCESS;
    switch (cmd) {
        case HI_MAPI_ADEC_CMD_PAYLOAD_FORMAT_CONFIG:
            if (attr_len < sizeof(hi_mapi_audio_payload_format)) {
                ret = HI_MAPI_ADEC_EILLPARAM;
                break;
            }
            *(hi_mapi_audio_payload_format *)attr =
                g_adec_context.adec_chn_cfg[adec_hdl].payload_format;
            break;
        default:
            ret = HI_MAPI_ADEC_EILLPARAM;
            break;
    }

    MAPI_MUTEX_UNLOCK(g_adec_func_lock[adec_hdl]);
    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
