/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>

#include "hi_mapi_ao.h"
#include "hi_mapi_ao_define.h"
#include "mapi_ao_inner.h"
#include "audio_comp/audio_comp_acodec.h"
#include "audio_comp/audio_comp_ao.h"
#include "mapi_comm_inner.h"
#include "hi_mapi_ao_arch.h"
#include "mapi_ao_arch.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

static mapi_ao_server_context g_ao_context[HI_MAPI_AO_DEV_MAX_NUM];
static td_bool g_ao_inited = TD_FALSE;
static pthread_mutex_t g_ao_func_lock[HI_MAPI_AO_DEV_MAX_NUM] = {
    [0 ... (HI_MAPI_AO_DEV_MAX_NUM - 1)] = PTHREAD_MUTEX_INITIALIZER
};

td_s32 mapi_ao_init(td_void)
{
    td_s32 i;
    td_s32 j;

    if (g_ao_inited == TD_TRUE) {
        return TD_SUCCESS;
    }

    for (i = 0; i < HI_MAPI_AO_DEV_MAX_NUM; i++) {
        hal_mapi_ao_init_context(&g_ao_context[i]);
        for (j = 0; j < HI_MAPI_AO_CHN_MAX_NUM; j++) {
            g_ao_context[i].ao_chn_start[j] = TD_FALSE;
        }
    }

    /* ES7210 external ADC has no inner acodec provider; skip open/close
     * to avoid spurious ERROR logs. Inner-codec path is unaffected because
     * g_active_ops is non-NULL there. */
    if (audio_comp_acodec_get_active() != TD_NULL) {
        audio_comp_acodec_open();
    }

    g_ao_inited = TD_TRUE;
    return TD_SUCCESS;
}

td_s32 mapi_ao_deinit(td_void)
{
    td_s32 i;
    td_s32 j;
    td_s32 ret = TD_SUCCESS;

    if (g_ao_inited != TD_TRUE) {
        return TD_SUCCESS;
    }
    for (i = 0; i < HI_MAPI_AO_DEV_MAX_NUM; i++) {
        if (g_ao_context[i].ao_state != MAPI_AO_UNINITED) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO %d is not uninited, media can not deinit! try deinit %d\n", i, i);
            ret = hi_mapi_ao_deinit((td_handle)i);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO[%d] call hi_mapi_ao_deinit error, ret:%#x", i, ret);
            }
        }
    }

    for (i = 0; i < HI_MAPI_AO_DEV_MAX_NUM; i++) {
        ret = memset_s(&g_ao_context[i].ao_attr, sizeof(hi_mapi_ao_attr), 0, sizeof(hi_mapi_ao_attr));
        if (ret != EOK) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "memset_s fail and return:[%#x]!\n", ret);
            ret = HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
        }

        g_ao_context[i].expand_flag = 0;
        g_ao_context[i].frm_num = 0;
        g_ao_context[i].chn_cnt = 0;
        g_ao_context[i].clk_sel = 0;
        g_ao_context[i].ao_state = MAPI_AO_BUTT;

        for (j = 0; j < HI_MAPI_AO_CHN_MAX_NUM; j++) {
            g_ao_context[i].ao_chn_start[j] = TD_FALSE;
        }
    }

    if (audio_comp_acodec_get_active() != TD_NULL) {
        audio_comp_acodec_close();
    }

    g_ao_inited = TD_FALSE;
    return ret;
}

td_void mapi_ao_init_vqe_cfg(const hi_mapi_audio_vqe_attr *audio_vqe_cfg)
{
    if (audio_vqe_cfg != TD_NULL) {
        td_s32 i;
        for (i = 0; i < HI_MAPI_AO_DEV_MAX_NUM; i++) {
            g_ao_context[i].ao_vqe_attr.open_mask = audio_vqe_cfg->ao_vqe_attr.open_mask;
        }
    }
}

static td_s32 mapi_ao_stop_all_chn(td_handle ao_hdl)
{
    td_s32 ret;
    td_u32 i;

    for (i = 0; i < HI_MAPI_AO_CHN_MAX_NUM - 1; i++) {
        if (g_ao_context[ao_hdl].ao_chn_start[i] != TD_FALSE) {
            ret = hi_mapi_ao_stop(ao_hdl, i);
            if (ret != TD_SUCCESS) {
                return ret;
            }
        }
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_ao_init(td_handle ao_hdl, const hi_mapi_ao_attr *ao_attr)
{
    td_s32 ret;

    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_NULL_PTR_RET(ao_attr);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_inited == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is started, can not be init!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ESTATEERR;
    }

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_STOPED &&
        ao_attr->sample_rate == g_ao_context[ao_hdl].ao_attr.sample_rate &&
        ao_attr->bit_width == g_ao_context[ao_hdl].ao_attr.bit_width &&
        ao_attr->sound_mode == g_ao_context[ao_hdl].ao_attr.sound_mode &&
        ao_attr->work_mode == g_ao_context[ao_hdl].ao_attr.work_mode &&
        ao_attr->pt_num_per_frm == g_ao_context[ao_hdl].ao_attr.pt_num_per_frm &&
        ao_attr->track_mode == g_ao_context[ao_hdl].ao_attr.track_mode &&
        ao_attr->in_sample_rate == g_ao_context[ao_hdl].ao_attr.in_sample_rate &&
        ao_attr->i2s_type == g_ao_context[ao_hdl].ao_attr.i2s_type) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_AO, "AO init attr is not change, return success!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return TD_SUCCESS;
    }

    ret = audio_comp_ao_set_pub_attr(ao_hdl, &g_ao_context[ao_hdl], ao_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_set_pub_attr", ret, g_ao_func_lock[ao_hdl]);

    ret = memcpy_s(&g_ao_context[ao_hdl].ao_attr, sizeof(g_ao_context[ao_hdl].ao_attr),
                   ao_attr, sizeof(hi_mapi_ao_attr));
    CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_AO, "memcpy_s", ret, g_ao_func_lock[ao_hdl]);

    g_ao_context[ao_hdl].ao_state = MAPI_AO_STOPED;
    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return ret;
}

td_s32 hi_mapi_ao_deinit(td_handle ao_hdl)
{
    td_s32 ret = TD_SUCCESS;

    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_INIT_RET(g_ao_inited);

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "Ao is started, can't be Deinit, try stop now\n");
        ret = mapi_ao_stop_all_chn(ao_hdl);
        if (ret != TD_SUCCESS) {
            return ret;
        }
    }

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_UNINITED) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_AO, "ao has already uninited, return success\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return TD_SUCCESS;
    }

    g_ao_context[ao_hdl].ao_attr.bit_width = HI_MAPI_AUDIO_BIT_WIDTH_BUTT;
    g_ao_context[ao_hdl].ao_attr.sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_BUTT;
    g_ao_context[ao_hdl].ao_attr.sound_mode = HI_MAPI_AUDIO_SOUND_MODE_BUTT;
    g_ao_context[ao_hdl].ao_attr.work_mode = HI_MAPI_AIO_MODE_BUTT;
    g_ao_context[ao_hdl].ao_attr.pt_num_per_frm = 0;
    g_ao_context[ao_hdl].ao_attr.in_sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_BUTT;
    g_ao_context[ao_hdl].ao_attr.track_mode = HI_MAPI_AUDIO_TRACK_BUTT;

    g_ao_context[ao_hdl].ao_state = MAPI_AO_UNINITED;

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return ret;
}

td_s32 hi_mapi_ao_start(td_handle ao_hdl, td_handle ao_chn_hdl)
{
    td_s32 ret;

    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_CHN_HANDLE_RANGE_RET(ao_chn_hdl);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_inited == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ao is not inited, can't be start!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ESTATEERR;
    }

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_STARTED) {
        if (g_ao_context[ao_hdl].ao_chn_start[ao_chn_hdl]) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ao[%u] chn[%u] has already started, return success!\n",
                ao_hdl, ao_chn_hdl);
            MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
            return TD_SUCCESS;
        }

        ret = audio_comp_ao_enable_chn(ao_hdl, ao_chn_hdl);
        CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_enable_chn", ret, g_ao_func_lock[ao_hdl]);

        if (g_ao_context[ao_hdl].ao_attr.sample_rate != g_ao_context[ao_hdl].ao_attr.in_sample_rate) {
            ret = audio_comp_ao_enable_resmp(ao_hdl, ao_chn_hdl, g_ao_context[ao_hdl].ao_attr.in_sample_rate);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "enable ao resample error. chn_id:%d\n", ao_chn_hdl);
                audio_comp_ao_disable_chn(ao_hdl, ao_chn_hdl);
                MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
                return ret;
            }
        }
        g_ao_context[ao_hdl].ao_chn_start[ao_chn_hdl] = TD_TRUE;

        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return TD_SUCCESS;
    }

    ret = audio_comp_ao_start(ao_hdl, ao_chn_hdl, &g_ao_context[ao_hdl].ao_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_start", ret, g_ao_func_lock[ao_hdl]);

    g_ao_context[ao_hdl].ao_chn_start[ao_chn_hdl] = TD_TRUE;
    g_ao_context[ao_hdl].ao_state = MAPI_AO_STARTED;

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_ao_stop(td_handle ao_hdl, td_handle ao_chn_hdl)
{
    td_s32 i;
    td_s32 ret;

    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_CHN_HANDLE_RANGE_RET(ao_chn_hdl);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_inited == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ao is uninited, can't be stop\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ESTATEERR;
    }

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_STOPED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ao has already stop, return success!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return TD_SUCCESS;
    }

    if (g_ao_context[ao_hdl].ao_chn_start[ao_chn_hdl]) {
        if (g_ao_context[ao_hdl].ao_attr.sample_rate != g_ao_context[ao_hdl].ao_attr.in_sample_rate) {
            ret = audio_comp_ao_disable_resmp(ao_hdl, ao_chn_hdl);
            CHECK_MAPI_PRINT(HI_MAPI_MOD_AO, "audio_comp_ao_disable_resmp", ret);
        }

        ret = audio_comp_ao_disable_chn(ao_hdl, ao_chn_hdl);
        CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_disable_chn", ret, g_ao_func_lock[ao_hdl]);

        g_ao_context[ao_hdl].ao_chn_start[ao_chn_hdl] = TD_FALSE;
    }

    for (i = 0; i < HI_MAPI_AO_CHN_MAX_NUM - 1; i++) {
        if (g_ao_context[ao_hdl].ao_chn_start[i] != TD_FALSE) {
            MAPI_WARN_TRACE(HI_MAPI_MOD_AO, "AO Chn[%d] is started, return successful\n", i);
            MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
            return TD_SUCCESS;
        }
    }

    ret = audio_comp_ao_stop(ao_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_stop", ret, g_ao_func_lock[ao_hdl]);

    g_ao_context[ao_hdl].ao_state = MAPI_AO_STOPED;

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return ret;
}

td_s32 hi_mapi_ao_enable_vqe(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_ao_vqe_attr *ao_vqe_attr)
{
#ifdef SUPPORT_TALKVQE
    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_CHN_HANDLE_RANGE_RET(ao_chn_hdl);
    CHECK_MAPI_AO_NULL_PTR_RET(ao_vqe_attr);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (!g_ao_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    if ((g_ao_context[ao_hdl].ao_state != MAPI_AO_STARTED) ||
        (g_ao_context[ao_hdl].ao_chn_start[ao_chn_hdl] != TD_TRUE)) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_AO, "AO or AO Chn is not been started, can not enable Vqe\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ESTATEERR;
    }

    td_u32 open_mask = 0;
    hal_mapi_ao_get_ao_vqe_open_mask(&g_ao_context[ao_hdl].ao_vqe_attr, &open_mask);
    td_s32 ret = audio_comp_ao_enable_vqe(ao_hdl, ao_chn_hdl, ao_vqe_attr, &g_ao_context[ao_hdl].ao_attr, open_mask);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_enable_vqe", ret, g_ao_func_lock[ao_hdl]);

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

#else
    MAPI_UNUSED(ao_hdl);
    MAPI_UNUSED(ao_chn_hdl);
    MAPI_UNUSED(ao_vqe_attr);
    MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "not open SUPPORT_TALKVQE config!\n");
#endif

    return TD_SUCCESS;
}

td_s32 hi_mapi_ao_disable_vqe(td_handle ao_hdl, td_handle ao_chn_hdl)
{
#ifdef SUPPORT_TALKVQE
    td_s32 ret;
    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_CHN_HANDLE_RANGE_RET(ao_chn_hdl);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (!g_ao_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO has not been pre inited, mapi media has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_UNINITED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO not been inited, can not disable_vqe\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ESTATEERR;
    }

    if (g_ao_context[ao_hdl].ao_state == MAPI_AO_STOPED ||
        (g_ao_context[ao_hdl].ao_chn_start[ao_chn_hdl] != TD_TRUE)) {
        MAPI_WARN_TRACE(HI_MAPI_MOD_AO, "AO or AO CHN is stopped, return successful\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return TD_SUCCESS;
    }

    ret = audio_comp_ao_disable_vqe(ao_hdl, ao_chn_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_disable_vqe", ret, g_ao_func_lock[ao_hdl]);

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

#else
    MAPI_UNUSED(ao_hdl);
    MAPI_UNUSED(ao_chn_hdl);
    MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "not open SUPPORT_TALKVQE config!\n");
#endif

    return TD_SUCCESS;
}

td_s32 hi_mapi_ao_set_volume(td_handle ao_hdl, td_s32 audio_gain)
{
    td_s32 ret;

    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    if (audio_gain < HI_MAPI_AO_MIN_GAIN || audio_gain > HI_MAPI_AO_MAX_GAIN) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "Gain out of range\n");
        return HI_MAPI_AO_EILLPARAM;
    }

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_inited == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    ret = audio_comp_acodec_set_ao_vol(audio_gain);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_acodec_set_ao_vol", ret, g_ao_func_lock[ao_hdl]);

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return ret;
}

td_s32 hi_mapi_ao_get_volume(td_handle ao_hdl, td_s32 *audio_gain)
{
    td_s32 volume_db;
    td_s32 ret;

    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_NULL_PTR_RET(audio_gain);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_inited == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    ret = audio_comp_acodec_get_ao_vol(&volume_db);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_acodec_get_ao_vol", ret, g_ao_func_lock[ao_hdl]);

    *audio_gain = volume_db;

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return ret;
}

td_s32 hi_mapi_ao_set_mute(td_handle ao_hdl, td_bool enable)
{
    td_s32 ret;

    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_inited == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited in set_mute!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    if (g_ao_context[ao_hdl].ao_state != MAPI_AO_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ao is not started, can't set mute\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ESTATEERR;
    }

    ret = audio_comp_ao_set_mute(ao_hdl, enable);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_set_mute", ret, g_ao_func_lock[ao_hdl]);

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_ao_send_frame(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_audio_frame *audio_frame,
    td_u32 timeout)
{
    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_CHN_HANDLE_RANGE_RET(ao_chn_hdl);
    CHECK_MAPI_AO_NULL_PTR_RET(audio_frame);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_inited == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    if (g_ao_context[ao_hdl].ao_state != MAPI_AO_STARTED ||
        !g_ao_context[ao_hdl].ao_chn_start[ao_chn_hdl]) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ao or ao chn is not started, can't send frame\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ESTATEERR;
    }

    td_s32 ret = audio_comp_ao_send_frame(ao_hdl, ao_chn_hdl, audio_frame, timeout);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_send_frame", ret, g_ao_func_lock[ao_hdl]);

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return ret;
}

td_s32 hi_mapi_ao_send_sys_frame(td_handle ao_hdl, const hi_mapi_audio_frame *audio_frame, td_u32 timeout)
{
    CHECK_MAPI_AO_HANDLE_RANGE_RET(ao_hdl);
    CHECK_MAPI_AO_NULL_PTR_RET(audio_frame);

    MAPI_MUTEX_LOCK(g_ao_func_lock[ao_hdl]);

    if (g_ao_inited == TD_FALSE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "AO is not inited!\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ENOTINITED;
    }

    if (g_ao_context[ao_hdl].ao_state != MAPI_AO_STARTED) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ao is not started, can't send frame\n");
        MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);
        return HI_MAPI_AO_ESTATEERR;
    }

    td_s32 ret = audio_comp_ao_send_frame(ao_hdl, MAPI_ADAPT_AO_SYSCHN_ID, audio_frame, timeout);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_AO, "audio_comp_ao_send_frame", ret, g_ao_func_lock[ao_hdl]);

    MAPI_MUTEX_UNLOCK(g_ao_func_lock[ao_hdl]);

    return ret;
}

td_s32 hi_mapi_ao_get_default_attr(hi_mapi_audio_sample_rate sample_rate,
                                   hi_mapi_audio_sound_mode sound_mode,
                                   hi_mapi_ao_attr *ao_attr)
{
    CHECK_MAPI_AO_NULL_PTR_RET(ao_attr);

    if (sample_rate >= HI_MAPI_AUDIO_SAMPLE_RATE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "invalid sample_rate %d\n", sample_rate);
        return HI_MAPI_AO_EILLPARAM;
    }
    if (sound_mode >= HI_MAPI_AUDIO_SOUND_MODE_BUTT) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "invalid sound_mode %d\n", sound_mode);
        return HI_MAPI_AO_EILLPARAM;
    }

    ao_attr->sample_rate     = sample_rate;
    ao_attr->bit_width       = HI_MAPI_AUDIO_BIT_WIDTH_16;
    ao_attr->sound_mode      = sound_mode;
    ao_attr->track_mode      = HI_MAPI_AUDIO_TRACK_NORMAL;
    ao_attr->work_mode       = HI_MAPI_AIO_MODE_I2S_MASTER;
    ao_attr->pt_num_per_frm  = 1024;
    ao_attr->in_sample_rate  = sample_rate;
    ao_attr->i2s_type        = HI_MAPI_AIO_I2STYPE_INNERCODEC;

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
