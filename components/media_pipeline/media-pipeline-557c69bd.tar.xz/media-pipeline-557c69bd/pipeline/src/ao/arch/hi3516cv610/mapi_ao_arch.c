/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_ao_inner.h"
#include "mapi_ao_arch.h"
#include "mapi_comm_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_void hal_mapi_ao_init_context(mapi_ao_server_context *ao_context)
{
    if (ao_context == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "ao context is null\n");
        return;
    }

    ao_context->ao_state = MAPI_AO_UNINITED;
    /* CV610 inner-codec AO is one physical mono output.  The old value (2)
     * described the number of logical Pipeline channel slots, but was passed
     * to ss_mpi_ao_set_pub_attr as the hardware chn_cnt and is rejected for
     * the mono inner-codec configuration. */
    ao_context->chn_cnt = 1;
    /* Inner-codec AO owns its clock; the external ES7210 input clock is not
     * shared with AO in the validated offline_voice hardware path. */
    ao_context->clk_sel = 0;
    ao_context->expand_flag = 0;
    ao_context->frm_num = MAPI_AO_FRAME_CACHED_CNT;
    ao_context->ao_attr.i2s_type = HI_MAPI_AIO_I2STYPE_INNERCODEC;
}

#ifdef SUPPORT_TALKVQE
td_void hal_mapi_ao_get_ao_vqe_open_mask(const hi_mapi_audio_ao_vqe_attr *ao_vqe_attr, td_u32 *open_mask)
{
    if (ao_vqe_attr == NULL || open_mask == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_AO, "input is null\n");
        return;
    }

    *open_mask = ao_vqe_attr->open_mask;
}
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
