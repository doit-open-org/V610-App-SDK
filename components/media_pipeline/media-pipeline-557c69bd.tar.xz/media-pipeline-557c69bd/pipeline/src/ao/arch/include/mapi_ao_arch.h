/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_AO_ARCH_H__
#define __MAPI_AO_ARCH_H__

#include "mapi_ao_inner.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_void hal_mapi_ao_init_context(mapi_ao_server_context *ao_context);

#ifdef SUPPORT_TALKVQE
td_void hal_mapi_ao_get_ao_vqe_open_mask(const hi_mapi_audio_ao_vqe_attr *ao_vqe_attr, td_u32 *open_mask);
#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_AO_ARCH_H__ */
