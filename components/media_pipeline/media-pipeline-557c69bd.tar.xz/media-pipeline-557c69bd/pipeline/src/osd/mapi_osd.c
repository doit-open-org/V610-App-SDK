/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <sys/prctl.h>
#include <pthread.h>
#include <errno.h>
#include <time.h>
#include <limits.h>
#include "hi_mapi_osd.h"
#include "hi_mapi_osd_define.h"
#include "hi_mapi_vpss_adapt_define.h"
#include "mapi_osd_inner.h"
#include "mapi_osd_adapt.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** OSD Module Init Flag
  Canbe modified only by hi_mapi_osd_init/hi_mapi_osd_deinit */
static td_bool g_osd_init_flg = TD_FALSE;

/** OSD Update Runing Flag
  Canbe modified only by hi_mapi_osd_init/hi_mapi_osd_deinit */
static td_bool g_osd_run = TD_FALSE;

/* OSD Parameter Array */
static mapi_osd_param g_osd_param[HI_MAPI_OSD_MAX_CNT];

/* OSD Update Task Thread ID, created by hi_mapi_osd_init, destroyed by hi_mapi_osd_deinit */
static pthread_t g_osd_time_tsk_id = 0;
static pthread_t g_osd_content_tsk_id = 0;

static td_s32 mapi_osd_usleep(td_u32 sec_time)
{
    td_s32 ret;
    struct timespec requst;
    struct timespec remain;

    remain.tv_sec = sec_time / (MAPI_SEC2MSEC_SCALE * MAPI_MSEC2USEC_SCALE);
    remain.tv_nsec = (sec_time % (MAPI_SEC2MSEC_SCALE * MAPI_MSEC2USEC_SCALE)) * MAPI_USEC2NSEC_SCALE;

    do {
        requst = remain;
        ret = nanosleep(&requst, &remain);
    } while (ret == -1 && errno == EINTR);

    return ret;
}

static td_s32 mapi_osd_get_time_str(const struct tm *sys_time, td_char *time_str, td_s32 str_len)
{
    td_s32 ret;
    /* get current Time */
    time_t now_time;
    struct tm local_time = {
        0,
    };

    if (sys_time == NULL) {
        time(&now_time);
        localtime_r(&now_time, &local_time);
        sys_time = &local_time;
    }

    /* generate time string */
    ret = snprintf_s(time_str, HI_MAPI_MAX_STR_LEN, (size_t)str_len, "%04d-%02d-%02d %02d:%02d:%02d",
        sys_time->tm_year + 1900, sys_time->tm_mon + 1, sys_time->tm_mday, /* 1900 is struct tm year reference */
        sys_time->tm_hour, sys_time->tm_min, sys_time->tm_sec);
    if (ret == TD_FAILURE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VENC, "snprintf_s fail and return:[%#x]!!\n", ret);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_osd_ratio_to_absolute(const mapi_adapt_osd_chn_bind_info *chn_info, const hi_mapi_point *ratio_coor,
    hi_mapi_point *abs_coor)
{
    td_s32 ret;
    hi_mapi_size image_size;

    if (ratio_coor->x < 0 || ratio_coor->x > MAPI_OSD_RATIO_COORDINATE_MAX_VALUE ||
        ratio_coor->y < 0 || ratio_coor->y > MAPI_OSD_RATIO_COORDINATE_MAX_VALUE) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "invalid ratio coordinate(%d,%d)\n", ratio_coor->x, ratio_coor->y);
        return HI_MAPI_OSD_EILLEGAL_PARAM;
    }

    ret = mapi_adapt_osd_get_image_size(chn_info, &image_size);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get osd image size fail,Error Code: [0x%08X]\n", ret);
        return ret;
    }

    CHECK_MAPI_UINT_PRODUCT_OVERFLOW_RET(HI_MAPI_MOD_OSD, image_size.width, ratio_coor->x);
    abs_coor->x = (td_s32)MAPI_ALIGN(image_size.width * ratio_coor->x /
        MAPI_OSD_RATIO_COORDINATE_MAX_VALUE, 2); /* 2: x align at 2 pixel */

    CHECK_MAPI_UINT_PRODUCT_OVERFLOW_RET(HI_MAPI_MOD_OSD, image_size.height, ratio_coor->y);
    abs_coor->y = (td_s32)MAPI_ALIGN(image_size.height * ratio_coor->y /
        MAPI_OSD_RATIO_COORDINATE_MAX_VALUE, 2); /* 2: y align at 2 pixel */

    return TD_SUCCESS;
}

static td_s32 mapi_osd_update_text_bitmap(td_u32 osd_idx, const hi_mapi_osd_content *osd_content)
{
    td_s32 ret;
    mapi_comm_text_bitmap osd_text = {0};

    if (osd_content->type == HI_MAPI_OSD_TYPE_STRING) {
        osd_text.font_size.width = osd_content->str_content.font_size.width;
        osd_text.font_size.height = osd_content->str_content.font_size.height;
        osd_text.bg_color = osd_content->str_content.bg_color;
    } else {
        osd_text.font_size.width = osd_content->time_content.font_size.width;
        osd_text.font_size.height = osd_content->time_content.font_size.height;
        osd_text.bg_color = osd_content->time_content.bg_color;
    }

    ret = mapi_adapt_osd_get_canvas_info(osd_idx, &osd_text);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get canvas info fail,rgn_hdl[%d] Error Code: [0x%08X]\n",
            osd_idx, ret);
        return ret;
    }

    osd_text.rgn_size.width = g_osd_param[osd_idx].max_size.width;
    osd_text.rgn_size.height = g_osd_param[osd_idx].max_size.height;
    osd_text.font_color = osd_content->color;

    ret = memcpy_s(osd_text.str, sizeof(osd_text.str), g_osd_param[osd_idx].str, sizeof(g_osd_param[osd_idx].str));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memcpy_s", ret);

    ret = mapi_comm_config_text_bitmap(&osd_text, TD_TRUE);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "config text bitmap fail\n");
        return ret;
    }

    ret = mapi_adapt_osd_update_canvas(osd_idx);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "update canvas fail,rgn_hdl[%d] Error Code: [0x%08X]\n",
            osd_idx, ret);
        return ret;
    }

    return ret;
}

static td_s32 mapi_osd_get_chn_bind_info(const hi_mapi_osd_disp_attr *disp_attr, mapi_adapt_osd_chn_bind_info *chn_info)
{
    chn_info->dev_id = (td_s32)disp_attr->mod_hdl;
    chn_info->chn_id = (td_s32)disp_attr->chn_hdl;

    switch (disp_attr->binded_mod) {
        case HI_MAPI_OSD_BINDMOD_VCAP:
        case HI_MAPI_OSD_BINDMOD_VPSS:
        case HI_MAPI_OSD_BINDMOD_DISP:
            chn_info->bind_module = disp_attr->binded_mod;
            break;

        case HI_MAPI_OSD_BINDMOD_STITCH:
#ifdef SUPPORT_AVS
            chn_info->bind_module = disp_attr->binded_mod;
            break;
#else
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "stitch is not support.\n");
            return HI_MAPI_OSD_ENOT_PERM;
#endif

        case HI_MAPI_OSD_BINDMOD_VENC:
            chn_info->bind_module = disp_attr->binded_mod;
            chn_info->dev_id = 0;
            break;

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "invalide bind mode [%d]\n", disp_attr->binded_mod);
            return HI_MAPI_OSD_EILLEGAL_PARAM;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_osd_attach_rgn(td_u32 osd_idx, const hi_mapi_osd_disp_attr *disp_attr,
    const hi_mapi_osd_content *osd_content)
{
    td_s32 ret;
    mapi_adapt_osd_chn_bind_info chn_bind_info;

    ret = mapi_osd_get_chn_bind_info(disp_attr, &chn_bind_info);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get osd bind chn info fail,rgn_hdl[%d] Error Code: [0x%08X]\n",
            osd_idx, ret);
        return ret;
    }

    hi_mapi_point start_pos;
    if (disp_attr->coordinate_mod == HI_MAPI_OSD_COORDINATE_RATIO_COOR) {
        ret = mapi_osd_ratio_to_absolute(&chn_bind_info, &disp_attr->start_pos, &start_pos);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "switch ratio to abs fail,rgn_hdl[%d] Error Code: [0x%08X]\n",
                osd_idx, ret);
            return ret;
        }
    } else {
        start_pos = disp_attr->start_pos;
    }

    mapi_adapt_osd_rgn_chn_attr rgn_chn_attr;
    rgn_chn_attr.content_color = osd_content->color;
    rgn_chn_attr.start_pos.x = start_pos.x;
    rgn_chn_attr.start_pos.y = start_pos.y;
    rgn_chn_attr.content_width = osd_content->circle_content.width;
    rgn_chn_attr.content_height = osd_content->circle_content.height;
    rgn_chn_attr.chn_bind_info.bind_module = chn_bind_info.bind_module;
    rgn_chn_attr.chn_bind_info.dev_id = chn_bind_info.dev_id;
    rgn_chn_attr.chn_bind_info.chn_id = chn_bind_info.chn_id;

    mapi_osd_param *osd_param = &g_osd_param[osd_idx];
    rgn_chn_attr.rgn_type = osd_param->rgn_type;

    ret = mapi_adapt_osd_attach_rgn_to_chn(osd_idx, &rgn_chn_attr, disp_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "attach rgn to chn fail,rgn_hdl[%d] chn[%d,%d,%d] Error Code: [0x%08X]\n",
            osd_idx, chn_bind_info.bind_module, chn_bind_info.dev_id, chn_bind_info.chn_id, ret);
        return ret;
    }

    return TD_SUCCESS;
}

static td_bool mapi_osd_check_if_bind_venc(const hi_mapi_osd_attr *osd_attr)
{
    td_u32 disp_idx;
    for (disp_idx = 0; disp_idx < osd_attr->disp_num; ++disp_idx) {
        if (osd_attr->disp_attr[disp_idx].binded_mod == HI_MAPI_OSD_BINDMOD_VENC) {
            return TD_TRUE;
        }
    }
    return TD_FALSE;
}

static td_s32 mapi_osd_get_max_size(const hi_mapi_osd_attr *osd_attr, hi_mapi_size *osd_size)
{
    td_u32 str_len = (td_u32)strnlen(osd_attr->osd_content.str_content.str, HI_MAPI_MAX_STR_LEN);
    td_u32 width;
    td_u32 height;

    if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_BITMAP) {
        width = osd_attr->osd_content.bitmap_content.width;
        height = osd_attr->osd_content.bitmap_content.height;
    } else if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_STRING) {
        if ((osd_attr->osd_content.str_content.font_size.width != 0) &&
            (str_len > UINT_MAX / osd_attr->osd_content.str_content.font_size.width)) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "has reached the max\n");
            return TD_FAILURE;
        }

        width = str_len * osd_attr->osd_content.str_content.font_size.width;
        height = osd_attr->osd_content.str_content.font_size.height;
    } else if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_CIRCLE) {
        width = osd_attr->osd_content.circle_content.width;
        height = osd_attr->osd_content.circle_content.height;
    } else {
        td_s32 ret;
        td_char time_str[HI_MAPI_MAX_STR_LEN];
        ret = mapi_osd_get_time_str(NULL, time_str, HI_MAPI_MAX_STR_LEN - 1);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get time string failed\n");
            return ret;
        }
        str_len = (td_u32)strnlen(time_str, HI_MAPI_MAX_STR_LEN);
        if ((osd_attr->osd_content.str_content.font_size.width != 0) &&
            (str_len > UINT_MAX / osd_attr->osd_content.time_content.font_size.width)) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "has reached the max\n");
            return TD_FAILURE;
        }

        width = str_len * osd_attr->osd_content.time_content.font_size.width;
        height = osd_attr->osd_content.time_content.font_size.height;
    }

    osd_size->width = width;
    osd_size->height = height;

    return TD_SUCCESS;
}

static mapi_osd_update_state mapi_osd_get_update_state(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr,
    const hi_mapi_size *osd_max_size)
{
    mapi_osd_param *osd_param = &g_osd_param[osd_idx];

    /* return TD_TRUE means go rebuild process */
    if ((osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_BITMAP) ||
        (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_STRING) ||
        (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_TIME)) {
        if (osd_max_size->width > osd_param->max_size.width ||
            osd_max_size->height > osd_param->max_size.height) {
            return MAPI_OSD_UPDATE_STATE_REBUILD;
        }
        /* if the string content is not extend, it will not rebuild for performance */
    }

    if (osd_param->osd_attr.disp_num != osd_attr->disp_num) {
        /* if disp num is added, we need attach new chn */
        return MAPI_OSD_UPDATE_STATE_ATTACH;
    }

    return MAPI_OSD_UPDATE_STATE_DISPLAY;
}

static td_void mapi_osd_get_rgn_attr(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr,
    mapi_adapt_osd_rgn_attr *rgn_attr)
{
    mapi_osd_param *osd_param = &g_osd_param[osd_idx];
    td_u32 str_len = (td_u32)strnlen(osd_param->str, HI_MAPI_MAX_STR_LEN);
    rgn_attr->pixel_format = HI_MAPI_PIXEL_FORMAT_ARGB_1555;

    if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_BITMAP) {
        rgn_attr->pixel_format = osd_attr->osd_content.bitmap_content.pixel_format;
        rgn_attr->rgn_size.width = osd_attr->osd_content.bitmap_content.width;
        rgn_attr->rgn_size.height = osd_attr->osd_content.bitmap_content.height;
        rgn_attr->type = mapi_osd_check_if_bind_venc(osd_attr) ? MAPI_OSD_OVERLAY_RGN : MAPI_OSD_OVERLAYEX_RGN;
    } else if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_TIME) {
        if ((osd_attr->osd_content.str_content.font_size.width != 0) &&
            (str_len > UINT_MAX / osd_attr->osd_content.time_content.font_size.width)) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "has reached the max\n");
            return;
        }

        rgn_attr->rgn_size.width = str_len * osd_attr->osd_content.time_content.font_size.width;
        rgn_attr->rgn_size.height = osd_attr->osd_content.time_content.font_size.height;
        rgn_attr->type = mapi_osd_check_if_bind_venc(osd_attr) ? MAPI_OSD_OVERLAY_RGN : MAPI_OSD_OVERLAYEX_RGN;
    } else if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_STRING) {
        if ((osd_attr->osd_content.str_content.font_size.width != 0) &&
            (str_len > UINT_MAX / osd_attr->osd_content.str_content.font_size.width)) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "has reached the max\n");
            return;
        }

        rgn_attr->rgn_size.width = str_len * osd_attr->osd_content.str_content.font_size.width;
        rgn_attr->rgn_size.height = osd_attr->osd_content.str_content.font_size.height;
        rgn_attr->type = mapi_osd_check_if_bind_venc(osd_attr) ? MAPI_OSD_OVERLAY_RGN : MAPI_OSD_OVERLAYEX_RGN;
    } else {
        rgn_attr->type = MAPI_OSD_COVEREX_RGN;
    }

    rgn_attr->color = osd_attr->osd_content.color;
    rgn_attr->osd_type = osd_attr->osd_content.type;
    osd_param->rgn_type = rgn_attr->type;
    return;
}

static td_s32 mapi_osd_update_rgn_content(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr)
{
    td_s32 ret = TD_SUCCESS;

    if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_BITMAP) {
        ret = mapi_adapt_osd_set_rgn_bitmap(osd_idx, osd_attr);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD,
                "set rgn bitmap fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
            return ret;
        }
    } else if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_TIME ||
        osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_STRING) {
        ret = mapi_osd_update_text_bitmap(osd_idx, &osd_attr->osd_content);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "OSD_UpdateTextBitmap failed\n");
            return ret;
        }
    }

    return ret;
}

static td_s32 mapi_osd_create_rgn(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr)
{
    td_s32 ret;
    td_s32 destroy_ret;
    td_u32 disp_idx;
    mapi_adapt_osd_rgn_attr rgn_attr;

    ret = memset_s(&rgn_attr, sizeof(rgn_attr), 0x0, sizeof(rgn_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

    mapi_osd_get_rgn_attr(osd_idx, osd_attr, &rgn_attr);
    ret = mapi_adapt_osd_create_rgn(osd_idx, &rgn_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "create rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
        return ret;
    }

    ret = mapi_osd_update_rgn_content(osd_idx, osd_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "osd update content fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
        destroy_ret = mapi_adapt_osd_destroy_rgn(osd_idx);
        if (destroy_ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "destroy osd rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
        }
        return ret;
    }

    for (disp_idx = 0; disp_idx < osd_attr->disp_num; ++disp_idx) {
        ret = mapi_osd_attach_rgn(osd_idx, &osd_attr->disp_attr[disp_idx], &osd_attr->osd_content);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "attach rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
            destroy_ret = mapi_adapt_osd_destroy_rgn(osd_idx);
            if (destroy_ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "destroy osd rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
            }
            return ret;
        }
    }

    return TD_SUCCESS;
}

static td_s32 mapi_osd_destroy_rgn(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr)
{
    td_s32 ret;
    td_s32 destroy_ret;
    td_u32 disp_idx;

    for (disp_idx = 0; disp_idx < osd_attr->disp_num; ++disp_idx) {
        ret = mapi_adapt_osd_detach_rgn(osd_idx, &osd_attr->disp_attr[disp_idx]);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "detach rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
            destroy_ret = mapi_adapt_osd_destroy_rgn(osd_idx);
            if (destroy_ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "destroy osd rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
            }
            return ret;
        }
    }

    ret = mapi_adapt_osd_destroy_rgn(osd_idx);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "destroy osd rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
        return ret;
    }

    return TD_SUCCESS;
}

static td_s32 mapi_osd_update_display(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr)
{
    td_s32 ret;
    td_u32 disp_idx;
    mapi_adapt_osd_chn_bind_info chn_bind_info;

    for (disp_idx = 0; disp_idx < osd_attr->disp_num; ++disp_idx) {
        ret = mapi_osd_get_chn_bind_info(&osd_attr->disp_attr[disp_idx], &chn_bind_info);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get osd chn bind info fail,rgn_hdl[%d] Error Code: [0x%08X]\n",
                osd_idx, ret);
            return ret;
        }

        hi_mapi_point start_pos;
        if (osd_attr->disp_attr[disp_idx].coordinate_mod == HI_MAPI_OSD_COORDINATE_RATIO_COOR) {
            ret = mapi_osd_ratio_to_absolute(&chn_bind_info, &osd_attr->disp_attr[disp_idx].start_pos, &start_pos);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "osd switch ratio to abs fail,rgn_hdl[%d] Error Code: [0x%08X]\n",
                    osd_idx, ret);
                return ret;
            }
        } else {
            start_pos = osd_attr->disp_attr[disp_idx].start_pos;
        }

        mapi_adapt_osd_rgn_chn_attr rgn_chn_attr;
        rgn_chn_attr.content_color = osd_attr->osd_content.color;
        rgn_chn_attr.start_pos.x = start_pos.x;
        rgn_chn_attr.start_pos.y = start_pos.y;
        rgn_chn_attr.content_width = osd_attr->osd_content.circle_content.width;
        rgn_chn_attr.content_height = osd_attr->osd_content.circle_content.height;
        rgn_chn_attr.chn_bind_info.bind_module = chn_bind_info.bind_module;
        rgn_chn_attr.chn_bind_info.dev_id = chn_bind_info.dev_id;
        rgn_chn_attr.chn_bind_info.chn_id = chn_bind_info.chn_id;

        ret = mapi_adapt_osd_set_display_attr(osd_idx, &rgn_chn_attr, &osd_attr->disp_attr[disp_idx]);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD,
                "set rgn display attr fail,rgn_hdl[%d] chn[%d,%d,%d] Error Code: [0x%08X]\n",
                osd_idx, chn_bind_info.bind_module, chn_bind_info.dev_id, chn_bind_info.chn_id, ret);
            return ret;
        }
    }

    return TD_SUCCESS;
}

static td_s32 mapi_osd_start(td_u32 osd_idx)
{
    td_s32 ret;
    mapi_osd_param *osd_param = &g_osd_param[osd_idx];

    /* Time OSD: Update time string and bitmap */
    if (osd_param->osd_attr.osd_content.type == HI_MAPI_OSD_TYPE_TIME) {
        ret = mapi_osd_get_time_str(NULL, osd_param->str, HI_MAPI_MAX_STR_LEN - 1);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "osd get time string failed:[0x%08X]\n", ret);
            return ret;
        }
    }

    ret = mapi_osd_create_rgn(osd_idx, &osd_param->osd_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "osd create rgn osd_idx[%d] failed:[0x%08X]\n", osd_idx, ret);
        return ret;
    }

    ret = memcpy_s(&osd_param->old_osd_attr, sizeof(osd_param->old_osd_attr),
        &osd_param->osd_attr, sizeof(osd_param->osd_attr));
    if (ret != EOK) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "memcpy_s failed:[0x%08X]\n", ret);
        (td_void)mapi_osd_destroy_rgn(osd_idx, &osd_param->osd_attr);
        return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
    }

    osd_param->is_start = TD_TRUE;
    return TD_SUCCESS;
}

static td_s32 mapi_osd_stop(td_u32 osd_idx)
{
    td_s32 ret;
    mapi_osd_param *osd_param = &g_osd_param[osd_idx];

    ret = mapi_osd_destroy_rgn(osd_idx, &osd_param->osd_attr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "osd destroy rgn osd_idx[%d] failed:[0x%08X]\n", osd_idx, ret);
        return ret;
    }

    osd_param->is_start = TD_FALSE;
    return TD_SUCCESS;
}

static td_s32 mapi_osd_check_stitch_mode_attr(const hi_mapi_osd_attr *osd_attr)
{
#ifdef SUPPORT_AVS
    td_u32 i;
    td_s32 ret;
    hi_mapi_vpss_stitch_mode stitch_mode;

    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, osd_attr, HI_MAPI_OSD_ENULL_PTR);

    for (i = 0; i < HI_MAPI_OSD_MAX_DISP_CNT; i++) {
        if ((osd_attr->disp_attr[i].binded_mod == HI_MAPI_OSD_BINDMOD_STITCH) &&
            (osd_attr->disp_attr[i].coordinate_mod == HI_MAPI_OSD_COORDINATE_RATIO_COOR)) {
            ret = mapi_adapt_osd_get_stitch_mode(osd_attr->disp_attr[i].mod_hdl, &stitch_mode);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "get stitch mode fail, stitchHdl[%d] Error Code: [0x%08X]\n",
                    osd_attr->disp_attr[i].mod_hdl, ret);
                return ret;
            }

            if (stitch_mode != HI_MAPI_VPSS_STITCH_MODE_BLEND) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "not support ratio coordinate when stitch mode is BLEND.\n");
                return HI_MAPI_OSD_EILLEGAL_PARAM;
            }
        }
    }
#else
    MAPI_UNUSED(osd_attr);
#endif

    return TD_SUCCESS;
}

static td_s32 mapi_osd_check_attr(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr)
{
    td_s32 ret;
    /* Check Input Param */
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, osd_attr, HI_MAPI_OSD_ENULL_PTR);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_idx < HI_MAPI_OSD_MAX_CNT, HI_MAPI_OSD_EHANDLE_ILLEGAL);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_attr->disp_num != 0, HI_MAPI_OSD_EILLEGAL_PARAM);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_attr->disp_num <= HI_MAPI_OSD_MAX_DISP_CNT, HI_MAPI_OSD_EILLEGAL_PARAM);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_attr->osd_content.type < HI_MAPI_OSD_TYPE_BUTT, HI_MAPI_OSD_EILLEGAL_PARAM);

    td_u32 i;
    for (i = 0; i < osd_attr->disp_num; i++) {
        CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_attr->disp_attr[i].binded_mod < HI_MAPI_OSD_BINDMOD_BUTT,
            HI_MAPI_OSD_EILLEGAL_PARAM);
        CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_attr->disp_attr[i].coordinate_mod <= HI_MAPI_OSD_COORDINATE_ABS_COOR,
            HI_MAPI_OSD_EILLEGAL_PARAM);
        if (osd_attr->disp_attr[i].binded_mod == HI_MAPI_OSD_BINDMOD_VENC) {
            CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_attr->disp_attr[i].attach_dest < HI_MAPI_ATTACH_JPEG_BUTT,
                HI_MAPI_OSD_EILLEGAL_PARAM);
        }

        if ((osd_attr->disp_attr[i].binded_mod == HI_MAPI_OSD_BINDMOD_STITCH) &&
            (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_CIRCLE)) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "stitch module not support circle.\n");
            return HI_MAPI_OSD_EILLEGAL_PARAM;
        }

        if ((osd_attr->disp_attr[i].binded_mod == HI_MAPI_OSD_BINDMOD_VENC) &&
            (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_CIRCLE)) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "venc module not support circle.\n");
            return HI_MAPI_OSD_EILLEGAL_PARAM;
        }
    }

    const mapi_comm_font_mod_attr *font_mod_attr = mapi_sys_get_font_mod_attr();
    if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_TIME) {
        CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_attr->osd_content.time_content.time_fmt < HI_MAPI_OSD_TIMEFMT_BUTT,
            HI_MAPI_OSD_EILLEGAL_PARAM);
        CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, font_mod_attr->is_init, HI_MAPI_OSD_ENOFONT);
    } else if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_BITMAP) {
        CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, osd_attr->osd_content.bitmap_content.data, HI_MAPI_OSD_ENULL_PTR);
    } else if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_STRING) {
        CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, font_mod_attr->is_init, HI_MAPI_OSD_ENOFONT);
    }

    ret = mapi_osd_check_stitch_mode_attr(osd_attr);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, ret == TD_SUCCESS, ret);

    return TD_SUCCESS;
}

static td_s32 mapi_osd_update_content(td_u32 osd_idx)
{
    td_s32 ret;

    if (g_osd_param[osd_idx].osd_attr.osd_content.type == HI_MAPI_OSD_TYPE_TIME) {
        ret = mapi_osd_get_time_str(TD_NULL, g_osd_param[osd_idx].str, HI_MAPI_MAX_STR_LEN - 1);
        CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "osd get time string fail", ret);
    }

    /* rebuild RGN */
    if (g_osd_param[osd_idx].update_state == MAPI_OSD_UPDATE_STATE_REBUILD) {
        /* clear update state, preventing repeated errors */
        g_osd_param[osd_idx].update_state = MAPI_OSD_UPDATE_STATE_BUTT;

        ret = mapi_osd_destroy_rgn(osd_idx, &g_osd_param[osd_idx].old_osd_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "osd destroy rgn fail", ret);

        ret = mapi_osd_create_rgn(osd_idx, &g_osd_param[osd_idx].osd_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "osd create rgn fail", ret);
    } else if (g_osd_param[osd_idx].update_state == MAPI_OSD_UPDATE_STATE_DISPLAY) {
        /* clear update state, preventing repeated errors */
        g_osd_param[osd_idx].update_state = MAPI_OSD_UPDATE_STATE_BUTT;
        ret = mapi_osd_update_rgn_content(osd_idx, &g_osd_param[osd_idx].osd_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "update rgn content fail", ret);

        ret = mapi_osd_update_display(osd_idx, &g_osd_param[osd_idx].osd_attr);
        CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "update display fail fail", ret);
    } else {
        /* clear update state, preventing repeated errors */
        g_osd_param[osd_idx].update_state = MAPI_OSD_UPDATE_STATE_BUTT;
        for (td_u32 i = 0; i < g_osd_param[osd_idx].old_osd_attr.disp_num; ++i) {
            ret = mapi_adapt_osd_detach_rgn(osd_idx, &g_osd_param[osd_idx].old_osd_attr.disp_attr[i]);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "detach rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
                return ret;
            }
        }

        for (td_u32 i = 0; i < g_osd_param[osd_idx].osd_attr.disp_num; ++i) {
            ret = mapi_osd_attach_rgn(osd_idx, &g_osd_param[osd_idx].osd_attr.disp_attr[i],
                &g_osd_param[osd_idx].osd_attr.osd_content);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "attach rgn fail,rgn_hdl[%d] Error Code: [0x%08X]\n", osd_idx, ret);
                return ret;
            }
        }
    }

    ret = memcpy_s(&g_osd_param[osd_idx].old_osd_attr, sizeof(g_osd_param[osd_idx].old_osd_attr),
        &g_osd_param[osd_idx].osd_attr, sizeof(g_osd_param[osd_idx].osd_attr));
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memcpy_s", ret);

    return TD_SUCCESS;
}

/* This command is used to update the OSD content when the OSD is started. */
static td_void *mapi_osd_update_content_thread(td_void *param)
{
    MAPI_UNUSED(param);
    td_s32 ret;
    td_u32 osd_idx;
    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)__FUNCTION__, 0, 0, 0);

    while (g_osd_run) {
        /* if osd updated */
        td_bool osd_update_flg = TD_FALSE;
        for (osd_idx = 0; osd_idx < HI_MAPI_OSD_MAX_CNT; ++osd_idx) {
            MAPI_MUTEX_LOCK(g_osd_param[osd_idx].mutex_lock);
            if (g_osd_param[osd_idx].is_start && (g_osd_param[osd_idx].update_state != MAPI_OSD_UPDATE_STATE_BUTT)) {
                osd_update_flg = TD_TRUE;

                ret = mapi_osd_update_content(osd_idx);
                CHECK_MAPI_PRINT(HI_MAPI_MOD_OSD, "osd update content fail", ret);
                MAPI_MUTEX_UNLOCK(g_osd_param[osd_idx].mutex_lock);
                continue;
            }
            MAPI_MUTEX_UNLOCK(g_osd_param[osd_idx].mutex_lock);
        }

        /* wait osd update event */
        if (!osd_update_flg) {
            mapi_osd_usleep(MAPI_ADEC_WAIT_TIME_CHANGE_USLEEP_TIME);
        }
    }

    return TD_NULL;
}

static td_void mapi_osd_update_time_display(const struct tm *local_time)
{
    td_s32 ret;
    td_u32 osd_idx;

    for (osd_idx = 0; osd_idx < HI_MAPI_OSD_MAX_CNT; ++osd_idx) {
        MAPI_MUTEX_LOCK(g_osd_param[osd_idx].mutex_lock);
        if (g_osd_param[osd_idx].osd_attr.osd_content.type == HI_MAPI_OSD_TYPE_TIME &&
            g_osd_param[osd_idx].is_start) {
            /* 1. update osd time string */
            ret = mapi_osd_get_time_str(local_time, g_osd_param[osd_idx].str, HI_MAPI_MAX_STR_LEN - 1);
            if (ret != TD_SUCCESS) {
                MAPI_MUTEX_UNLOCK(g_osd_param[osd_idx].mutex_lock);
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "osd get time string failed\n");
                continue;
            }

            /* 2. update osd text bitmap */
            ret = mapi_osd_update_text_bitmap(osd_idx, &g_osd_param[osd_idx].osd_attr.osd_content);
            if (ret != TD_SUCCESS) {
                MAPI_MUTEX_UNLOCK(g_osd_param[osd_idx].mutex_lock);
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "update text bitmap failed\n");
                continue;
            }

            /* 3. update osd display attribute */
            ret = mapi_osd_update_display(osd_idx, &g_osd_param[osd_idx].osd_attr);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "update display attribute failed\n");
            }
        }
        MAPI_MUTEX_UNLOCK(g_osd_param[osd_idx].mutex_lock);
    }
}

/* This command is used to update the time OSD content when the OSD is started. */
static td_void *mapi_osd_time_update_thread(td_void *param)
{
    MAPI_UNUSED(param);
    time_t now_time = 0;
    time_t last_time = 0;
    struct tm local_time = {
        0,
    };
    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)__FUNCTION__, 0, 0, 0);

    while (g_osd_run) {
        (td_void)time(&now_time);

        if (now_time == last_time) {
            (td_void)mapi_osd_usleep(MAPI_ADEC_WAIT_TIME_CHANGE_USLEEP_TIME);
            continue;
        } else {
            (td_void)localtime_r(&now_time, &local_time);
            mapi_osd_update_time_display(&local_time);
            last_time = now_time; /* update last time */
        }

        mapi_osd_usleep(MAPI_ADEC_WAIT_UPDATE_TIME_USLEEP_TIME);
    }

    return TD_NULL;
}

td_s32 hi_mapi_osd_init(td_void)
{
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_OSD_ENOT_INITED);

    if (g_osd_init_flg) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "The OSD has been initialized.\n");
        return TD_SUCCESS;
    }

    td_u32 osd_idx;

    /* Init osd Param */
    for (osd_idx = 0; osd_idx < HI_MAPI_OSD_MAX_CNT; ++osd_idx) {
        MAPI_MUTEX_INIT_LOCK(g_osd_param[osd_idx].mutex_lock);

        MAPI_MUTEX_LOCK(g_osd_param[osd_idx].mutex_lock);
        td_s32 ret = memset_s(&g_osd_param[osd_idx].osd_attr, sizeof(hi_mapi_osd_attr), 0, sizeof(hi_mapi_osd_attr));
        CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_OSD, "memset_s", ret, g_osd_param[osd_idx].mutex_lock);

        ret = memset_s(&g_osd_param[osd_idx].max_size, sizeof(hi_mapi_size), 0, sizeof(hi_mapi_size));
        CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_OSD, "memset_s", ret, g_osd_param[osd_idx].mutex_lock);
        g_osd_param[osd_idx].is_init = TD_FALSE;
        g_osd_param[osd_idx].is_start = TD_FALSE;
        g_osd_param[osd_idx].update_state = MAPI_OSD_UPDATE_STATE_BUTT;
        g_osd_param[osd_idx].rgn_type = MAPI_OSD_RGN_BUTT;

        ret = memset_s(&g_osd_param[osd_idx].str, sizeof(td_char) * HI_MAPI_MAX_STR_LEN, 0,
            sizeof(td_char) * HI_MAPI_MAX_STR_LEN);
        MAPI_MUTEX_UNLOCK(g_osd_param[osd_idx].mutex_lock);
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);
    }

    g_osd_run = TD_TRUE;
    td_s32 ret = pthread_create(&g_osd_content_tsk_id, NULL, mapi_osd_update_content_thread, NULL);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "create update osd content thread failed.\n");
        return HI_MAPI_OSD_ENOMEM;
    }

    const mapi_comm_font_mod_attr *font_mod_attr = mapi_sys_get_font_mod_attr();
    if (font_mod_attr->is_init) {
        /* create Time OSD Update Thread */
        ret = pthread_create(&g_osd_time_tsk_id, NULL, mapi_osd_time_update_thread, NULL);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "create update osd time thread failed.\n");
            return HI_MAPI_OSD_ENOMEM;
        }
    }

    g_osd_init_flg = TD_TRUE;
    return TD_SUCCESS;
}

td_s32 hi_mapi_osd_deinit(td_void)
{
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_OSD_ENOT_INITED);

    if (!g_osd_init_flg) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "The OSD is not initialized.\n");
        return HI_MAPI_OSD_ENOT_INITED;
    }

    if (g_osd_time_tsk_id != 0) {
        /* Destroy Time OSD Update Task */
        g_osd_run = TD_FALSE;
        pthread_join(g_osd_time_tsk_id, NULL);
    }

    if (g_osd_content_tsk_id != 0) {
        /* Destroy OSD Update content Task */
        g_osd_run = TD_FALSE;
        pthread_join(g_osd_content_tsk_id, NULL);
    }

    td_u32 osd_idx;
    td_s32 ret;
    for (osd_idx = 0; osd_idx < HI_MAPI_OSD_MAX_CNT; ++osd_idx) {
        MAPI_MUTEX_LOCK(g_osd_param[osd_idx].mutex_lock);
        /* stop Osd */
        if (g_osd_param[osd_idx].is_start) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "OSD[%d] is started, try stop.\n", osd_idx);
            ret = mapi_osd_stop(osd_idx);
            if (ret != TD_SUCCESS) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "OSD[%d] stop error:%#x\n", osd_idx, ret);
            }
        }

        MAPI_MUTEX_UNLOCK(g_osd_param[osd_idx].mutex_lock);
        MAPI_MUTEX_DESTROY(g_osd_param[osd_idx].mutex_lock);
    }

    g_osd_init_flg = TD_FALSE;

    return TD_SUCCESS;
}

static td_s32 mapi_osd_save_str_content(const hi_mapi_osd_attr *osd_attr, mapi_osd_param *osd_param)
{
    td_s32 ret;

    if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_STRING) {
        ret = memset_s(osd_param->str, HI_MAPI_MAX_STR_LEN, 0, HI_MAPI_MAX_STR_LEN);
        CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memset_s", ret);

        ret = snprintf_s(osd_param->str, HI_MAPI_MAX_STR_LEN, HI_MAPI_MAX_STR_LEN - 1, "%s",
            osd_attr->osd_content.str_content.str);
        if (ret == TD_FAILURE) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "snprintf_s fail, Error Code: [0x%08X]\n", ret);
            return HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL;
        }
    } else if (osd_attr->osd_content.type == HI_MAPI_OSD_TYPE_TIME) {
        ret = mapi_osd_get_time_str(NULL, osd_param->str, HI_MAPI_MAX_STR_LEN - 1);
        if (ret != TD_SUCCESS) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "osd get time str fail, Error Code: [0x%08X]\n", ret);
            return ret;
        }
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_osd_set_attr(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr)
{
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, osd_attr, HI_MAPI_OSD_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_OSD, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_OSD_ENOT_INITED);

    /* Check Module Init or not */
    if (!g_osd_init_flg) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "The OSD is not initialized.\n");
        return HI_MAPI_OSD_ENOT_INITED;
    }

    td_s32 ret = mapi_osd_check_attr(osd_idx, osd_attr);
    CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "mapi_osd_check_attr", ret);

    hi_mapi_size osd_max_size;
    mapi_osd_param *osd_param = &g_osd_param[osd_idx];

    ret = mapi_osd_get_max_size(osd_attr, &osd_max_size);
    CHECK_MAPI_RET(HI_MAPI_MOD_OSD, "mapi_osd_get_max_size", ret);

    MAPI_MUTEX_LOCK(osd_param->mutex_lock);
    /* attr do not save time osd str ,so will use osd_param->str save time osd and str osd content */
    ret = mapi_osd_save_str_content(osd_attr, osd_param);
    if (ret != TD_SUCCESS) {
        MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "osd save str content fail, Error Code: [0x%08X]\n", ret);
        return ret;
    }

    td_bool is_start = osd_param->is_start;
    if (is_start) {
        mapi_osd_update_state update_state = mapi_osd_get_update_state(osd_idx, osd_attr, &osd_max_size);
        if (osd_param->update_state != MAPI_OSD_UPDATE_STATE_REBUILD) {
            osd_param->update_state = update_state;
        }
        if (update_state == MAPI_OSD_UPDATE_STATE_REBUILD) {
            osd_param->max_size.width = osd_max_size.width;
            osd_param->max_size.height = osd_max_size.height;
        }
    } else {
        osd_param->max_size.width = osd_max_size.width;
        osd_param->max_size.height = osd_max_size.height;
    }

    ret = memcpy_s(&osd_param->osd_attr, sizeof(osd_param->osd_attr), osd_attr, sizeof(hi_mapi_osd_attr));
    CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_OSD, "memcpy_s", ret, osd_param->mutex_lock);
    osd_param->is_init = TD_TRUE;
    MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);

    return TD_SUCCESS;
}

td_s32 hi_mapi_osd_get_attr(td_u32 osd_idx, hi_mapi_osd_attr *osd_attr)
{
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_OSD, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_OSD_ENOT_INITED);

    /* Check Module Init or not */
    if (!g_osd_init_flg) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "The OSD is not initialized.\n");
        return HI_MAPI_OSD_ENOT_INITED;
    }

    /* Check Input Param */
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_idx < HI_MAPI_OSD_MAX_CNT, HI_MAPI_OSD_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_OSD, osd_attr, HI_MAPI_OSD_ENULL_PTR);

    mapi_osd_param *osd_param = &g_osd_param[osd_idx];
    MAPI_MUTEX_LOCK(osd_param->mutex_lock);

    /* Check OSD Attrbute init or not */
    if (!osd_param->is_init) {
        MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "OSD[%d] attributes are not set!\n", osd_idx);
        return HI_MAPI_OSD_ENOT_PERM;
    }

    td_s32 ret = memcpy_s(osd_attr, sizeof(hi_mapi_osd_attr), &osd_param->osd_attr, sizeof(osd_param->osd_attr));
    MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
    CHECK_MAPI_SAFEFUNC_RET(HI_MAPI_MOD_OSD, "memcpy_s", ret);
    return TD_SUCCESS;
}

td_s32 hi_mapi_osd_start(td_u32 osd_idx)
{
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_OSD_ENOT_INITED);

    /* Check Module Init or not */
    if (!g_osd_init_flg) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "The OSD is not initialized.\n");
        return HI_MAPI_OSD_ENOT_INITED;
    }
    /* Check Input Param */
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_idx < HI_MAPI_OSD_MAX_CNT, HI_MAPI_OSD_EHANDLE_ILLEGAL);

    td_s32 ret;
    mapi_osd_param *osd_param = &g_osd_param[osd_idx];

    MAPI_MUTEX_LOCK(osd_param->mutex_lock);

    /* Check OSD Attrbute init or not */
    if (!osd_param->is_init) {
        MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "OSD[%d] attributes are not set!\n", osd_idx);
        return HI_MAPI_OSD_ENOT_PERM;
    }

    /* Check OSD stop or not */
    if (osd_param->is_start) {
        MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
        MAPI_INFO_TRACE(HI_MAPI_MOD_OSD, "OSD[%d] has already is_start!\n", osd_idx);
        return TD_SUCCESS;
    }

    ret = mapi_osd_start(osd_idx);
    MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
    return ret;
}

td_s32 hi_mapi_osd_stop(td_u32 osd_idx)
{
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_OSD_ENOT_INITED);

    /* Check Module Init or not */
    if (!g_osd_init_flg) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "The OSD is not initialized.\n");
        return HI_MAPI_OSD_ENOT_INITED;
    }
    /* Check Input Param */
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_OSD, osd_idx < HI_MAPI_OSD_MAX_CNT, HI_MAPI_OSD_EHANDLE_ILLEGAL);

    td_s32 ret;
    mapi_osd_param *osd_param = &g_osd_param[osd_idx];

    MAPI_MUTEX_LOCK(osd_param->mutex_lock);

    /* Check OSD Attrbute init or not */
    if (!osd_param->is_init) {
        MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
        return TD_SUCCESS;
    }

    /* Check OSD stop or not */
    if (!osd_param->is_start) {
        MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
        return TD_SUCCESS;
    }

    ret = mapi_osd_stop(osd_idx);
    if (ret == TD_SUCCESS) {
        osd_param->max_size.width = 0;
        osd_param->max_size.height = 0;
    }
    MAPI_MUTEX_UNLOCK(osd_param->mutex_lock);
    return ret;
}

td_s32 hi_mapi_osd_batch(td_u32 batch_id, td_bool show)
{
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_OSD_ENOT_INITED);

    if (!g_osd_init_flg) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_OSD, "The OSD is not initialized.\n");
        return HI_MAPI_OSD_ENOT_INITED;
    }

    td_u32 osd_idx;
    td_u32 disp_idx;
    td_bool update_content_flg;

    for (osd_idx = 0; osd_idx < HI_MAPI_OSD_MAX_CNT; ++osd_idx) {
        if (!g_osd_param[osd_idx].is_start) {
            continue;
        }

        update_content_flg = TD_FALSE;
        MAPI_MUTEX_LOCK(g_osd_param[osd_idx].mutex_lock);
        for (disp_idx = 0; disp_idx < g_osd_param[osd_idx].osd_attr.disp_num; ++disp_idx) {
            if (g_osd_param[osd_idx].osd_attr.disp_attr[disp_idx].batch_id == batch_id) {
                update_content_flg = TD_TRUE;
                g_osd_param[osd_idx].osd_attr.disp_attr[disp_idx].show = show;
            }
        }

        /* nonentity batch, no need update display */
        if (update_content_flg == TD_TRUE) {
            mapi_osd_update_display(osd_idx, &g_osd_param[osd_idx].osd_attr);
        }
        MAPI_MUTEX_UNLOCK(g_osd_param[osd_idx].mutex_lock);
    }

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
