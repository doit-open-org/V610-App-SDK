/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "hi_mapi_disp_define.h"
#include "hi_mapi_disp_arch.h"
#include "mapi_disp_adapt.h"
#include "mapi_disp_arch.h"
#include "hi_mw_log.h"
#include "mapi_comm_inner.h"
#include "hi_log.h"
#include "securec.h"
#ifdef SUPPORT_LVGL
#include <stdint.h>
#include <arm_neon.h>
#include "lvgl.h"
#include "pthread.h"
#include "unistd.h"
#include "stdlib.h"
#include "fcntl.h"
#include "ot_math.h"
#endif

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#ifdef SUPPORT_LVGL
#define DRM_CARD0  "/dev/dri/card0"

/* ---- Kernel backlight control ---- */
#define BL_BRIGHTNESS_PATH      "/sys/class/backlight/backlight/brightness"
#define BL_MAX_BRIGHTNESS_PATH  "/sys/class/backlight/backlight/max_brightness"
#define BL_PERCENT_MAX      100
#define BL_LEVEL_MIN        1
#define BL_BUF_SIZE         8   /* fits "100\0" with margin */

/* ---- Video pipeline types (internal to arch) ---- */
#define MAPI_DISP_RGB565_BUF_COUNT          2
#define MAPI_DISP_VIDEO_FLUSH_PERIOD_MS     33
typedef struct {
    td_s32 queue[MAPI_DISP_RGB565_BUF_COUNT];
    td_s32 head;
    td_s32 tail;
    td_s32 count;
    td_s32 stopped;
    pthread_mutex_t mutex;
    pthread_cond_t not_full;
} mapi_disp_bounded_queue;

typedef struct {
    mapi_disp_bounded_queue free_queue;
    mapi_disp_bounded_queue ready_queue;
} mapi_disp_rgb565_slot_pool;

typedef struct {
    td_phys_addr_t phys_addr;
    td_void *virt_addr;
    td_u32 size;
} mapi_disp_ive_temp_buf;

typedef struct {
    void *img_obj;          /* lv_obj_t *  — child of video_screen */
    void *img_dsc;          /* lv_image_dsc_t * (calloc'd) */
    void *flush_timer;      /* lv_timer_t * driving set_video_frame */
    td_s32 displaying_idx;  /* rgb565 slot currently shown; -1 if none */
} mapi_disp_lvgl_video_flush_ctx;

typedef struct {
    mapi_disp_rgb565_slot_pool      pool;
    mapi_disp_ive_temp_buf          ive_temp;
    mapi_disp_lvgl_video_flush_ctx  flush;
} mapi_disp_video_pipeline_ctx;

typedef struct {
    td_u8 *rgb565_buf[MAPI_DISP_RGB565_BUF_COUNT];
    void  *video_screen;
    td_s32 video_screen_ref_cnt;
    mapi_disp_video_pipeline_ctx video_pipeline;
    td_u32 vl_width;
    td_u32 vl_height;
    hi_mapi_disp_window_attr wnd_attr;  /* current video window rect + priority */
} mapi_disp_arch_ctx;

static mapi_disp_arch_ctx g_disp_arch_ctx[HI_MAPI_DISP_MAX_NUM];

/* ---- LVGL thread state ---- */
static pthread_t        g_lvgl_thread;
static pthread_t        g_lvgl_tick_thread;
static volatile td_bool g_lvgl_running = TD_FALSE;
static pthread_mutex_t  g_disp_pipeline_lock = PTHREAD_MUTEX_INITIALIZER;

/* ---- Backlight ---- */
static void set_backlight(int percent)
{
    FILE *fp;
    char buf[BL_BUF_SIZE];
    int level;

    if (percent < 0) {
        percent = 0;
    }
    if (percent > BL_PERCENT_MAX) {
        percent = BL_PERCENT_MAX;
    }
    /* percent 0 -> level 1: brightness-levels[0] is off, keep panel lit */
    level = (percent == 0) ? BL_LEVEL_MIN : percent;
    snprintf(buf, sizeof(buf), "%d", level);
    fp = fopen(BL_BRIGHTNESS_PATH, "w");
    if (fp != NULL) {
        if (fputs(buf, fp) == EOF) {
            fprintf(stderr, "[backlight] write failed: %s\n", BL_BRIGHTNESS_PATH);
        }
        fclose(fp);
    } else {
        fprintf(stderr, "[backlight] open failed: %s\n", BL_BRIGHTNESS_PATH);
    }
}

static void backlight_init(void)
{
    /* Validate that the kernel's max_brightness matches our compile-time
     * assumption.  A mismatch means the DTS brightness-levels array was
     * changed without updating BL_PERCENT_MAX (or the slider range). */
    FILE *fp = fopen(BL_MAX_BRIGHTNESS_PATH, "r");
    if (fp != NULL) {
        int max_brightness = 0;
        if (fscanf(fp, "%d", &max_brightness) == 1 &&
            max_brightness != BL_PERCENT_MAX) {
            fprintf(stderr, "[backlight] WARNING: max_brightness=%d but "
                    "BL_PERCENT_MAX=%d; slider range and DTS mismatch!\n",
                    max_brightness, BL_PERCENT_MAX);
        }
        fclose(fp);
    }
    set_backlight(BL_PERCENT_MAX); /* sync hardware with slider default */
}

static void backlight_deinit(void)
{
    /* Write brightness index 0 (brightness-levels[0] = off) so the backlight
     * goes dark when the process exits, not frozen at the last slider value. */
    FILE *fp = fopen(BL_BRIGHTNESS_PATH, "w");
    if (fp != NULL) {
        fputs("0", fp);
        fclose(fp);
    }
}

static lv_display_t *create_drm_display(const char *device)
{
    lv_display_t *disp = lv_linux_drm_create();
    if (!disp) {
        return NULL;
    }
    if (lv_linux_drm_set_file(disp, device, -1) != LV_RESULT_OK) {
        lv_display_delete(disp);
        return NULL;
    }
    return disp;
}

static void discovery_cb(lv_indev_t *indev, lv_evdev_type_t type, void *user_data)
{
    LV_LOG_USER("new '%s' device discovered", type == LV_EVDEV_TYPE_REL ? "REL" :
                type == LV_EVDEV_TYPE_ABS ? "ABS" :
                type == LV_EVDEV_TYPE_KEY ? "KEY" :
                "unknown");

    lv_display_t *disp = user_data;
    lv_indev_set_display(indev, disp);
}

static void init_evdev_display(lv_display_t *display)
{
    const char *input_device = getenv("LV_LINUX_EVDEV_POINTER_DEVICE");

    if (input_device == NULL) {
        HI_LOGI("disp", "Using evdev automatic discovery");
        lv_evdev_discovery_start(discovery_cb, display);
        return;
    }

    lv_indev_t *indev = lv_evdev_create(LV_INDEV_TYPE_POINTER, input_device);
    if (indev == NULL) {
        return;
    }
    lv_indev_set_display(indev, display);
}

static void *lvgl_thread_func(void *arg)
{
    uint32_t idle_time;
    (void)arg;

    while (g_lvgl_running) {
        idle_time = lv_timer_handler();
        if (!g_lvgl_running)
            break;
        if (idle_time > 500)
            idle_time = 500;
        usleep(idle_time * 1000);
    }
    return NULL;
}

static void *lvgl_tick_thread_func(void *arg)
{
    (void)arg;
    while (g_lvgl_running) {
        usleep(5000);
        if (g_lvgl_running)
            lv_tick_inc(5);
    }
    return NULL;
}

static void create_lvgl_tick_thread(void)
{
    if (pthread_create(&g_lvgl_tick_thread, NULL, lvgl_tick_thread_func, NULL) != 0) {
        fprintf(stderr, "[lvgl] tick thread create failed\n");
    }
}

static void create_lvgl_main_thread(void)
{
    if (pthread_create(&g_lvgl_thread, NULL, lvgl_thread_func, NULL) != 0) {
        fprintf(stderr, "[lvgl] thread create failed\n");
        g_lvgl_running = TD_FALSE;
    }
}

static void destroy_lvgl_thread(void)
{
    g_lvgl_running = TD_FALSE;
    pthread_join(g_lvgl_tick_thread, NULL);
    pthread_join(g_lvgl_thread, NULL);
}

/* ---- LVGL init/deinit (static, called only from arch interface) ---- */
static td_s32 hal_mapi_disp_lvgl_init(td_handle disp_hdl)
{
    lv_init();
    lv_display_t *disp = create_drm_display(DRM_CARD0);
    if (disp == NULL) {
        fprintf(stderr, "DRM create failed\n");
        lv_deinit();
        return TD_FAILURE;
    }
    init_evdev_display(disp);

    /* 设置默认界面背景色为黑色 */
    lv_obj_t *boot_scr = lv_display_get_screen_active(disp);
    if (boot_scr != NULL) {
        lv_obj_set_style_bg_color(boot_scr, lv_color_black(), 0);
        lv_obj_set_style_bg_opa(boot_scr, LV_OPA_COVER, 0);
    }

    backlight_init();
    lv_timer_t *refr_timer = lv_display_get_refr_timer(disp);
    if (refr_timer != NULL) {
        lv_timer_pause(refr_timer);
    }
    g_lvgl_running = TD_TRUE;
    create_lvgl_tick_thread();
    create_lvgl_main_thread();
    return TD_SUCCESS;
}

static td_s32 hal_mapi_disp_lvgl_deinit(td_handle disp_hdl)
{
    destroy_lvgl_thread();
    if (g_disp_arch_ctx[disp_hdl].video_screen != NULL) {
        lv_lock();
        lv_obj_delete((lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_screen);
        lv_unlock();
        g_disp_arch_ctx[disp_hdl].video_screen = NULL;
    }
    backlight_deinit();
    lv_deinit();
    return TD_SUCCESS;
}

static td_void mapi_disp_free_rgb_bufs(td_handle disp_hdl)
{
    td_s32 i;
    for (i = 0; i < MAPI_DISP_RGB565_BUF_COUNT; i++) {
        if (g_disp_arch_ctx[disp_hdl].rgb565_buf[i] != NULL) {
            free(g_disp_arch_ctx[disp_hdl].rgb565_buf[i]);
            g_disp_arch_ctx[disp_hdl].rgb565_buf[i] = NULL;
        }
    }
}

static td_void mapi_disp_queue_init(mapi_disp_bounded_queue *q)
{
    q->head = 0;
    q->tail = 0;
    q->count = 0;
    q->stopped = 0;
    pthread_mutex_init(&q->mutex, NULL);
    pthread_cond_init(&q->not_full, NULL);
}

static td_void mapi_disp_queue_stop(mapi_disp_bounded_queue *q)
{
    pthread_mutex_lock(&q->mutex);
    q->stopped = 1;
    pthread_cond_broadcast(&q->not_full);
    pthread_mutex_unlock(&q->mutex);
}

static td_void mapi_disp_queue_destroy(mapi_disp_bounded_queue *q)
{
    pthread_mutex_destroy(&q->mutex);
    pthread_cond_destroy(&q->not_full);
}

static td_void mapi_disp_queue_enqueue(mapi_disp_bounded_queue *q, td_s32 buf_index)
{
    pthread_mutex_lock(&q->mutex);
    while (q->count == MAPI_DISP_RGB565_BUF_COUNT && !q->stopped) {
        pthread_cond_wait(&q->not_full, &q->mutex);
    }
    if (!q->stopped) {
        q->queue[q->tail] = buf_index;
        q->tail = (q->tail + 1) % MAPI_DISP_RGB565_BUF_COUNT;
        q->count++;
    }
    pthread_mutex_unlock(&q->mutex);
}

static td_s32 mapi_disp_queue_dequeue(mapi_disp_bounded_queue *q, td_s32 *buf_index)
{
    td_s32 ret;

    pthread_mutex_lock(&q->mutex);
    if (q->count == 0) {
        *buf_index = -1;
        ret = -1;
    } else {
        *buf_index = q->queue[q->head];
        q->head = (q->head + 1) % MAPI_DISP_RGB565_BUF_COUNT;
        q->count--;
        pthread_cond_signal(&q->not_full);
        ret = 0;
    }
    pthread_mutex_unlock(&q->mutex);
    return ret;
}

static td_void mapi_disp_rgb888_to_rgb565_neon(td_u32 width, td_u32 height,
    td_u8 *bgr888_addr, td_u8 *rgb565_addr)
{
    uint8_t *src = bgr888_addr;
    uint16_t *dst = (uint16_t *)rgb565_addr;
    int count = (int)(height * width);

    while (count >= 8) {
        uint8x8x3_t vsrc;
        uint16x8_t vdst;

        vsrc = vld3_u8(src);
        vdst = vshll_n_u8(vsrc.val[0], 8);
        vdst = vsriq_n_u16(vdst, vshll_n_u8(vsrc.val[1], 8), 5);
        vdst = vsriq_n_u16(vdst, vshll_n_u8(vsrc.val[2], 8), 11);
        vst1q_u16(dst, vdst);

        dst += 8;
        src += 8 * 3;
        count -= 8;
    }
}

static td_s32 mapi_disp_alloc_ive_temp_vb(td_handle disp_hdl)
{
    mapi_disp_ive_temp_buf *ive = &g_disp_arch_ctx[disp_hdl].video_pipeline.ive_temp;
    td_handle pool_hdl = OT_VB_INVALID_POOL_ID;
    td_u64 phys_addr;
    td_void *virt_addr;
    td_s32 ret;

    ive->size = (td_u32)(OT_ALIGN_UP(g_disp_arch_ctx[disp_hdl].vl_width, 16) *
                          g_disp_arch_ctx[disp_hdl].vl_height * 3);
    ret = mapi_sys_get_video_block(&pool_hdl, &phys_addr, &virt_addr, ive->size, TD_NULL);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "ive_temp mapi_sys_get_video_block fail ret:%#x\n", ret);
        ive->size = 0;
        return ret;
    }
    ive->phys_addr = (td_phys_addr_t)phys_addr;
    ive->virt_addr = virt_addr;
    return TD_SUCCESS;
}

static td_void mapi_disp_release_ive_temp_vb(td_handle disp_hdl)
{
    mapi_disp_ive_temp_buf *ive = &g_disp_arch_ctx[disp_hdl].video_pipeline.ive_temp;

    if (ive->virt_addr != TD_NULL && ive->phys_addr != 0) {
        (td_void)mapi_sys_release_video_block(ive->phys_addr, ive->virt_addr);
        ive->virt_addr = TD_NULL;
        ive->phys_addr = 0;
        ive->size = 0;
    }
}

static td_s32 mapi_disp_init_pipeline(td_handle disp_hdl)
{
    mapi_disp_video_pipeline_ctx *vctx = &g_disp_arch_ctx[disp_hdl].video_pipeline;
    td_s32 ret;
    td_s32 i;

    ret = mapi_disp_alloc_ive_temp_vb(disp_hdl);
    if (ret != TD_SUCCESS) {
        return ret;
    }

    mapi_disp_queue_init(&vctx->pool.free_queue);
    mapi_disp_queue_init(&vctx->pool.ready_queue);
    for (i = 0; i < MAPI_DISP_RGB565_BUF_COUNT; i++) {
        mapi_disp_queue_enqueue(&vctx->pool.free_queue, i);
    }
    return TD_SUCCESS;
}

static td_void mapi_disp_deinit_pipeline(td_handle disp_hdl)
{
    mapi_disp_video_pipeline_ctx *vctx = &g_disp_arch_ctx[disp_hdl].video_pipeline;

    mapi_disp_queue_stop(&vctx->pool.ready_queue);
    mapi_disp_queue_stop(&vctx->pool.free_queue);
    mapi_disp_queue_destroy(&vctx->pool.free_queue);
    mapi_disp_queue_destroy(&vctx->pool.ready_queue);
    mapi_disp_release_ive_temp_vb(disp_hdl);
}

static void mapi_disp_set_video_frame_cb(lv_timer_t *t)
{
    td_handle disp_hdl = (td_handle)(td_uintptr_t)lv_timer_get_user_data(t);
    mapi_disp_video_pipeline_ctx *vctx = &g_disp_arch_ctx[disp_hdl].video_pipeline;
    lv_image_dsc_t *dsc = (lv_image_dsc_t *)vctx->flush.img_dsc;
    td_s32 idx;

    if (vctx->flush.img_obj == NULL || dsc == NULL) {
        return;
    }
    if (mapi_disp_queue_dequeue(&vctx->pool.ready_queue, &idx) != 0) {
        return;
    }
    if (vctx->flush.displaying_idx >= 0) {
        mapi_disp_queue_enqueue(&vctx->pool.free_queue, vctx->flush.displaying_idx);
        vctx->flush.displaying_idx = -1;
    }
    dsc->data = g_disp_arch_ctx[disp_hdl].rgb565_buf[idx];
    dsc->data_size = (uint32_t)g_disp_arch_ctx[disp_hdl].vl_width *
                     (uint32_t)g_disp_arch_ctx[disp_hdl].vl_height * 2;
    vctx->flush.displaying_idx = idx;
    lv_image_set_src((lv_obj_t *)vctx->flush.img_obj, dsc);
}

static td_s32 mapi_disp_create_video_flush(td_handle disp_hdl)
{
    mapi_disp_lvgl_video_flush_ctx *flush = &g_disp_arch_ctx[disp_hdl].video_pipeline.flush;
    lv_image_dsc_t *dsc;
    lv_obj_t *img;
    lv_timer_t *timer;

    flush->displaying_idx = -1;

    dsc = (lv_image_dsc_t *)calloc(1, sizeof(lv_image_dsc_t));
    if (dsc == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "img_dsc calloc fail\n");
        return TD_FAILURE;
    }
    dsc->header.w  = (uint32_t)g_disp_arch_ctx[disp_hdl].vl_width;
    dsc->header.h  = (uint32_t)g_disp_arch_ctx[disp_hdl].vl_height;
    dsc->header.cf = LV_COLOR_FORMAT_RGB565;
    flush->img_dsc = dsc;

    img = lv_image_create((lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_screen);
    if (img == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "lv_image_create fail\n");
        free(dsc);
        flush->img_dsc = NULL;
        return TD_FAILURE;
    }
    lv_obj_set_size(img,
        (int32_t)g_disp_arch_ctx[disp_hdl].vl_width,
        (int32_t)g_disp_arch_ctx[disp_hdl].vl_height);
    lv_obj_align(img, LV_ALIGN_TOP_LEFT, 0, 0);
    flush->img_obj = img;

    timer = lv_timer_create(mapi_disp_set_video_frame_cb,
        MAPI_DISP_VIDEO_FLUSH_PERIOD_MS, (void *)(td_uintptr_t)disp_hdl);
    if (timer == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "lv_timer_create fail\n");
        lv_obj_delete(img);
        flush->img_obj = NULL;
        free(dsc);
        flush->img_dsc = NULL;
        return TD_FAILURE;
    }
    flush->flush_timer = timer;
    return TD_SUCCESS;
}

static td_void mapi_disp_destroy_video_flush(td_handle disp_hdl)
{
    mapi_disp_lvgl_video_flush_ctx *flush = &g_disp_arch_ctx[disp_hdl].video_pipeline.flush;

    if (flush->flush_timer != NULL) {
        lv_timer_delete((lv_timer_t *)flush->flush_timer);
        flush->flush_timer = NULL;
    }
    if (flush->img_obj != NULL) {
        lv_obj_delete((lv_obj_t *)flush->img_obj);
        flush->img_obj = NULL;
    }
    if (flush->img_dsc != NULL) {
        free(flush->img_dsc);
        flush->img_dsc = NULL;
    }
    flush->displaying_idx = -1;
}
#endif /* SUPPORT_LVGL */

td_s32 hal_mapi_disp_get_screen_resolution(td_handle disp_hdl, td_u32 *width, td_u32 *hight)
{
#ifdef SUPPORT_LVGL
    lv_display_t *disp;
    (void)disp_hdl;
    if (width == NULL || hight == NULL) {
        return TD_FAILURE;
    }
    disp = lv_display_get_default();
    if (disp == NULL) {
        return TD_FAILURE;
    }
    *width = (td_u32)lv_display_get_horizontal_resolution(disp);
    *hight = (td_u32)lv_display_get_vertical_resolution(disp);
    return TD_SUCCESS;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_init(td_handle disp_hdl, const hi_mapi_disp_attr *disp_attr,
    td_u32 *vl_width, td_u32 *vl_height, td_u32 *vl_frame_rate)
{
#ifdef SUPPORT_LVGL
    td_s32 ret;

    if (!(disp_attr->pub_attr.intf_type & HI_MAPI_DISP_INTF_LCD)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
            "LVGL mode requires LCD interface, but intf_type=0x%x\n",
            disp_attr->pub_attr.intf_type);
        return HI_MAPI_DISP_EILLEGAL_PARAM;
    }

    ret = hal_mapi_disp_lvgl_init(disp_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "hal_mapi_disp_lvgl_init fail ret:%x\n", ret);
        return ret;
    }

    ret = hal_mapi_disp_get_screen_resolution(disp_hdl, vl_width, vl_height);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "hal_mapi_disp_get_screen_resolution fail ret:%x\n", ret);
        (td_void)hal_mapi_disp_lvgl_deinit(disp_hdl);
        return ret;
    }

    *vl_frame_rate = 0;
    return TD_SUCCESS;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_deinit(td_handle disp_hdl)
{
#ifdef SUPPORT_LVGL
    return hal_mapi_disp_lvgl_deinit(disp_hdl);
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_start(td_handle disp_hdl, const hi_mapi_disp_video_layer_attr *video_layer_attr,
    td_u32 vl_width, td_u32 vl_height, td_u32 vl_frame_rate, const hi_mapi_disp_attr *disp_attr)
{
#ifdef SUPPORT_LVGL
    td_s32 ret;
    td_s32 i;
    size_t rgb565_size;

    (void)vl_frame_rate;

    if ((video_layer_attr->image_size.width != 0 || video_layer_attr->image_size.height != 0) &&
        (video_layer_attr->image_size.width != vl_width ||
         video_layer_attr->image_size.height != vl_height)) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
            "video_layer_attr size(%u x %u) mismatch ctx(%u x %u)\n",
            video_layer_attr->image_size.width,
            video_layer_attr->image_size.height,
            vl_width,
            vl_height);
        return HI_MAPI_DISP_EILLEGAL_PARAM;
    }

    g_disp_arch_ctx[disp_hdl].vl_width  = vl_width;
    g_disp_arch_ctx[disp_hdl].vl_height = vl_height;

    /* rgb565 double buffer: width * height * 2 bytes each */
    rgb565_size = (size_t)vl_width * vl_height * 2;
    for (i = 0; i < MAPI_DISP_RGB565_BUF_COUNT; i++) {
        g_disp_arch_ctx[disp_hdl].rgb565_buf[i] = (td_u8 *)malloc(rgb565_size);
        if (g_disp_arch_ctx[disp_hdl].rgb565_buf[i] == NULL) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "rgb565_buf[%d] malloc fail\n", i);
            mapi_disp_free_rgb_bufs(disp_hdl);
            return TD_FAILURE;
        }
    }

    lv_lock();
    if (g_disp_arch_ctx[disp_hdl].video_screen == NULL) {
        /* First start: create the screen. */
        g_disp_arch_ctx[disp_hdl].video_screen = (void *)lv_obj_create(NULL);
        if (g_disp_arch_ctx[disp_hdl].video_screen == NULL) {
            lv_unlock();
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "lv_obj_create for video_screen fail\n");
            mapi_disp_free_rgb_bufs(disp_hdl);
            return TD_FAILURE;
        }
        lv_obj_set_style_bg_color((lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_screen,
            lv_color_hex(disp_attr->pub_attr.bg_color), 0);
        lv_obj_set_style_bg_opa((lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_screen, LV_OPA_COVER, 0);
    }
    /* Reuse the existing screen on stop→start restart; ref_cnt always resets. */
    g_disp_arch_ctx[disp_hdl].video_screen_ref_cnt = 0;
    lv_unlock();

    ret = mapi_disp_init_pipeline(disp_hdl);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "disp pipeline init fail\n");
        lv_lock();
        lv_obj_delete((lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_screen);
        lv_unlock();
        g_disp_arch_ctx[disp_hdl].video_screen = NULL;
        mapi_disp_free_rgb_bufs(disp_hdl);
        return ret;
    }

    lv_lock();
    ret = mapi_disp_create_video_flush(disp_hdl);
    if (ret != TD_SUCCESS) {
        lv_unlock();
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "disp create video flush fail\n");
        mapi_disp_deinit_pipeline(disp_hdl);
        lv_lock();
        lv_obj_delete((lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_screen);
        lv_unlock();
        g_disp_arch_ctx[disp_hdl].video_screen = NULL;
        mapi_disp_free_rgb_bufs(disp_hdl);
        return ret;
    }
    lv_unlock();

    /* default window: full screen, do NOT load the video screen here — the
     * caller switches to it later via hal_mapi_disp_start_window. */
    g_disp_arch_ctx[disp_hdl].wnd_attr.rect.x = 0;
    g_disp_arch_ctx[disp_hdl].wnd_attr.rect.y = 0;
    g_disp_arch_ctx[disp_hdl].wnd_attr.rect.width = vl_width;
    g_disp_arch_ctx[disp_hdl].wnd_attr.rect.height = vl_height;
    g_disp_arch_ctx[disp_hdl].wnd_attr.priority = 0;

    return TD_SUCCESS;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_stop(td_handle disp_hdl)
{
#ifdef SUPPORT_LVGL
    if (g_disp_arch_ctx[disp_hdl].video_screen_ref_cnt != 0) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
            "cannot stop disp: video_screen still referenced (ref_cnt=%d)\n",
            g_disp_arch_ctx[disp_hdl].video_screen_ref_cnt);
        return HI_MAPI_DISP_EBUSY;
    }

    lv_lock();
    mapi_disp_destroy_video_flush(disp_hdl);
    lv_unlock();

    pthread_mutex_lock(&g_disp_pipeline_lock);
    mapi_disp_deinit_pipeline(disp_hdl);
    mapi_disp_free_rgb_bufs(disp_hdl);
    pthread_mutex_unlock(&g_disp_pipeline_lock);

    return TD_SUCCESS;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_send_frame(td_s32 dev_id, td_s32 chn_id, hi_mapi_frame_data *data)
{
#ifdef SUPPORT_LVGL
    td_handle disp_hdl = (td_handle)(td_u32)dev_id;
    mapi_disp_video_pipeline_ctx *vctx;
    td_s32 idx;
    td_s32 ret;

    (td_void)chn_id;

    if (disp_hdl >= HI_MAPI_DISP_MAX_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "invalid dev_id %d\n", dev_id);
        return HI_MAPI_DISP_EINVALID_DEVID;
    }
    vctx = &g_disp_arch_ctx[disp_hdl].video_pipeline;

    pthread_mutex_lock(&g_disp_pipeline_lock);
    if (g_disp_arch_ctx[disp_hdl].rgb565_buf[0] == NULL || vctx->ive_temp.virt_addr == NULL) {
        pthread_mutex_unlock(&g_disp_pipeline_lock);
        return TD_SUCCESS;
    }
    if (mapi_disp_queue_dequeue(&vctx->pool.free_queue, &idx) != 0) {
        pthread_mutex_unlock(&g_disp_pipeline_lock);
        return TD_SUCCESS;
    }
    ret = mapi_adapt_disp_nv12_to_rgb888_ive(data, vctx->ive_temp.phys_addr, vctx->ive_temp.virt_addr);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "nv12_to_rgb888_ive fail ret:%x\n", ret);
        mapi_disp_queue_enqueue(&vctx->pool.free_queue, idx);
        pthread_mutex_unlock(&g_disp_pipeline_lock);
        return ret;
    }
    mapi_disp_rgb888_to_rgb565_neon(
        g_disp_arch_ctx[disp_hdl].vl_width,
        g_disp_arch_ctx[disp_hdl].vl_height,
        (td_u8 *)vctx->ive_temp.virt_addr,
        g_disp_arch_ctx[disp_hdl].rgb565_buf[idx]);
    pthread_mutex_unlock(&g_disp_pipeline_lock);

    mapi_disp_queue_enqueue(&vctx->pool.ready_queue, idx);
    return TD_SUCCESS;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

void *hal_mapi_disp_get_video_screen(td_handle disp_hdl)
{
#ifdef SUPPORT_LVGL
    if (g_disp_arch_ctx[disp_hdl].video_screen == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "video_screen is NULL\n");
        return NULL;
    }
    g_disp_arch_ctx[disp_hdl].video_screen_ref_cnt ++;
    return g_disp_arch_ctx[disp_hdl].video_screen;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return NULL;
#endif
}

td_s32 hal_mapi_disp_release_video_screen(td_handle disp_hdl, void *video_screen)
{
#ifdef SUPPORT_LVGL
    if (video_screen != g_disp_arch_ctx[disp_hdl].video_screen) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
            "release video_screen(%p) mismatch ctx(%p)\n",
            video_screen,
            g_disp_arch_ctx[disp_hdl].video_screen);
        return HI_MAPI_DISP_EILLEGAL_PARAM;
    }
    if (g_disp_arch_ctx[disp_hdl].video_screen_ref_cnt > 0) {
        g_disp_arch_ctx[disp_hdl].video_screen_ref_cnt --;
    }
    return TD_SUCCESS;
#else
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_set_window_attr(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_attr *wnd_attr)
{
#ifdef SUPPORT_LVGL
    lv_obj_t *img;
    td_s32 ret;

    (td_void)wnd_hdl;
    if (wnd_attr == NULL) {
        return HI_MAPI_DISP_EILLEGAL_PARAM;
    }
    img = (lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_pipeline.flush.img_obj;
    if (img == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "video img_obj is NULL, start disp first\n");
        return TD_FAILURE;
    }

    lv_lock();
    /* position + destination size, then stretch the video to fill the rect */
    lv_obj_set_pos(img, (int32_t)wnd_attr->rect.x, (int32_t)wnd_attr->rect.y);
    lv_obj_set_size(img, (int32_t)wnd_attr->rect.width, (int32_t)wnd_attr->rect.height);
    lv_image_set_inner_align(img, LV_IMAGE_ALIGN_STRETCH);
    lv_unlock();

    ret = memcpy_s(&g_disp_arch_ctx[disp_hdl].wnd_attr, sizeof(g_disp_arch_ctx[disp_hdl].wnd_attr),
        wnd_attr, sizeof(hi_mapi_disp_window_attr));
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "memcpy_s wnd_attr fail ret:%x\n", ret);
        return ret;
    }
    return TD_SUCCESS;
#else
    MAPI_UNUSED(disp_hdl);
    MAPI_UNUSED(wnd_hdl);
    MAPI_UNUSED(wnd_attr);
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_get_window_attr(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_attr *wnd_attr)
{
#ifdef SUPPORT_LVGL
    td_s32 ret;

    (td_void)wnd_hdl;
    if (wnd_attr == NULL) {
        return HI_MAPI_DISP_EILLEGAL_PARAM;
    }
    ret = memcpy_s(wnd_attr, sizeof(hi_mapi_disp_window_attr),
        &g_disp_arch_ctx[disp_hdl].wnd_attr, sizeof(g_disp_arch_ctx[disp_hdl].wnd_attr));
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "memcpy_s wnd_attr fail ret:%x\n", ret);
        return ret;
    }
    return TD_SUCCESS;
#else
    MAPI_UNUSED(disp_hdl);
    MAPI_UNUSED(wnd_hdl);
    MAPI_UNUSED(wnd_attr);
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_start_window(td_handle disp_hdl, td_handle wnd_hdl)
{
#ifdef SUPPORT_LVGL
    lv_obj_t *img;
    lv_obj_t *screen;

    (td_void)wnd_hdl;
    img = (lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_pipeline.flush.img_obj;
    screen = (lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_screen;
    if (img == NULL || screen == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "video img_obj/screen is NULL, start disp first\n");
        return TD_FAILURE;
    }

    lv_lock();
    lv_obj_remove_flag(img, LV_OBJ_FLAG_HIDDEN);
    lv_screen_load(screen);
    lv_unlock();

    return TD_SUCCESS;
#else
    MAPI_UNUSED(disp_hdl);
    MAPI_UNUSED(wnd_hdl);
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_stop_window(td_handle disp_hdl, td_handle wnd_hdl)
{
#ifdef SUPPORT_LVGL
    lv_obj_t *img;

    (td_void)wnd_hdl;
    img = (lv_obj_t *)g_disp_arch_ctx[disp_hdl].video_pipeline.flush.img_obj;
    if (img == NULL) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "video img_obj is NULL, start disp first\n");
        return TD_FAILURE;
    }

    lv_lock();
    lv_obj_add_flag(img, LV_OBJ_FLAG_HIDDEN);
    lv_unlock();

    return TD_SUCCESS;
#else
    MAPI_UNUSED(disp_hdl);
    MAPI_UNUSED(wnd_hdl);
    MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "not support LVGL\n");
    return MAPI_EN_ERR_NOT_SUPPORT;
#endif
}

td_s32 hal_mapi_disp_set_window_aspect_ratio_attr(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr)
{
    MAPI_UNUSED(disp_hdl);
    MAPI_UNUSED(wnd_hdl);
    MAPI_UNUSED(aspect_ratio_attr);
    return MAPI_EN_ERR_NOT_SUPPORT;
}

td_s32 hal_mapi_disp_get_window_aspect_ratio_attr(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr)
{
    MAPI_UNUSED(disp_hdl);
    MAPI_UNUSED(wnd_hdl);
    MAPI_UNUSED(aspect_ratio_attr);
    return MAPI_EN_ERR_NOT_SUPPORT;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
