/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __MAPI_DISP_ARCH_H__
#define __MAPI_DISP_ARCH_H__

#include "hi_mapi_disp_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 hal_mapi_disp_set_window_aspect_ratio_attr(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr);
td_s32 hal_mapi_disp_get_window_aspect_ratio_attr(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr);

/* Unified arch interface — chip-specific implementation (610: LVGL, 710: VO) */
td_s32 hal_mapi_disp_init(td_handle disp_hdl, const hi_mapi_disp_attr *disp_attr,
    td_u32 *vl_width, td_u32 *vl_height, td_u32 *vl_frame_rate);
td_s32 hal_mapi_disp_deinit(td_handle disp_hdl);
td_s32 hal_mapi_disp_start(td_handle disp_hdl, const hi_mapi_disp_video_layer_attr *video_layer_attr,
    td_u32 vl_width, td_u32 vl_height, td_u32 vl_frame_rate, const hi_mapi_disp_attr *disp_attr);
td_s32 hal_mapi_disp_stop(td_handle disp_hdl);
td_s32 hal_mapi_disp_send_frame(td_s32 dev_id, td_s32 chn_id, hi_mapi_frame_data *data);
void  *hal_mapi_disp_get_video_screen(td_handle disp_hdl);
td_s32 hal_mapi_disp_release_video_screen(td_handle disp_hdl, void *video_screen);
td_s32 hal_mapi_disp_get_screen_resolution(td_handle disp_hdl, td_u32 *width, td_u32 *hight);
td_s32 hal_mapi_disp_set_window_attr(td_handle disp_hdl, td_handle wnd_hdl,
    const hi_mapi_disp_window_attr *wnd_attr);
td_s32 hal_mapi_disp_get_window_attr(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_attr *wnd_attr);
td_s32 hal_mapi_disp_start_window(td_handle disp_hdl, td_handle wnd_hdl);
td_s32 hal_mapi_disp_stop_window(td_handle disp_hdl, td_handle wnd_hdl);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __MAPI_DISP_ARCH_H__ */
