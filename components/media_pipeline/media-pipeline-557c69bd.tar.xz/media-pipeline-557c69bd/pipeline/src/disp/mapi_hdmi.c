/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <pthread.h>

#include "hi_mapi_comm_define.h"
#include "hi_mapi_hdmi_define.h"
#include "hi_mw_log.h"
#include "mapi_hdmi_inner.h"
#include "mapi_comm_inner.h"
#include "mapi_hdmi_os.h"
#include "mapi_hdmi_adapt.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#ifdef SUPPORT_HDMI

static mapi_hdmi_context g_hdmi_ctx[HI_MAPI_HDMI_ID_BUTT] = {
    {
        TD_FALSE,
        TD_FALSE,
        {
            TD_NULL,
            TD_NULL,
        },
    },
};

static pthread_mutex_t g_hdmi_lock[HI_MAPI_HDMI_ID_BUTT] = {
    [0 ... (HI_MAPI_HDMI_ID_BUTT - 1)] = PTHREAD_MUTEX_INITIALIZER
};

td_s32 hi_mapi_hdmi_init(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_call_back_func *hdmi_call_back_func)
{
    td_s32 ret;
    hi_mapi_hdmi_call_back_func hdmi_call_back_fn;

    HDMI_CHECK_HANDLE(hdmi_id);

    MAPI_MUTEX_LOCK(g_hdmi_lock[hdmi_id]);

    if (g_hdmi_ctx[hdmi_id].hdmi_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has been init, do not need to init again!\n");
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return TD_SUCCESS;
    }

    ret = hal_mapi_hdmi_config_callback_func(&hdmi_call_back_fn, hdmi_call_back_func);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_HDMI, "hal_mapi_hdmi_config_callback_func", ret, g_hdmi_lock[hdmi_id]);

    ret = mapi_adapt_hdmi_init(hdmi_id, &hdmi_call_back_fn);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_HDMI, "mapi_adapt_hdmi_init", ret, g_hdmi_lock[hdmi_id]);

    g_hdmi_ctx[hdmi_id].hdmi_cb_func.hdmi_event_callback = hdmi_call_back_fn.hdmi_event_callback;
    g_hdmi_ctx[hdmi_id].hdmi_cb_func.private_data = hdmi_call_back_fn.private_data;
    g_hdmi_ctx[hdmi_id].hdmi_inited = TD_TRUE;

    MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_hdmi_deinit(hi_mapi_hdmi_id hdmi_id)
{
    td_s32 ret;

    HDMI_CHECK_HANDLE(hdmi_id);

    MAPI_MUTEX_LOCK(g_hdmi_lock[hdmi_id]);
    if (!g_hdmi_ctx[hdmi_id].hdmi_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return HI_MAPI_HDMI_ENOTREADY;
    }

    hi_mapi_hdmi_call_back_func hdmi_call_back_fn;
    hdmi_call_back_fn.hdmi_event_callback = g_hdmi_ctx[hdmi_id].hdmi_cb_func.hdmi_event_callback;
    hdmi_call_back_fn.private_data = g_hdmi_ctx[hdmi_id].hdmi_cb_func.private_data;
    ret = mapi_adapt_hdmi_deinit(hdmi_id, &hdmi_call_back_fn);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "mapi_adapt_hdmi_deinit 0x%x ERR.\n", ret);
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return ret;
    }

    g_hdmi_ctx[hdmi_id].hdmi_cb_func.hdmi_event_callback = TD_NULL;
    g_hdmi_ctx[hdmi_id].hdmi_cb_func.private_data = TD_NULL;
    g_hdmi_ctx[hdmi_id].hdmi_inited = TD_FALSE;
    MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);

    return ret;
}

td_s32 hi_mapi_hdmi_get_sink_capability(hi_mapi_hdmi_id hdmi_id,
    hi_mapi_hdmi_sink_capability *sink_capability)
{
    HDMI_CHECK_HANDLE(hdmi_id);
    HDMI_CHECK_NULL_PTR(sink_capability);

    MAPI_MUTEX_LOCK(g_hdmi_lock[hdmi_id]);
    if (!g_hdmi_ctx[hdmi_id].hdmi_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return HI_MAPI_HDMI_ENOTREADY;
    }

    td_s32 ret = mapi_adapt_hdmi_get_sink_capability(hdmi_id, sink_capability);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_HDMI, "mapi_adapt_hdmi_get_sink_capability", ret, g_hdmi_lock[hdmi_id]);

    MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);

    return ret;
}

td_s32 hi_mapi_hdmi_get_attr(hi_mapi_hdmi_id hdmi_id, hi_mapi_hdmi_attr *hdmi_attr)
{
    HDMI_CHECK_HANDLE(hdmi_id);
    HDMI_CHECK_NULL_PTR(hdmi_attr);

    MAPI_MUTEX_LOCK(g_hdmi_lock[hdmi_id]);
    if (!g_hdmi_ctx[hdmi_id].hdmi_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return HI_MAPI_HDMI_ENOTREADY;
    }

    td_s32 ret = mapi_adapt_hdmi_get_attr(hdmi_id, hdmi_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_HDMI, "mapi_adapt_hdmi_get_attr", ret, g_hdmi_lock[hdmi_id]);

    MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_hdmi_set_attr(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_attr *hdmi_attr)
{
    HDMI_CHECK_HANDLE(hdmi_id);
    HDMI_CHECK_NULL_PTR(hdmi_attr);

    MAPI_MUTEX_LOCK(g_hdmi_lock[hdmi_id]);
    if (!g_hdmi_ctx[hdmi_id].hdmi_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return HI_MAPI_HDMI_ENOTREADY;
    }

    td_s32 ret = mapi_adapt_hdmi_set_attr(hdmi_id, hdmi_attr, g_hdmi_ctx[hdmi_id].hdmi_started);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_HDMI, "mapi_adapt_hdmi_set_attr", ret, g_hdmi_lock[hdmi_id]);

    MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_hdmi_start(hi_mapi_hdmi_id hdmi_id)
{
    td_s32 ret;

    HDMI_CHECK_HANDLE(hdmi_id);

    MAPI_MUTEX_LOCK(g_hdmi_lock[hdmi_id]);
    if (!g_hdmi_ctx[hdmi_id].hdmi_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return HI_MAPI_HDMI_ENOTREADY;
    }

    if (g_hdmi_ctx[hdmi_id].hdmi_started) {
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return TD_SUCCESS;
    }

    ret = mapi_adapt_hdmi_start(hdmi_id);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_HDMI, "mapi_adapt_hdmi_start\n", ret, g_hdmi_lock[hdmi_id]);

    g_hdmi_ctx[hdmi_id].hdmi_started = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_hdmi_stop(hi_mapi_hdmi_id hdmi_id)
{
    td_s32 ret;
    HDMI_CHECK_HANDLE(hdmi_id);

    MAPI_MUTEX_LOCK(g_hdmi_lock[hdmi_id]);
    if (!g_hdmi_ctx[hdmi_id].hdmi_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "HDMI has not been inited\n");
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return HI_MAPI_HDMI_ENOTREADY;
    }

    if (!g_hdmi_ctx[hdmi_id].hdmi_started) {
        MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);
        return TD_SUCCESS;
    }

    ret = mapi_adapt_hdmi_stop(hdmi_id);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_HDMI, "mapi_adapt_hdmi_stop\n", ret, g_hdmi_lock[hdmi_id]);

    g_hdmi_ctx[hdmi_id].hdmi_started = TD_FALSE;
    MAPI_MUTEX_UNLOCK(g_hdmi_lock[hdmi_id]);

    return TD_SUCCESS;
}

#else

td_s32 hi_mapi_hdmi_init(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_call_back_func *hdmi_call_back_func)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Not support HDMI.\n");
    return HI_MAPI_HDMI_ENOT_SUPPORT;
}

td_s32 hi_mapi_hdmi_deinit(hi_mapi_hdmi_id hdmi_id)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Not support HDMI.\n");
    return HI_MAPI_HDMI_ENOT_SUPPORT;
}

td_s32 hi_mapi_hdmi_get_sink_capability(hi_mapi_hdmi_id hdmi_id,
    hi_mapi_hdmi_sink_capability *sink_capability)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Not support HDMI.\n");
    return HI_MAPI_HDMI_ENOT_SUPPORT;
}

td_s32 hi_mapi_hdmi_get_attr(hi_mapi_hdmi_id hdmi_id, hi_mapi_hdmi_attr *hdmi_attr)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Not support HDMI.\n");
    return HI_MAPI_HDMI_ENOT_SUPPORT;
}

td_s32 hi_mapi_hdmi_set_attr(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_attr *hdmi_attr)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Not support HDMI.\n");
    return HI_MAPI_HDMI_ENOT_SUPPORT;
}

td_s32 hi_mapi_hdmi_start(hi_mapi_hdmi_id hdmi_id)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Not support HDMI.\n");
    return HI_MAPI_HDMI_ENOT_SUPPORT;
}

td_s32 hi_mapi_hdmi_stop(hi_mapi_hdmi_id hdmi_id)
{
    MAPI_ERR_TRACE(HI_MAPI_MOD_HDMI, "Not support HDMI.\n");
    return HI_MAPI_HDMI_ENOT_SUPPORT;
}

#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
