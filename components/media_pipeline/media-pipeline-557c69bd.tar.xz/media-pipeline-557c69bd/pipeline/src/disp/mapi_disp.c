/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <pthread.h>
#include <limits.h>

#include "hi_mapi_comm_define.h"
#include "hi_mapi_vpss_define.h"
#include "hi_mapi_disp_define.h"
#include "hi_mw_log.h"
#include "mapi_disp_inner.h"
#include "mapi_comm_inner.h"
#include "mapi_disp_arch.h"
#include "mapi_disp_adapt.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

static mapi_disp_context g_disp_ctx[HI_MAPI_DISP_MAX_NUM];
static pthread_mutex_t g_disp_func_lock[HI_MAPI_DISP_MAX_NUM] = {
    [0 ... (HI_MAPI_DISP_MAX_NUM - 1)] = PTHREAD_MUTEX_INITIALIZER
};

static td_s32 mapi_disp_reset_status(td_void)
{
    td_u32 i, j;

    for (i = 0; i < HI_MAPI_DISP_MAX_NUM; i++) {
        g_disp_ctx[i].disp_started = TD_FALSE;
        for (j = 0; j < HI_MAPI_DISP_WND_MAX_NUM; j++) {
            g_disp_ctx[i].wnd_attr[j].window_started = TD_FALSE;
        }
    }
    return TD_SUCCESS;
}

td_s32 mapi_disp_init(td_void)
{
    return mapi_disp_reset_status();
}

td_s32 mapi_disp_deinit(td_void)
{
    return mapi_disp_reset_status();
}

td_s32 mapi_disp_send_frame(td_s32 dev_id, td_s32 chn_id, hi_mapi_frame_data *data)
{
    DISP_CHECK_NULL_PTR_RET(data);
    return hal_mapi_disp_send_frame(dev_id, chn_id, data);
}

td_s32 hi_mapi_disp_init(td_handle disp_hdl, const hi_mapi_disp_attr *disp_attr)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_NULL_PTR_RET(disp_attr);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    if (g_disp_ctx[disp_hdl].disp_inited) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Disp is already inited\n");
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return TD_SUCCESS;
    }

    ret = hal_mapi_disp_init(disp_hdl, disp_attr,
        &g_disp_ctx[disp_hdl].vl_width,
        &g_disp_ctx[disp_hdl].vl_height,
        &g_disp_ctx[disp_hdl].vl_frame_rate);
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "hal_mapi_disp_init fail ret:%x\n", ret);
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return ret;
    }

    ret = memcpy_s(&g_disp_ctx[disp_hdl].disp_attr, sizeof(g_disp_ctx[disp_hdl].disp_attr), disp_attr,
        sizeof(hi_mapi_disp_attr));
    if (ret != TD_SUCCESS) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "memcpy_s fail ret:%x\n", ret);
        (td_void)hal_mapi_disp_deinit(disp_hdl);
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return ret;
    }

    g_disp_ctx[disp_hdl].disp_inited = TD_TRUE;

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return ret;
}

td_s32 hi_mapi_disp_deinit(td_handle disp_hdl)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    if (g_disp_ctx[disp_hdl].disp_started) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Disp is still started, please call hi_mapi_disp_stop first\n");
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return HI_MAPI_DISP_EBUSY;
    }
    ret = hal_mapi_disp_deinit(disp_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_deinit", ret, g_disp_func_lock[disp_hdl]);
    g_disp_ctx[disp_hdl].disp_inited = TD_FALSE;

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return ret;
}

td_s32 hi_mapi_disp_set_attr_ex(td_handle disp_hdl, hi_mapi_disp_cmd cmd, const td_void *attr, td_u32 attr_len)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    switch (cmd) {
        case HI_MAPI_DISP_CMD_VIDEO_CSC: {
            if (attr_len != sizeof(hi_mapi_disp_csc_attr_ex)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
                    "Disp_Set Video CSC attr_len:%x is not the size of HI_MAPI_DISP_CSCATTREX_S\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
                return HI_MAPI_DISP_EILLEGAL_PARAM;
            }

            hi_mapi_disp_csc_attr_ex *disp_attr_ex = (hi_mapi_disp_csc_attr_ex *)attr;
            ret = mapi_adapt_disp_set_video_layer_csc(disp_hdl, disp_attr_ex);
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "mapi_adapt_disp_set_video_layer_csc", ret,
                g_disp_func_lock[disp_hdl]);
            break;
        }

        case HI_MAPI_DISP_CMD_GRAPHIC_CSC: {
            if (attr_len != sizeof(hi_mapi_disp_csc_attr_ex)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
                    "Disp_Set Graphic CSC attr_len:%x is not the size of HI_MAPI_DISP_CSCATTREX_S\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
                return HI_MAPI_DISP_EILLEGAL_PARAM;
            }

            hi_mapi_disp_csc_attr_ex *disp_attr_ex = (hi_mapi_disp_csc_attr_ex *)attr;
            ret = mapi_adapt_disp_set_graphic_layer_csc(disp_hdl, disp_attr_ex);
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "mapi_adapt_disp_set_graphic_layer_csc", ret,
                g_disp_func_lock[disp_hdl]);
            break;
        }

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Do not support cmd %d in Set DispAttrEx.\n", cmd);
            MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
            return HI_MAPI_DISP_EILLEGAL_PARAM;
    }

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_get_attr_ex(td_handle disp_hdl, hi_mapi_disp_cmd cmd, td_void *attr, td_u32 attr_len)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    switch (cmd) {
        case HI_MAPI_DISP_CMD_VIDEO_CSC: {
            if (attr_len != sizeof(hi_mapi_disp_csc_attr_ex)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
                    "Disp_Get Video CSC attr_len:%x is not the size of HI_MAPI_DISP_CSCATTREX_S in setExAttr\n",
                    attr_len);
                MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
                return HI_MAPI_DISP_EILLEGAL_PARAM;
            }

            hi_mapi_disp_csc_attr_ex disp_attr_ex;
            ret = mapi_adapt_disp_get_video_layer_csc(disp_hdl, &disp_attr_ex);
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "mapi_adapt_disp_get_video_layer_csc", ret,
                g_disp_func_lock[disp_hdl]);

            ret = memcpy_s(attr, attr_len, &disp_attr_ex, sizeof(disp_attr_ex));
            CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_DISP, "memcpy_s", ret, g_disp_func_lock[disp_hdl]);

            break;
        }
        case HI_MAPI_DISP_CMD_GRAPHIC_CSC: {
            if (attr_len != sizeof(hi_mapi_disp_csc_attr_ex)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
                    "Disp_Get Graphic CSC attr_len:%x is not the size of HI_MAPI_DISP_CSCATTREX_S\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
                return HI_MAPI_DISP_EILLEGAL_PARAM;
            }

            hi_mapi_disp_csc_attr_ex disp_attr_ex;
            ret = mapi_adapt_disp_get_graphic_layer_csc(disp_hdl, &disp_attr_ex);
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "mapi_adapt_disp_get_graphic_layer_csc", ret,
                g_disp_func_lock[disp_hdl]);

            ret = memcpy_s(attr, attr_len, &disp_attr_ex, sizeof(disp_attr_ex));
            CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_DISP, "memcpy_s", ret, g_disp_func_lock[disp_hdl]);

            break;
        }

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Do not support cmd %d in Get DispAttrEx.\n", cmd);
            MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
            return HI_MAPI_DISP_EILLEGAL_PARAM;
    }

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_set_window_attr_ex(td_handle disp_hdl, td_handle wnd_hdl, hi_mapi_disp_window_cmd cmd,
    const td_void *attr, td_u32 attr_len)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_WIN_ID_RET(wnd_hdl);
    DISP_CHECK_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    switch (cmd) {
        case HI_MAPI_DISP_WINDOW_CMD_ROTATE: {
            if (attr_len != sizeof(hi_mapi_disp_window_rotate)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
                    "Disp_SETROTATE attr_len:%x is not the size of HI_MAPI_DISP_WINDOW_ROTATE_S\n",
                               attr_len);
                MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
                return HI_MAPI_DISP_EILLEGAL_PARAM;
            }

            hi_mapi_disp_window_rotate *disp_rotate = (hi_mapi_disp_window_rotate *)attr;
            ret = mapi_adapt_disp_set_chn_rotation(disp_hdl, wnd_hdl, disp_rotate);
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "mapi_adapt_disp_set_chn_rotation", ret,
                g_disp_func_lock[disp_hdl]);

            break;
        }
        case HI_MAPI_DISP_WINDOW_CMD_ASPECTRATIO: {
            if (attr_len != sizeof(hi_mapi_disp_window_aspect_ratio)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
                    "Disp_SETROTATE attr_len:%x is not the size of HI_MAPI_DISP_WINDOW_ASPECTRATIO_S\n",
                               attr_len);
                MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
                return HI_MAPI_DISP_EILLEGAL_PARAM;
            }

            hi_mapi_disp_window_aspect_ratio *aspect_ratio_attr = (hi_mapi_disp_window_aspect_ratio *)attr;
            ret = hal_mapi_disp_set_window_aspect_ratio_attr(disp_hdl, wnd_hdl, aspect_ratio_attr);
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_set_window_aspect_ratio_attr", ret,
                g_disp_func_lock[disp_hdl]);

            break;
        }

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Do not support cmd %d in Set WindowAttrEx.\n", cmd);
            MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
            return HI_MAPI_DISP_EILLEGAL_PARAM;
    }

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_get_window_attr_ex(td_handle disp_hdl, td_handle wnd_hdl, hi_mapi_disp_window_cmd cmd,
                                    td_void *attr, td_u32 attr_len)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_WIN_ID_RET(wnd_hdl);
    DISP_CHECK_NULL_PTR_RET(attr);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    switch (cmd) {
        case HI_MAPI_DISP_WINDOW_CMD_ROTATE: {
            if (attr_len != sizeof(hi_mapi_disp_window_rotate)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
                    "Disp_SETROTATE attr_len:%x is not the size of HI_MAPI_DISP_WINDOW_ROTATE_S\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
                return HI_MAPI_DISP_EILLEGAL_PARAM;
            }

            hi_mapi_disp_window_rotate *disp_rotate = (hi_mapi_disp_window_rotate *)attr;
            ret = mapi_adapt_disp_get_chn_rotation(disp_hdl, wnd_hdl, disp_rotate);
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "mapi_adapt_disp_get_chn_rotation", ret,
                g_disp_func_lock[disp_hdl]);

            break;
        }
        case HI_MAPI_DISP_WINDOW_CMD_ASPECTRATIO: {
            if (attr_len != sizeof(hi_mapi_disp_window_aspect_ratio)) {
                MAPI_ERR_TRACE(HI_MAPI_MOD_DISP,
                    "Disp_SETROTATE attr_len:%x is not the size of HI_MAPI_DISP_WINDOW_PARAM_S\n", attr_len);
                MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
                return HI_MAPI_DISP_EILLEGAL_PARAM;
            }

            hi_mapi_disp_window_aspect_ratio aspect_ratio_attr;
            ret = hal_mapi_disp_get_window_aspect_ratio_attr(disp_hdl, wnd_hdl, &aspect_ratio_attr);
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_get_window_aspect_ratio_attr", ret,
                g_disp_func_lock[disp_hdl]);

            ret = memcpy_s(attr, attr_len, &aspect_ratio_attr, sizeof(aspect_ratio_attr));
            CHECK_MAPI_SAFEFUNC_RET_UNLOCK(HI_MAPI_MOD_DISP, "memcpy_s", ret, g_disp_func_lock[disp_hdl]);

            break;
        }

        default:
            MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "Do not support cmd %d in Get WindowAttrEx.\n", cmd);
            MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
            return HI_MAPI_DISP_EILLEGAL_PARAM;
    }

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_start(td_handle disp_hdl, const hi_mapi_disp_video_layer_attr *video_layer_attr)
{
    td_s32 ret = TD_SUCCESS;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_NULL_PTR_RET(video_layer_attr);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    if (g_disp_ctx[disp_hdl].disp_started) {
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return TD_SUCCESS;
    }

    ret = hal_mapi_disp_start(disp_hdl, video_layer_attr,
        g_disp_ctx[disp_hdl].vl_width,
        g_disp_ctx[disp_hdl].vl_height,
        g_disp_ctx[disp_hdl].vl_frame_rate,
        &g_disp_ctx[disp_hdl].disp_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_start", ret, g_disp_func_lock[disp_hdl]);
    g_disp_ctx[disp_hdl].disp_started = TD_TRUE;

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return ret;
}

td_s32 hi_mapi_disp_stop(td_handle disp_hdl)
{
    td_s32 ret = TD_SUCCESS;

    DISP_CHECK_HANDLE_RET(disp_hdl);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    ret = hal_mapi_disp_stop(disp_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_stop", ret, g_disp_func_lock[disp_hdl]);
    g_disp_ctx[disp_hdl].disp_started = TD_FALSE;

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return ret;
}

td_s32 hi_mapi_disp_set_window_attr(td_handle disp_hdl, td_handle wnd_hdl,
                                  const hi_mapi_disp_window_attr *wnd_attr)
{
    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_WIN_ID_RET(wnd_hdl);
    DISP_CHECK_NULL_PTR_RET(wnd_attr);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    if (!g_disp_ctx[disp_hdl].disp_started) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "DISP has not been started\n");
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return HI_MAPI_DISP_ENOTREADY;
    }

    td_s32 ret = hal_mapi_disp_set_window_attr(disp_hdl, wnd_hdl, wnd_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_set_window_attr", ret, g_disp_func_lock[disp_hdl]);

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_get_window_attr(td_handle disp_hdl, td_handle wnd_hdl,
    hi_mapi_disp_window_attr *wnd_attr)
{
    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_WIN_ID_RET(wnd_hdl);
    DISP_CHECK_NULL_PTR_RET(wnd_attr);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    if (!g_disp_ctx[disp_hdl].disp_started) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "DISP has not been started\n");
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return HI_MAPI_DISP_ENOTREADY;
    }

    td_s32 ret = hal_mapi_disp_get_window_attr(disp_hdl, wnd_hdl, wnd_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_get_window_attr", ret, g_disp_func_lock[disp_hdl]);

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_start_window(td_handle disp_hdl, td_handle wnd_hdl)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_WIN_ID_RET(wnd_hdl);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    if (!g_disp_ctx[disp_hdl].disp_started) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "DISP has not been started\n");
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return HI_MAPI_DISP_ENOTREADY;
    }

    if (g_disp_ctx[disp_hdl].wnd_attr[wnd_hdl].window_started) {
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return TD_SUCCESS;
    }
    ret = hal_mapi_disp_start_window(disp_hdl, wnd_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_start_window", ret, g_disp_func_lock[disp_hdl]);

    g_disp_ctx[disp_hdl].wnd_attr[wnd_hdl].window_started = TD_TRUE;

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_stop_window(td_handle disp_hdl, td_handle wnd_hdl)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_WIN_ID_RET(wnd_hdl);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    if (!g_disp_ctx[disp_hdl].disp_started) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "DISP has not been started\n");
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return HI_MAPI_DISP_ENOTREADY;
    }

    if (!g_disp_ctx[disp_hdl].wnd_attr[wnd_hdl].window_started) {
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return TD_SUCCESS;
    }

    ret = hal_mapi_disp_stop_window(disp_hdl, wnd_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "hal_mapi_disp_stop_window", ret, g_disp_func_lock[disp_hdl]);

    g_disp_ctx[disp_hdl].wnd_attr[wnd_hdl].window_started = TD_FALSE;

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_clear_window(td_handle disp_hdl, td_handle wnd_hdl)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_WIN_ID_RET(wnd_hdl);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    ret = mapi_adapt_disp_clear_vo_chn_buf(disp_hdl, wnd_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "mapi_adapt_disp_clear_vo_chn_buf", ret, g_disp_func_lock[disp_hdl]);

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_send_frame(td_handle disp_hdl, td_handle wnd_hdl, const hi_mapi_frame_data *frame_data)
{
    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_WIN_ID_RET(wnd_hdl);
    DISP_CHECK_NULL_PTR_RET(frame_data);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    if (frame_data->frame_data_type != HI_MAPI_FRAME_DATA_TYPE_YUV) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "disp_hdl(%d, %d) sendFrame is not YUV.\n", disp_hdl, wnd_hdl);
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return HI_MAPI_DISP_EILLEGAL_PARAM;
    }

    td_s32 ret = mapi_adapt_disp_send_frame(disp_hdl, wnd_hdl, frame_data);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_DISP, "mapi_adapt_disp_send_frame", ret, g_disp_func_lock[disp_hdl]);

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_disp_get_screen_resolution(td_handle disp_hdl, td_u32 *width, td_u32 *hight)
{
    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_NULL_PTR_RET(width);
    DISP_CHECK_NULL_PTR_RET(hight);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);
    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    td_s32 ret = hal_mapi_disp_get_screen_resolution(disp_hdl, width, hight);

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
    return ret;
}

void *hi_mapi_disp_get_video_screen(td_handle disp_hdl)
{
    void *screen;

    if (disp_hdl >= HI_MAPI_DISP_MAX_NUM) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "disp dev(%d) is invalid, only support [0, %d]\n",
            disp_hdl, HI_MAPI_DISP_MAX_NUM - 1);
        return NULL;
    }

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    if (!g_disp_ctx[disp_hdl].disp_started) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_DISP, "DISP has not been started\n");
        MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
        return NULL;
    }

    screen = hal_mapi_disp_get_video_screen(disp_hdl);

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
    return screen;
}

td_s32 hi_mapi_disp_release_video_screen(td_handle disp_hdl, void *video_screen)
{
    td_s32 ret;

    DISP_CHECK_HANDLE_RET(disp_hdl);
    DISP_CHECK_NULL_PTR_RET(video_screen);

    MAPI_MUTEX_LOCK(g_disp_func_lock[disp_hdl]);

    DISP_CHECK_INIT_RET_UNLOCK(g_disp_ctx[disp_hdl].disp_inited, g_disp_func_lock[disp_hdl]);

    ret = hal_mapi_disp_release_video_screen(disp_hdl, video_screen);

    MAPI_MUTEX_UNLOCK(g_disp_func_lock[disp_hdl]);
    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
