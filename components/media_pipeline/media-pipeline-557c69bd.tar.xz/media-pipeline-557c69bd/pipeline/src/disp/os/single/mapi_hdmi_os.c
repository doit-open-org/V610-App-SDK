/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "mapi_hdmi_inner.h"
#include "hi_mapi_hdmi_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

td_s32 hal_mapi_hdmi_config_callback_func(hi_mapi_hdmi_call_back_func *hdmi_call_back_config,
    const hi_mapi_hdmi_call_back_func *hdmi_call_back_func)
{
    HDMI_CHECK_NULL_PTR(hdmi_call_back_func);
    HDMI_CHECK_NULL_PTR(hdmi_call_back_config);
    hdmi_call_back_config->hdmi_event_callback = hdmi_call_back_func->hdmi_event_callback;
    hdmi_call_back_config->private_data = hdmi_call_back_func->private_data;

    return TD_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
