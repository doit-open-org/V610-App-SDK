/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <unistd.h>
#include "ss_mpi_vb.h"
#include "hi_mapi_vdec.h"
#include "mapi_vdec_inner.h"
#include "mapi_comm_inner.h"
#include "mapi_vdec_adapt.h"
#include "mapi_comm_adapt.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

static td_bool g_vdec_module_inited = TD_FALSE;
static mapi_vdec_server_context g_vdec_context;

static pthread_mutex_t g_vdec_lock[HI_MAPI_VDEC_MAX_NUM] = {
    [0 ... (HI_MAPI_VDEC_MAX_NUM - 1)] = PTHREAD_MUTEX_INITIALIZER
};
static pthread_mutex_t g_vdec_module_lock = PTHREAD_MUTEX_INITIALIZER;

static td_s32 mapi_vdec_init(td_void)
{
    MAPI_MUTEX_LOCK(g_vdec_module_lock);
    if (g_vdec_module_inited == TD_TRUE) {
        MAPI_MUTEX_UNLOCK(g_vdec_module_lock);
        return TD_SUCCESS;
    }

    for (td_u32 i = 0; i < HI_MAPI_VDEC_MAX_NUM; i++) {
        MAPI_MUTEX_LOCK(g_vdec_lock[i]);
        g_vdec_context.vdec_chn_cfg[i].is_init = TD_FALSE;
        g_vdec_context.vdec_chn_cfg[i].is_start = TD_FALSE;
        g_vdec_context.vdec_chn_cfg[i].get_frame_mode = HI_MAPI_VDEC_MODE_BUTT;
        g_vdec_context.vdec_chn_cfg[i].vb_pool.pic_vb_pool = OT_VB_INVALID_POOL_ID;
        g_vdec_context.vdec_chn_cfg[i].vb_pool.tmv_vb_pool = OT_VB_INVALID_POOL_ID;
        MAPI_MUTEX_UNLOCK(g_vdec_lock[i]);
    }

    td_s32 ret = mapi_adapt_vdec_set_mod_param();
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_set_mod_param", ret, g_vdec_module_lock);

    g_vdec_module_inited = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_vdec_module_lock);
    return TD_SUCCESS;
}

static td_void mapi_vdec_deinit(td_void)
{
    if (g_vdec_module_inited == TD_FALSE) {
        return;
    }

    td_u32 i;
    td_s32 ret;

    for (i = 0; i < HI_MAPI_VDEC_MAX_NUM; i++) {
        MAPI_MUTEX_LOCK(g_vdec_lock[i]);
        g_vdec_context.vdec_chn_cfg[i].is_init = TD_FALSE;
        g_vdec_context.vdec_chn_cfg[i].is_start = TD_FALSE;
        MAPI_MUTEX_UNLOCK(g_vdec_lock[i]);
        if (g_vdec_context.vdec_chn_cfg[i].vb_pool.pic_vb_pool != OT_VB_INVALID_POOL_ID) {
            ret = mapi_adapt_comm_destroy_vb_pool(g_vdec_context.vdec_chn_cfg[i].vb_pool.pic_vb_pool);
            CHECK_MAPI_PRINT(HI_MAPI_MOD_VDEC, "call mapi_adapt_comm_destroy_vb_pool failed", ret);
            g_vdec_context.vdec_chn_cfg[i].vb_pool.pic_vb_pool = OT_VB_INVALID_POOL_ID;
        }
        if (g_vdec_context.vdec_chn_cfg[i].vb_pool.tmv_vb_pool != OT_VB_INVALID_POOL_ID) {
            ret = mapi_adapt_comm_destroy_vb_pool(g_vdec_context.vdec_chn_cfg[i].vb_pool.tmv_vb_pool);
            CHECK_MAPI_PRINT(HI_MAPI_MOD_VDEC, "call mapi_adapt_comm_destroy_vb_pool failed", ret);
            g_vdec_context.vdec_chn_cfg[i].vb_pool.tmv_vb_pool = OT_VB_INVALID_POOL_ID;
        }
    }

    g_vdec_module_inited = TD_FALSE;

    return;
}

td_s32 hi_mapi_vdec_init(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_attr, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, (vdec_attr->get_frame_mode >= HI_MAPI_VDEC_MODE_COMMON) &&
        (vdec_attr->get_frame_mode < HI_MAPI_VDEC_MODE_BUTT), HI_MAPI_VDEC_EILLEGAL_PARAM);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    td_s32 ret = mapi_vdec_init();
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_vdec_init", ret);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_FALSE,
        TD_SUCCESS, g_vdec_lock[vdec_hdl]);

    ret = mapi_adapt_vdec_create_chn(vdec_hdl, vdec_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_create_chn", ret, g_vdec_lock[vdec_hdl]);

    g_vdec_context.vdec_chn_cfg[vdec_hdl].get_frame_mode = vdec_attr->get_frame_mode;
    g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);
    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_deinit(td_handle vdec_hdl)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    td_s32 ret;
    td_u32 i;
    td_bool ret_err_flg = TD_FALSE;

    if (g_vdec_context.vdec_chn_cfg[vdec_hdl].is_start == TD_TRUE) {
        ret = hi_mapi_vdec_stop(vdec_hdl);
        CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_VDEC, "hi_mapi_vdec_stop", ret, ret_err_flg);
    }

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        TD_SUCCESS, g_vdec_lock[vdec_hdl]);

    if (g_vdec_context.data_fifo_cfg[vdec_hdl].unhandle_frame.frame_data.phy_addr[0] != 0) {
        ret = mapi_adapt_vdec_release_frame(vdec_hdl, &g_vdec_context.data_fifo_cfg[vdec_hdl].unhandle_frame.frame_data);
        CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_release_frame", ret, ret_err_flg);
    }

    ret = mapi_adapt_vdec_reset_chn(vdec_hdl);
    CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_reset_chn", ret, ret_err_flg);

    ret = mapi_adapt_vdec_destroy_chn(vdec_hdl);
    CHECK_MAPI_FUNC_RUN_PRINT(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_destroy_chn", ret, ret_err_flg);

    g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init = TD_FALSE;

    if (ret_err_flg) {
        MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);
        return HI_MAPI_VDEC_EBUSY;
    }

    /* module deinit need all vdec chn deinit */
    for (i = 0; i < HI_MAPI_VDEC_MAX_NUM; i++) {
        if (g_vdec_context.vdec_chn_cfg[i].is_init) {
            MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);
            return TD_SUCCESS;
        }
    }

    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);

    if (i == HI_MAPI_VDEC_MAX_NUM) {
        mapi_vdec_deinit();
    }

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_start(td_handle vdec_hdl)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_start == TD_FALSE,
        TD_SUCCESS, g_vdec_lock[vdec_hdl]);

    td_s32 ret = mapi_adapt_vdec_start(vdec_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_start", ret,
        g_vdec_lock[vdec_hdl]);

    g_vdec_context.vdec_chn_cfg[vdec_hdl].is_start = TD_TRUE;
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_stop(td_handle vdec_hdl)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_start == TD_TRUE,
        TD_SUCCESS, g_vdec_lock[vdec_hdl]);

    td_s32 ret = mapi_adapt_vdec_stop(vdec_hdl);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_stop", ret, g_vdec_lock[vdec_hdl]);

    if ((g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.pic_vb_pool != OT_VB_INVALID_POOL_ID ||
        g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.tmv_vb_pool != OT_VB_INVALID_POOL_ID) &&
        ss_mpi_vdec_detach_vb_pool((ot_vdec_chn)vdec_hdl) != TD_SUCCESS) {
            CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_detach_vb_pool", ret, g_vdec_lock[vdec_hdl]);
    }

    g_vdec_context.vdec_chn_cfg[vdec_hdl].is_start = TD_FALSE;
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_query_status(td_handle vdec_hdl, hi_mapi_vdec_status *status)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, status, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    td_s32 ret = mapi_adapt_vdec_query_status(vdec_hdl, status);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_query_status", ret);

    return TD_SUCCESS;
}

static td_s32 mapi_adapt_vdec_set_vb(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr)
{
    if (vdec_attr->user_vb_flag == TD_FALSE) {
        return TD_SUCCESS;
    }
    td_s32 ret;

    ot_vb_pool_cfg cfg = {0};
    cfg.remap_mode = OT_VB_REMAP_MODE_NONE;
    if (vdec_attr->frame_buf_size > 0 && vdec_attr->frame_buf_cnt > 0) {
        if (g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.pic_vb_pool != OT_VB_INVALID_POOL_ID) {
            ret = mapi_adapt_comm_destroy_vb_pool(g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.pic_vb_pool);
            CHECK_MAPI_PRINT(HI_MAPI_MOD_VDEC, "call mapi_adapt_comm_destroy_vb_pool failed", ret);
            g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.pic_vb_pool = OT_VB_INVALID_POOL_ID;
        }
        cfg.blk_size = vdec_attr->frame_buf_size;
        cfg.blk_cnt = vdec_attr->frame_buf_cnt;
        g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.pic_vb_pool = ss_mpi_vb_create_pool(&cfg);
        if (g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.pic_vb_pool == OT_VB_INVALID_POOL_ID) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VDEC, "vdec_hdl:[%d] create pool failed! cnt:[%u]\n", vdec_hdl, cfg.blk_cnt);
            return TD_FAILURE;
        }
    }

    if (vdec_attr->vdec_video_attr.tmv_buf_size > 0 && vdec_attr->vdec_video_attr.ref_frame_num > 0) {
        if (g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.tmv_vb_pool != OT_VB_INVALID_POOL_ID) {
            ret = mapi_adapt_comm_destroy_vb_pool(g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.tmv_vb_pool);
            CHECK_MAPI_PRINT(HI_MAPI_MOD_VDEC, "call mapi_adapt_comm_destroy_vb_pool failed", ret);
            g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.tmv_vb_pool = OT_VB_INVALID_POOL_ID;
        }
        cfg.blk_size = vdec_attr->vdec_video_attr.tmv_buf_size;
        cfg.blk_cnt = vdec_attr->vdec_video_attr.ref_frame_num;
        g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.tmv_vb_pool = ss_mpi_vb_create_pool(&cfg);
        if (g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.tmv_vb_pool == OT_VB_INVALID_POOL_ID) {
            MAPI_ERR_TRACE(HI_MAPI_MOD_VDEC, "vdec_hdl:[%d] create pool failed! cnt:[%u]\n", vdec_hdl, cfg.blk_cnt);
            return TD_FAILURE;
        }
    }

    if ((g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.pic_vb_pool != OT_VB_INVALID_POOL_ID ||
        g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool.tmv_vb_pool != OT_VB_INVALID_POOL_ID)) {
        ret = ss_mpi_vdec_attach_vb_pool((ot_vdec_chn)vdec_hdl, &g_vdec_context.vdec_chn_cfg[vdec_hdl].vb_pool);
        CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "ss_mpi_vdec_attach_vb_pool", ret);
    }
    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_set_attr(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_attr, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);

    if (g_vdec_context.vdec_chn_cfg[vdec_hdl].get_frame_mode != vdec_attr->get_frame_mode) {
        MAPI_ERR_TRACE(HI_MAPI_MOD_VDEC, "the get_frame_mode is static attribute, not support change. \n");
        MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);
        return HI_MAPI_VDEC_ENOT_PERM;
    }

    td_s32 ret = mapi_adapt_vdec_set_vb(vdec_hdl, vdec_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_set_vb", ret, g_vdec_lock[vdec_hdl]);

    ret = mapi_adapt_vdec_set_attr(vdec_hdl, vdec_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_set_attr", ret, g_vdec_lock[vdec_hdl]);
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_get_attr(td_handle vdec_hdl, hi_mapi_vdec_attr *vdec_attr)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_attr, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);

    td_s32 ret = mapi_adapt_vdec_get_attr(vdec_hdl, vdec_attr);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_get_attr", ret,
        g_vdec_lock[vdec_hdl]);
    vdec_attr->get_frame_mode = g_vdec_context.vdec_chn_cfg[vdec_hdl].get_frame_mode;
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_set_param(td_handle vdec_hdl, const hi_mapi_vdec_param *vdec_param)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_param, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);

    td_s32 ret = mapi_adapt_vdec_set_param(vdec_hdl, vdec_param);
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_set_param", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_get_param(td_handle vdec_hdl, hi_mapi_vdec_param *vdec_param)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, vdec_param, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);

    td_s32 ret = mapi_adapt_vdec_get_param(vdec_hdl, vdec_param);
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_get_param", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_send_stream(td_handle vdec_hdl, const hi_mapi_vdec_stream *stream, td_s32 timeout)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, stream, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);

    td_s32 ret = mapi_adapt_vdec_send_stream(vdec_hdl, stream, timeout);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_send_stream", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_get_frame(td_handle vdec_hdl, hi_mapi_frame_data *frame_data, td_u32 timeout)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, frame_data, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);
    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);

    td_s32 ret = mapi_adapt_vdec_get_frame(vdec_hdl, frame_data, timeout);
    CHECK_MAPI_RET(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_get_frame", ret);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_release_frame(td_handle vdec_hdl, const hi_mapi_frame_data *frame_data)
{
    CHECK_MAPI_BOOL_RET(HI_MAPI_MOD_VDEC, vdec_hdl < HI_MAPI_VDEC_MAX_NUM, HI_MAPI_VDEC_EHANDLE_ILLEGAL);
    CHECK_MAPI_NULL_PTR_RET(HI_MAPI_MOD_VDEC, frame_data, HI_MAPI_VDEC_ENULL_PTR);
    CHECK_MAPI_STATE_RET(HI_MAPI_MOD_VGS, mapi_get_media_init_status(), "media has not been pre inited",
        HI_MAPI_VDEC_ENOT_INITED);

    MAPI_MUTEX_LOCK(g_vdec_lock[vdec_hdl]);
    CHECK_MAPI_BOOL_RET_UNLOCK(HI_MAPI_MOD_VDEC, g_vdec_context.vdec_chn_cfg[vdec_hdl].is_init == TD_TRUE,
        HI_MAPI_VDEC_ENOT_INITED, g_vdec_lock[vdec_hdl]);

    td_s32 ret = mapi_adapt_vdec_release_frame(vdec_hdl, frame_data);
    CHECK_MAPI_RET_UNLOCK(HI_MAPI_MOD_VDEC, "mapi_adapt_vdec_release_frame", ret,
        g_vdec_lock[vdec_hdl]);

    MAPI_MUTEX_UNLOCK(g_vdec_lock[vdec_hdl]);

    return TD_SUCCESS;
}

td_s32 hi_mapi_vdec_get_default_attr(const hi_mapi_vdec_base_attr *base_attr, hi_mapi_vdec_attr *vdec_attr)
{
    mapi_vdec_pic_buf_attr mapi_buf_attr = {0};

    CHECK_MAPI_VENC_NULL_PTR_RET(base_attr);
    CHECK_MAPI_VENC_NULL_PTR_RET(vdec_attr);

    (td_void)memset_s(vdec_attr, sizeof(hi_mapi_venc_attr), 0, sizeof(hi_mapi_venc_attr));

    vdec_attr->type = base_attr->type;
    vdec_attr->pic_width = base_attr->width;
    vdec_attr->pic_height = base_attr->height;

    vdec_attr->mode = HI_MAPI_VDEC_VIDEO_MODE_STREAM;
    vdec_attr->get_frame_mode = HI_MAPI_VDEC_MODE_COMMON;
    vdec_attr->stream_buf_size = vdec_attr->pic_width * vdec_attr->pic_height * 3 / 4;
    vdec_attr->user_vb_flag = TD_FALSE;
    
    mapi_buf_attr.type = base_attr->type;
    mapi_buf_attr.width = base_attr->width;
    mapi_buf_attr.height = base_attr->height;
    mapi_buf_attr.bit_width = 8;  /* 8: default bit width */
    mapi_buf_attr.pixel_format = HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    mapi_buf_attr.compress_mode = HI_MAPI_COMPRESS_MODE_NONE;
    mapi_buf_attr.video_format = HI_MAPI_VIDEO_FORMAT_LINEAR;
    vdec_attr->frame_buf_size = mapi_adapt_comm_vb_get_buffer_size(MAPI_BUF_TYPE_VDEC_PIC_BUF, 
        &mapi_buf_attr, sizeof(mapi_buf_attr));

    if (base_attr->type == HI_MAPI_PAYLOAD_TYPE_H264 || base_attr->type == HI_MAPI_PAYLOAD_TYPE_H265) {
        vdec_attr->vdec_video_attr.ref_frame_num = 3;  /* 3: self venc stream; 5: other stream */
        vdec_attr->vdec_video_attr.temporal_mvp_enable = TD_FALSE;
        vdec_attr->vdec_video_attr.tmv_buf_size = mapi_adapt_comm_vb_get_buffer_size(MAPI_BUF_TYPE_VDEC_TMV_BUF, 
            &mapi_buf_attr, sizeof(mapi_buf_attr));
    }

    return TD_SUCCESS;
}



#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
