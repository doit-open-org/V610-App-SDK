/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VGS_DEFINE_H__
#define __HI_MAPI_VGS_DEFINE_H__

#include "hi_mapi_vgs_adapt_define.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_errno.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */


/* error code for osd */
#define HI_MAPI_VGS_EHANDLE_ILLEGAL \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VGS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)
#define HI_MAPI_VGS_EILLEGAL_PARAM \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VGS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
#define HI_MAPI_VGS_ENULL_PTR   HI_MAPI_DEF_ERR(HI_MAPI_MOD_VGS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
#define HI_MAPI_VGS_EOPERATE_FAIL   HI_MAPI_DEF_ERR(HI_MAPI_MOD_VGS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_OPERATE_FAIL)
#define HI_MAPI_VGS_ENOFONT HI_MAPI_DEF_ERR(HI_MAPI_MOD_VGS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NO_FONT)
#define HI_MAPI_VGS_ENOINITED HI_MAPI_DEF_ERR(HI_MAPI_MOD_VGS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_INITED)

#define HI_MAPI_VGS_TASK_MAX_CNT 20

typedef struct {
    hi_mapi_frame_data frame_data_in;   /* Input Vedio frame */
    hi_mapi_frame_data frame_data_out;  /* Output Vedio frame */
} hi_mapi_vgs_task_attr;

typedef struct {
    hi_mapi_vgs_task_attr   vgs_task_attr;
    hi_mapi_vgs_scale_coef_mode scale_coef_mode;
} hi_mapi_vgs_scale_task_attr;

typedef struct {
    hi_mapi_vgs_task_attr vgs_task_attr;
    hi_mapi_vgs_draw_line *vgs_draw_line;
    td_u32 num;
} hi_mapi_vgs_draw_line_task_attr;

typedef struct {
    hi_mapi_vgs_quadrangle_cover quad_rangle; /* The quadrangle area */
    td_u32 color;                           /* Range: [0,0xFFFFFF]; Color of cover */
} hi_mapi_vgs_add_cover;

typedef struct {
    hi_mapi_vgs_task_attr vgs_task_attr;
    hi_mapi_vgs_add_cover *vgs_add_cover;
    td_u32 num;
} hi_mapi_vgs_cover_task_attr;

typedef struct {
    td_u32 bg_color;
    /* region size,W:[2,RGN_OVERLAY_MAX_WIDTH],align:2,H:[2,RGN_OVERLAY_MAX_HEIGHT],align:2 */
    hi_mapi_size size;
} hi_mapi_vgs_rgn_attr;

typedef struct {
    hi_mapi_vgs_rgn_attr rgn_attr[HI_MAPI_VGS_TASK_MAX_CNT]; /* array index amount to rgn handle */
    td_u32 num;
} hi_mapi_vgs_rgn_task_attr;

typedef struct {
    td_u32 rgn_hdl;             /* rgn handle */
    hi_mapi_point start_point;  /* Osd start point */
    td_u32 bg_alpha;            /* Range: [0,255]; Background alpha of osd */
    td_u32 fg_alpha;            /* Range: [0,255]; Foreground alpha of osd */
    hi_mapi_str_content str_content;
    td_u32 color;
} hi_mapi_vgs_add_osd;

typedef struct {
    hi_mapi_vgs_task_attr vgs_task_attr;
    hi_mapi_vgs_add_osd *vgs_add_osd;
    td_u32 num;
} hi_mapi_vgs_osd_task_attr;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_VGS_DEFINE_H__ */
