/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_ADEC_DEFINE_H__
#define __HI_MAPI_ADEC_DEFINE_H__

#include "hi_mapi_errno.h"
#include "hi_mapi_audio_adapt_define.h"
#include "hi_mapi_comm_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     ADEC */
/** @{ */  /** <!-- [ADEC] */

/** error code
      invalid handle error for ADEC */
#define HI_MAPI_ADEC_EINVALIDHDL \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ADEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)
/* NULL point error for ADEC */
#define HI_MAPI_ADEC_ENULLPTR \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ADEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
/* media not inited */
#define HI_MAPI_ADEC_ENOTINITED \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ADEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
/* state error for ADEC */
#define HI_MAPI_ADEC_ESTATEERR \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ADEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
/* at lease one parameter is illagal for ADEC */
#define HI_MAPI_ADEC_EILLPARAM \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ADEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
/* operation fail for ADEC */
#define HI_MAPI_ADEC_ERR_OPERATE_FAIL \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ADEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_OPERATE_FAIL)
/* buf full for ADEC */
#define HI_MAPI_ADEC_ERR_BUF_FULL \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ADEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUF_FULL)

typedef struct {
    hi_mapi_audio_format          adec_format;          /* Audio decoding Format */
    hi_mapi_adec_mode             adec_mode;
} hi_mapi_adec_attr;


typedef struct {
    hi_mapi_audio_frame *frame;
    hi_mapi_audio_frame audio_frame;
    // Audio frame index, this index will be used as uniquely identify when release data.
    td_u32 index;
} hi_mapi_audio_frame_info;

/* ADEC extension command for hi_mapi_adec_set_param / hi_mapi_adec_get_param.
   Suffix convention:
     _CONFIG : must be set before the first hi_mapi_adec_send_stream; returns
               HI_MAPI_ADEC_ESTATEERR if called after streaming has started.
     _PARAM  : settable at any state. */
typedef enum {
    HI_MAPI_ADEC_CMD_PAYLOAD_FORMAT_CONFIG = 0,  /* hi_mapi_audio_payload_format, OPUS only */
    HI_MAPI_ADEC_CMD_BUTT
} hi_mapi_adec_cmd;

/** @} */  /** <!-- ==== ADEC End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_ADEC_DEFINE_H__ */
