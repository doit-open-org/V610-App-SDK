/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_AENC_DEFINE_H__
#define __HI_MAPI_AENC_DEFINE_H__

#include "hi_mapi_comm_define.h"
#include "hi_mapi_errno.h"
#include "hi_mapi_audio_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/** \addtogroup     AENC */
/** @{ */ /** <!-- [AENC] */

/* Error code
    invalid handle error for aenc */
#define HI_MAPI_AENC_EINVALIDHDL HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)

/** null pointer error for aenc */
#define HI_MAPI_AENC_ENULLPTR    HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)

/** not inited error for aenc */
#define HI_MAPI_AENC_ENOTINITED  HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)

/** state error for aenc */
#define HI_MAPI_AENC_ESTATEERR   HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)

/** illegal parameter error for aenc */
#define HI_MAPI_AENC_EILLPARAM   HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)

/** resource full error for aenc */
#define HI_MAPI_AENC_ERESFULL    HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_EXIST)

/** resource not exist error for aenc */
#define HI_MAPI_AENC_EUNEXIST    HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_UNEXIST)

/** memory error for aenc */
#define HI_MAPI_AENC_EMEMERR     HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)

/** busy error for aenc */
#define HI_MAPI_AENC_EBUSY       HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUSY)

/** no data in buffer  for aenc */
#define HI_MAPI_AENC_BUF_EMPTY   HI_MAPI_DEF_ERR(HI_MAPI_MOD_AENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUF_EMPTY)


/* Structure */
/** aenc init attr */
typedef struct {
    hi_mapi_audio_format aenc_format; /* audio encode format type */
    td_u32 pt_num_per_frm;              /* sampling point number per frame */
    td_void *value;                  /* pointer of Aenc attr */
    td_u32 value_len;                 /* Aenc attr struct len */
} hi_mapi_aenc_attr;

/** data proc callback function pointer */
typedef td_s32 (*hi_mapi_aenc_proc_data_cb)(td_handle aenc_hdl, const hi_mapi_audio_stream *audio_stream_data,
    td_void *private_data);

/** aenc callback struct */
typedef struct {
    hi_mapi_aenc_proc_data_cb proc_data_cb;
    td_void *private_data; /** private data */
} hi_mapi_aenc_callback;

/* AENC extension command for hi_mapi_aenc_set_param / hi_mapi_aenc_get_param.
   Suffix convention:
     _CONFIG : must be set before hi_mapi_aenc_start; returns HI_MAPI_AENC_ESTATEERR if called while STARTED.
     _PARAM  : settable at any state. */
typedef enum {
    HI_MAPI_AENC_CMD_PAYLOAD_FORMAT_CONFIG = 0,  /* hi_mapi_audio_payload_format, OPUS only */
    HI_MAPI_AENC_CMD_BUTT
} hi_mapi_aenc_cmd;

/** @} */ /** <!-- ==== AENC End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_AENC_H__ */
