/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_DISP_ADAPT_DEFINE_H__
#define __HI_MAPI_DISP_ADAPT_DEFINE_H__

#include "hi_mw_type.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define HI_MAPI_DISP_INTF_CVBS       (0x01L << 0)
#define HI_MAPI_DISP_INTF_VGA        (0x01L << 1)
#define HI_MAPI_DISP_INTF_BT656      (0x01L << 2)
#define HI_MAPI_DISP_INTF_BT1120     (0x01L << 3)
#define HI_MAPI_DISP_INTF_HDMI       (0x01L << 4)
#define HI_MAPI_DISP_INTF_RGB_6BIT   (0x01L << 5)
#define HI_MAPI_DISP_INTF_RGB_8BIT   (0x01L << 6)
#define HI_MAPI_DISP_INTF_RGB_16BIT  (0x01L << 7)
#define HI_MAPI_DISP_INTF_RGB_18BIT  (0x01L << 8)
#define HI_MAPI_DISP_INTF_RGB_24BIT  (0x01L << 9)
#define HI_MAPI_DISP_INTF_MIPI       (0x01L << 10)
#define HI_MAPI_DISP_INTF_MIPI_SLAVE (0x01L << 11)
#define HI_MAPI_DISP_INTF_HDMI1      (0x01L << 12)
#define HI_MAPI_DISP_INTF_LCD        (0x01L << 13)

typedef  td_s32 hi_mapi_disp_intf_type;

typedef enum {
    HI_MAPI_DISP_OUTPUT_PAL = 0, /* PAL standard */
    HI_MAPI_DISP_OUTPUT_NTSC = 1, /* NTSC standard */
    HI_MAPI_DISP_OUTPUT_960H_PAL = 2, /* ITU-R BT.1302 960 x 576 at 50 Hz (interlaced) */
    HI_MAPI_DISP_OUTPUT_960H_NTSC = 3, /* ITU-R BT.1302 960 x 480 at 60 Hz (interlaced) */

    HI_MAPI_DISP_OUTPUT_640x480_60 = 4, /* VESA 640 x 480 at 60 Hz (non-interlaced) CVT */
    HI_MAPI_DISP_OUTPUT_480P60 = 5, /* 720 x 480 at 60 Hz. */
    HI_MAPI_DISP_OUTPUT_576P50 = 6, /* 720 x 576 at 50 Hz. */
    HI_MAPI_DISP_OUTPUT_800x600_60 = 7, /* VESA 800 x 600 at 60 Hz (non-interlaced) */
    HI_MAPI_DISP_OUTPUT_1024x768_60 = 8, /* VESA 1024 x 768 at 60 Hz (non-interlaced) */
    HI_MAPI_DISP_OUTPUT_720P50 = 9, /* 1280 x 720 at 50 Hz. */
    HI_MAPI_DISP_OUTPUT_720P60 = 10, /* 1280 x 720 at 60 Hz. */
    HI_MAPI_DISP_OUTPUT_1280x800_60 = 11, /* 1280*800@60Hz VGA@60Hz */
    HI_MAPI_DISP_OUTPUT_1280x1024_60 = 12, /* VESA 1280 x 1024 at 60 Hz (non-interlaced) */
    HI_MAPI_DISP_OUTPUT_1366x768_60 = 13, /* VESA 1366 x 768 at 60 Hz (non-interlaced) */
    HI_MAPI_DISP_OUTPUT_1400x1050_60 = 14, /* VESA 1400 x 1050 at 60 Hz (non-interlaced) CVT */
    HI_MAPI_DISP_OUTPUT_1440x900_60 = 15, /* VESA 1440 x 900 at 60 Hz (non-interlaced) CVT Compliant */
    HI_MAPI_DISP_OUTPUT_1680x1050_60 = 16, /* VESA 1680 x 1050 at 60 Hz (non-interlaced) */

    HI_MAPI_DISP_OUTPUT_1080P24 = 17, /* 1920 x 1080 at 24 Hz. */
    HI_MAPI_DISP_OUTPUT_1080P25 = 18, /* 1920 x 1080 at 25 Hz. */
    HI_MAPI_DISP_OUTPUT_1080P30 = 19, /* 1920 x 1080 at 30 Hz. */
    HI_MAPI_DISP_OUTPUT_1080I50 = 20, /* 1920 x 1080 at 50 Hz, interlaced. */
    HI_MAPI_DISP_OUTPUT_1080I60 = 21, /* 1920 x 1080 at 60 Hz, interlaced. */
    HI_MAPI_DISP_OUTPUT_1080P50 = 22, /* 1920 x 1080 at 50 Hz. */
    HI_MAPI_DISP_OUTPUT_1080P60 = 23, /* 1920 x 1080 at 60 Hz. */

    HI_MAPI_DISP_OUTPUT_1600x1200_60 = 24, /* VESA 1600 x 1200 at 60 Hz (non-interlaced) */
    HI_MAPI_DISP_OUTPUT_1920x1200_60 = 25, /* VESA 1920 x 1200 at 60 Hz (non-interlaced) CVT (Reduced Blanking) */
    HI_MAPI_DISP_OUTPUT_1920x2160_30 = 26, /* 1920x2160_30 */
    HI_MAPI_DISP_OUTPUT_2560x1440_30 = 27, /* 2560x1440_30 */
    HI_MAPI_DISP_OUTPUT_2560x1440_60 = 28, /* 2560x1440_60 */
    HI_MAPI_DISP_OUTPUT_2560x1600_60 = 29, /* 2560x1600_60 */

    HI_MAPI_DISP_OUTPUT_3840x2160_24 = 30, /* 3840x2160_24 */
    HI_MAPI_DISP_OUTPUT_3840x2160_25 = 31, /* 3840x2160_25 */
    HI_MAPI_DISP_OUTPUT_3840x2160_30 = 32, /* 3840x2160_30 */
    HI_MAPI_DISP_OUTPUT_3840x2160_50 = 33, /* 3840x2160_50 */
    HI_MAPI_DISP_OUTPUT_3840x2160_60 = 34, /* 3840x2160_60 */
    HI_MAPI_DISP_OUTPUT_4096x2160_24 = 35, /* 4096x2160_24 */
    HI_MAPI_DISP_OUTPUT_4096x2160_25 = 36, /* 4096x2160_25 */
    HI_MAPI_DISP_OUTPUT_4096x2160_30 = 37, /* 4096x2160_30 */
    HI_MAPI_DISP_OUTPUT_4096x2160_50 = 38, /* 4096x2160_50 */
    HI_MAPI_DISP_OUTPUT_4096x2160_60 = 39, /* 4096x2160_60 */
    HI_MAPI_DISP_OUTPUT_7680x4320_30 = 40, /* 7680x4320_30 */

    HI_MAPI_DISP_OUTPUT_240x320_50 = 41, /* 240x320_50 */
    HI_MAPI_DISP_OUTPUT_320x240_50 = 42, /* 320x240_50 */
    HI_MAPI_DISP_OUTPUT_240x320_60 = 43, /* 240x320_60 */
    HI_MAPI_DISP_OUTPUT_320x240_60 = 44, /* 320x240_60 */
    HI_MAPI_DISP_OUTPUT_800x600_50 = 45, /* 800x600_50 */

    HI_MAPI_DISP_OUTPUT_720x1280_60 = 46, /* For MIPI DSI Tx 720 x1280 at 60 Hz */
    HI_MAPI_DISP_OUTPUT_1080x1920_60 = 47, /* For MIPI DSI Tx 1080x1920 at 60 Hz */

    HI_MAPI_DISP_OUTPUT_USER = 48, /* User timing. */

    HI_MAPI_DISP_OUTPUT_BUTT,
} hi_mapi_disp_intf_sync;

typedef enum {
    HI_MAPI_DISP_CLK_SOURCE_PLL,        /* Clock source type PLL */
    HI_MAPI_DISP_CLK_SOURCE_LCDMCLK,    /* Clock source type LCDMCLK */
    HI_MAPI_DISP_CLK_SRC_PLL_FOUT4 = 2, /* Clock source type PLL FOUT4 */
    HI_MAPI_DISP_CLK_SRC_FIXED = 3,     /* Clock source type FIXED */

    HI_MAPI_DISP_CLK_SOURCE_BUTT
} hi_mapi_disp_clk_source;

typedef struct {
    td_u32 fbdiv;
    td_u32 frac;
    td_u32 refdiv;
    td_u32 postdiv1;
    td_u32 postdiv2;
} hi_mapi_disp_user_intf_sync_pll;

typedef enum {
    HI_MAPI_DISP_FIXED_CLK_148_5M  = 0, /* Fixed clock source 148.5MHz */
    HI_MAPI_DISP_FIXED_CLK_134_4M  = 1, /* Fixed clock source 134.4MHz */
    HI_MAPI_DISP_FIXED_CLK_108M    = 2, /* Fixed clock source 108MHz */
    HI_MAPI_DISP_FIXED_CLK_74_25M  = 3, /* Fixed clock source 74.25MHz */
    HI_MAPI_DISP_FIXED_CLK_64M     = 4, /* Fixed clock source 64MHz */
    HI_MAPI_DISP_FIXED_CLK_54M     = 5, /* Fixed clock source 54MHz */
    HI_MAPI_DISP_FIXED_CLK_37_125M = 6, /* Fixed clock source 37.125MHz */
    HI_MAPI_DISP_FIXED_CLK_13_5M   = 7, /* Fixed clock source 13.5MHz */

    HI_MAPI_DISP_FIXED_CLK_BUTT,
} hi_mapi_disp_fixed_clk;

typedef struct {
    hi_mapi_disp_clk_source clk_source;

    union {
        hi_mapi_disp_user_intf_sync_pll user_sync_pll;
        td_u32 lcd_mclk_div;
        hi_mapi_disp_fixed_clk fixed_clk; /* fixed clock.
                                          AUTO: hi_mapi_disp_fixed_clk:HI_MAPI_DISP_CLK_SRC_FIXED; */
    };
} hi_mapi_disp_user_intf_sync_attr;

typedef enum {
    HI_MAPI_DISP_CSC_MATRIX_BT601LIMIT_TO_BT601LIMIT = 0, /* Identity matrix.   from BT.601 limit to BT.601 limit */
    HI_MAPI_DISP_CSC_MATRIX_BT601FULL_TO_BT601LIMIT = 1,  /* Change color space from BT.601 full to BT.601 limit */
    HI_MAPI_DISP_CSC_MATRIX_BT709LIMIT_TO_BT601LIMIT = 2, /* Change color space from BT.709 limit to BT.601 limit */
    HI_MAPI_DISP_CSC_MATRIX_BT709FULL_TO_BT601LIMIT = 3,  /* Change color space from BT.709 full to BT.601 limit */

    HI_MAPI_DISP_CSC_MATRIX_BT601LIMIT_TO_BT709LIMIT = 4, /* Change color space from BT.601 limit to BT.709 limit */
    HI_MAPI_DISP_CSC_MATRIX_BT601FULL_TO_BT709LIMIT = 5,  /* Change color space from BT.601 full to BT.709 limit */
    HI_MAPI_DISP_CSC_MATRIX_BT709LIMIT_TO_BT709LIMIT = 6, /* Identity matrix.   from BT.709 limit to BT.709 limit */
    HI_MAPI_DISP_CSC_MATRIX_BT709FULL_TO_BT709LIMIT = 7,  /* Change color space from BT.709 full to BT.709 limit */

    HI_MAPI_DISP_CSC_MATRIX_BT601LIMIT_TO_BT601FULL = 8,  /* Change color space from BT.601 limit to BT.601 full */
    HI_MAPI_DISP_CSC_MATRIX_BT601FULL_TO_BT601FULL = 9,   /* Identity matrix.   from BT.601 full to BT.601 full */
    HI_MAPI_DISP_CSC_MATRIX_BT709LIMIT_TO_BT601FULL = 10,  /* Change color space from BT.709 limit to BT.601 full */
    HI_MAPI_DISP_CSC_MATRIX_BT709FULL_TO_BT601FULL = 11,   /* Change color space from BT.709 full to BT.601 full */

    HI_MAPI_DISP_CSC_MATRIX_BT601LIMIT_TO_BT709FULL = 12,  /* Change color space from BT.601 limit to BT.709 full */
    HI_MAPI_DISP_CSC_MATRIX_BT601FULL_TO_BT709FULL = 13,   /* Change color space from BT.601 full to BT.709 full */
    HI_MAPI_DISP_CSC_MATRIX_BT709LIMIT_TO_BT709FULL = 14,  /* Change color space from BT.709 limit to BT.709 full */
    HI_MAPI_DISP_CSC_MATRIX_BT709FULL_TO_BT709FULL = 15,   /* Identity matrix.   from BT.709 full to BT.709 full */

    HI_MAPI_DISP_CSC_MATRIX_BT601LIMIT_TO_RGBFULL = 16,    /* Change color space from BT.601 limit to RGB full */
    HI_MAPI_DISP_CSC_MATRIX_BT601FULL_TO_RGBFULL = 17,     /* Change color space from BT.601 full to RGB full */
    HI_MAPI_DISP_CSC_MATRIX_BT709LIMIT_TO_RGBFULL = 18,    /* Change color space from BT.709 limit to RGB full */
    HI_MAPI_DISP_CSC_MATRIX_BT709FULL_TO_RGBFULL = 19,     /* Change color space from BT.709 full to RGB full */

    HI_MAPI_DISP_CSC_MATRIX_BT601LIMIT_TO_RGBLIMIT = 20,   /* Change color space from BT.601 limit to RGB limit */
    HI_MAPI_DISP_CSC_MATRIX_BT601FULL_TO_RGBLIMIT = 21,    /* Change color space from BT.709 full to RGB limit */
    HI_MAPI_DISP_CSC_MATRIX_BT709LIMIT_TO_RGBLIMIT = 22,   /* Change color space from BT.601 limit to RGB limit */
    HI_MAPI_DISP_CSC_MATRIX_BT709FULL_TO_RGBLIMIT = 23,    /* Change color space from BT.709 full to RGB limit */

    HI_MAPI_DISP_CSC_MATRIX_RGBFULL_TO_BT601LIMIT = 24,    /* Change color space from RGB full to BT.601 limit */
    HI_MAPI_DISP_CSC_MATRIX_RGBFULL_TO_BT601FULL = 25,     /* Change color space from RGB full to BT.601 full */
    HI_MAPI_DISP_CSC_MATRIX_RGBFULL_TO_BT709LIMIT = 26,    /* Change color space from RGB full to BT.709 limit */
    HI_MAPI_DISP_CSC_MATRIX_RGBFULL_TO_BT709FULL = 27,     /* Change color space from RGB full to BT.709 full */

    HI_MAPI_DISP_CSC_MATRIX_BUTT,
} hi_mapi_disp_csc_matrix;

typedef struct {
    hi_mapi_disp_csc_matrix csc_matrix; /* CSC matrix */
    td_u32 luma; /* Range:    [0, 100]; luminance, default: 50 */
    td_u32 contrast; /* Range:    [0, 100]; contrast, default: 50 */
    td_u32 hue; /* Range:    [0, 100]; hue, default: 50 */
    td_u32 satuature; /* Range:    [0, 100]; satuature, default: 50 */
    td_bool enable_ex_csc; /* Range: [0, 1]; extended csc switch for luminance, default: 0 */
} hi_mapi_disp_csc_attr;

typedef struct {
    td_bool synm; /* sync mode(0:timing,as BT.656; 1:signal,as LCD) */
    td_bool iop;  /* interlaced or progressive display(0:i; 1:p) */
    td_u8 intfb;  /* interlace bit width while output */

    td_u16 vact;  /* vertical active area */
    td_u16 vbb;   /* vertical back blank porch */
    td_u16 vfb;   /* vertical front blank porch */

    td_u16 hact;  /* horizontal active area */
    td_u16 hbb;   /* horizontal back blank porch */
    td_u16 hfb;   /* horizontal front blank porch */
    td_u16 hmid;  /* bottom horizontal active area */

    td_u16 bvact; /* bottom vertical active area */
    td_u16 bvbb;  /* bottom vertical back blank porch */
    td_u16 bvfb;  /* bottom vertical front blank porch */

    td_u16 hpw;   /* horizontal pulse width */
    td_u16 vpw;   /* vertical pulse width */

    td_bool idv;  /* inverse data valid of output */
    td_bool ihs;  /* inverse horizontal synch signal */
    td_bool ivs;  /* inverse vertical synch signal */
} hi_mapi_disp_sync_info;

typedef struct {
    td_u32 bg_color;                  /* Background color of a device, in RGB format. */
    hi_mapi_disp_intf_type  intf_type; /* Type of a disp interface */
    hi_mapi_disp_intf_sync  intf_sync; /* Type of a disp interface timing */
    hi_mapi_disp_sync_info  sync_info; /* Information about disp interface timings */
} hi_mapi_disp_pub_attr;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_DISP_ADAPT_DEFINE_H_ */
