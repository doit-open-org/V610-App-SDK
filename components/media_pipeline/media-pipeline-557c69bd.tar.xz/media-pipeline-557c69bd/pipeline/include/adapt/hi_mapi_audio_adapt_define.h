/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_AUDIO_ADAPT_DEFINE_H__
#define __HI_MAPI_AUDIO_ADAPT_DEFINE_H__

#include "hi_mapi_comm_adapt_define.h"
#include "ot_common_aio.h"


#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */


#define HI_MAPI_AUDIO_STEREO_SOUND_MODE_CHN_CNT 2
#define HI_MAPI_AUDIO_MONO_SOUND_MODE_CHN_CNT   1

#define HI_MAPI_AI_TALKVQEV2_MASK_PNR       0x1
#define HI_MAPI_AI_TALKVQEV2_MASK_NR        0x2
#define HI_MAPI_AI_TALKVQEV2_MASK_EQ        0x4
#define HI_MAPI_AI_TALKVQEV2_MASK_AGC       0x8
#define HI_MAPI_AI_TALKVQEV2_MASK_DRC       0x10
#define HI_MAPI_AI_TALKVQEV2_MASK_LIMITER   0x20
#define HI_MAPI_AI_TALKVQEV2_MASK_DEREVERB  0x40
#define HI_MAPI_AI_TALKVQEV2_MASK_FMP       0x80
#define HI_MAPI_AI_TALKVQEV2_MASK_WNR       0x100
#define HI_MAPI_AI_TALKVQEV2_MASK_AEC       0x200
#define HI_MAPI_AI_TALKVQEV2_MASK_HS        0x400

#define HI_MAPI_AI_RECORDVQE_MASK_HPF       0x1
#define HI_MAPI_AI_RECORDVQE_MASK_RNR       0x2
#define HI_MAPI_AI_RECORDVQE_MASK_HDR       0x4
#define HI_MAPI_AI_RECORDVQE_MASK_DRC       0x8
#define HI_MAPI_AI_RECORDVQE_MASK_EQ        0x10
#define HI_MAPI_AI_RECORDVQE_MASK_AGC       0x20

#define HI_MAPI_AI_TALKVQE_MASK_HPF     0x1
#define HI_MAPI_AI_TALKVQE_MASK_AEC     0x2
#define HI_MAPI_AI_TALKVQE_MASK_AGC     0x8
#define HI_MAPI_AI_TALKVQE_MASK_EQ      0x10
#define HI_MAPI_AI_TALKVQE_MASK_ANR     0x20

#define HI_MAPI_AO_VQE_MASK_HPF         0x1
#define HI_MAPI_AO_VQE_MASK_ANR         0x2
#define HI_MAPI_AO_VQE_MASK_AGC         0x4
#define HI_MAPI_AO_VQE_MASK_EQ          0x8


/************* audio comm struct *************/
typedef enum {
    HI_MAPI_AUDIO_SAMPLE_RATE_8000  = 8000,   /* 8K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_12000 = 12000,  /* 12K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_11025 = 11025,  /* 11.025K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_16000 = 16000,  /* 16K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_22050 = 22050,  /* 22.050K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_24000 = 24000,  /* 24K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_32000 = 32000,  /* 32K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_44100 = 44100,  /* 44.1K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_48000 = 48000,  /* 48K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_64000 = 64000,  /* 64K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_96000 = 96000,  /* 96K samplerate */
    HI_MAPI_AUDIO_SAMPLE_RATE_BUTT,
} hi_mapi_audio_sample_rate;

typedef enum {
    HI_MAPI_AUDIO_BIT_WIDTH_8  = 0,  /* 8bit width */
    HI_MAPI_AUDIO_BIT_WIDTH_16 = 1,  /* 16bit width */
    HI_MAPI_AUDIO_BIT_WIDTH_24 = 2,  /* 24bit width */
    HI_MAPI_AUDIO_BIT_WIDTH_BUTT,
} hi_mapi_audio_bit_width;

typedef enum  {
    HI_MAPI_AIO_MODE_I2S_MASTER = 0,  /* AIO I2S master mode */
    HI_MAPI_AIO_MODE_I2S_SLAVE,       /* AIO I2S slave mode */
    HI_MAPI_AIO_MODE_PCM_SLAVE_STD,   /* AIO PCM slave standard mode */
    HI_MAPI_AIO_MODE_PCM_SLAVE_NSTD,  /* AIO PCM slave non-standard mode */
    HI_MAPI_AIO_MODE_PCM_MASTER_STD,  /* AIO PCM master standard mode */
    HI_MAPI_AIO_MODE_PCM_MASTER_NSTD, /* AIO PCM master non-standard mode */
    HI_MAPI_AIO_MODE_BUTT
} hi_mapi_aio_work_mode;

typedef enum {
    HI_MAPI_AUDIO_SOUND_MODE_MONO   = 0,  /* mono */
    HI_MAPI_AUDIO_SOUND_MODE_STEREO = 1,  /* stereo */
    HI_MAPI_AUDIO_SOUND_MODE_BUTT
} hi_mapi_audio_sound_mode;

typedef enum {
    HI_MAPI_AUDIO_TRACK_NORMAL      = 0,
    HI_MAPI_AUDIO_TRACK_BOTH_LEFT   = 1,
    HI_MAPI_AUDIO_TRACK_BOTH_RIGHT  = 2,
    HI_MAPI_AUDIO_TRACK_EXCHANGE    = 3,
    HI_MAPI_AUDIO_TRACK_MIX         = 4,
    HI_MAPI_AUDIO_TRACK_LEFT_MUTE   = 5,
    HI_MAPI_AUDIO_TRACK_RIGHT_MUTE  = 6,
    HI_MAPI_AUDIO_TRACK_BOTH_MUTE   = 7,
    HI_MAPI_AUDIO_TRACK_BUTT
} hi_mapi_audio_track_mode;

typedef enum {
    HI_MAPI_ACODEC_MIXER_IN0   = 0x0,
    HI_MAPI_ACODEC_MIXER_IN1   = 0x1,
    HI_MAPI_ACODEC_MIXER_IN_D  = 0x2,
    HI_MAPI_ACODEC_MIXER_BUTT,
} hi_mapi_aio_acodec_mixer;

typedef enum {
    HI_MAPI_AIO_I2STYPE_INNERCODEC = 0, /* AIO I2S connect inner audio CODEC */
    HI_MAPI_AIO_I2STYPE_INNERHDMI,      /* AIO I2S connect Inner HDMI */
    HI_MAPI_AIO_I2STYPE_EXTERN,         /* AIO I2S connect extern hardware */
} hi_mapi_aio_i2s_type;

typedef ot_audio_frame hi_mapi_audio_frame;

typedef struct {
    td_u8 MAPI_ALIGN_ATTRIBUTE *stream;  /* the virtual address of stream */
    td_u64 MAPI_ALIGN_ATTRIBUTE phy_addr; /* the physics address of stream */
    td_u32 len;                          /* stream lenth, by bytes */
    td_u64 time_stamp;                    /* frame time stamp */
    td_u32 seq;                          /* frame seq,if stream is not a valid frame,u32Seq is 0 */
} hi_mapi_audio_stream;

typedef enum {
    HI_MAPI_VQE_WORKSTATE_COMMON  = 0,
    HI_MAPI_VQE_WORKSTATE_MUSIC   = 1,
    HI_MAPI_VQE_WORKSTATE_NOISY   = 2
} hi_mapi_audio_work_state;

/********** acap struct *************/
typedef struct {
    hi_mapi_audio_frame ref_frame; /* aec reference audio frame */
    td_bool             valid;    /* whether frame is valid */
    td_bool             sys_bind;  /* whether is sysbind */
} hi_mapi_aec_frame;

/********** aenc struct *************/
typedef struct {
    td_u32 resv;            /* reserve item */
} hi_mapi_aenc_g711_attr;

typedef struct {
    td_u32 resv;            /* reserve item */
} hi_mapi_aenc_lpcm_attr;

/********** adec struct *************/
typedef enum {
    HI_MAPI_ADEC_MODE_PACK = 0,  /* require input is valid dec pack(a
                                    complete frame encode result),
                                    e.g.the stream get from AENC is a
                                    valid dec pack, the stream know actually
                                    pack len from file is also a dec pack.
                                    this mode is high-performative */
    HI_MAPI_ADEC_MODE_STREAM,  /* input is stream, low-performative,
                                  if you couldn't find out whether a stream is
                                  vaild dec pack, you could use
                                  this mode */
    HI_MAPI_ADEC_MODE_BUTT
} hi_mapi_adec_mode;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_COMM_ADAPT_DEFINE_H_ */
