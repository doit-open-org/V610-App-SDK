/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_HDMI_ADAPT_DEFINE_H__
#define __HI_MAPI_HDMI_ADAPT_DEFINE_H__

#include "hi_mw_type.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

typedef enum {
    HI_MAPI_HDMI_ID_0         = 0,               /* HDMI 0 */
    HI_MAPI_HDMI_ID_BUTT
} hi_mapi_hdmi_id;

/* HDMI EVENT TYPE */
typedef enum {
    HI_MAPI_HDMI_EVENT_HOTPLUG = 0x10,           /* HDMI hot-plug event */
    HI_MAPI_HDMI_EVENT_NO_PLUG,                  /* HDMI cable disconnection event */
    HI_MAPI_HDMI_EVENT_EDID_FAIL,                /* HDMI EDID read failure event */
    HI_MAPI_HDMI_EVENT_BUTT
} hi_mapi_hdmi_event_type;

/* hdmi event handling callback function */
typedef void (*hi_mapi_hdmi_call_back)(hi_mapi_hdmi_event_type event, td_void *private_data);

typedef struct {
    hi_mapi_hdmi_call_back hdmi_event_callback;    /* Event handling callback function */
    td_void               *private_data;         /* Private data of the callback functions and parameters */
} hi_mapi_hdmi_call_back_func;


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_HDMI_ADAPT_DEFINE_H_ */
