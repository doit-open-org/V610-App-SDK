/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_AENC_ADPT_H__
#define __HI_MAPI_AENC_ADPT_H__

#include "hi_mapi_comm_define.h"
#include "hi_mapi_audio_adapt_define.h"
#include "ot_aacenc.h"
#include "ot_common_aenc.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     AENC ADPT */
/** @{ */ /** <!-- [AENC ADPT] */

/** Macro define */
#define HI_MAPI_AENC_AACLD_SAMPLES_PER_FRAME   512 /** samples per frame for AACLD */
#define HI_MAPI_AENC_AACLC_SAMPLES_PER_FRAME   1024 /** samples per frame for AACLC */
#define HI_MAPI_AENC_AACPLUS_SAMPLES_PER_FRAME 2048 /** samples per frame for aacPlus */

#define HI_MAPI_AENC_MAX_AAC_MAINBUF_SIZE (768 * 2) /** max length of AAC stream by bytes */

/** Struct */
typedef enum {
    HI_MAPI_AAC_TYPE_AACLC = 0,    /* AAC LC */
    HI_MAPI_AAC_TYPE_EAAC = 1,     /* eAAC  (HEAAC or AAC+  or aacPlusV1) */
    HI_MAPI_AAC_TYPE_EAACPLUS = 2, /* eAAC+ (AAC++ or aacPlusV2) */
    HI_MAPI_AAC_TYPE_AACLD = 3,
    HI_MAPI_AAC_TYPE_AACELD = 4,
    HI_MAPI_AAC_TYPE_BUTT,
} hi_mapi_aenc_aac_type;

typedef enum {
    HI_MAPI_AAC_BPS_8K  = 8000,
    HI_MAPI_AAC_BPS_16K = 16000,
    HI_MAPI_AAC_BPS_22K = 22000,
    HI_MAPI_AAC_BPS_24K = 24000,
    HI_MAPI_AAC_BPS_32K = 32000,
    HI_MAPI_AAC_BPS_48K = 48000,
    HI_MAPI_AAC_BPS_64K = 64000,
    HI_MAPI_AAC_BPS_96K = 96000,
    HI_MAPI_AAC_BPS_128K = 128000,
    HI_MAPI_AAC_BPS_256K = 256000,
    HI_MAPI_AAC_BPS_320K = 320000,
    HI_MAPI_AAC_BPS_BUTT
} hi_mapi_aenc_aac_bps;

/*
    AAC Commendatory Parameter:
    Sampling Rate(HZ)   LC BitRate(Kbit/s)  EAAC BitRate (Kbit/s)   EAAC+ BitRate (Kbit/s)
    48000               128                 48                      32  24
    44100               128                 48                      32  24
    32000               96                  22                      16
    24000               64
    22050               64
    16000               48
*/
typedef enum {
    HI_MAPI_AAC_TRANS_TYPE_ADTS = 0, /* ADTS */
    HI_MAPI_AAC_TRANS_TYPE_LOAS = 1, /* LOAS */
    HI_MAPI_AAC_TRANS_TYPE_LATM_MCP1 = 2, /* LATM_MCP1 */
    HI_MAPI_AAC_TRANS_TYPE_BUTT
} hi_mapi_aenc_aac_trans_type;

typedef struct {
    hi_mapi_aenc_aac_type aac_type;         /* AAC profile type */
    hi_mapi_aenc_aac_bps bit_rate;          /* AAC bitrate (LC:48~128, EAAC:22~48, EAAC+:16~32) */
    hi_mapi_audio_sample_rate sample_rate;  /* AAC sample rate (LC:16~48, EAAC:32~48, EAAC+:32~48) */
    hi_mapi_audio_bit_width bit_width;      /* AAC bit width (only support 16bit) */
    hi_mapi_audio_sound_mode sound_mode;    /* sound type of inferent audio frame */
    hi_mapi_aenc_aac_trans_type trans_type;  /* AAC Trans type */
    td_s16 band_width; /* targeted audio bandwidth in Hz (0 or 1000~enSmpRate/2), the default is 0 */
} hi_mapi_aenc_aac_attr;

typedef enum {
    HI_MAPI_OPUS_BPS_16K = 16000,
    HI_MAPI_OPUS_BPS_22K = 22000,
    HI_MAPI_OPUS_BPS_24K = 24000,
    HI_MAPI_OPUS_BPS_32K = 32000,
    HI_MAPI_OPUS_BPS_44K = 44000,
    HI_MAPI_OPUS_BPS_48K = 48000,
    HI_MAPI_OPUS_BPS_64K = 64000,
    HI_MAPI_OPUS_BPS_96K = 96000,
    HI_MAPI_OPUS_BPS_128K = 128000,
    HI_MAPI_OPUS_BPS_132K = 132000,
    HI_MAPI_OPUS_BPS_144K = 144000,
    HI_MAPI_OPUS_BPS_192K = 192000,
    HI_MAPI_OPUS_BPS_256K = 256000,
    HI_MAPI_OPUS_BPS_288K = 288000,
    HI_MAPI_OPUS_BPS_320K = 320000,
    HI_MAPI_OPUS_BPS_BUTT
} hi_mapi_aenc_opus_bps;

typedef enum {
    HI_MAPI_OPUS_APPLICATION_VOIP = 2048,
    HI_MAPI_OPUS_APPLICATION_AUDIO = 2049,
    HI_MAPI_OPUS_APPLICATION_RESTRICTED_LOWDELAY = 2051,
} hi_mapi_aenc_opus_application;

typedef struct {
    hi_mapi_audio_sample_rate sample_rate;
    hi_mapi_audio_bit_width bit_width;
    hi_mapi_audio_sound_mode sound_mode;
    hi_mapi_aenc_opus_bps bit_rate;
    hi_mapi_aenc_opus_application application;
} hi_mapi_aenc_opus_attr;

#define HI_MAPI_AENC_MAX_MAINBUF_SIZE 2048 /* mp3 minium size of output buffer. UNIT:bytes */

typedef enum {
    HI_MAPI_MP3_BPS_32K     = 32000,
    HI_MAPI_MP3_BPS_40K     = 40000,
    HI_MAPI_MP3_BPS_48K     = 48000,
    HI_MAPI_MP3_BPS_56K     = 56000,
    HI_MAPI_MP3_BPS_64K     = 64000,
    HI_MAPI_MP3_BPS_80K     = 80000,
    HI_MAPI_MP3_BPS_96K     = 96000,
    HI_MAPI_MP3_BPS_112K    = 112000,
    HI_MAPI_MP3_BPS_128K    = 128000,
    HI_MAPI_MP3_BPS_160K    = 160000,
    HI_MAPI_MP3_BPS_192K    = 192000,
    HI_MAPI_MP3_BPS_224K    = 224000,
    HI_MAPI_MP3_BPS_256K    = 256000,
    HI_MAPI_MP3_BPS_320K    = 320000,
} hi_mapi_aenc_mp3_bps;

typedef struct {
    hi_mapi_audio_sample_rate sample_rate; /* sample rate, support [8k, 48k] */
    hi_mapi_audio_bit_width   bit_width; /* bit width (only support 16bit) */
    hi_mapi_audio_sound_mode  sound_mode; /* sound mode of inferent audio frame */

    hi_mapi_aenc_mp3_bps bit_rate; /* encode bitrate. */
    td_u32              quality; /* encode bitstream quality, support[0, 9].
                                    0:  Highest quality, very slow;
                                    9:  Poor quality, but fast. default 7. */
} hi_mapi_aenc_mp3_attr;

/** @} */ /** <!-- ==== AENC ADPT End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
