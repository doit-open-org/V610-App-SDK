/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef HI_MAPI_COMM_ARCH_DEFINE_H
#define HI_MAPI_COMM_ARCH_DEFINE_H

#include "ot_common_sys.h"
#include "ot_common_vb.h"
#include "hi_mw_type.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define MAPI_ALIGN_ATTRIBUTE          ATTRIBUTE

#define HI_MAPI_MAX_MMZ_NAME_LEN      OT_MAX_MMZ_NAME_LEN
#define HI_MAPI_VB_MAX_COMMON_POOLS   OT_VB_MAX_COMMON_POOLS
#define HI_MAPI_VI_VPSS_MAX_MODE_NUM  OT_VI_MAX_PIPE_NUM
#define HI_MAPI_FRAME_DATA_ADDR_NUM   2
#define HI_MAPI_ADEC_CHN_MAX_NUM     (OT_ADEC_MAX_CHN_NUM / 2)

typedef enum {
    HI_MAPI_PIXEL_FORMAT_RGB_444 = 0,
    HI_MAPI_PIXEL_FORMAT_RGB_555,
    HI_MAPI_PIXEL_FORMAT_RGB_565,
    HI_MAPI_PIXEL_FORMAT_RGB_888,

    HI_MAPI_PIXEL_FORMAT_BGR_444,
    HI_MAPI_PIXEL_FORMAT_BGR_555,
    HI_MAPI_PIXEL_FORMAT_BGR_565,
    HI_MAPI_PIXEL_FORMAT_BGR_888,

    HI_MAPI_PIXEL_FORMAT_ARGB_1555,
    HI_MAPI_PIXEL_FORMAT_ARGB_4444,
    HI_MAPI_PIXEL_FORMAT_ARGB_8565,
    HI_MAPI_PIXEL_FORMAT_ARGB_8888,
    HI_MAPI_PIXEL_FORMAT_ARGB_2BPP,
    HI_MAPI_PIXEL_FORMAT_ARGB_CLUT2,
    HI_MAPI_PIXEL_FORMAT_ARGB_CLUT2_2X2,
    HI_MAPI_PIXEL_FORMAT_ARGB_CLUT2_4X4,
    HI_MAPI_PIXEL_FORMAT_ARGB_CLUT4,
    HI_MAPI_PIXEL_FORMAT_ARGB_CLUT4_2X2,
    HI_MAPI_PIXEL_FORMAT_ARGB_CLUT4_4X4,

    HI_MAPI_PIXEL_FORMAT_ABGR_1555,
    HI_MAPI_PIXEL_FORMAT_ABGR_4444,
    HI_MAPI_PIXEL_FORMAT_ABGR_8565,
    HI_MAPI_PIXEL_FORMAT_ABGR_8888,

    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_8BPP,
    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_10BPP,
    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_12BPP,
    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_14BPP,
    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP,

    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_H10,
    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_H12,
    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_H14,

    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_L10,
    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_L12,
    HI_MAPI_PIXEL_FORMAT_RGB_BAYER_16BPP_L14,

    HI_MAPI_PIXEL_FORMAT_YVU_PLANAR_422,
    HI_MAPI_PIXEL_FORMAT_YVU_PLANAR_420,
    HI_MAPI_PIXEL_FORMAT_YVU_PLANAR_444,

    HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_422,
    HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420,
    HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_444,

    HI_MAPI_PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    HI_MAPI_PIXEL_FORMAT_YUV_SEMIPLANAR_420,
    HI_MAPI_PIXEL_FORMAT_YUV_SEMIPLANAR_444,

    HI_MAPI_PIXEL_FORMAT_YUYV_PACKAGE_422,
    HI_MAPI_PIXEL_FORMAT_YVYU_PACKAGE_422,
    HI_MAPI_PIXEL_FORMAT_UYVY_PACKAGE_422,
    HI_MAPI_PIXEL_FORMAT_VYUY_PACKAGE_422,
    HI_MAPI_PIXEL_FORMAT_YYUV_PACKAGE_422,
    HI_MAPI_PIXEL_FORMAT_YYVU_PACKAGE_422,
    HI_MAPI_PIXEL_FORMAT_UVYY_PACKAGE_422,
    HI_MAPI_PIXEL_FORMAT_VUYY_PACKAGE_422,
    HI_MAPI_PIXEL_FORMAT_VY1UY0_PACKAGE_422,

    HI_MAPI_PIXEL_FORMAT_YUV_400,
    HI_MAPI_PIXEL_FORMAT_UV_420,

    /* SVP data format */
    HI_MAPI_PIXEL_FORMAT_BGR_888_PLANAR,
    HI_MAPI_PIXEL_FORMAT_HSV_888_PACKAGE,
    HI_MAPI_PIXEL_FORMAT_HSV_888_PLANAR,
    HI_MAPI_PIXEL_FORMAT_LAB_888_PACKAGE,
    HI_MAPI_PIXEL_FORMAT_LAB_888_PLANAR,
    HI_MAPI_PIXEL_FORMAT_S8C1,
    HI_MAPI_PIXEL_FORMAT_S8C2_PACKAGE,
    HI_MAPI_PIXEL_FORMAT_S8C2_PLANAR,
    HI_MAPI_PIXEL_FORMAT_S8C3_PLANAR,
    HI_MAPI_PIXEL_FORMAT_S16C1,
    HI_MAPI_PIXEL_FORMAT_U8C1,
    HI_MAPI_PIXEL_FORMAT_U16C1,
    HI_MAPI_PIXEL_FORMAT_S32C1,
    HI_MAPI_PIXEL_FORMAT_U32C1,
    HI_MAPI_PIXEL_FORMAT_U64C1,
    HI_MAPI_PIXEL_FORMAT_S64C1,

    HI_MAPI_PIXEL_FORMAT_BUTT
} hi_mapi_pixel_format;

typedef enum {
    HI_MAPI_COMPRESS_MODE_NONE = 0,
    HI_MAPI_COMPRESS_MODE_SEG,
    HI_MAPI_COMPRESS_MODE_SEG_COMPACT,
    HI_MAPI_COMPRESS_MODE_TILE,
    HI_MAPI_COMPRESS_MODE_LINE,
    HI_MAPI_COMPRESS_MODE_FRAME,
    HI_MAPI_COMPRESS_MODE_FMAP,

    HI_MAPI_COMPRESS_MODE_BUTT
} hi_mapi_compress_mode;

typedef enum {
    HI_MAPI_VIDEO_FORMAT_LINEAR = 0,       /* nature video line */
    HI_MAPI_VIDEO_FORMAT_TILE_64x16,       /* tile cell: 64pixel x 16line */
    HI_MAPI_VIDEO_FORMAT_TILE_16x8,        /* tile cell: 16pixel x 8line */
    HI_MAPI_VIDEO_FORMAT_TILE_32x4,

    HI_MAPI_VIDEO_FORMAT_BUTT
} hi_mapi_video_format;

typedef struct {
    td_u64   misc_info_phys_addr;
    td_u64   jpeg_dcf_phy_addr;
    td_u64   isp_info_phy_addr;
    td_u64   low_delay_phy_addr;
    td_u64   bnr_mot_phy_addr;
    td_u64   motion_data_phy_addr;
    td_u64   frame_dng_phy_addr;
    td_u64   assip_phy_addr;

    td_void *MAPI_ALIGN_ATTRIBUTE misc_info_vir_addr;
    td_void *MAPI_ALIGN_ATTRIBUTE jpeg_dcf_vir_addr;        /* JPEG_DCF_S, used in JPEG DCF */
    td_void *MAPI_ALIGN_ATTRIBUTE isp_info_vir_addr;        /* ISP_FRAME_INFO_S, used in ISP debug,
                                                            when get raw and send raw */
    td_void *MAPI_ALIGN_ATTRIBUTE low_delay_vir_addr;       /* used in low delay */
    td_void *MAPI_ALIGN_ATTRIBUTE bnr_mot_virt_addr;        /* used for 3dnr from bnr mot */
    td_void *MAPI_ALIGN_ATTRIBUTE motion_data_vir_addr;     /* vpss 3dnr use: gme motion data,
                                                            Filter motion data, gyro data. */
    td_void *MAPI_ALIGN_ATTRIBUTE frame_dng_vir_addr;
    td_void *MAPI_ALIGN_ATTRIBUTE assip_vir_addr;
} hi_mapi_video_supplement;

/* DSP core id */
typedef enum {
    HI_MAPI_DSP_ID_0 = 0x0,
    HI_MAPI_DSP_ID_1 = 0x1,

    HI_MAPI_DSP_ID_BUTT
} hi_mapi_sys_dsp_id;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef HI_MAPI_COMM_ARCH_DEFINE_H */
