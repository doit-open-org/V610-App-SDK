/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef HI_MAPI_VENC_ARCH_DEFINE_H
#define HI_MAPI_VENC_ARCH_DEFINE_H

#include "hi_mw_type.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/* the nalu type of H265E */
typedef enum {
    HI_MAPI_VENC_H265E_NALU_BSLICE = 0,                          /* B SLICE types */
    HI_MAPI_VENC_H265E_NALU_PSLICE = 1,                          /* P SLICE types */
    HI_MAPI_VENC_H265E_NALU_ISLICE = 2,                          /* I SLICE types */
    HI_MAPI_VENC_H265E_NALU_IDRSLICE = 19,                       /* IDR SLICE types */
    HI_MAPI_VENC_H265E_NALU_VPS    = 32,                         /* VPS types */
    HI_MAPI_VENC_H265E_NALU_SPS    = 33,                         /* SPS types */
    HI_MAPI_VENC_H265E_NALU_PPS    = 34,                         /* PPS types */
    HI_MAPI_VENC_H265E_NALU_SEI    = 39,                         /* SEI types */
    HI_MAPI_VENC_H265E_NALU_ENHANCE  = 64,

    HI_MAPI_VENC_H265E_NALU_BUTT
} hi_mapi_venc_h265e_nalu_type;

typedef enum {
    HI_MAPI_VENC_SVAC3_NALU_FORBIDDEN = 0,
    HI_MAPI_VENC_SVAC3_NALU_NRAP_PATCH = 1,
    HI_MAPI_VENC_SVAC3_NALU_RAPI_PATCH = 2,
    HI_MAPI_VENC_SVAC3_NALU_PIC_HEAD = 3,
    HI_MAPI_VENC_SVAC3_NALU_IDR_PATCH = 4,
    HI_MAPI_VENC_SVAC3_NALU_EXTENSION = 5,
    HI_MAPI_VENC_SVAC3_NALU_SEI = 6,
    HI_MAPI_VENC_SVAC3_NALU_SPS = 7,
    HI_MAPI_VENC_SVAC3_NALU_PPS = 8,
    HI_MAPI_VENC_SVAC3_NALU_SEC_PS = 9,
    HI_MAPI_VENC_SVAC3_NALU_AUTH_DATA = 10,
    HI_MAPI_VENC_SVAC3_NALU_EOS = 11,
    HI_MAPI_VENC_SVAC3_NALU_CRR_NDP_PATCH = 12,
    HI_MAPI_VENC_SVAC3_NALU_RL_PATCH = 14,
    HI_MAPI_VENC_SVAC3_NALU_PIC_DL = 15,
    HI_MAPI_VENC_SVAC3_NALU_EOCVS = 16,
    HI_MAPI_VENC_SVAC3_NALU_CRR_DP_PATCH = 17,
    HI_MAPI_VENC_SVAC3_NALU_CRR_DL_PATCH = 18,
    HI_MAPI_VENC_SVAC3_NALU_CRR_PRIVACY = 19,
    HI_MAPI_VENC_SVAC3_NALU_BUTT
} hi_mapi_venc_svac3e_nalu_type;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef HI_MAPI_VENC_ARCH_DEFINE_H */
