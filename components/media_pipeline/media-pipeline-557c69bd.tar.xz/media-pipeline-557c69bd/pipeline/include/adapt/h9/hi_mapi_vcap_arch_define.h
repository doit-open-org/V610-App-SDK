/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef HI_MAPI_VCAP_ARCH_DEFINE_H
#define HI_MAPI_VCAP_ARCH_DEFINE_H

#include "ot_mipi_rx.h"
#include "ss_mpi_isp.h"
#include "ss_mpi_vi.h"
#include "ss_mpi_ae.h"
#ifdef SUPPORT_SNAP
#include "ss_mpi_snap.h"
#endif
#include "hi_mw_type.h"

#ifdef SUPPORT_GYRO
#include "ot_common_motionfusion.h"
#include "ot_common_motionsensor.h"
#endif

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define HI_MAPI_VCAP_CMP_PARAM_SIZE  OT_VI_COMPRESS_PARAM_SIZE

#define HI_MAPI_VCAP_MSENSOR_GRADIENT    OT_MSENSOR_GRADIENT

#define HI_MAPI_VCAP_MSENSOR_TEMP_GYRO   OT_MSENSOR_TEMP_GYRO
#define HI_MAPI_VCAP_MSENSOR_TEMP_ACC    OT_MSENSOR_TEMP_ACC
#define HI_MAPI_VCAP_MSENSOR_TEMP_MAGN   OT_MSENSOR_TEMP_MAGN
#define HI_MAPI_VCAP_MSENSOR_TEMP_ALL    OT_MSENSOR_TEMP_GYRO

#define HI_MAPI_VCAP_MSENSOR_DEVICE_GYRO OT_MSENSOR_DEVICE_GYRO
#define HI_MAPI_VCAP_MSENSOR_DEVICE_ACC  OT_MSENSOR_DEVICE_ACC
#define HI_MAPI_VCAP_MSENSOR_DEVICE_MAGN OT_MSENSOR_DEVICE_MAGN
#define HI_MAPI_VCAP_MSENSOR_DEVICE_ALL  OT_MSENSOR_DEVICE_ALL

#define HI_MAPI_VCAP_ISP_FUSION_RHR_FRAME_NUM  OT_ISP_WDR_MAX_FRAME_NUM

#define HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM OT_ISP_AUTO_ISO_NUM
#define HI_MAPI_VCAP_ISP_WDR_RATIO_NUM         OT_ISP_WDR_RATIO_NUM

typedef enum {
    HI_MAPI_VCAP_WDR_MODE_NONE = 0,
    HI_MAPI_VCAP_WDR_MODE_BUILT_IN,
    HI_MAPI_VCAP_WDR_MODE_QUDRA,
    HI_MAPI_VCAP_WDR_MODE_2To1_LINE,
    HI_MAPI_VCAP_WDR_MODE_2To1_FRAME,
    HI_MAPI_VCAP_WDR_MODE_3To1_LINE,
    HI_MAPI_VCAP_WDR_MODE_3To1_FRAME,
    HI_MAPI_VCAP_WDR_MODE_4To1_LINE,
    HI_MAPI_VCAP_WDR_MODE_4To1_FRAME,

    HI_MAPI_VCAP_WDR_MODE_BUTT,
} hi_mapi_vcap_wdr_mode;

typedef enum {
    HI_MAPI_VCAP_MODE_BT656 = 0,          /* BT.656 mode */
    HI_MAPI_VCAP_MODE_BT601,              /* BT.601 mode */
    HI_MAPI_VCAP_MODE_DIGITAL_CAMERA,     /* Digital Camera mode */
    HI_MAPI_VCAP_MODE_BT1120,             /* BT.1120 mode */
    HI_MAPI_VCAP_MODE_MIPI,               /* MIPI RAW mode */
    HI_MAPI_VCAP_MODE_MIPI_YUV420_NORM,   /* MIPI YUV420 mode */
    HI_MAPI_VCAP_MODE_MIPI_YUV420_LEGACY, /* MIPI YUV420 legacy mode */
    HI_MAPI_VCAP_MODE_MIPI_YUV422,        /* MIPI YUV422 mode */
    HI_MAPI_VCAP_MODE_INTF_MODE_THERMO,   /* Thermo mode */

    HI_MAPI_VCAP_MODE_ODE_BUTT
} hi_mapi_vcap_intf_mode;

typedef enum {
    HI_MAPI_VCAP_INPUT_MODE_MIPI = 0x0,    /* mipi */
    HI_MAPI_VCAP_INPUT_MODE_SUBLVDS = 0x1, /* SUB_LVDS */
    HI_MAPI_VCAP_INPUT_MODE_LVDS = 0x2,    /* LVDS */
    HI_MAPI_VCAP_INPUT_MODE_HISPI = 0x3,   /* HISPI */

    HI_MAPI_VCAP_INPUT_MODE_BUTT
} hi_mapi_vcap_input_mode;

typedef enum {
    HI_MAPI_VCAP_FRAME_INTERRUPT_START,
    HI_MAPI_VCAP_FRAME_INTERRUPT_EARLY,
    HI_MAPI_VCAP_FRAME_INTERRUPT_EARLY_END,
    HI_MAPI_VCAP_FRAME_INTERRUPT_EARLY_ONE_BUF,
    HI_MAPI_VCAP_FRAME_INTERRUPT_EARLY_END_ONE_BUF,

    HI_MAPI_VCAP_FRAME_INTERRUPT_BUTT,
} hi_mapi_vcap_frame_interrupt_type;

typedef struct {
    td_u8 md_thr_low_gain;
    td_u8 md_thr_hig_gain;
} hi_mapi_vcap_isp_fswdr_manual_attr;

typedef struct {
    td_u8 md_thr_low_gain[HI_MAPI_VCAP_ISP_WDR_RATIO_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8 md_thr_hig_gain[HI_MAPI_VCAP_ISP_WDR_RATIO_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
} hi_mapi_vcap_isp_fswdr_auto_attr;

typedef enum {
    HI_MAPI_VCAP_ISP_OP_TYPE_AUTO    = 0,
    HI_MAPI_VCAP_ISP_OP_TYPE_MANUAL  = 1,

    HI_MAPI_VCAP_ISP_OP_TYPE_BUTT
} hi_mapi_vcap_isp_op_type;

typedef struct {
    td_bool short_expo_chk;     /* Range:[0x0,0x1];Format:1.0; */
    td_u16  short_check_thd;   /* Range:[0x0,0xFFF];Format:12.0 */
    td_bool md_ref_flicker;
    td_u8 mdt_still_thd;     /* Range:[0x0,0xFE];Format:8.0 */
    td_u8 mdt_full_thd;      /* Range:[0x0,0xFE];Format:8.0,Only used for 3559AV100 */
    td_u8 mdt_long_blend;    /* Range:[0x0,0xFE] */
    hi_mapi_vcap_isp_op_type op_type;
    hi_mapi_vcap_isp_fswdr_manual_attr manual_attr;
    hi_mapi_vcap_isp_fswdr_auto_attr auto_attr;
} hi_mapi_vcap_isp_fswdr_mdt_attr;

typedef struct {
    td_bool motion_comp;
    td_bool force_long_coarse;
    td_u16 short_thr;
    td_u16 long_thr;
    td_bool force_long;
    td_u16 force_long_low_thr;
    td_u16 force_long_hig_thr;
    hi_mapi_vcap_isp_fswdr_mdt_attr wdr_mdt;
    td_u16 force_long_coarse_low_thr;
    td_u16 force_longcoarse_hig_thr;
} hi_mapi_vcap_isp_wdr_combine_attr;

typedef struct {
    /* Range:[0x0,0x3FFF];Format:14.0;The threshold of the 4 frame */
    td_u16 fusion_thr[HI_MAPI_VCAP_ISP_FUSION_RHR_FRAME_NUM];
} hi_mapi_vcap_isp_fusion_attr;

typedef enum {
    HI_MAPI_VCAP_MERGE_WDR_MODE      = 0,
    HI_MAPI_VCAP_MERGE_FUSION_MODE   = 1,

    HI_MAPI_VCAP_MERGE_BUTT
} hi_mapi_vcap_isp_wdr_merge_mode;

typedef struct {
    hi_mapi_vcap_isp_wdr_merge_mode wdr_merge_mode;
    hi_mapi_vcap_isp_wdr_combine_attr wdr_combine;
    hi_mapi_vcap_isp_fusion_attr fusion;
} hi_mapi_vcap_isp_wdr_fs_attr;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef HI_MAPI_VCAP_ARCH_DEFINE_H */
