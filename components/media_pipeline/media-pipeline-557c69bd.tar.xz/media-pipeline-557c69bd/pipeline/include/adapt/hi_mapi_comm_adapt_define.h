/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_COMM_ADAPT_DEFINE_H__
#define __HI_MAPI_COMM_ADAPT_DEFINE_H__

#include "hi_mapi_comm_arch_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     COMM */
/** @{ */ /** <!-- [COMM] */

/*********** vedio comm struct ************/
typedef struct {
    td_u32 width;
    td_u32 height;
} hi_mapi_size;

typedef struct {
    td_s32 x;
    td_s32 y;
} hi_mapi_point;

typedef struct {
    td_s32 x;
    td_s32 y;
    td_u32 width;
    td_u32 height;
} hi_mapi_rect;

typedef struct {
    td_s32 src_frame_rate; /* source frame rate */
    td_s32 dst_frame_rate; /* dest frame rate */
} hi_mapi_frame_rate_ctrl;

typedef enum  {
    HI_MAPI_VIDEO_FIELD_TOP         = 1,    /* even field */
    HI_MAPI_VIDEO_FIELD_BOTTOM      = 2,    /* odd field */
    HI_MAPI_VIDEO_FIELD_INTERLACED  = 3,    /* two interlaced fields */
    HI_MAPI_VIDEO_FIELD_FRAME       = 4,    /* frame */

    HI_MAPI_VIDEO_FIELD_BUTT
} hi_mapi_video_field;

typedef enum  {
    HI_MAPI_DYNAMIC_RANGE_SDR8 = 0,
    HI_MAPI_DYNAMIC_RANGE_SDR10,
    HI_MAPI_DYNAMIC_RANGE_HDR10,
    HI_MAPI_DYNAMIC_RANGE_HLG,
    HI_MAPI_DYNAMIC_RANGE_SLF,
    HI_MAPI_DYNAMIC_RANGE_XDR,
    HI_MAPI_DYNAMIC_RANGE_BUTT
} hi_mapi_dynamic_range;

typedef enum  {
    HI_MAPI_COLOR_GAMUT_BT601 = 0,
    HI_MAPI_COLOR_GAMUT_BT709,
    HI_MAPI_COLOR_GAMUT_BT2020,
    HI_MAPI_COLOR_GAMUT_USER,
    HI_MAPI_COLOR_GAMUT_BUTT
} hi_mapi_color_gamut;

typedef enum {
    HI_MAPI_DATA_BIT_WIDTH_8 = 0,
    HI_MAPI_DATA_BIT_WIDTH_10,
    HI_MAPI_DATA_BIT_WIDTH_12,
    HI_MAPI_DATA_BIT_WIDTH_14,
    HI_MAPI_DATA_BIT_WIDTH_16,
    HI_MAPI_DATA_BIT_WIDTH_BUTT
} hi_mapi_data_bit_width;

typedef enum {
    HI_MAPI_DATA_SEQ_VUVU = 0,
    HI_MAPI_DATA_SEQ_UVUV,
    HI_MAPI_DATA_SEQ_UYVY,
    HI_MAPI_DATA_SEQ_VYUY,
    HI_MAPI_DATA_SEQ_YUYV,
    HI_MAPI_DATA_SEQ_YVYU,

    HI_MAPI_DATA_SEQ_BUTT
} hi_mapi_yuv_data_seq;

typedef enum {
    HI_MAPI_ROTATION_0   = 0,
    HI_MAPI_ROTATION_90  = 1,
    HI_MAPI_ROTATION_180 = 2,
    HI_MAPI_ROTATION_270 = 3,

    HI_MAPI_ROTATION_BUTT
} hi_mapi_rotation;

typedef enum {
    HI_MAPI_ASPECT_RATIO_NONE   = 0,        /* full screen */
    HI_MAPI_ASPECT_RATIO_AUTO   = 1,        /* ratio no change, 1:1 */
    HI_MAPI_ASPECT_RATIO_MANUAL = 2,        /* ratio manual set */

    HI_MAPI_ASPECT_RATIO_BUTT
} hi_mapi_aspect_ratio_mode;

typedef struct {
    hi_mapi_aspect_ratio_mode mode;      /* aspect ratio mode: none/auto/manual */
    td_u32                  bg_color;   /* background color, RGB 888 */
    hi_mapi_rect            video_rect; /* valid in ASPECT_RATIO_MANUAL mode */
} hi_mapi_aspect_ratio_attr;

/************ sys comm struct *************/
typedef struct {
    td_bool           all_online;
    td_u32            frame_rate;       /* Input frame rate of VIPROC(linear/Frame mode WDR is the sensor frame rate,
                                          and the line mode WDR is the frame rate after synthesis) */
    td_u32            full_lines_std;    /* Total height of sensor, include of VBlank */
    hi_mapi_size      large_stream_size; /* VENC Large Stream Size */
    hi_mapi_size      small_stream_size; /* VENC Small Stream Size */
} hi_mapi_sys_vpss_venc_wrap_param;

typedef enum {
    HI_MAPI_VB_REMAP_MODE_NONE    = 0,  /* no remap */
    HI_MAPI_VB_REMAP_MODE_NOCACHE = 1,  /* no cache remap */
    HI_MAPI_VB_REMAP_MODE_CACHED  = 2,  /* cache remap, if you use this mode, you should flush cache by yourself */
    HI_MAPI_VB_REMAP_MODE_BUTT
} hi_mapi_sys_vb_remap_mode;

typedef struct {
    td_u64 blk_size;
    td_u32 blk_cnt;
    hi_mapi_sys_vb_remap_mode remap_mode;
    td_char mmz_name[HI_MAPI_MAX_MMZ_NAME_LEN];
} hi_mapi_sys_vb_pool_config;

typedef struct {
    td_u32 max_pool_cnt;     /* max count of pools, (0,VB_MAX_POOLS]  */
    hi_mapi_sys_vb_pool_config comm_pool[HI_MAPI_VB_MAX_COMMON_POOLS];
} hi_mapi_sys_vb_config;

typedef enum {
    HI_MAPI_VI_OFFLINE_VPSS_OFFLINE = 0,
    HI_MAPI_VI_OFFLINE_VPSS_ONLINE,
    HI_MAPI_VI_ONLINE_VPSS_OFFLINE,
    HI_MAPI_VI_ONLINE_VPSS_ONLINE,
    HI_MAPI_VI_PARALLEL_VPSS_OFFLINE,
    HI_MAPI_VI_PARALLEL_VPSS_PARALLEL,
    HI_MAPI_VI_VPSS_MODE_BUTT
} hi_mapi_vi_vpss_mode;

typedef struct {
    hi_mapi_vi_vpss_mode mode[HI_MAPI_VI_VPSS_MAX_MODE_NUM];
} hi_mapi_sys_vi_vpss_mode;

#define HI_MAPI_DCF_DRSCRIPTION_LENGTH  32
#define HI_MAPI_DCF_CAPTURE_TIME_LENGTH 20

typedef struct {
    td_u8       image_description[HI_MAPI_DCF_DRSCRIPTION_LENGTH];    /* Describes image */
    td_u8       make[HI_MAPI_DCF_DRSCRIPTION_LENGTH];                /* Shows manufacturer of digital cameras */
    td_u8       model[HI_MAPI_DCF_DRSCRIPTION_LENGTH];           /* Shows model number of digital cameras */
    td_u8       software[HI_MAPI_DCF_DRSCRIPTION_LENGTH];       /* Shows firmware (internal software of digital cameras)
                                                            * version number */

    td_u8       light_source;     /* Light source, actually this means white balance setting. '0' means unknown,
                                    '1' daylight, '2' fluorescent, '3' tungsten, '10' flash, '17' standard light A,
                                    '18' standard light B, '19' standard light C, '20' D55, '21' D65, '22' D75,
                                    '255' other */
    td_u32      focal_length;        /* Focal length of lens used to take image. Unit is millimeter */
    td_u8       scene_type;          /* Indicates the type of scene. Value '0x01'
                                        means that the image was directly photographed. */
    td_u8       custom_rendered;        /* Indicates the use of special processing on image data, such as rendering
                                            geared to output. 0 = Normal process  1 = Custom process */
    td_u8       focal_length_in35mm_film;  /* Indicates the equivalent focal length assuming a 35mm film camera, in mm */
    td_u8       scene_capture_type;  /* Indicates the type of scene that was shot. 0 = Standard,1 = Landscape,
                                        2 = Portrait,3 = Night scene. */
    td_u8       gain_control;     /* Indicates the degree of overall image gain adjustment. 0 = None,1 = Low gain up,
                                    2 = High gain up,3 = Low gain down,4 = High gain down. */
    td_u8       contrast;    /* Indicates the direction of contrast processing applied by the camera when the image
                                was shot. 0 = Normal,1 = Soft,2 = Hard */
    td_u8       saturation;   /* Indicates the direction of saturation processing applied by the camera when the image
                                was shot. 0 = Normal,1 = Low saturation,2 = High saturation */
    td_u8       sharpness;    /* Indicates the direction of sharpness processing applied by the camera when the image
                                    was shot. 0 = Normal,1 = Soft,2 = Hard . */
    td_u8       metering_mode;     /* Exposure metering method. '0' means unknown, '1' average, '2' center weighted
                                    average, '3' spot, '4' multi-spot, '5' multi-segment, '6' partial, '255' other */
} hi_mapi_isp_dcf_const_info;

typedef struct {
    td_u32      iso_speed_ratings;      /* CCD sensitivity equivalent to Ag-Hr film speedrate */
    td_u32      exposure_time;         /* Exposure time (reciprocal of shutter speed). */
    td_u32      exposure_bias_value;    /* Exposure bias (compensation) value of taking picture */
    td_u8       exposure_program;       /* Exposure program that the camera used when image was taken.
                                         '1' means manual control, '2' program normal, '3' aperture priority,
                                         '4' shutter priority, '5' program creative (slow program),
                                         '6' program action(high-speed program), '7' portrait mode,
                                         '8' landscape mode */
    td_u32      f_number;              /* The actual F-number (F-stop) of lens when the image was taken */
    td_u32      max_aperture_value;     /* Maximum aperture value of lens. */
    td_u8       exposure_mode;          /* Indicates the exposure mode set when the image was shot.
                                                   0 = Auto exposure,1 = Manual exposure, 2 = Auto bracket */
    td_u8       white_balance;          /* Indicates the white balance mode set when the image was shot.
                                                     0 = Auto white balance ,1 = Manual white balance */
} hi_mapi_isp_dcf_update_info;

typedef struct {
    hi_mapi_isp_dcf_const_info  isp_dcf_const_info;
    hi_mapi_isp_dcf_update_info isp_dcf_update_info;
} hi_mapi_isp_dcf_info;

typedef struct {
    td_u8     capture_time[HI_MAPI_DCF_CAPTURE_TIME_LENGTH]; /* The date and time when the picture data was generated */
    td_bool   flash;                                      /* whether the picture is captured when a flash lamp is on */
    td_u32    digital_zoom_ratio;                         /* Indicates the digital zoom ratio when the image was shot.
                                                            If the numerator of the recorded value is 0, this indicates
                                                            that digital zoom was not used. */
    hi_mapi_isp_dcf_info  isp_dcf_info;
} hi_mapi_jpeg_dcf;

#define HI_MAPI_CFACOLORPLANE     3
#define HI_MAPI_DNG_NP_SIZE       6
#define HI_MAPI_ISP_BAYER_CHN     4

typedef struct {
    td_u32 numerator;    /* represents the numerator of a fraction, */
    td_u32 denominator;  /* the denominator. */
} hi_mapi_dng_rational;

/*
Defines the structure of DNG image dynamic information
*/
typedef struct {
    td_u32 black_level[HI_MAPI_ISP_BAYER_CHN];           /* RO;Range: [0x0, 0xFFFF]; black level */
    hi_mapi_dng_rational as_shot_neutral[HI_MAPI_CFACOLORPLANE]; /* specifies the selected white balanceat time
                                                  of capture, encoded as the coordinates of a perfectly neutral color
                                                  in linear reference space values. */
    td_double noise_profile[HI_MAPI_DNG_NP_SIZE];          /* RO;describes the amount of noise in a raw image */
} hi_mapi_dng_image_dynamic_info;

typedef struct {
    td_bool aspect;
    td_s32 x_ratio;
    td_s32 y_ratio;
    td_s32 xy_ratio;
    td_s32 center_x_offset;
    td_s32 center_y_offset;
    td_s32 distortion_ratio;
} hi_mapi_ldc_attr;

#if defined (__SS928V100__) || defined (__HI3516DV500__) || defined (__HI3519DV500__) || defined(__HI3516CV610__)
#define HI_MAPI_LDC_SRC_LENS_COEF_SEG          1
#define HI_MAPI_LDC_DES_LENS_COEF_SEG          1
#define HI_MAPI_LDC_SRC_LENS_COEF_NUM          9
#define HI_MAPI_LDC_DES_LENS_COEF_NUM          14
#else
#define HI_MAPI_LDC_SRC_LENS_COEF_SEG          2
#define HI_MAPI_LDC_DES_LENS_COEF_SEG          3
#define HI_MAPI_LDC_SRC_LENS_COEF_NUM          4
#define HI_MAPI_LDC_DES_LENS_COEF_NUM          4
#endif
#define HI_MAPI_LDC_DST_LENS_COEF_SEG_POINT    (HI_MAPI_LDC_DES_LENS_COEF_SEG - 1)

typedef struct {
    td_s32 focal_len_x;              /* focal length in horizontal direction, with 2 decimal numbers */
    td_s32 focal_len_y;              /* focal length in vertical direction, with 2 decimal numbers */
    td_s32 coor_shift_x;             /* coordinate of image center, with 2 decimal numbers */
    td_s32 coor_shift_y;             /* Y coordinate of image center, with 2 decimal numbers */
    td_s32 src_cali_ratio[HI_MAPI_LDC_SRC_LENS_COEF_SEG][HI_MAPI_LDC_SRC_LENS_COEF_NUM];
                                  /* lens distortion coefficients of the source image, with 5 decimal numbers */
    td_s32 dst_cali_ratio[HI_MAPI_LDC_DES_LENS_COEF_SEG][HI_MAPI_LDC_DES_LENS_COEF_NUM];
                                  /* lens distortion coefficients, with 5 decimal numbers */
    td_s32 max_du;                  /* max undistorted distance before 3rd polynomial drop, with 16bits decimal */
} hi_mapi_ldc_v2_attr;

typedef struct {
    td_bool aspect;
    td_s32 x_ratio;
    td_s32 y_ratio;
    td_s32 xy_ratio;
    td_s32 focal_len_x;
    td_s32 focal_len_y;
    td_s32 coord_shift_x;
    td_s32 coord_shift_y;
    td_s32 src_calibration_ratio[HI_MAPI_LDC_SRC_LENS_COEF_NUM];
    td_s32 src_calibration_ratio_next[HI_MAPI_LDC_SRC_LENS_COEF_NUM];
    td_u32 coef_intp_ratio;
} hi_mapi_ldc_v3_attr;

typedef enum {
    HI_MAPI_LDC_VIEW_TYPE_ALL  = 0,
    HI_MAPI_LDC_VIEW_TYPE_CROP = 1,
    HI_MAPI_LDC_VIEW_TYPE_BUTT,
} hi_mapi_ldc_view_type;

typedef struct {
    hi_mapi_ldc_view_type view_type;
    td_s32 center_x_offset;
    td_s32 center_y_offset;
    td_s32 distortion_ratio;
    td_s32 min_ratio;
} hi_mapi_ldc_v4_attr;

typedef enum {
    HI_MAPI_VPSS_LUT_CELL_SIZE_16,
    HI_MAPI_VPSS_LUT_CELL_SIZE_32,
    HI_MAPI_VPSS_LUT_CELL_SIZE_64,
    HI_MAPI_VPSS_LUT_CELL_SIZE_128,
    HI_MAPI_VPSS_LUT_CELL_SIZE_256,
    HI_MAPI_VPSS_LUT_CELL_SIZE_BUTT
} hi_mapi_vpss_lut_cell_size;

typedef struct {
    td_u32  in_width;
    td_u32  in_height;
    hi_mapi_vpss_lut_cell_size cell_size;
} hi_mapi_vpss_gdc_param;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_COMM_ADAPT_DEFINE_H__ */
