/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VCAP_ADAPT_DEFINE_H__
#define __HI_MAPI_VCAP_ADAPT_DEFINE_H__

#include "hi_mapi_comm_adapt_define.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_vcap_arch_define.h"
#include "hi_mapi_errno.h"
#include "hi_mw_log.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     VCAP */
/** @{ */ /** <!-- [VCAP] */

#define HI_MAPI_VCAP_COMPMASK_NUM               (2UL)
#define HI_MAPI_VCAP_PRO_MAX_FRAME_NUM          8

#define HI_MAPI_VCAP_AXIS_NUM                   3
#define HI_MAPI_VCAP_MATRIX_NUM                 9
#define HI_MAPI_VCAP_MATRIX_TEMP_NUM            9
#define HI_MAPI_VCAP_TEMP_LUT_SAMPLES           30
#define HI_MAPI_VCAP_MFUSION_LUT_STATUS_NUM     2

/* Sharpen intensity curve number of segments */
#define HI_MAPI_VCAP_ISP_AUTO_ISO_NUM             16
#define HI_MAPI_VCAP_ISP_SHARPEN_LUMA_NUM       32
#define HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM       32

#define HI_MAPI_VCAP_ISP_EXP_RATIO_STRENGTH_NUM      16
#define HI_MAPI_VCAP_ISP_BAYER_CHN_NUM               4
#define HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE             9
#if defined (__SS928V100__)
#define HI_MAPI_VCAP_ISP_LCAC_DET_NUM                3
#endif

#define HI_MAPI_VCAP_CFA_COLORPLANE             3

#define HI_MAPI_VCAP_GPS_NUMBERATOR_DENOMINATOR 2
#define HI_MAPI_VCAP_GPS_LATITUDE_COORDINATE    3

typedef struct {
    hi_mapi_vcap_wdr_mode wdr_mode;
    td_u32 cache_line;
    td_bool reverse;
    td_u32 fusion_grp;
} hi_mapi_vcap_wdr_attr;

typedef enum {
    HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_8BIT = 0,
    HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_10BIT,
    HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_12BIT,
    HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_14BIT,
    HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_16BIT,
    HI_MAPI_VCAP_INPUT_DATA_TYPE_YUV420_8BIT_NORMAL,
    HI_MAPI_VCAP_INPUT_DATA_TYPE_YUV420_8BIT_LEGACY,
    HI_MAPI_VCAP_INPUT_DATA_TYPE_YUV422_8BIT,
    HI_MAPI_VCAP_INPUT_DATA_TYPE_YUV422_PACKED,

    HI_MAPI_VCAP_INPUT_DATA_TYPE_BUTT
} hi_mapi_vcap_input_datatype;

typedef enum {
    HI_MAPI_VCAP_DATA_TYPE_YUV = 0,
    HI_MAPI_VCAP_DATA_TYPE_RGB = 1,

    HI_MAPI_VCAP_DATA_TYPE_BUTT
} hi_mapi_vcap_data_type;

typedef enum {
    HI_MAPI_VCAP_PIPE_BYPASS_NONE,
    HI_MAPI_VCAP_PIPE_BYPASS_FE,
    HI_MAPI_VCAP_PIPE_BYPASS_BE,

    HI_MAPI_VCAP_PIPE_BYPASS_BUTT
} hi_mapi_vcap_pipe_bypass_mode;

/************ frame interrupt attr *******************/
typedef struct {
    hi_mapi_vcap_frame_interrupt_type int_type;
    td_u32 early_line;
} hi_mapi_vcap_frame_interrupt_attr;

typedef enum {
    HI_MAPI_VCAP_BAYER_RGGB    = 0,
    HI_MAPI_VCAP_BAYER_GRBG    = 1,
    HI_MAPI_VCAP_BAYER_GBRG    = 2,
    HI_MAPI_VCAP_BAYER_BGGR    = 3,

    HI_MAPI_VCAP_BAYER_BUTT
} hi_mapi_vcap_isp_bayer_format;

typedef enum {
    HI_MAPI_VCAP_ISP_SNS_NORMAL      = 0,
    HI_MAPI_VCAP_ISP_SNS_MIRROR      = 1,
    HI_MAPI_VCAP_ISP_SNS_FLIP        = 2,
    HI_MAPI_VCAP_ISP_SNS_MIRROR_FLIP = 3,

    HI_MAPI_VCAP_ISP_SNS_BUTT
} hi_mapi_vcap_isp_sns_mirror_flip_type;

typedef enum {
    HI_MAPI_VCAP_SNAP_TYPE_NORMAL,
    HI_MAPI_VCAP_SNAP_TYPE_PRO,

    HI_MAPI_VCAP_SNAP_TYPE_BUTT
} hi_mapi_vcap_snap_type;

typedef enum {
    HI_MAPI_VCAP_OPERATION_MODE_AUTO = 0,
    HI_MAPI_VCAP_OPERATION_MODE_MANUAL = 1,

    HI_MAPI_VCAP_OPERATION_MODE_BUTT
} hi_mapi_vcap_operation_mode;

typedef struct {
    td_u16 pro_exp_step[HI_MAPI_VCAP_PRO_MAX_FRAME_NUM];
} hi_mapi_vcap_snap_pro_auto_parm;

typedef struct {
    td_u32 man_exp_time[HI_MAPI_VCAP_PRO_MAX_FRAME_NUM];
    td_u32 man_sysgain[HI_MAPI_VCAP_PRO_MAX_FRAME_NUM];
} hi_mapi_vcap_snap_pro_manual_parm;

typedef struct {
    hi_mapi_vcap_operation_mode operation_mode;
    hi_mapi_vcap_snap_pro_auto_parm auto_param;
    hi_mapi_vcap_snap_pro_manual_parm manual_param;
} hi_mapi_vcap_snap_pro_param;

typedef struct {
    td_u32  frame_cnt;
    td_u32  repeat_send_times;
    hi_mapi_vcap_snap_pro_param pro_param;
} hi_mapi_vcap_snap_pro_attr;

typedef enum {
    HI_MAPI_VCAP_STITCH_ISP_CFG_NORMAL = 0,
    HI_MAPI_VCAP_STITCH_ISP_CFG_SYNC,

    HI_MAPI_VCAP_STITCH_ISP_CFG_BUTT
} hi_mapi_vcap_stitch_isp_cfg_mode;

typedef struct {
    td_bool stitch;
    hi_mapi_vcap_stitch_isp_cfg_mode mode;
    td_u32 max_pts_gap;
    td_u32 pipe_num;
    td_handle pipe_id[HI_MAPI_VCAP_MAX_PIPE_NUM];
} hi_mapi_vcap_stitch_grp_attr;

typedef struct {
    td_char gps_latitude_ref;
    td_u32 gps_latitude[HI_MAPI_VCAP_GPS_LATITUDE_COORDINATE][HI_MAPI_VCAP_GPS_NUMBERATOR_DENOMINATOR];
    td_char gps_longitude_ref;
    td_u32 gps_longitude[HI_MAPI_VCAP_GPS_LATITUDE_COORDINATE][HI_MAPI_VCAP_GPS_NUMBERATOR_DENOMINATOR];
    td_u8 gps_altitude_ref;
    td_u32 gps_altitude[HI_MAPI_VCAP_GPS_NUMBERATOR_DENOMINATOR];
} hi_mapi_vcap_gps_info;

typedef enum {
    HI_MAPI_VCAP_ISP_IRIS_F_NO_32_0 = 0,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_22_0,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_16_0,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_11_0,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_8_0,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_5_6,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_4_0,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_2_8,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_2_0,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_1_4,
    HI_MAPI_VCAP_ISP_IRIS_F_NO_1_0,

    HI_MAPI_VCAP_ISP_IRIS_F_NO_BUTT,
} hi_mapi_vcap_isp_iris_fno;

typedef struct {
    td_bool enable;
    hi_mapi_ldc_attr ldc_attr;
} hi_mapi_vcap_ldc_attr;

typedef struct {
    td_u32 max_roll_delta;
    td_s32 final_roll;
} hi_mapi_dis_roration_compensation;

typedef struct {
    td_bool enable;
    hi_mapi_dis_roration_compensation rotation_compensation;
} hi_mapi_dis_rotation_compensation_attr;

typedef struct {
    td_bool enable;
    td_bool gdc_bypass;
    td_u32 moving_subject_level;
    td_s32 rolling_shutter_coef;
    td_s32 timelag;
    td_u32 view_angle;
    td_u32 horizontal_limit;
    td_u32 vertical_limit;
    td_bool still_crop;
    td_u32 strength;
    td_bool enable_fix_ref;
    hi_mapi_dis_rotation_compensation_attr rotation_compensation;
} hi_mapi_dis_attr;


typedef struct {
    td_bool enable;                     /* Whether LDCv2 is enbale */
    hi_mapi_ldc_v2_attr attr;
} hi_mapi_vcap_ldc_v2_attr;

typedef enum {
    HI_MAPI_VCAP_DIS_MODE_4_DOF_GME = 0, /* Only use with GME in 4 dof  */
    HI_MAPI_VCAP_DIS_MODE_6_DOF_GME,     /* Only use with GME in 6 dof  */
    HI_MAPI_VCAP_DIS_MODE_GYRO,          /* Only use with gryo in 6 dof  */
    HI_MAPI_VCAP_DIS_MODE_GYRO_ADVANCE,  /* Only use with gryo advance. */
    HI_MAPI_VCAP_DIS_MODE_HYBRID,  /* Only use with gyro and gme. */
    HI_MAPI_VCAP_DIS_MODE_DOF_BUTT,
} hi_mapi_vcap_dis_mode;

/* The motion level of camera */
typedef enum {
    HI_MAPI_VCAP_DIS_MOTION_LEVEL_LOW = 0,  /* Low motion level */
    HI_MAPI_VCAP_DIS_MOTION_LEVEL_NORMAL,   /* Normal motion level */
    HI_MAPI_VCAP_DIS_MOTION_LEVEL_HIGH,     /* High motion level */

    HI_MAPI_VCAP_DIS_MOTION_LEVEL_BUTT
} hi_mapi_vcap_dis_motion_level;

/* Different product type used DIS */
typedef enum {
    HI_MAPI_VCAP_DIS_PDT_TYPE_IPC = 0, /* IPC product type */
    HI_MAPI_VCAP_DIS_PDT_TYPE_DV,      /* DV product type */
    HI_MAPI_VCAP_DIS_PDT_TYPE_DRONE,   /* DRONE product type */

    HI_MAPI_VCAP_DIS_PDT_TYPE_BUTT
} hi_mapi_vcap_dis_pdt_type;

typedef struct {
    td_u32 steady_time_thr;
    td_s32 gyro_offset;
    td_s32 acc_offset;
    td_s32 gyro_rms;
    td_s32 acc_rms;
    td_s32 gyro_offset_factor;
    td_s32 acc_offset_factor;
    td_s32 gyro_rms_factor;
    td_s32 acc_rms_factor;
} hi_mapi_vcap_mfusion_steady_detect_attr;

typedef struct {
    hi_mapi_vcap_dis_mode mode;
    hi_mapi_vcap_dis_motion_level motion_level;
    hi_mapi_vcap_dis_pdt_type pdt_type;
    td_u32 buf_num;
    td_u32 crop_ratio;
    td_u32 frame_rate;
    td_u32 gyro_output_range;
    td_u32 gyro_data_bit_width;
    td_bool camera_steady;
    td_bool scale;
} hi_mapi_vcap_dis_config;

typedef struct {
    td_u32 device_mask;        /* device mask: gyro,acc or magn */
    td_u32 temperature_mask;   /* temperature mask: gyro temperature ,acc temperatureor magn temperature */
    hi_mapi_vcap_mfusion_steady_detect_attr steady_detect_attr;
} hi_mapi_vcap_mfusion_attr;

typedef enum {
    HI_MAPI_VCAP_IMU_TEMP_DRIFT_CURV = 0, /* polynomial mode */
    HI_MAPI_VCAP_IMU_TEMP_DRIFT_LUT,      /* lookup table mode */

    HI_MAPI_VCAP_IMU_TEMP_DRIFT_BUTT
} hi_mapi_vcap_mfusion_temp_drift_mode;

typedef struct {
    td_s32 imu_lut[HI_MAPI_VCAP_TEMP_LUT_SAMPLES][HI_MAPI_VCAP_AXIS_NUM];
    td_s32 gyro_lut_status[HI_MAPI_VCAP_TEMP_LUT_SAMPLES][HI_MAPI_VCAP_MFUSION_LUT_STATUS_NUM];
    td_s32 range_min;
    td_s32 range_max;
    td_s32 step;
} hi_mapi_vcap_mfusion_temp_drift_lut;

typedef struct {
    hi_mapi_vcap_mfusion_temp_drift_mode mode;        /* temperature drift mode  */
    union {
        td_s32 temp_matrix[HI_MAPI_VCAP_MATRIX_TEMP_NUM];  /* RW;temperature drift polynomial matrix data */
        hi_mapi_vcap_mfusion_temp_drift_lut temp_lut; /* temperature drift  lookup table data */
    };
} hi_mapi_vcap_mfusion_temp_drift;

/* only ss928 support set/get */
typedef struct {
    td_bool enable; /* RW;Whether LDC is enbale */
    hi_mapi_ldc_v3_attr attr;
} hi_mapi_vcap_ldc_v3_attr;

/* only hi3516cv610 support set/get,the ldcv4 corresponds to ldcv3 in MPP. */
typedef struct {
    td_bool enable; /* RW;Whether LDC is enbale */
    hi_mapi_ldc_v4_attr attr;
} hi_mapi_vcap_ldc_v4_attr;

typedef struct {
    td_u16 rgain;       /* Range: [0x0, 0xFFF]; Multiplier for R  color channel */
    td_u16 ggain;       /* Range: [0x0, 0xFFF]; Multiplier for G  color channel */
    td_u16 bgain;       /* Range: [0x0, 0xFFF]; Multiplier for B  color channel */
} hi_mapi_vcap_isp_dng_wb_gain;

typedef struct {
    td_u16 color_temp;                   /* RW;  range:[2000,10000]; format:16.0; the current color temperature */
    td_u16 ccm[OT_ISP_CCM_MATRIX_SIZE]; /* RW;  range: [0x0, 0xFFFF]; format:8.8;
                                           CCM matrixes for different color temperature */
} hi_mapi_vcap_isp_dng_ccm_tab;

typedef struct {
    hi_mapi_vcap_isp_dng_wb_gain wb_gain1;
    hi_mapi_vcap_isp_dng_wb_gain wb_gain2;
    hi_mapi_vcap_isp_dng_ccm_tab ccm_tab1; /* the calibration CCM in low colortemper light source */
    hi_mapi_vcap_isp_dng_ccm_tab ccm_tab2; /* the calibration CCM in high colortemper light source */
} hi_mapi_vcap_isp_dng_color_param;

typedef struct {
    td_bool debug_en;     /* 1:enable debug, 0:disable debug */
    td_u64 phy_addr;     /* phy address of debug info */
    td_u32 depth;       /* depth of debug info */
} hi_mapi_vcap_isp_debug_info;

typedef struct {
    td_s32 offset[HI_MAPI_VCAP_ISP_BAYER_CHN_NUM];
    td_u32 gain[HI_MAPI_VCAP_ISP_BAYER_CHN_NUM];
    td_u16 color_matrix[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];
} hi_mapi_vcap_isp_pipe_diff_attr;

typedef struct {
    td_u8 de_purple_cr_str;
    td_u8 de_purple_cb_str;
} hi_mapi_vcap_isp_de_purple_str_manual_attr;

/* Defines purple fringing correction automatic attribute */
typedef struct {
    td_u8 de_purple_cr_str[HI_MAPI_VCAP_ISP_EXP_RATIO_STRENGTH_NUM];
    td_u8 de_purple_cb_str[HI_MAPI_VCAP_ISP_EXP_RATIO_STRENGTH_NUM];
} hi_mapi_vcap_isp_de_purple_str_auto_attr;

/* 59v200 amp version is not support, will be update in the next version */
#if defined (__SS928V100__)
typedef struct {
    td_bool enable;
    td_u16 purple_det_range;
    td_u16 var_thr;
    td_u16 r_det_thr[HI_MAPI_VCAP_ISP_LCAC_DET_NUM];
    td_u16 g_det_thr[HI_MAPI_VCAP_ISP_LCAC_DET_NUM];
    td_u16 b_det_thr[HI_MAPI_VCAP_ISP_LCAC_DET_NUM];
    td_u16 luma_det_thr[HI_MAPI_VCAP_ISP_LCAC_DET_NUM];
    td_s16 cb_cr_ratio[HI_MAPI_VCAP_ISP_LCAC_DET_NUM];
    hi_mapi_vcap_isp_op_type op_type;
    hi_mapi_vcap_isp_de_purple_str_manual_attr manual_attr;
    hi_mapi_vcap_isp_de_purple_str_auto_attr auto_attr;
} hi_mapi_vcap_isp_local_cac_attr;
#else
/* Purple fringing detection and correction attribute */
typedef struct {
    td_bool enable;
    td_u16 purple_det_range;
    td_u16 var_thr;
    hi_mapi_vcap_isp_op_type op_type;
    hi_mapi_vcap_isp_de_purple_str_manual_attr manual_attr;
    hi_mapi_vcap_isp_de_purple_str_auto_attr auto_attr;
} hi_mapi_vcap_isp_local_cac_attr;
#endif

typedef enum {
    HI_MAPI_VCAP_AWB_INDOOR_MODE = 0,
    HI_MAPI_VCAP_AWB_OUTDOOR_MODE = 1,

    HI_MAPI_VCAP_AWB_INDOOR_OUTDOOR_BUTT
} hi_mapi_vcap_isp_awb_indoor_outdoor_status;

typedef struct {
    td_u16 rgain;
    td_u16 grgain;
    td_u16 gbgain;
    td_u16 bgain;
    td_u16 saturation;
    td_u16 color_temp;
    td_u16 ccm[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];

    td_u16 l_s0_ct;
    td_u16 l_s1_ct;
    td_u16 l_s0_area;
    td_u16 l_s1_area;
    td_u8  multi_degree;
    td_u16 active_shift;
    td_u32 first_stable_time;
    hi_mapi_vcap_isp_awb_indoor_outdoor_status in_out_status;
    td_s16 bv;
} hi_mapi_vcap_isp_wb_info;

typedef enum {
    HI_MAPI_VCAP_CFALAYOUT_TYPE_RECTANGULAR = 1,
    HI_MAPI_VCAP_CFALAYOUT_TYPE_A,
    HI_MAPI_VCAP_CFALAYOUT_TYPE_B,
    HI_MAPI_VCAP_CFALAYOUT_TYPE_C,
    HI_MAPI_VCAP_CFALAYOUT_TYPE_D,
    HI_MAPI_VCAP_CFALAYOUT_TYPE_E,
    HI_MAPI_VCAP_CFALAYOUT_TYPE_F,
    HI_MAPI_VCAP_CFALAYOUT_TYPE_G,
    HI_MAPI_VCAP_CFALAYOUT_TYPE_H,

    HI_MAPI_VCAP_CFALAYOUT_TYPE_BUTT
} hi_mapi_vcap_dng_cfa_layout_type;

typedef struct {
    td_u16 blc_repeat_rows;
    td_u16 blc_repeat_cols;
} hi_mapi_vcap_dng_blc_repeat_dim;

typedef struct {
    td_u32 numerator;
    td_u32 denominator;
} hi_mapi_vcap_dng_rational;

typedef struct {
    hi_mapi_vcap_dng_rational default_scale_h;
    hi_mapi_vcap_dng_rational default_scale_v;
} hi_mapi_vcap_dng_default_scale;

typedef struct {
    td_u16 repeat_pattern_dim_rows;
    td_u16 repeat_pattern_dim_cols;
} hi_mapi_vcap_dng_repeat_pattern_dim;

typedef struct {
    td_u8 bits_per_sample;
    td_u8 cfa_plane_color[HI_MAPI_VCAP_CFA_COLORPLANE];
    hi_mapi_vcap_dng_cfa_layout_type cfa_layout;
    hi_mapi_vcap_dng_blc_repeat_dim blc_repeat_dim;
    td_u32 white_level;
    hi_mapi_vcap_dng_default_scale default_scale;
    hi_mapi_vcap_dng_repeat_pattern_dim cfa_repeat_pattern_dim;
    td_u8 cfa_pattern[HI_MAPI_VCAP_ISP_BAYER_CHN_NUM];
} hi_mapi_vcap_dng_raw_format;

typedef struct {
    td_s32 numerator;   /* represents the numerator of a fraction, */
    td_s32 denominator; /* the denominator. */
} hi_mapi_vcap_dng_srational;

typedef struct {
    hi_mapi_vcap_dng_raw_format dng_raw_format;
    hi_mapi_vcap_dng_srational color_matrix1[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];
    hi_mapi_vcap_dng_srational color_matrix2[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];
    hi_mapi_vcap_dng_srational camera_calibration1[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];
    hi_mapi_vcap_dng_srational camera_calibration2[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];
    hi_mapi_vcap_dng_srational forwad_matrix1[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];
    hi_mapi_vcap_dng_srational forwad_matrix2[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];
    td_u8 calibration_illuminant1;
    td_u8 calibration_illuminant2;
} hi_mapi_vcap_dng_image_static_info;

typedef struct {
    hi_mapi_rect wnd_rect;
    hi_mapi_size sns_size;
    td_float frame_rate;
    hi_mapi_vcap_isp_bayer_format bayer;
    hi_mapi_vcap_wdr_mode wdr_mode;
    td_u8 sns_mode;
} hi_mapi_vcap_isp_pub_attr;

typedef struct {
    td_u8 cmp_param[HI_MAPI_VCAP_CMP_PARAM_SIZE];
} hi_mapi_vcap_cmp_param;

typedef enum {
    HI_MAPI_VCAP_CROP_ABS_COOR = 0,
    HI_MAPI_VCAP_CROP_RATIO_COOR,

    HI_MAPI_VCAP_CROP_BUTT
} hi_mapi_vcap_crop_coordinate;

typedef struct {
    td_bool enable;
    hi_mapi_vcap_crop_coordinate crop_coordinate;
    hi_mapi_rect crop_rect;
} hi_mapi_vcap_crop_info;

typedef enum {
    HI_MAPI_VCAP_DUMP_TYPE_RAW = 0,
    HI_MAPI_VCAP_DUMP_TYPE_YUV = 1,
    HI_MAPI_VCAP_DUMP_TYPE_IR = 2,

    HI_MAPI_VCAP_DUMP_TYPE_BUTT
} hi_mapi_vcap_dump_type;

typedef struct {
    td_bool enable;
    td_u32 depth;
    hi_mapi_vcap_dump_type dump_type;
} hi_mapi_dump_attr;

typedef struct {
    td_bool enable;
    td_u32 depth;
} hi_mapi_bnr_dump_attr;

typedef struct {
    td_u8   chroma_str[HI_MAPI_VCAP_ISP_BAYER_CHN_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8   fine_str[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u16  coring_wgt[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u16  coarse_str[HI_MAPI_VCAP_ISP_BAYER_CHN_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
} hi_mapi_vcap_isp_nr_auto_attr;

typedef struct {
    td_bool enable;
    td_u32 param_num;
    hi_mapi_vcap_isp_nr_auto_attr *isp_nr_attr;
} hi_mapi_vcap_isp_pro_bnr_param;

typedef struct {
    td_u8  luma_wgt[HI_MAPI_VCAP_ISP_SHARPEN_LUMA_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u16 texture_str[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u16 edge_str[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u16 texture_freq[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u16 edge_freq[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  over_shoot[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  under_shoot[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  shoot_sup_str[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  shoot_sup_adj[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  detail_ctrl[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  detail_ctrl_thr[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  edge_filt_str[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  edge_filt_max_cap[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  r_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  g_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  b_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  skin_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u16 max_sharp_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
    td_u8  weak_detail_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_STRENGTH_NUM];
} hi_mapi_vcap_isp_sharpen_auto_attr;

typedef struct {
    td_bool enable;
    td_u32 param_num;
    hi_mapi_vcap_isp_sharpen_auto_attr *isp_shp_attr;
} hi_mapi_vcap_isp_pro_sharpen_param;


/** @} */ /** <!-- ==== VCAP adapt End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_VCAP_ADAPT_DEFINE_H__ */
