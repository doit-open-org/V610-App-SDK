/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_OSD_ADAPT_DEFINE_H__
#define __HI_MAPI_OSD_ADAPT_DEFINE_H__

#include "hi_mapi_comm_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */


typedef enum {
    HI_MAPI_ATTACH_JPEG_MAIN = 0,
    HI_MAPI_ATTACH_JPEG_MPF0,
    HI_MAPI_ATTACH_JPEG_MPF1,
    HI_MAPI_ATTACH_JPEG_BUTT
} hi_mapi_osd_attach_dest;

typedef struct {
    hi_mapi_pixel_format pixel_format;      /* Bitmap's pixel format */
    td_u32 width;                         /* Bitmap's width */
    td_u32 height;                        /* Bitmap's height */
    td_void *MAPI_ALIGN_ATTRIBUTE data;   /* Address of Bitmap's data */
} hi_mapi_osd_bitmap;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_OSD_ADAPT_DEFINE_H__ */
