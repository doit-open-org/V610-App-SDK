/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VPSS_ADAPT_DEFINE_H__
#define __HI_MAPI_VPSS_ADAPT_DEFINE_H__

#include "hi_mapi_comm_adapt_define.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_errno.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define HI_MAPI_VPSS_PHOTO_HDR_ISO_LEVEL_CNT       10
#define HI_MAPI_VPSS_PHOTO_SFNR_ISO_LEVEL_CNT      8
#define HI_MAPI_VPSS_PHOTO_MFNR_ISO_LEVEL_CNT      8
#define HI_MAPI_VPSS_PHOTO_DE_ISO_LEVEL_CNT        8

typedef enum {
    HI_MAPI_VPSS_NR_TYPE_VIDEO         = 0,
    HI_MAPI_VPSS_NR_TYPE_SNAP          = 1,
    HI_MAPI_VPSS_NR_TYPE_VIDEO_SPATIAL = 2,
    HI_MAPI_VPSS_NR_TYPE_VIDEO_ENHANCE = 3,

    HI_MAPI_VPSS_NR_TYPE_BUTT
} hi_mapi_vpss_nr_type;

typedef enum {
    HI_MAPI_VPSS_NR_MOTION_MODE_NORMAL          = 0,        /* normal */
    HI_MAPI_VPSS_NR_MOTION_MODE_COMPENSATE      = 1,        /* motion compensate */

    HI_MAPI_VPSS_NR_MOTION_MODE_BUTT
} hi_mapi_vpss_nr_motion_mode;

typedef struct {
    hi_mapi_vpss_nr_type nr_type;
    hi_mapi_compress_mode compress_mode;              /* Reference frame compress mode */
    hi_mapi_vpss_nr_motion_mode nr_motion_mode;    /* NR motion compensate mode. */
} hi_mapi_vpss_grp_nr_attr;

typedef struct {
    td_bool enable;          /* low delay enable. */
    td_u32  line_cnt;         /* range: [16, 16384]; Low delay shoreline. */
} hi_mapi_vpss_low_delay_info;

typedef enum {
    HI_MAPI_VPSS_CROP_ABS_COOR = 0,         /* Absolute coordinate. */
    HI_MAPI_VPSS_CROP_RATIO_COOR,   /* Ratio coordinate. */
    HI_MAPI_VPSS_CROP_BUTT
} hi_mapi_vpss_crop_coordonate;

typedef struct {
    td_bool enable;            /* Range: [0, 1];  CROP enable. */
    hi_mapi_vpss_crop_coordonate crop_coordinate;   /* Range: [0, 1]; Coordinate mode of the crop start point. */
    hi_mapi_rect crop_rect;         /* CROP rectangular. */
} hi_mapi_vpss_crop_info;

#ifdef SUPPORT_AVS
typedef enum {
    HI_MAPI_VPSS_STITCH_LUT_ACCURACY_HIGH = 0,
    HI_MAPI_VPSS_STITCH_LUT_ACCURACY_LOW = 1,

    HI_MAPI_VPSS_STITCH_LUT_ACCURACY_BUTT
}hi_mapi_vpss_stitch_lut_accracy_type;

typedef enum {
    HI_MAPI_VPSS_STITCH_MODE_BLEND = 0,
    HI_MAPI_VPSS_STITCH_MODE_NOBLEND_VER = 1,
    HI_MAPI_VPSS_STITCH_MODE_NOBLEND_HOR = 2,
    HI_MAPI_VPSS_STITCH_MODE_NOBLEND_QR = 3,

    HI_MAPI_VPSS_STITCH_MODE_BUTT
} hi_mapi_vpss_stitch_mode;

typedef struct {
    hi_mapi_vpss_stitch_lut_accracy_type accuracy;
    td_u64 phy_addr[HI_MAPI_VPSS_STITCH_PIPE_MAX_NUM];
} hi_mapi_vpss_stitch_lut;

typedef enum {
    HI_MAPI_VPSS_STITCH_GAIN_MODE_MANUAL = 0,
    HI_MAPI_VPSS_STITCH_GAIN_MODE_AUTO = 1,

    HI_MAPI_VPSS_STITCH_GAIN_MODE_BUTT
} hi_mapi_vpss_stitch_gain_mode;

typedef struct {
    hi_mapi_vpss_stitch_gain_mode mode;
    td_s32 coef[HI_MAPI_VPSS_STITCH_PIPE_MAX_NUM];
} hi_mapi_vpss_stitch_gain_attr;

typedef enum {
    HI_MAPI_VPSS_STITCH_PROJECTION_EQUIRECTANGULAR = 0,
    HI_MAPI_VPSS_STITCH_PROJECTION_RECTILINEAR = 1,
    HI_MAPI_VPSS_STITCH_PROJECTION_CYLINDRICAL = 2,
    HI_MAPI_VPSS_STITCH_PROJECTION_CUBE_MAP = 3,

    HI_MAPI_VPSS_STITCH_PROJECTION_BUTT
} hi_mapi_vpss_stitch_projection_mode;

typedef struct {
    td_u32 fov_x;
    td_u32 fov_y;
} hi_mapi_vpss_stitch_fov_info;

typedef struct {
    td_s32 yaw;
    td_s32 pitch;
    td_s32 roll;
} hi_mapi_vpss_stitch_rotation;

typedef struct {
    td_u32 pipe_num;
    td_s32 stitch_pipe[HI_MAPI_VPSS_STITCH_SPLIT_PIPE_NUM];
} hi_mapi_vpss_stitch_split_attr;

typedef struct {
    td_bool bg_color_enable;
    td_u32 bg_color;
    td_u32 surface_length;
    hi_mapi_point start_point[HI_MAPI_VPSS_STITCH_CUBE_MAP_SURFACE_NUM];
} hi_mapi_vpss_stitch_cube_map_attr;

typedef struct {
    hi_mapi_vpss_stitch_projection_mode prj_mode;
    hi_mapi_point center;
    hi_mapi_vpss_stitch_fov_info fov_info;
    hi_mapi_vpss_stitch_rotation ori_rotation;
    hi_mapi_vpss_stitch_rotation rotation;
    hi_mapi_vpss_stitch_split_attr split_attr[HI_MAPI_VPSS_STITCH_SPLIT_NUM];
    hi_mapi_vpss_stitch_cube_map_attr cube_map_attr;
} hi_mapi_vpss_stitch_output_attr;
#endif

typedef enum {
    HI_MAPI_VPSS_PHOTO_ALG_TYPE_HDR = 0x0,
    HI_MAPI_VPSS_PHOTO_ALG_TYPE_SFNR = 0x1,
    HI_MAPI_VPSS_PHOTO_ALG_TYPE_MFNR = 0x2,
    HI_MAPI_VPSS_PHOTO_ALG_TYPE_DE = 0x3,

    HI_MAPI_VPSS_PHOTO_ALG_TYPE_BUTT
} hi_mapi_vpss_photo_alg_type;

typedef struct {
    td_s32 iso_speed;
    td_s32 motion_low_gray;
    td_s32 motion_high_gray;
    td_float motion_ratio;
    td_s32 night_average_luma;
} hi_mapi_vpss_photo_dark_motion_detection_param;

typedef struct {
    td_s32 iso_speed;
    td_s32 pyramid_top_size;
    td_s32 weight_curve_method;
    td_s32 weight_calc_method;
    td_s32 blend_uv_gain;
    td_s32 detail_enhance_ratio_l0;
    td_s32 detail_enhance_ratio_l1;
    td_float blend_sigma;
}hi_mapi_vpss_photo_image_fusion_param;

typedef struct {
    td_s32 ajust_ratio;
    td_s32 image_scale_method;
    hi_mapi_vpss_photo_dark_motion_detection_param
    motion_detection_param[HI_MAPI_VPSS_PHOTO_HDR_ISO_LEVEL_CNT];
    hi_mapi_vpss_photo_image_fusion_param
    image_fusion_param[HI_MAPI_VPSS_PHOTO_HDR_ISO_LEVEL_CNT];
} hi_mapi_vpss_photo_hdr_coef;

typedef struct {
    td_s32 iso_value;
    td_s32 luma;
    td_s32 chroma;
    td_s32 luma_hf;
    td_s32 chroma_hf;
} hi_mapi_vpss_photo_sfnr_iso_strategy;

typedef struct {
    hi_mapi_vpss_photo_sfnr_iso_strategy iso_strat[HI_MAPI_VPSS_PHOTO_SFNR_ISO_LEVEL_CNT];
} hi_mapi_vpss_photo_sfnr_coef;

typedef struct {
    td_s32 iso_value;
    td_s32 stnr;
    td_s32 tnr_frm_num;
    td_s32 stnr_dark_less;
    td_s32 stnr_ghost_less;
    td_s32 luma_alpha;
    td_s32 luma_delta;
    td_s32 chroma_alpha;
    td_s32 chroma_delta;
} hi_mapi_vpss_photo_mfnr3d_nr_iso_strategy;

typedef struct {
    hi_mapi_vpss_photo_mfnr3d_nr_iso_strategy mfnr3d_nr_iso_strat[HI_MAPI_VPSS_PHOTO_MFNR_ISO_LEVEL_CNT];
} hi_mapi_vpss_photo_mfnr3d_nr_param;

typedef struct {
    td_s32 iso_value;
    td_s32 luma;
    td_s32 chroma;
    td_s32 luma_hf2;
    td_s32 detail_min;
} hi_mapi_vpss_photo_mfnr2d_nr_iso_strategy;

typedef struct {
    hi_mapi_vpss_photo_mfnr2d_nr_iso_strategy mfnr2d_nr_iso_strat[HI_MAPI_VPSS_PHOTO_MFNR_ISO_LEVEL_CNT];
} hi_mapi_vpss_photo_mfnr2d_nr_param;

typedef struct {
    td_s32 iso_value;
    td_s32 global_gain;
    td_s32 gain_lf;
    td_s32 gain_hf_pos;
    td_s32 gain_hf_neg;
    td_s32 luma_scale_x0;
    td_s32 luma_scale_x1;
    td_s32 luma_scale_y1;
    td_s32 satu_gain_x0;
    td_s32 satu_gain_x1;
    td_s32 satu_gain_y1;
} hi_mapi_vpss_photo_de_iso_strategy;

typedef struct {
    hi_mapi_vpss_photo_de_iso_strategy de_iso_strat[HI_MAPI_VPSS_PHOTO_DE_ISO_LEVEL_CNT];
} hi_mapi_vpss_photo_de_coef;

typedef struct {
    td_bool image_scale;
    hi_mapi_vpss_photo_mfnr3d_nr_param mfnr3d_nr_param;
    hi_mapi_vpss_photo_mfnr2d_nr_param mfnr2d_nr_param;
    td_bool de_enable;
    hi_mapi_vpss_photo_de_coef photo_de_coef;
} hi_mapi_vpss_photo_mfnr_coef;

typedef struct {
    union {
        hi_mapi_vpss_photo_hdr_coef photo_hdr_coef;
        hi_mapi_vpss_photo_sfnr_coef photo_sfnr_coef;
        hi_mapi_vpss_photo_mfnr_coef photo_mfnr_coef;
        hi_mapi_vpss_photo_de_coef photo_de_coef;
    };
} hi_mapi_vpss_photo_alg_coef;

typedef struct {
    td_bool enable;
    hi_mapi_ldc_attr ldc_attr;
} hi_mapi_vpss_ldc_attr;

typedef struct {
    td_bool enable;                     /* Whether LDCv2 is enbale */
    hi_mapi_ldc_v2_attr attr;
} hi_mapi_vpss_ldc_v2_attr;

typedef struct {
    td_bool enable; /* RW;Whether LDC is enbale */
    hi_mapi_ldc_v3_attr attr;
} hi_mapi_vpss_ldc_v3_attr;

typedef struct {
    td_bool enable; /* RW;Whether LDC is enbale */
    hi_mapi_ldc_v4_attr attr;
} hi_mapi_vpss_ldc_v4_attr;

/** @} */ /** <!-- ==== VPSS End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_VPSS_ADAPT_DEFINE_H__ */
