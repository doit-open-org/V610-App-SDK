/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VENC_ADAPT_DEFINE_H__
#define __HI_MAPI_VENC_ADAPT_DEFINE_H__

#include "hi_mapi_venc_arch_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define HI_MAPI_VENC_MPF_MAX_CNT            2
#define HI_MAPI_VENC_HIERARCHICAL_QP_NUM    4
#define HI_MAPI_VENC_TEXTURE_THRESHOLD_SIZE 16

/* <H264,H265 and MJPEG attr are the same, Data structure reference MPI
       the attribute of constant bit rate */
typedef struct {
    td_u32      gop;                    /* Range:[1, 65536]; the interval of I Frame, MJPEG is invalid. */
    td_u32      stat_time;               /* Range:[1, 60]; the rate statistic time, the unit is senconds(s) */
    td_u32      src_frame_rate;           /* Range:[1, 240]; the input frame rate of the venc chnnel */
    td_u32      dst_frame_rate;           /* Range:[0.015625, 240]; the target frame rate of the venc chnnel,
                                           can not be larger than u32SrcFrameRate */
    td_u32      bit_rate;                /* Range:[2, 614400]; average bitrate */
} hi_mapi_venc_cbr_attr;

/* <H264,H265 and MJPEG attr are the same, Data structure reference MPI
       the attribute of variable bit rate */
typedef struct {
    td_u32      gop;                     /* Range:[1, 65536]; the interval of ISLICE, MJPEG is invalid. */
    td_u32      stat_time;                /* Range:[1, 60]; the rate statistic time, the unit is senconds(s) */
    td_u32      src_frame_rate;            /* Range:[1, 240]; the input frame rate of the venc chnnel */
    td_u32      dst_frame_rate;            /* Range:[0.015625, 240]; the target frame rate of the venc chnnel,
                                            can not be larger than u32SrcFrameRate */
    td_u32      max_bit_rate;              /* Range:[2, 614400];the max bitrate */
} hi_mapi_venc_vbr_attr;

/* <H264,H265 attr are the same, Data structure reference MPI
       the attribute of cvbr */
typedef struct {
    td_u32      gop;                     /* Range:[1, 65536]; the interval of ISLICE. */
    td_u32      stat_time;                /* Range:[1, 60]; the rate statistic time, the unit is senconds(s) */
    td_u32      src_frame_rate;            /* Range:[1, 240]; the input frame rate of the venc chnnel */
    td_u32      dst_frame_rate;            /* Range:[0.015625, 240]; the target frame rate of the venc chnnel,
                                            can not be larger than u32SrcFrameRate */
    td_u32      max_bit_rate;              /* Range:[2, 614400];the max bitrate */

    td_u32      short_term_stat_time;       /* Range:[1, 120]; the long-term rate statistic time,
                                            the unit is second (s) */
    td_u32      long_term_stat_time;        /* Range:[1, 1440]; the long-term rate statistic time,
                                            the unit is u32LongTermStatTimeUnit */
    td_u32      long_term_max_bitrate;      /* Range:[2, 614400];the long-term target max bitrate,
                                            can not be larger than u32MaxBitRate,the unit is kbps */
    td_u32      long_term_min_bitrate;      /* Range:[0, 614400];the long-term target min bitrate,
                                            can not be larger than u32LongTermMaxBitrate,the unit is kbps */
} hi_mapi_venc_cvbr_attr;

/* <H264,H265 attr are the same, Data structure reference MPI
       the attribute of avbr */
typedef struct {
    td_u32      gop;                  /* Range:[1, 65536]; the interval of ISLICE. */
    td_u32      stat_time;             /* Range:[1, 60]; the rate statistic time, the unit is senconds(s) */
    td_u32      src_frame_rate;         /* Range:[1, 240]; the input frame rate of the venc chnnel */
    td_u32      dst_frame_rate;         /* Range:[0.015625, 240]; the target frame rate of the venc chnnel,
                                         can not be larger than u32SrcFrameRate */
    td_u32      max_bit_rate;           /* Range:[2, 614400];the max bitrate */
} hi_mapi_venc_avbr_attr;

/* <H264,H265 attr are the same, Data structure reference MPI
       the attribute of qvbr */
typedef struct {
    td_u32      gop;                   /* Range:[1, 65536];the interval of ISLICE. */
    td_u32      stat_time;              /* Range:[1, 60]; the rate statistic time, the unit is senconds(s) */
    td_u32      src_frame_rate;          /* Range:[1, 240]; the input frame rate of the venc chnnel */
    td_u32      dst_frame_rate;          /* Range:[0.015625, 240]; the target frame rate of the venc chnnel,
                                          can not be larger than u32SrcFrameRate */
    td_u32      target_bit_rate;         /* Range:[2, 614400]; the target bitrate */
} hi_mapi_venc_qvbr_attr;

typedef struct {
    td_u8        large_thumb_nail_num; /* Range:[0, 2]; the large thumbnail pic num of the MPF */
    hi_mapi_size large_thumb_nail_size[HI_MAPI_VENC_MPF_MAX_CNT]; /* The resolution of large ThumbNail */
} hi_mapi_venc_mpf_config;

typedef enum {
    HI_MAPI_VENC_PIC_RECEIVE_SINGLE = 0,
    HI_MAPI_VENC_PIC_RECEIVE_MULTI,
    HI_MAPI_VENC_PIC_RECEIVE_BUTT
} hi_mapi_venc_pic_receive_mode;

/* Jpeg snap mode */
typedef enum {
    HI_MAPI_JPEG_ENCODE_ALL   = 0, /* Jpeg channel snap all the pictures when started. */
    HI_MAPI_JPEG_ENCODE_SNAP  = 1, /* Jpeg channel snap the flashed pictures when started. */
    HI_MAPI_JPEG_ENCODE_BUTT,
} hi_mapi_venc_jpeg_encode_mode;

/* the nalu type of H264E */
typedef enum {
    HI_MAPI_VENC_H264E_NALU_BSLICE = 0,                         /* B SLICE types */
    HI_MAPI_VENC_H264E_NALU_PSLICE = 1,                         /* P SLICE types */
    HI_MAPI_VENC_H264E_NALU_ISLICE = 2,                         /* I SLICE types */
    HI_MAPI_VENC_H264E_NALU_IDRSLICE = 5,                       /* IDR SLICE types */
    HI_MAPI_VENC_H264E_NALU_SEI    = 6,                         /* SEI types */
    HI_MAPI_VENC_H264E_NALU_SPS    = 7,                         /* SPS types */
    HI_MAPI_VENC_H264E_NALU_PPS    = 8,                         /* PPS types */
    HI_MAPI_VENC_H264E_NALU_BUTT
} hi_mapi_venc_h264e_nalu_type;

/* the pack type of JPEGE */
typedef enum {
    HI_MAPI_VENC_JPEGE_PACK_ECS = 5,                            /* ECS types */
    HI_MAPI_VENC_JPEGE_PACK_APP = 6,                            /* APP types */
    HI_MAPI_VENC_JPEGE_PACK_VDO = 7,                            /* VDO types */
    HI_MAPI_VENC_JPEGE_PACK_PIC = 8,                            /* PIC types */
    HI_MAPI_VENC_JPEGE_PACK_DCF = 9,                            /* DCF types */
    HI_MAPI_VENC_JPEGE_PACK_DCF_PIC = 10,                       /* DCF PIC types */
    HI_MAPI_VENC_JPEGE_PACK_BUTT
} hi_mapi_venc_jpeg_pack_type;

/* Defines the frame type and reference attributes of the H.264/H.265 frame skipping reference streams
     H264 and H265 attr are the same, Data structure reference MPI */
typedef enum {
    HI_MAPI_VENC_BASE_IDRSLICE = 0,            /* the Idr frame at Base layer */
    HI_MAPI_VENC_BASE_PSLICE_REFTOIDR,         /* the P frame at Base layer, referenced by other frames
                                                  at Base layer and reference to Idr frame */
    HI_MAPI_VENC_BASE_PSLICE_REFBYBASE,        /* the P frame at Base layer, referenced by other frames
                                                  at Base layer */
    HI_MAPI_VENC_BASE_PSLICE_REFBYENHANCE,     /* the P frame at Base layer, referenced by other frames
                                                  at Enhance layer */
    HI_MAPI_VENC_ENHANCE_PSLICE_REFBYENHANCE,  /* the P frame at Enhance layer, referenced by other frames
                                                  at Enhance layer */
    HI_MAPI_VENC_ENHANCE_PSLICE_NOTFORREF,     /* the P frame at Enhance layer ,not referenced */
    HI_MAPI_VENC_ENHANCE_PSLICE_BUTT
} hi_mapi_venc_ref_type;

/* the attribute of the normalp */
typedef struct {
    td_s32   ip_qp_delta;           /* Range:[-10, 30]; QP variance between P frame and I frame */
} hi_mapi_venc_normalp_gop;

/* the attribute of the dualp */
typedef struct {
    td_u32 sp_interval;            /* Range:[0, 65536]; Interval of the special P frames,
                                         1 is not supported and should be less than Gop */
    td_s32 sp_qp_delta;             /* Range:[-10, 30]; QP variance between P frame and special P frame */
    td_s32 ip_qp_delta;             /* Range:[-10, 30]; QP variance between P frame and I frame */
} hi_mapi_venc_dualp_gop;

/* the attribute of the smartp */
typedef struct {
    td_u32  bg_interval;           /* Interval of the long-term reference frame, can not be less than gop */
    td_s32  bg_qp_delta;            /* Range:[-10, 30]; QP variance between P frame and Bg frame */
    td_s32  vi_qp_delta;            /* Range:[-10, 30]; QP variance between P frame and virtual I  frame */
} hi_mapi_venc_smartp_gop;

/* the attribute of the bipredb */
typedef struct {
    td_u32 b_frm_num;              /* Range:[1, 3]; Number of B frames */
    td_s32 b_qp_delta;             /* Range:[-10, 30]; QP variance between P frame and B frame */
    td_s32 ip_qp_delta;            /* Range:[-10, 30]; QP variance between P frame and I frame */
} hi_mapi_venc_bipredb_gop;

/* The param of H264e cbr */
typedef struct {
    td_u32  min_ip_ratio;                /* Range:[1, 100]; the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* Range:[1, 100]; the max ratio of i frame and p frame,
                                            can not be smaller than min_ip_ratio */
    td_u32  max_qp;                   /* Range:[0, 51];the max QP value */
    td_u32  min_qp;                   /* Range:[0, 51]; the min QP value,can not be larger than max_qp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; max qp for i frame */
    td_u32  min_i_qp;                  /* Range:[0, 51]; min qp for i frame,can not be larger than min_i_qp */
    td_s32  max_reencode_times;        /* Range:[0, 3]; Range:max number of re-encode times */
    td_bool qpmap_en;                   /* Range:[0, 1]; enable qpmap */
} hi_mapi_venc_h264_cbr_param;

/* The param of H264e vbr */
typedef struct {
    td_s32  change_pos;               /* Range:[50, 100]; Indicates the ratio of the current bit rate to
                                            the maximum bit rate when the QP value starts to be adjusted */
    td_u32  min_ip_ratio;                /* Range:[1, 100] ; the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* Range:[1, 100] ; the max ratio of i frame and p frame,
                                            can not be smaller than min_ip_ratio */
    td_s32  max_reencode_times;        /* Range:[0, 3]; max number of re-encode times */
    td_bool qpmap_en;                 /* Range:[0, 1]; enable qpmap */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp,can not be larger than max_qp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp ,can not be larger than max_i_qp */
} hi_mapi_venc_h264_vbr_param;

/* The param of H264e avbr */
typedef struct {
    td_s32  change_pos;               /* Range:[50, 100]; Indicates the ratio of the current bit rate to
                                            the maximum bit rate when the QP value starts to be adjusted */
    td_u32  min_ip_ratio;                /* Range:[1, 100] ; the min ratio of i frame and p frame */

    td_u32  max_ip_ratio;                /* Range:[1, 100] ; the max ratio of i frame and p frame,
                                            can not be smaller than min_ip_ratio */
    td_s32  max_reencode_times;        /* Range:[0, 3]; max number of re-encode times */
    td_bool qpmap_en;                 /* Range:[0, 1]; enable qpmap */

    td_s32  min_still_percent;         /* Range:[5, 100]; the min percent of target bitrate for still scene */
    td_u32  max_still_qp;              /* Range:[0, 51]; the max QP value of I frame for still scene, can not be
                                            smaller than u32MinIQp and can not be larger than su32MaxIQp */
    td_u32  min_still_psnr;            /* reserved,Invalid member currently */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp,can not be larger than u32MaxIQp */
    td_u32  min_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMinQp and MinQp,
                                            FrameLevelMinQp = MinQp(or MinIQp) + MinQpDelta  */
    td_u32  motion_sensitivity;       /* Range:[0, 100]; Motion Sensitivity */
} hi_mapi_venc_h264_avbr_param;

/* The param of H264e qvbr */
typedef struct {
    td_u32  min_ip_ratio;               /* Range:[1, 100]; the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;               /* Range:[1, 100] ;the max ratio of i frame and p frame,
                                           can not be smaller than u32MinIprop */
    td_s32  max_reencode_times;       /* Range:[0, 3];max number of re-encode times [0, 3] */
    td_bool qpmap_en;                /* Range:[0, 1]; enable qpmap */

    td_u32  max_qp;                  /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                  /* Range:[0, 51]; the min P B qp,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                 /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                 /* Range:[0, 51]; the min I qp,can not be larger than u32MaxIQp */

    td_s32  bit_percent_ul;           /* Range:[30, 180]; Indicate the ratio of bitrate  upper limit */
    td_s32  bit_percent_ll;           /* Range:[30, 180]; Indicate the ratio of bitrate  lower limit,
                                           can not be larger than s32BitPercentUL */
    td_s32  psnr_fluctuate_ul;        /* Range:[18, 40]; Reduce the target bitrate
                                           when the value of psnr approch the upper limit */
    td_s32  psnr_fluctuate_ll;        /* Range:[18, 40]; Increase the target bitrate when the value of psnr
                                           approch the lower limit, can not be larger than s32PsnrFluctuateUL */
} hi_mapi_venc_h264_qvbr_param;

/* The param of H264e cvbr */
typedef struct {
    td_u32  min_ip_ratio;                /* Range:[1, 100] ; the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* Range:[1, 100] ; the max ratio of i frame and p frame,
                                            can not be smaller than u32MinIprop */
    td_s32  max_reencode_times;        /* Range:[0, 3]; max number of re-encode times */
    td_bool qpmap_en;                 /* Range:[0, 1]; enable qpmap */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp,can not be larger than u32MaxIQp */

    td_u32  min_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMinQp and MinQp,
                                            FrameLevelMinQp = MinQp(or MinIQp) + MinQpDelta  */
    td_u32  max_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMaxQp and MaxQp,
                                            FrameLevelMaxQp = MaxQp(or MaxIQp) - MaxQpDelta  */

    td_u32  extra_bit_percent;         /* Range:[0, 1000];the extra bits that can be allocated
                                            when the actual bitrate goes above the target bitrate */
    td_u32  long_term_stat_time_unit;    /* Range:[1, 1800]; the time unit of LongTermStatTime,
                                            the unit is senconds(s) */
} hi_mapi_venc_h264_cvbr_param;

/* The param of mjpege cbr */
typedef struct {
    td_u32  max_qfactor;               /* Range:[1, 99]; the max Qfactor value */
    td_u32  min_qfactor;               /* Range:[1, 99]; the min Qfactor value,
                                             can not be larger than u32MaxQfactor */
} hi_mapi_venc_mjpeg_cbr_param;

/* The param of mjpege vbr */
typedef struct {
    td_s32 change_pos;                 /* Range:[50, 100]; Indicates the ratio of the current bit rate to
                                             the maximum bit rate when the Qfactor value starts to be adjusted */
    td_u32 max_qfactor;                /* Range:[1, 99]; max image quailty allowed */
    td_u32 min_qfactor;                /* Range:[1, 99]; min image quality allowed,
                                             can not be larger than u32MaxQfactor */
} hi_mapi_venc_mjpeg_vbr_param;

/* qpmap mode */
typedef enum {
    HI_MAPI_VENC_RC_QPMAP_MODE_MEANQP = 0,
    HI_MAPI_VENC_RC_QPMAP_MODE_MINQP,
    HI_MAPI_VENC_RC_QPMAP_MODE_MAXQP,

    HI_MAPI_VENC_RC_QPMAP_MODE_BUTT,
} hi_mapi_venc_rc_qp_map_mode;

/* The param of h265e cbr */
typedef struct {
    td_u32  min_ip_ratio;                   /* Range:[1, 100]; the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                   /* Range:[1, 100];the max ratio of i frame and p frame,
                                               can not be smaller than u32MinIprop */
    td_u32  max_qp;                      /* Range:[0, 51];the max QP value */
    td_u32  min_qp;                      /* Range:[0, 51];the min QP value ,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                     /* Range:[0, 51];max qp for i frame */
    td_u32  min_i_qp;                     /* Range:[0, 51];min qp for i frame,can not be larger than u32MaxIQp */
    td_s32  max_reencode_times;           /* Range:[0, 3]; Range:max number of re-encode times */
    td_bool qpmap_en;                    /* Range:[0, 1]; enable qpmap */
    hi_mapi_venc_rc_qp_map_mode qpmap_mode; /* Qpmap Mode */
} hi_mapi_venc_h265_cbr_param;

/* The param of h265e vbr */
typedef struct {
    td_s32  change_pos;               /* Range:[50, 100];Indicates the ratio of the current bit rate
                                            to the maximum bit rate when the QP value starts to be adjusted */
    td_u32  min_ip_ratio;                /* [1, 100]the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* [1, 100]the max ratio of i frame and p frame,
                                            can not be smaller than u32MinIprop */
    td_s32  max_reencode_times;        /* Range:[0, 3]; Range:max number of re-encode times */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp ,can not be larger than max_i_qp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp,can not be larger than min_i_qp */

    td_bool qpmap_en;                      /* Range:[0, 1]; enable qpmap flag */
    hi_mapi_venc_rc_qp_map_mode qpmap_mode;   /* Qpmap Mode */
} hi_mapi_venc_h265_vbr_param;

/* The param of h265e avbr */
typedef struct {
    td_s32  change_pos;               /* Range:[50, 100];Indicates the ratio of the current bit rate to
                                            the maximum bit rate when the QP value starts to be adjusted */
    td_u32  min_ip_ratio;                /* [1, 100]the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* [1, 100]the max ratio of i frame and p frame,
                                            can not be smaller than minIprop */
    td_s32  max_reencode_times;        /* Range:[0, 3]; Range:max number of re-encode times */

    td_s32  min_still_percent;         /* Range:[5, 100]; the min percent of target bitrate for still scene */
    td_u32  max_still_qp;              /* Range:[0, 51]; the max QP value of I frame for still scene, can not be
                                            smaller than u32MinIQp and can not be larger than max_i_qp */
    td_u32  min_still_psnr;            /* reserved */

    td_u32  max_qp;                   /* Range:[0, 51];the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51];the min P B qp,can not be larger than max_qp */
    td_u32  max_i_qp;                  /* Range:[0, 51];the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51];the min I qp,can not be larger than max_i_qp */

    td_u32  min_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMinQp and MinQp,
                                            FrameLevelMinQp = MinQp(or MinIQp) + MinQpDelta  */
    td_u32  motion_sensitivity;       /* Range:[0, 100]; Motion Sensitivity */

    td_bool qpmap_en;                      /* Range:[0, 1]; enable qpmap */
    hi_mapi_venc_rc_qp_map_mode qpmap_mode;   /* Qpmap Mode */
} hi_mapi_venc_h265_avbr_param;

typedef struct {
    td_u32  min_ip_ratio;                /* [1, 100];the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* [1, 100];the max ratio of i frame and p frame,
                                            can not be smaller than minIprop */
    td_s32  max_reencode_times;        /* [0, 3]; max number of re-encode times [0, 3] */

    td_bool qpmap_en;                      /* Range:[0, 1]; enable qpmap */
    hi_mapi_venc_rc_qp_map_mode qpmap_mode;   /* Qpmap Mode */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp,can not be larger than u32MaxIQp */

    td_s32  bit_percent_ul;            /* Range:[30, 180]; Indicate the ratio of bitrate  upper limit */
    td_s32  bit_percent_ll;            /* Range:[30, 180]; Indicate the ratio of bitrate  lower limit,
                                            can not be larger than s32BitPercentUL */
    td_s32  psnr_fluctuate_ul;         /* Range:[18, 40];  Reduce the target bitrate
                                            when the value of psnr approch the upper limit */
    td_s32  psnr_fluctuate_ll;         /* Range:[18, 40];  Increase the target bitrate when the value of psnr
                                            approch the lower limit,can not be larger than s32PsnrFluctuateUL */
} hi_mapi_venc_h265_qvbr_param;

typedef struct {
    td_u32  min_ip_ratio;                /* Range:[1, 100] ; the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* Range:[1, 100] ; the max ratio of i frame and p frame,
                                            can not be smaller than u32MinIprop */
    td_s32  max_reencode_times;        /* Range:[0, 3]; max number of re-encode times */
    td_bool qpmap_en;
    hi_mapi_venc_rc_qp_map_mode qpmap_mode;   /* Qpmap Mode */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp,can not be larger than u32MaxIQp */

    td_u32  min_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMinQp and MinQp,
                                            FrameLevelMinQp = MinQp(or MinIQp) + MinQpDelta  */
    td_u32  max_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMaxQp and MaxQp,
                                            FrameLevelMaxQp = MaxQp(or MaxIQp) - MaxQpDelta  */

    td_u32  extra_bit_percent;         /* Range:[0, 1000];the extra ratio of bitrate that can be allocated
                                            when the actual bitrate goes above the long-term target bitrate */
    td_u32  long_term_stat_time_unit;    /* Range:[1, 1800]; the time unit of LongTermStatTime,
                                            the unit is senconds(s) */
} hi_mapi_venc_h265_cvbr_param;

/* The param of svac3e cbr */
typedef struct {
    td_u32  min_ip_ratio;                   /* Range:[1, 100]; the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                   /* Range:[1, 100];the max ratio of i frame and p frame,
                                               can not be smaller than u32MinIprop */
    td_u32  max_qp;                      /* Range:[0, 51];the max QP value */
    td_u32  min_qp;                      /* Range:[0, 51];the min QP value ,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                     /* Range:[0, 51];max qp for i frame */
    td_u32  min_i_qp;                     /* Range:[0, 51];min qp for i frame,can not be larger than u32MaxIQp */
    td_s32  max_reencode_times;           /* Range:[0, 3]; Range:max number of re-encode times */
    td_bool qpmap_en;                    /* Range:[0, 1]; enable qpmap */
    hi_mapi_venc_rc_qp_map_mode qpmap_mode; /* Qpmap Mode */
} hi_mapi_venc_svac3_cbr_param;

/* The param of svac3e vbr */
typedef struct {
    td_s32  change_pos;               /* Range:[50, 100];Indicates the ratio of the current bit rate
                                            to the maximum bit rate when the QP value starts to be adjusted */
    td_u32  min_ip_ratio;                /* [1, 100]the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* [1, 100]the max ratio of i frame and p frame,
                                            can not be smaller than u32MinIprop */
    td_s32  max_reencode_times;        /* Range:[0, 3]; Range:max number of re-encode times */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp ,can not be larger than max_i_qp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp,can not be larger than min_i_qp */

    td_bool qpmap_en;                      /* Range:[0, 1]; enable qpmap flag */
    hi_mapi_venc_rc_qp_map_mode qpmap_mode;   /* Qpmap Mode */
} hi_mapi_venc_svac3_vbr_param;

/* The param of svac3e avbr */
typedef struct {
    td_s32  change_pos;               /* Range:[50, 100];Indicates the ratio of the current bit rate to
                                            the maximum bit rate when the QP value starts to be adjusted */
    td_u32  min_ip_ratio;                /* [1, 100]the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* [1, 100]the max ratio of i frame and p frame,
                                            can not be smaller than minIprop */
    td_s32  max_reencode_times;        /* Range:[0, 3]; Range:max number of re-encode times */

    td_s32  min_still_percent;         /* Range:[5, 100]; the min percent of target bitrate for still scene */
    td_u32  max_still_qp;              /* Range:[0, 51]; the max QP value of I frame for still scene, can not be
                                            smaller than u32MinIQp and can not be larger than max_i_qp */
    td_u32  min_still_psnr;            /* reserved */

    td_u32  max_qp;                   /* Range:[0, 51];the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51];the min P B qp,can not be larger than max_qp */
    td_u32  max_i_qp;                  /* Range:[0, 51];the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51];the min I qp,can not be larger than max_i_qp */

    td_u32  min_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMinQp and MinQp,
                                            FrameLevelMinQp = MinQp(or MinIQp) + MinQpDelta  */
    td_u32  motion_sensitivity;       /* Range:[0, 100]; Motion Sensitivity */

    td_bool qpmap_en;                      /* Range:[0, 1]; enable qpmap */
    hi_mapi_venc_rc_qp_map_mode qpmap_mode;   /* Qpmap Mode */
} hi_mapi_venc_svac3_avbr_param;

typedef struct {
    td_u32  min_ip_ratio;                /* [1, 100];the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* [1, 100];the max ratio of i frame and p frame,
                                            can not be smaller than minIprop */
    td_s32  max_reencode_times;        /* [0, 3]; max number of re-encode times [0, 3] */

    td_bool qpmap_en;                      /* Range:[0, 1]; enable qpmap */
    hi_mapi_venc_rc_qp_map_mode qpmap_mode;   /* Qpmap Mode */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp,can not be larger than u32MaxIQp */

    td_s32  bit_percent_ul;            /* Range:[30, 180]; Indicate the ratio of bitrate  upper limit */
    td_s32  bit_percent_ll;            /* Range:[30, 180]; Indicate the ratio of bitrate  lower limit,
                                            can not be larger than s32BitPercentUL */
    td_s32  psnr_fluctuate_ul;         /* Range:[18, 40];  Reduce the target bitrate
                                            when the value of psnr approch the upper limit */
    td_s32  psnr_fluctuate_ll;         /* Range:[18, 40];  Increase the target bitrate when the value of psnr
                                            approch the lower limit,can not be larger than s32PsnrFluctuateUL */
} hi_mapi_venc_svac3_qvbr_param;

typedef struct {
    td_u32  min_ip_ratio;                /* Range:[1, 100] ; the min ratio of i frame and p frame */
    td_u32  max_ip_ratio;                /* Range:[1, 100] ; the max ratio of i frame and p frame,
    can not be smaller than u32MinIprop */
    td_s32  max_reencode_times;        /* Range:[0, 3]; max number of re-encode times */
    td_bool qpmap_en;
    hi_mapi_venc_rc_qp_map_mode qpmap_mode;   /* Qpmap Mode */

    td_u32  max_qp;                   /* Range:[0, 51]; the max P B qp */
    td_u32  min_qp;                   /* Range:[0, 51]; the min P B qp,can not be larger than u32MaxQp */
    td_u32  max_i_qp;                  /* Range:[0, 51]; the max I qp */
    td_u32  min_i_qp;                  /* Range:[0, 51]; the min I qp,can not be larger than u32MaxIQp */

    td_u32  min_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMinQp and MinQp,
                                            FrameLevelMinQp = MinQp(or MinIQp) + MinQpDelta  */
    td_u32  max_qp_delta;              /* Range:[0, 4];Difference between FrameLevelMaxQp and MaxQp,
                                            FrameLevelMaxQp = MaxQp(or MaxIQp) - MaxQpDelta  */

    td_u32  extra_bit_percent;         /* Range:[0, 1000];the extra ratio of bitrate that can be allocated
                                            when the actual bitrate goes above the long-term target bitrate */
    td_u32  long_term_stat_time_unit;    /* Range:[1, 1800]; the time unit of LongTermStatTime,
                                            the unit is senconds(s) */
} hi_mapi_venc_svac3_cvbr_param;

typedef struct {
    td_bool detect_scene_change;         /* Range:[0, 1]; enable detect scene change. */
    td_bool adaptive_insert_idr_frame;    /* Range:[0, 1]; enable a daptive insertIDR frame. */
} hi_mapi_venc_scene_change_detect;

/* The param of rc */
typedef struct {
    td_u32 thrd_i[HI_MAPI_VENC_TEXTURE_THRESHOLD_SIZE]; /* Range:[0, 255]; Mad threshold for controlling
                                                the macroblock-level bit rate of I frames */
    td_u32 thrd_p[HI_MAPI_VENC_TEXTURE_THRESHOLD_SIZE]; /* Range:[0, 255]; Mad threshold for controlling
                                                the macroblock-level bit rate of P frames */
    td_u32 thrd_b[HI_MAPI_VENC_TEXTURE_THRESHOLD_SIZE];   /* Range:[0, 255]; Mad threshold for controlling
                                                the macroblock-level bit rate of B frames */
    td_u32 direction_thrd;                /* Range:[0, 16]; The direction for controlling
                                                the macroblock-level bit rate */
    td_u32 row_qp_delta;                   /* Range:[0, 10];the start QP value of each macroblock row
                                                relative to the start QP value */
    td_s32 first_frame_start_qp;            /* Range:[-1, 51];Start QP value of the first frame */
    hi_mapi_venc_scene_change_detect scene_change_detect;
    union {
        hi_mapi_venc_h264_cbr_param     h264_cbr_param;
        hi_mapi_venc_h264_vbr_param     h264_vbr_param;
        hi_mapi_venc_h264_avbr_param    h264_avbr_param;
        hi_mapi_venc_h264_qvbr_param    h264_qvbr_param;
        hi_mapi_venc_h264_cvbr_param    h264_cvbr_param;
        hi_mapi_venc_h265_cbr_param     h265_cbr_param;
        hi_mapi_venc_h265_vbr_param     h265_vbr_param;
        hi_mapi_venc_h265_avbr_param    h265_avbr_param;
        hi_mapi_venc_h265_qvbr_param    h265_qvbr_param;
        hi_mapi_venc_h265_cvbr_param    h265_cvbr_param;
        hi_mapi_venc_svac3_cbr_param     svac3_cbr_param;
        hi_mapi_venc_svac3_vbr_param     svac3_vbr_param;
        hi_mapi_venc_svac3_avbr_param    svac3_avbr_param;
        hi_mapi_venc_svac3_qvbr_param    svac3_qvbr_param;
        hi_mapi_venc_svac3_cvbr_param    svac3_cvbr_param;
        hi_mapi_venc_mjpeg_cbr_param    mjpeg_cbr_param;
        hi_mapi_venc_mjpeg_vbr_param    mjpeg_vbr_param;
    };
} hi_mapi_venc_rc_param;

/* venc mode type */
typedef enum {
    HI_MAPI_VENC_INTRA_REFRESH_ROW = 0,                      /* Line mode */
    HI_MAPI_VENC_INTRA_REFRESH_COLUMN,                       /* Column mode */
    HI_MAPI_VENC_INTRA_REFRESH_BUTT
} hi_mapi_venc_intra_refresh_mode;

/* the param of the intra refresh */
typedef struct {
    td_bool                        refresh_enable;    /* Range:[0, 1]; intra refresh enable,
                                                        TD_TRUE:enable, TD_FALSE:diable, default value:TD_FALSE */
    hi_mapi_venc_intra_refresh_mode  intra_refresh_mode; /* The mode of intra refresh */
    td_u32                         refresh_num;       /* Number of rows/column to be refreshed
                                                        during each I macroblock refresh */
    td_u32                         req_i_qp;           /* Range:[0, 51]; QP value of the I frame */
} hi_mapi_venc_intra_refresh;

/* the param of the venc frame rate */
typedef struct {
    /* Range:[0, 1];    Hierarchical QP enable */
    td_bool     hierarchical_qp_en;
    /* Range:[-10, 10]; QP delta of the frames at each layer relative to the P-frame at layer 0 */
    td_s32      hierarchical_qp_delta[HI_MAPI_VENC_HIERARCHICAL_QP_NUM];
    /* Range:[0, 5];    Number of frames at each layer */
    td_s32      hierarchical_frame_num[HI_MAPI_VENC_HIERARCHICAL_QP_NUM];
} hi_mapi_venc_hierarchical_qp;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_VENC_ADAPT_DEFINE_H__ */
