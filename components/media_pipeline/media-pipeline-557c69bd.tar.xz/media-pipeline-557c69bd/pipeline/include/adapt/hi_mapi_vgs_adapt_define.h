/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VGS_ADAPT_DEFINE_H__
#define __HI_MAPI_VGS_ADAPT_DEFINE_H__

#include "hi_mapi_comm_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define HI_MAPI_VGS_QUADRANGLE_POINT_NUM 4

typedef enum {
    HI_MAPI_VGS_SCLCOEF_NORMAL  = 0,    /* normal scale coefficient */
    HI_MAPI_VGS_SCLCOEF_TAP2    = 1,    /* scale coefficient of 2 tap */
    HI_MAPI_VGS_SCLCOEF_TAP4    = 2,    /* scale coefficient of 4 tap */
    HI_MAPI_VGS_SCLCOEF_TAP6    = 3,    /* scale coefficient of 6 tap */
    HI_MAPI_VGS_SCLCOEF_TAP8    = 4,    /* scale coefficient of 8 tap */
    HI_MAPI_VGS_SCLCOEF_BUTT
} hi_mapi_vgs_scale_coef_mode;

typedef struct {
    hi_mapi_point start_point; /* Line start point */
    hi_mapi_point end_point;   /* Line end point */
    td_u32 thick;             /* Width of line */
    td_u32 color;             /* Range: [0,0xFFFFFF]; Color of line */
} hi_mapi_vgs_draw_line;

typedef struct {
    td_bool is_solid;        /* Solid or hollow cover */
    td_u32 thick;           /* Range: [2,8]; Thick of the hollow quadrangle */
    hi_mapi_point point[HI_MAPI_VGS_QUADRANGLE_POINT_NUM]; /* Four points of the quadrangle */
} hi_mapi_vgs_quadrangle_cover;


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_VGS_ADAPT_DEFINE_H__ */
