/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VDEC_ADAPT_DEFINE_H__
#define __HI_MAPI_VDEC_ADAPT_DEFINE_H__

#include "hi_mapi_comm_arch_define.h"
#include "hi_mapi_comm_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

typedef struct {
    td_u32 stream_len; /* stream len */
    td_u64 time_stamp; /* time stamp */
    td_u64 private_data; /* only valid by HI_MAPI_VDEC_VIDEO_MODE_FRAME or HI_MAPI_VDEC_VIDEO_MODE_COMPAT. */
    td_bool end_of_frame; /* is the end of a frame */
    td_bool end_of_stream; /* is the end of all stream */
    td_bool display; /* is the current frame displayed. only valid by HI_MAPI_VDEC_VIDEO_MODE_FRAME */
    td_u8 *MAPI_ALIGN_ATTRIBUTE stream_addr; /* stream address */
} hi_mapi_vdec_stream;

typedef enum {
    HI_MAPI_VDEC_VIDEO_DEC_MODE_IPB = 0,
    HI_MAPI_VDEC_VIDEO_DEC_MODE_IP,
    HI_MAPI_VDEC_VIDEO_DEC_MODE_I,
    HI_MAPI_VDEC_VIDEO_DEC_MODE_BUTT
} hi_mapi_vdec_video_dec_mode;

typedef enum {
    HI_MAPI_VDEC_VIDEO_OUTPUT_ORDER_DISP = 0,
    HI_MAPI_VDEC_VIDEO_OUTPUT_ORDER_DEC,
    HI_MAPI_VDEC_VIDEO_OUTPUT_ORDER_BUTT
} hi_mapi_vdec_video_output_order;

typedef enum {
    HI_MAPI_VDEC_QUICK_MARK_ADAPT = 0,
    HI_MAPI_VDEC_QUICK_MARK_FORCE,
    HI_MAPI_VDEC_QUICK_MARK_NONE,
    HI_MAPI_VDEC_QUICK_MARK_BUTT
} hi_mapi_vdec_quick_mark_mode;

typedef struct {
    /* TD_FALSE: output base layer; TD_TRUE: output enhance layer; default: TD_FALSE */
    td_bool enable_composite_dec;
    /* TD_FALSE: don't support slice low latency; TD_TRUE: support slice low latency; default: TD_FALSE */
    td_bool enable_slice_input;
    td_s32 err_threshold; /* Range: [0, 100];
                 threshold for stream error process, 0: discard with any error, 100 : keep data with any error */
    hi_mapi_vdec_video_dec_mode dec_mode; /* decode mode,
                 0: deocde IPB frames, 1: only decode I frame & P frame , 2: only decode I frame */
    hi_mapi_vdec_video_output_order output_order; /* frames output order,
                 0: the same with display order , 1: the same width decoder order */
    hi_mapi_compress_mode compress_mode; /* compress mode */
    hi_mapi_video_format  video_format;   /* video format */
    hi_mapi_vdec_quick_mark_mode quick_mark_mode;
} hi_mapi_vdec_video_param;

typedef enum {
    HI_MAPI_VDEC_VIDEO_MODE_STREAM = 0, /* send by stream */
    HI_MAPI_VDEC_VIDEO_MODE_FRAME,      /* send by frame  */
    HI_MAPI_VDEC_VIDEO_MODE_COMPAT,     /* One frame supports multiple packets sending. */
           /* The current frame is considered to end when bEndOfFrame is equal to TD_TRUE */
    HI_MAPI_VDEC_VIDEO_MODE_BUTT
} hi_mapi_vdec_video_mode;

typedef struct {
    td_u32 ref_frame_num;        /* Range: [0, 16]; reference frame num. */
    td_bool temporal_mvp_enable; /* specifies whether temporal motion vector predictors
                                                     can be used for inter prediction */
    td_u32 tmv_buf_size;         /* tmv buffer size(Byte) */
} hi_mapi_vdec_video_attr;

typedef struct {
    hi_mapi_pixel_format pxel_format; /* out put pixel format */
    td_u32 alpha; /* Range: [0, 255]; value 0 is transparent. */
    /* [0 ,127]   is deemed to transparent when enPixelFormat is ARGB1555 or ABGR1555
     * [128 ,256] is deemed to non-transparent when enPixelFormat is ARGB1555 or ABGR1555
     */
} hi_mapi_vdec_picture_param;

typedef struct {
    hi_mapi_payload_type type; /* video type to be decoded   */
    td_u32 display_frame_num;      /* Range: [0, 16]; display frame num */
    union {
        hi_mapi_vdec_video_param vdec_video_param;     /* structure with video ( h265/h264) */
        hi_mapi_vdec_picture_param vdec_picture_param; /* structure with picture (jpeg/mjpeg ) */
    };
} hi_mapi_vdec_param;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_COMM_ADAPT_DEFINE_H_ */
