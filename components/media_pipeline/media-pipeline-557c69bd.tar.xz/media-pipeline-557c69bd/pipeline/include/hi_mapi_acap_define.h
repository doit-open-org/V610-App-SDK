/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_ACAP_DEFINE_H__
#define __HI_MAPI_ACAP_DEFINE_H__

#include "hi_mapi_audio_adapt_define.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_errno.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     ACAP */
/** @{ */ /** <!-- [ACAP] */

/* Error code
    Invalid handle error for acap */
#define HI_MAPI_ACAP_EINVALIDHDL HI_MAPI_DEF_ERR(HI_MAPI_MOD_ACAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_DEVID)
/** Null pointer error for acap */
#define HI_MAPI_ACAP_ENULLPTR    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ACAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
/** media sys not inited error for acap */
#define HI_MAPI_ACAP_ENOINITED   HI_MAPI_DEF_ERR(HI_MAPI_MOD_ACAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
/** current state error for acap */
#define HI_MAPI_ACAP_ESTATEERR   HI_MAPI_DEF_ERR(HI_MAPI_MOD_ACAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
/** illegal parameter error for acap */
#define HI_MAPI_ACAP_EILLPARAM   HI_MAPI_DEF_ERR(HI_MAPI_MOD_ACAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
/** invalid fd error for acap */
#define HI_MAPI_ACAP_EINVALIDFD  HI_MAPI_DEF_ERR(HI_MAPI_MOD_ACAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_UNEXIST)
/** operate failed  for acap */
#define HI_MAPI_ACAP_EOPERATE    HI_MAPI_DEF_ERR(HI_MAPI_MOD_ACAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_OPERATE_FAIL)

/* Structure */
#define HI_MAPI_ACAP_MIC_CHN_MAX_NUM 2

/** Optional hardware input topology. Disabled preserves the legacy inner-codec defaults. */
typedef struct {
    td_bool enable;
    td_u32 chn_cnt;
    td_bool clk_share;
    td_u32 mic_chn_cnt;
    td_handle mic_chn_hdl[HI_MAPI_ACAP_MIC_CHN_MAX_NUM];
    td_handle ref_chn_hdl;
    td_handle out_chn_hdl;
    td_u32 reserved[4];
} hi_mapi_acap_input_topology;

/** Acap init attr */
typedef struct {
    hi_mapi_audio_sample_rate sample_rate;    /* Audio sampling rate, in Hz */
    hi_mapi_audio_bit_width   bit_width;      /* Audio bit width */
    hi_mapi_audio_sound_mode  sound_mode;     /* momo or steror */
    hi_mapi_audio_track_mode  track_mode;     /* audio track mode */
    hi_mapi_aio_work_mode     work_mode;      /* Audio workmode , eg I2S master or slave */
    td_u32                   pt_num_per_frm;   /* sampling points every frame */
    hi_mapi_aio_acodec_mixer  mixer_mic_mode;  /* mixer mic input mode for acodec */
    hi_mapi_audio_sample_rate resample_rate;  /* for resampler frame */
    hi_mapi_aio_i2s_type      i2s_type;       /* i2s type */
    hi_mapi_acap_input_topology input_topology; /* Optional external ADC channel topology */
} hi_mapi_acap_attr;

/** VQE type for HI_MAPI_ACAP_EnableVqe */
typedef enum {
    HI_MAPI_ACAP_VQE_TYPE_RECORD = 0,  /* Record VQE: ANR + AGC, no AO reference needed */
    HI_MAPI_ACAP_VQE_TYPE_TALK,         /* Talk VQE: AEC + ANR + AGC, requires AO reference */
    HI_MAPI_ACAP_VQE_TYPE_TALKV2,       /* Talk VQE V2: dual-MIC, requires AO reference */
    HI_MAPI_ACAP_VQE_TYPE_BUTT
} hi_mapi_acap_vqe_type;

/* ACAP extension command for hi_mapi_acap_set_param / hi_mapi_acap_get_param.
   Suffix convention:
     _CONFIG : must be set before hi_mapi_acap_start; returns HI_MAPI_ACAP_ESTATEERR if called while STARTED.
     _PARAM  : settable at any state. */
typedef enum {
    HI_MAPI_ACAP_CMD_AFE_PROVIDER_CONFIG = 0, /* const char[], e.g. "hisi" / "unisound" */
    HI_MAPI_ACAP_CMD_AFE_ATTR_CONFIG,         /* hi_mapi_acap_afe_attr_t */
    HI_MAPI_ACAP_CMD_BUTT
} hi_mapi_acap_cmd;

/** Public AFE provider extension attributes. */
typedef struct {
    const td_char *model_path; /* Optional software AFE model path; ignored by SDK providers. */
} hi_mapi_acap_afe_attr_t;

/** @} */ /** <!-- ==== ACAP End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_ACAP_H_ */
