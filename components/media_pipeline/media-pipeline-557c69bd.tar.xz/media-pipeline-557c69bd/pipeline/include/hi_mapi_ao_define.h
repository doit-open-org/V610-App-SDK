/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef HI_MAPI_AO_DEFINE_H
#define HI_MAPI_AO_DEFINE_H

#include "ot_defines.h"
#include "hi_mapi_errno.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_audio_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/** \addtogroup     AO */
/** @{ */ /** <!-- [AO] */

/** error code
      invlalid Handle error for AO */
#define HI_MAPI_AO_EINVALIDHDL HI_MAPI_DEF_ERR(HI_MAPI_MOD_AO, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_DEVID)
/* NULL point error for AO */
#define HI_MAPI_AO_ENULLPTR    HI_MAPI_DEF_ERR(HI_MAPI_MOD_AO, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
/* media not inited */
#define HI_MAPI_AO_ENOTINITED  HI_MAPI_DEF_ERR(HI_MAPI_MOD_AO, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
/* state error for AO */
#define HI_MAPI_AO_ESTATEERR   HI_MAPI_DEF_ERR(HI_MAPI_MOD_AO, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
/* at lease one parameter is illagal for AO */
#define HI_MAPI_AO_EILLPARAM   HI_MAPI_DEF_ERR(HI_MAPI_MOD_AO, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)

#define MAPI_ADAPT_AO_SYSCHN_ID OT_AO_SYS_CHN_ID

/* Structure */
/** attr for ao pub */
typedef struct {
    hi_mapi_audio_sample_rate sample_rate;       /* Audio output samplerate, in Hz */
    hi_mapi_audio_bit_width bit_width;           /* Audio bit width */
    hi_mapi_audio_sound_mode sound_mode;         /* momo or steror */
    hi_mapi_audio_track_mode track_mode;         /* audio track mode */
    hi_mapi_aio_work_mode work_mode;             /* work mode for ao */
    td_u32 pt_num_per_frm;                        /* sampling points every frame */
    hi_mapi_audio_sample_rate in_sample_rate;     /* ao input resample for resample */
    hi_mapi_aio_i2s_type i2s_type;               /* i2s type */
} hi_mapi_ao_attr;

/** ao vqe config */
typedef struct {
    hi_mapi_audio_work_state work_state;
} hi_mapi_ao_vqe_attr;

/** @} */ /** <!-- ==== AO ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_AO_H__ */
