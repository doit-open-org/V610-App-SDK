/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_DISP_H__
#define __HI_MAPI_DISP_H__

#include "hi_mapi_disp_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/** \addtogroup     Disp */
/** @{ */ /** <!-- [Disp] */

/**
 * @brief Init disp.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] disp_attr hi_mapi_disp_attr *: disp attribute.
 * @return 0 init disp success.
 * @return Non 0 init disp failed.
 */
td_s32 hi_mapi_disp_init(td_handle disp_hdl, const hi_mapi_disp_attr *disp_attr);

/**
 * @brief deinit disp.
 * @param[in] dispHdl td_handle: handle of disp.
 * @return 0 deinit disp success.
 * @return Non 0 deinit disp failed.
 */
td_s32 hi_mapi_disp_deinit(td_handle disp_hdl);

/**
 * @brief start disp.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] videoLayerAttr hi_mapi_disp_video_layer_attr *: the attribute of VideoLayer.
 * @return 0 start disp success.
 * @return Non 0 start disp failed.
 */
td_s32 hi_mapi_disp_start(td_handle disp_hdl, const hi_mapi_disp_video_layer_attr *video_layer_attr);

/**
 * @brief stop disp.
 * @param[in] dispHdl td_handle: handle of disp.
 * @return 0 stop disp success.
 * @return Non 0 stop disp failed.
 */
td_s32 hi_mapi_disp_stop(td_handle disp_hdl);

/**
 * @brief set disp extend attr.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] cmd hi_mapi_disp_cmd: command of set disp extend attribute.
 * @param[in] attr td_void *: the extend attribute of disp instance.
 * @param[in] attr_len td_u32: length of the extend attribute.
 * @return 0 set disp extend attr success.
 * @return Non 0 set disp extend attr failed.
 */
td_s32 hi_mapi_disp_set_attr_ex(td_handle disp_hdl, hi_mapi_disp_cmd cmd, const td_void *attr, td_u32 attr_len);

/**
 * @brief get disp extend attribute.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] cmd hi_mapi_disp_cmd: command of get disp extend attribute.
 * @param[out] attr td_void *: the extend attribute of disp instance.
 * @param[in] attr_len td_u32: length of the extend attribute.
 * @return 0 get disp extend attr success.
 * @return Non 0 get disp extend attr failed.
 */
td_s32 hi_mapi_disp_get_attr_ex(td_handle disp_hdl, hi_mapi_disp_cmd cmd, td_void *attr, td_u32 attr_len);

/**
 * @brief set window attribute.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] wndHdl  td_handle: handle of window.
 * @param[in] wndAttr hi_mapi_disp_window_attr *: the attribute of window instance.
 * @return 0 set window attribute success.
 * @return Non 0 set window attribute failed.
 */
td_s32 hi_mapi_disp_set_window_attr(td_handle disp_hdl, td_handle wnd_hdl,
                                  const hi_mapi_disp_window_attr *wnd_attr);

/**
 * @brief get window attribute.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] wndHdl  td_handle: handle of window.
 * @param[out] wndAttr hi_mapi_disp_window_attr *: the attribute of window instance.
 * @return 0 get window attribute success.
 * @return Non 0 get window attribute failed.
 */
td_s32 hi_mapi_disp_get_window_attr(td_handle disp_hdl, td_handle wnd_hdl, hi_mapi_disp_window_attr *wnd_attr);

/**
 * @brief set window extend attribute.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] wndHdl  td_handle: handle of window.
 * @param[in] cmd hi_mapi_disp_window_cmd: command of get window extend attribute.
 * @param[in] attr td_void *: the extend attribute of window instance.
 * @param[in] attr_len td_u32: length of the extend attribute.
 * @return 0 set window extend attribute success.
 * @return Non 0 set window extend attribute failed.
 */
td_s32 hi_mapi_disp_set_window_attr_ex(td_handle disp_hdl, td_handle wnd_hdl, hi_mapi_disp_window_cmd cmd,
    const td_void *attr, td_u32 attr_len);

/**
 * @brief get window extend attribute.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] wndHdl  td_handle: handle of window.
 * @param[in] cmd hi_mapi_disp_window_cmd: command of get window extend attribute.
 * @param[out] attr td_void *: the extend attribute of window instance.
 * @param[in] attr_len td_u32: length of the extend attribute.
 * @return 0 get window extend attribute success.
 * @return Non 0 get window extend attribute failed.
 */
td_s32 hi_mapi_disp_get_window_attr_ex(td_handle disp_hdl, td_handle wnd_hdl, hi_mapi_disp_window_cmd cmd,
    td_void *attr, td_u32 attr_len);

/**
 * @brief start window.
 * @param[in] dispHdl td_handle: handle of disp
 * @param[in] wndHdl  td_handle: handle of window
 * @return 0 start window success.
 * @return Non 0 start window failed.
 */
td_s32 hi_mapi_disp_start_window(td_handle disp_hdl, td_handle wnd_hdl);

/**
 * @brief stop window.
 * @param[in] dispHdl td_handle: handle of disp
 * @param[in] wndHdl  td_handle: handle of window
 * @return 0 stop window success.
 * @return Non 0 stop window failed.
 */
td_s32 hi_mapi_disp_stop_window(td_handle disp_hdl, td_handle wnd_hdl);

/**
 * @brief clear window.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] wndHdl  td_handle: handle of window.
 * @return 0 clear window success.
 * @return Non 0 clear window failed.
 */
td_s32 hi_mapi_disp_clear_window(td_handle disp_hdl, td_handle wnd_hdl);

/**
 * @brief send video frame to window.
 * @param[in] dispHdl td_handle: handle of disp.
 * @param[in] wndHdl  td_handle: handle of window.
 * @param[in] framedata hi_mapi_frame_data: framedata info.
 * @return 0 send video frame to window success.
 * @return Non 0 send video frame to window failed.
 */
td_s32 hi_mapi_disp_send_frame(td_handle disp_hdl, td_handle wnd_hdl, const hi_mapi_frame_data *framedata);

/**
 * @brief get screen resolution.
 * @param[in] disp_hdl td_handle: handle of disp.
 * @param[out] width td_u32 *: screen width in pixels.
 * @param[out] hight td_u32 *: screen height in pixels.
 * @return 0 success.
 * @return Non 0 failed.
 */
td_s32 hi_mapi_disp_get_screen_resolution(td_handle disp_hdl, td_u32 *width, td_u32 *hight);

/**
 * @brief get the LVGL video screen object and increment its reference count.
 * @param[in] disp_hdl td_handle: handle of disp.
 * @return non-NULL LVGL screen object pointer on success.
 * @return NULL if disp has not been started or screen is unavailable.
 */
void *hi_mapi_disp_get_video_screen(td_handle disp_hdl);

/**
 * @brief release the LVGL video screen object and decrement its reference count.
 * @param[in] disp_hdl td_handle: handle of disp.
 * @param[in] video_screen void *: screen pointer returned by hi_mapi_disp_get_video_screen.
 * @return 0 success.
 * @return Non 0 failed.
 */
td_s32 hi_mapi_disp_release_video_screen(td_handle disp_hdl, void *video_screen);

/** @} */ /** <!-- ==== Disp End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_DISP_H__ */

