/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_ACAP_H__
#define __HI_MAPI_ACAP_H__

#include "hi_mapi_acap_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     ACAP */
/** @{ */ /** <!-- [ACAP] */

/* Interface */
/**
 * @brief initialize acap attribute.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] acap_attr hi_mapi_acap_attr *:acap attr
 * @return 0  initialize acap attribute success.
 * @return Non 0  initialize acap attribute fail.
 */
td_s32 hi_mapi_acap_init(td_handle acap_hdl, const hi_mapi_acap_attr *acap_attr);

/**
 * @brief deinit acap attribute.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @return 0  deinit acap attribute success.
 * @return Non 0  deinit acap attribute fail.
 */
td_s32 hi_mapi_acap_deinit(td_handle acap_hdl);

/**
 * @brief start acap device.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] acap_chn_hdl td_handle:handle of audio capture device chn.
 * @return 0  start acap attribute success.
 * @return Non 0  start acap attribute fail.
 */
td_s32 hi_mapi_acap_start(td_handle acap_hdl, td_handle acap_chn_hdl);

/**
 * @brief stop acap device.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] acap_chn_hdl td_handle:handle of audio capture device chn.
 * @return 0  stop acap device success.
 * @return Non 0  stop acap device fail.
 */
td_s32 hi_mapi_acap_stop(td_handle acap_hdl, td_handle acap_chn_hdl);

/**
 * @brief enable acap audio quality enhance.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] acap_chn_hdl td_handle:handle of audio capture device chn.
 * @param[in] vqe_type hi_mapi_acap_vqe_type:vqe type (RECORD/TALK/TALKV2).
 * @param[in] ref_ao_hdl td_handle:reference AO handle for AEC; pass HI_MAPI_INVALID_HANDLE for RECORD type.
 * @return 0  enable acap audio quality enhance success.
 * @return Non 0  enable acap audio quality enhance fail.
 */
td_s32 hi_mapi_acap_enable_vqe(td_handle acap_hdl, td_handle acap_chn_hdl,
                               hi_mapi_acap_vqe_type vqe_type, td_handle ref_ao_hdl);

/**
 * @brief disable acap audio quality enhance.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] acap_chn_hdl td_handle:handle of audio capture device chn.
 * @return 0  disable acap audio quality enhance success.
 * @return Non 0  disable acap audio quality enhance fail.
 */
td_s32 hi_mapi_acap_disable_vqe(td_handle acap_hdl, td_handle acap_chn_hdl);

/**
 * @brief set acap volume.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] audio_gain td_s32:the value of audio gain.
 * @return 0  set acap volume success.
 * @return Non 0  set acap volume fail.
 */
td_s32 hi_mapi_acap_set_volume(td_handle acap_hdl, td_s32 audio_gain);

/**
 * @brief get acap volume.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[out] audio_gain td_s32 *:the value of audio gain.
 * @return 0  get acap volume success.
 * @return Non 0  get acap volume fail.
 */
td_s32 hi_mapi_acap_get_volume(td_handle acap_hdl, td_s32 *audio_gain);

/**
 * @brief acap mute.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @return 0  acap mute success.
 * @return Non 0  acap mute fail.
 */
td_s32 hi_mapi_acap_mute(td_handle acap_hdl);

/**
 * @brief acap unmute.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @return 0  acap unmute success.
 * @return Non 0  acap unmute fail.
 */
td_s32 hi_mapi_acap_unmute(td_handle acap_hdl);

/**
 * @brief get acap frame.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] acap_chn_hdl td_handle:handle of audio capture device chn.
 * @param[out] audio_frm hi_mapi_audio_frame *:audio frame info.
 * @param[out] aec_frm hi_mapi_aec_frame *:aec frame info
 * @return 0  get acap frame success.
 * @return Non 0  get acap frame fail.
 */
td_s32 hi_mapi_acap_get_frame(td_handle acap_hdl, td_handle acap_chn_hdl, hi_mapi_audio_frame *audio_frm,
                             hi_mapi_aec_frame *aec_frm);

/**
 * @brief release acap frame.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] acap_chn_hdl td_handle:handle of audio capture device chn.
 * @param[in] audio_frm hi_mapi_audio_frame *:audio frame info.
 * @param[in] aec_frm hi_mapi_aec_frame *:aec frame info
 * @return 0  release acap frame success.
 * @return Non 0  release acap frame fail.
 */
td_s32 hi_mapi_acap_release_frame(td_handle acap_hdl, td_handle acap_chn_hdl, const hi_mapi_audio_frame *audio_frm,
                                 const hi_mapi_aec_frame *aec_frm);

/**
 * @brief get default acap attribute, only sample rate and sound mode need to be specified.
 * @param[in] sample_rate hi_mapi_audio_sample_rate:audio sample rate.
 * @param[in] sound_mode hi_mapi_audio_sound_mode:audio sound mode (mono/stereo).
 * @param[out] acap_attr hi_mapi_acap_attr *:acap attr filled with default values.
 * @return 0  get default acap attribute success.
 * @return Non 0  get default acap attribute fail.
 */
td_s32 hi_mapi_acap_get_default_attr(hi_mapi_audio_sample_rate sample_rate,
                                    hi_mapi_audio_sound_mode sound_mode,
                                    hi_mapi_acap_attr *acap_attr);

/**
 * @brief set an ACAP extension parameter by command.
 *        `_CONFIG` suffixed commands are only permitted before hi_mapi_acap_start;
 *        calling after STARTED returns HI_MAPI_ACAP_ESTATEERR.
 *        AFE_PROVIDER_CONFIG selects the provider used later by enable_vqe;
 *        AFE_ATTR_CONFIG supplies optional provider attributes such as model_path.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] cmd hi_mapi_acap_cmd: extension command id.
 * @param[in] attr const td_void *: pointer to the command-specific attribute.
 * @param[in] attr_len td_u32: size of *attr in bytes.
 * @return 0 success.
 * @return Non 0 failure.
 */
td_s32 hi_mapi_acap_set_param(td_handle acap_hdl, hi_mapi_acap_cmd cmd,
                              const td_void *attr, td_u32 attr_len);

/**
 * @brief read back an ACAP extension parameter by command.
 * @param[in] acap_hdl td_handle:handle of audio capture device.
 * @param[in] cmd hi_mapi_acap_cmd: extension command id.
 * @param[out] attr td_void *: caller buffer to receive the attribute value.
 * @param[in] attr_len td_u32: size of *attr in bytes.
 * @return 0 success.
 * @return Non 0 failure.
 */
td_s32 hi_mapi_acap_get_param(td_handle acap_hdl, hi_mapi_acap_cmd cmd,
                              td_void *attr, td_u32 attr_len);

/** @} */ /** <!-- ==== ACAP End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_ACAP_H_ */
