/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_HDMI_DEFINE_H__
#define __HI_MAPI_HDMI_DEFINE_H__

#include "hi_mapi_errno.h"
#include "hi_mapi_hdmi_adapt_define.h"
#include "hi_mapi_disp_adapt_define.h"
#include "hi_mapi_audio_adapt_define.h"
#include "hi_mapi_comm_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     HDMI */
/** @{ */ /** <!-- [HDMI] */

#define HI_MAPI_HDMI_ENULL_PTR      HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
#define HI_MAPI_HDMI_ENOTREADY      HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
#define HI_MAPI_HDMI_EINVALID_DEVID \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_DEVID)
#define HI_MAPI_HDMI_EINVALID_CHNID \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)
#define HI_MAPI_HDMI_ENOT_SUPPORT   HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_SUPPORT)
#define HI_MAPI_HDMI_ENOT_PERM      HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
#define HI_MAPI_HDMI_ENOMEM         HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)
#define HI_MAPI_HDMI_EILLEGAL_PARAM \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
#define HI_MAPI_HDMI_EBUSY          HI_MAPI_DEF_ERR(HI_MAPI_MOD_HDMI, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUSY)

typedef struct {
    td_bool connected;     /* < Whether the devices are connected. */
    td_bool support_hdmi;   /* < Whether the HDMI is supported by the device. If the HDMI
                                 is not supported by the device, the device is DVI. */
    td_bool is_sink_power_on; /* < Whether the sink device is powered on. */

    hi_mapi_disp_intf_sync native_intf_sync;       /* < Physical resolution of the display device. */
    td_bool intf_sync[HI_MAPI_DISP_OUTPUT_BUTT];    /* < Video capability set.TD_TRUE: This display sync is supported.
                                                TD_FALSE: This display format is not supported. */
    hi_mapi_audio_sample_rate support_sample_rate[HI_MAPI_AO_MAX_SUPPORT_SAMPLERATE_NUM]; /* <Audio sample rate */
    td_bool support_hdmi_2_0; /* < Whether to support HDMI2.0. */
} hi_mapi_hdmi_sink_capability;

typedef struct {
    td_bool enable_hdmi;       /* < Whether to forcibly output the video over the HDMI.  */
    td_bool enable_video;      /* < Whether to output video.The value must be TD_TRUE.
                                    If the value is TD_FALSE, the HDMI is forcibly set to TD_TRUE. */
    hi_mapi_disp_intf_sync hdmi_sync; /* < Video norm. This value of the video norm
                                    must be consistent with the norm of the video output. */
    td_bool enable_audio;      /* < Whether to enable the audio. */
    hi_mapi_audio_sample_rate
        sample_rate;          /* < Audio sampling rate. This parameter needs to be consistent with that of the AO. */
    td_u32 pix_clk;          /* < Pixclk of enVideoFmt(unit is kHz).(This param is valid only when
                                    enVideoFmt is HDMI_VIDEO_FMT_VESA_CUSTOMER_DEFINE) */
} hi_mapi_hdmi_attr;

/** @} */ /** <!-- ==== HDMI End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_HDMI_DEFINE_H__ */
