/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_DISP_DEFINE_H__
#define __HI_MAPI_DISP_DEFINE_H__

#include "hi_mapi_comm_define.h"
#include "hi_mapi_disp_adapt_define.h"
#include "hi_mapi_errno.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     DISP */
/** @{ */ /** <!-- [DISP] */
#define HI_MAPI_DISP_ENULL_PTR      HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
#define HI_MAPI_DISP_ENOTREADY      HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
#define HI_MAPI_DISP_EINVALID_DEVID \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_DEVID)
#define HI_MAPI_DISP_EINVALID_CHNID \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)
#define HI_MAPI_DISP_ENOT_SUPPORT   HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_SUPPORT)
#define HI_MAPI_DISP_ENOT_PERM      HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
#define HI_MAPI_DISP_ENOMEM         HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)
#define HI_MAPI_DISP_EILLEGAL_PARAM \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
#define HI_MAPI_DISP_EBUSY          HI_MAPI_DEF_ERR(HI_MAPI_MOD_DISP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUSY)

typedef struct {
    hi_mapi_disp_user_intf_sync_attr user_intf_sync_attr; /* RW; user synchronization timing attribute */
    td_u32 pre_div;                      /* RW, range: [1, 32]; device previous division */
    td_u32 dev_div;                      /* RW, range: [1, 4]; device clock division */
} hi_mapi_disp_user_intf_manual_sync_attr;

typedef struct {
    td_u32 pixel_clk; /* RW, pixel clock(Hz) */
} hi_mapi_disp_user_intf_auto_sync_attr;

typedef enum  {
    HI_MAPI_DISP_OP_MODE_AUTO   = 0,
    HI_MAPI_DISP_OP_MODE_MANUAL = 1,
    HI_MAPI_DISP_OP_MODE_BUTT
} hi_mapi_disp_op_mode;

typedef struct {
    hi_mapi_disp_op_mode mode;
    td_bool clk_reverse;
    union {
        hi_mapi_disp_user_intf_auto_sync_attr  auto_sync_attr;
        hi_mapi_disp_user_intf_manual_sync_attr manual_sync_attr;
    };
} hi_mapi_disp_user_intf_sync_info;

typedef struct {
    hi_mapi_disp_user_intf_sync_info user_info;
    td_u32 dev_frame_rate;
} hi_mapi_disp_user_info_attr;

typedef struct {
    hi_mapi_disp_pub_attr pub_attr;
    hi_mapi_disp_user_info_attr user_info_attr;
} hi_mapi_disp_attr;

typedef struct {
    hi_mapi_size image_size;
    td_u32 frame_rate;
    td_u32 buf_len;
} hi_mapi_disp_video_layer_attr;

typedef struct {
    hi_mapi_rect rect;
    td_u32 priority;
} hi_mapi_disp_window_attr;

typedef struct {
    hi_mapi_disp_csc_attr vo_csc;
} hi_mapi_disp_csc_attr_ex;

typedef struct {
    hi_mapi_rotation rorate;
} hi_mapi_disp_window_rotate;

typedef struct {
#if defined (__HI3516DV500__) || defined(__HI3519DV500__) || defined(__HI3516CV610__)
    td_bool hor_split_en;
#endif
    hi_mapi_aspect_ratio_attr aspect_ratio;
} hi_mapi_disp_window_aspect_ratio;

typedef enum {
    HI_MAPI_DISP_CMD_VIDEO_CSC,
    HI_MAPI_DISP_CMD_GRAPHIC_CSC,
    HI_MAPI_DISP_CMD_BUTT
} hi_mapi_disp_cmd;

typedef enum {
    HI_MAPI_DISP_WINDOW_CMD_ROTATE,
    HI_MAPI_DISP_WINDOW_CMD_ASPECTRATIO,
    HI_MAPI_DISP_WINDOW_CMD_BUTT
} hi_mapi_disp_window_cmd;

/** @} */ /** <!-- ==== DISP End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_DISP_DEFINE_H__ */
