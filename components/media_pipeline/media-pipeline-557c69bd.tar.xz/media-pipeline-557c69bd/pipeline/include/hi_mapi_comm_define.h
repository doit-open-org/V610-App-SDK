/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_COMM_DEFINE_H__
#define __HI_MAPI_COMM_DEFINE_H__

#include <pthread.h>
#include "hi_mapi_comm_adapt_define.h"
#include "hi_mapi_errno.h"


#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */


/** \addtogroup     COMM */
/** @{ */ /** <!-- [COMM] */

#define MAPI_MUTEX_INIT_LOCK(mutex)                  \
    do {                                        \
        (void)pthread_mutex_init(&(mutex), NULL); \
    } while (0)

#define MAPI_MUTEX_LOCK(mutex)                 \
    do {                                  \
        (void)pthread_mutex_lock(&(mutex)); \
    } while (0)

#define MAPI_MUTEX_UNLOCK(mutex)                 \
    do {                                    \
        (void)pthread_mutex_unlock(&(mutex)); \
    } while (0)

#define MAPI_MUTEX_DESTROY(mutex)                 \
    do {                                     \
        (void)pthread_mutex_destroy(&(mutex)); \
    } while (0)

#define MAPI_UNUSED(x) (void)(x)

/* VCAP attribute range */
#ifdef __HI3516CV610__
#define HI_MAPI_VCAP_MAX_DEV_NUM          2
#else
#define HI_MAPI_VCAP_MAX_DEV_NUM          4
#endif

#ifdef __HI3516CV610__
#define HI_MAPI_SENSOR_MAX_LANE_NUM (4)
#else
#define HI_MAPI_SENSOR_MAX_LANE_NUM (8)
#endif

#if defined (__HI3516DV500__) || defined (__HI3519DV500__)
#define HI_MAPI_VCAP_MAX_PIPE_NUM         7
#elif defined (__HI3516CV610__)
#define HI_MAPI_VCAP_MAX_PIPE_NUM         2
#else
#define HI_MAPI_VCAP_MAX_PIPE_NUM         4
#endif
#define HI_MAPI_VCAP_PIPE_MAX_CHN_NUM          1
#define HI_MAPI_VCAP_DEV_SENSOR_MAX_NUM        4
#define HI_MAPI_VCAP_STITCH_MAX_GROUP_NUM      4 /* not valid */
#define HI_MAPI_VCAP_MAX_EXT_DATA_TYPE_NUM   3

/* VPSS attribute range */
#define HI_MAPI_VPSS_STITCH_PIPE_MAX_NUM         4
#define HI_MAPI_VPSS_STITCH_SPLIT_PIPE_NUM       4
#define HI_MAPI_VPSS_STITCH_SPLIT_NUM            2
#define HI_MAPI_VPSS_STITCH_CUBE_MAP_SURFACE_NUM 6
#ifdef __HI3516CV610__
#define HI_MAPI_VPSS_PHY_CHN_MAX_NUM           3
#else
#define HI_MAPI_VPSS_PHY_CHN_MAX_NUM           4
#endif
#if defined (__SS928V100__)
#define HI_MAPI_VPSS_EXT_CHN_MAX_NUM           8
#define HI_MAPI_VPSS_MAX_NUM                128 /* OT_VPSS_MAX_GRP_NUM */
#elif defined (__HI3516CV610__)
#define HI_MAPI_VPSS_EXT_CHN_MAX_NUM           2
#define HI_MAPI_VPSS_MAX_NUM                6 /* OT_VPSS_MAX_GRP_NUM */
#else
#define HI_MAPI_VPSS_EXT_CHN_MAX_NUM           4
#define HI_MAPI_VPSS_MAX_NUM                16 /* OT_VPSS_MAX_GRP_NUM */
#endif
#define HI_MAPI_VPSS_CHN_MAX_NUM       (HI_MAPI_VPSS_PHY_CHN_MAX_NUM + HI_MAPI_VPSS_EXT_CHN_MAX_NUM)   

/* the maximum number of professional snap */
#define HI_MAPI_PRO_MAX_FRAME_NUM     8
/* the maximum number of normal snap */
#define HI_MAPI_NORMAL_MAX_FRAME_NUM 0xFFFFFFFF
#define HI_MAPI_VCAP_OSD_MAX_NUM     4

/* VPSS attribute range */
#define HI_MAPI_VPSS_STITCH_MAX_NUM      32
#define HI_MAPI_VPSS_STITCH_CHN_MAX_NUM 2
#define HI_MAPI_VPSS_OSD_MAX_NUM   4

/* VENC attribute range */
#define HI_MAPI_VENC_MAX_CHN_NUM      8
#define HI_MAPI_VENC_CALLBACK_MAX_NUM 5
#define HI_MAPI_VENC_OSD_MAX_NUM      8

/* DISP attribute range */
#define HI_MAPI_DISP_OSD_MAX_NUM 1
/* HDMI attribute range */
#define HI_MAPI_HDMI_MAX_NUM 1

/* VDEC attribute range */
#define HI_MAPI_VDEC_MAX_NUM 8

/* OSD attribute range */
/** Maximum OSD Count */
#define HI_MAPI_OSD_MAX_CNT  (16)

/** Maximum Display Count for Each OSD */
#define HI_MAPI_OSD_MAX_DISP_CNT (4)

/* audio attribute range */
#define HI_MAPI_AIO_MAX_POINT_PER_FRAME 2048

#define HI_MAPI_ACAP_CHN_MAX_NUM 4

#define HI_MAPI_AENC_CHN_MAX_NUM          2
#define HI_MAPI_AENC_CHN_CALLBACK_MAX_NUM 5

#define HI_MAPI_AO_MIN_GAIN                   (-121)
#define HI_MAPI_AO_MAX_GAIN                   6
#define HI_MAPI_AO_MAX_SUPPORT_SAMPLERATE_NUM 3

#define HI_MAPI_MODE_NAME_LEN 8

#define OT_IPCMSG_PORT_MPP 1

#ifndef OT_INVALID_HANDLE
#define OT_INVALID_HANDLE (-1)
#endif

#ifndef OT_INVALID_VALUE
#define OT_INVALID_VALUE  (-1)
#endif

/* pthread  name lenght */
#define HI_MAPI_PTHREAD_NAME_LEN   16

/** String OSD Maximum Length */
#define HI_MAPI_MAX_STR_LEN        64

#define HI_MAPI_SYS_ESAFEFUNC_OPERATE_FAIL    \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SAFEFUNC_OPERATE_FAIL)

#define HI_MAPI_SYS_ARRAY_OUT_BOUNDS          \
        HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ARRAY_OUT_BOUNDS)

#define HI_MAPI_SYS_VALUE_OVERFLOW            \
HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_VALUE_OVERFLOW)

typedef enum {
    HI_MAPI_MOD_SYS = 0,
    HI_MAPI_MOD_VCAP,
    HI_MAPI_MOD_VPSS,
    HI_MAPI_MOD_VENC,
    HI_MAPI_MOD_ACAP,
    HI_MAPI_MOD_AENC,
    HI_MAPI_MOD_AO,
    HI_MAPI_MOD_DISP,
    HI_MAPI_MOD_HDMI,
    HI_MAPI_MOD_ADEC,
    HI_MAPI_MOD_VDEC,
    HI_MAPI_MOD_OSD,
    HI_MAPI_MOD_VGS,
    HI_MAPI_MOD_BUTT,
} hi_mapi_module_id;

typedef struct {
    hi_mapi_module_id mod_id;
    td_s32            dev_id;
    td_s32            chn_id;
} hi_mapi_mpp_chn;

typedef enum {
    HI_MAPI_PAYLOAD_TYPE_H264,
    HI_MAPI_PAYLOAD_TYPE_H265,
    HI_MAPI_PAYLOAD_TYPE_MJPEG,
    HI_MAPI_PAYLOAD_TYPE_JPEG,
    HI_MAPI_PAYLOAD_TYPE_AAC,
    HI_MAPI_PAYLOAD_TYPE_G711A,
    HI_MAPI_PAYLOAD_TYPE_G711U,
    HI_MAPI_PAYLOAD_TYPE_MP3,
    HI_MAPI_PAYLOAD_TYPE_LPCM,
    HI_MAPI_PAYLOAD_TYPE_SVAC3,
    HI_MAPI_PAYLOAD_TYPE_BUTT
} hi_mapi_payload_type;

/* Audio bitstream payload packaging format. Shared by AENC / ADEC, currently
   only meaningful for OPUS streams (other formats are always HI_NATIVE). */
typedef enum {
    HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE = 0,  /* Hisi-private packing: each frame prefixed with an 8-byte big-endian length header */
    HI_MAPI_AUDIO_PAYLOAD_STANDARD,        /* Bare RTP payload, no length prefix (RFC 7587 OPUS RTP payload format) */
    HI_MAPI_AUDIO_PAYLOAD_BUTT
} hi_mapi_audio_payload_format;

typedef enum {
    HI_MAPI_FRAME_DATA_TYPE_RAW,
    HI_MAPI_FRAME_DATA_TYPE_YUV,
    HI_MAPI_FRAME_DATA_TYPE_BUTT
} hi_mapi_frame_data_type;

/* Frame supplemental information */
typedef struct {
    hi_mapi_frame_data_type frame_data_type;
    td_u32 width;
    td_u32 height;
    hi_mapi_pixel_format pixel_format;
    hi_mapi_video_format video_format;
    hi_mapi_compress_mode compress_mode;
    td_u64 phy_addr[HI_MAPI_FRAME_DATA_ADDR_NUM];
    td_u64 vir_addr[HI_MAPI_FRAME_DATA_ADDR_NUM];
    td_u32 stride[HI_MAPI_FRAME_DATA_ADDR_NUM];
    hi_mapi_video_field field;
    td_u64 header_phys_addr[HI_MAPI_FRAME_DATA_ADDR_NUM];
    td_u64 heade_virt_addr[HI_MAPI_FRAME_DATA_ADDR_NUM];
    td_u32 heade_stride[HI_MAPI_FRAME_DATA_ADDR_NUM];
    hi_mapi_dynamic_range dynamic_range;
    hi_mapi_color_gamut   color_gamut;
    td_u32 mod_id;
    td_u32 time_ref;
    td_u32 frame_flag;
    td_u64 pts;
    td_u32 pool_id;

    hi_mapi_video_supplement video_supplement;
} hi_mapi_frame_data;

typedef enum {
    HI_MAPI_AUDIO_FORMAT_AACLC = 0, /* AAC-LC format  */
    HI_MAPI_AUDIO_FORMAT_G711A,     /* G711A format  */
    HI_MAPI_AUDIO_FORMAT_G711U,     /* G711U format  */
    HI_MAPI_AUDIO_FORMAT_MP3,       /* MP3 format  */
    HI_MAPI_AUDIO_FORMAT_LPCM,      /* LPCM format  */
    HI_MAPI_AUDIO_FORMAT_OPUS,
    HI_MAPI_AUDIO_FORMAT_BUTT
} hi_mapi_audio_format;

typedef enum {
    HI_MAPI_SYS_VB = 0, /* need vb */
    HI_MAPI_SYS_AUDIO,
} hi_mapi_sys_cmd;

/** media config param */
typedef struct {
    hi_mapi_sys_vi_vpss_mode vi_vpss_mode;
    hi_mapi_sys_vb_config vb_config;
} hi_mapi_sys_media_config;

/** the param of the venc mod */
typedef struct {
    td_u32 h264e_low_power_mode; /* <H264e low power consumption mode Range:[0,2]; */
    td_u32 h265e_low_power_mode; /* <H265e low power consumption mode Range:[0,2]; */
    td_u32 svac3e_low_power_mode; /* <SVA3e low power consumption mode Range:[0,2]; */
} hi_mapi_sys_venc_mode_param;

/** the param of the isp mod */
typedef struct {
    td_bool param_valid;
    td_bool quick_start;
    td_bool int_bottom_half;
} hi_mapi_isp_param_mode;

#define HI_MAPI_AI_TALKV2_MASK_NR        0x2U
#define HI_MAPI_AI_TALKV2_MASK_EQ        0x4U
#define HI_MAPI_AI_TALKV2_MASK_AGC       0x8U
#define HI_MAPI_AI_TALKV2_MASK_DRC       0x10U
#define HI_MAPI_AI_TALKV2_MASK_LIMITER   0x20U
#define HI_MAPI_AI_TALKV2_MASK_DEREVERB  0x40U
#define HI_MAPI_AI_TALKV2_MASK_FMP       0x80U
#define HI_MAPI_AI_TALKV2_MASK_WNR       0x100U
#define HI_MAPI_AI_TALKV2_MASK_AEC       0x200U
#define HI_MAPI_AI_TALKV2_MASK_HS        0x400U

/** talk vqe config */
typedef struct {
    td_u32 open_mask;
} hi_mapi_audio_talk_vqe_attr;

/** ao vqe config */
typedef struct {
    td_u32 open_mask;
} hi_mapi_audio_ao_vqe_attr;

/** vqe config */
typedef struct {
    hi_mapi_audio_talk_vqe_attr talk_vqe_attr;
    hi_mapi_audio_ao_vqe_attr   ao_vqe_attr;
} hi_mapi_audio_vqe_attr;

/** the param of the audio mod */
typedef struct {
    td_bool audio_bypass;
    hi_mapi_audio_vqe_attr vqe_attr;
} hi_mapi_audio_param_mode;

/** media base attribute */
typedef struct {
	td_u32 vcap_dev_num;
    hi_mapi_size vcap_reso_size[HI_MAPI_VCAP_MAX_DEV_NUM];
    td_bool vcap_online[HI_MAPI_VCAP_MAX_DEV_NUM];
	td_u32 raw_bit_width;
    td_bool is_wdr;

	td_u32 vpss_grp_num;
	td_u32 vpss_chn_num;
	hi_mapi_size vpss_reso_size[HI_MAPI_VPSS_MAX_NUM][HI_MAPI_VPSS_CHN_MAX_NUM];
    td_bool vpss_online[HI_MAPI_VPSS_MAX_NUM];
    td_bool vpss_wrap_en[HI_MAPI_VPSS_MAX_NUM];      /* per-grp VPSS chn0 wrap */
    td_bool vi_wrap_en[HI_MAPI_VCAP_MAX_DEV_NUM];    /* per-dev VI pipe wrap (offline) */
    td_u32  sensor_full_lines_std[HI_MAPI_VCAP_MAX_DEV_NUM];
    td_u32  frame_rate[HI_MAPI_VCAP_MAX_DEV_NUM];
} hi_mapi_sys_base_attr;

/** media init attribute */
typedef struct {
    hi_mapi_sys_media_config media_config;
    hi_mapi_sys_venc_mode_param venc_mod_para;
    hi_mapi_isp_param_mode isp_mod_para;
    hi_mapi_audio_param_mode audio_mod_para;
} hi_mapi_sys_media_attr;

typedef td_s32 (*hi_mapi_sys_get_font_mod_cb)(const td_char *character, td_u8 **font_mod, td_s32 *font_mod_len);

/* OSD Fonts Lib */
typedef struct {
    /* OSD Lib Font Size, in pixel */
    td_u32 font_width;
    td_u32 font_height;
    hi_mapi_sys_get_font_mod_cb get_font_mod_cb;
} hi_mapi_sys_font_attr;

typedef struct {
    td_char str[HI_MAPI_MAX_STR_LEN];
    hi_mapi_size  font_size;
    td_u32  bg_color;
} hi_mapi_str_content;

/** @} */ /** <!-- ==== COMM End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_COMM_DEFINE_H__ */

