/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MW_LOG_H__
#define __HI_MW_LOG_H__
#include <stdio.h>
#include "hi_mw_type.h"
#include "hi_log.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

typedef HI_LOG_LEVEL_E hi_log_level;

#ifndef HI_LOG_LEVEL_VERBOSE
#define HI_LOG_LEVEL_VERBOSE HI_LOG_LEVEL_DEBUG
#endif
#ifndef HI_LOG_LEVEL_ERR
#define HI_LOG_LEVEL_ERR     HI_LOG_LEVEL_ERROR
#endif
static inline td_s32 hi_log_set_enabled_level(hi_log_level level)
{
    return HI_LOG_SetEnabledLevel((HI_LOG_LEVEL_E)level);
}

#ifdef LOG_ENABLE

#define hi_log_printf_info(mod_name, level, func, line, fmt, ...) \
    do { \
        (void)(func); \
        (void)(line); \
        switch (level) { \
            case HI_LOG_LEVEL_FATAL: \
            case HI_LOG_LEVEL_ERROR: \
            case HI_LOG_LEVEL_WARN: \
            case HI_LOG_LEVEL_INFO: \
            case HI_LOG_LEVEL_DEBUG: \
                HI_LOG_PrintfInfo((const char *)mod_name, (HI_LOG_LEVEL_E)level, func, line, fmt, ##__VA_ARGS__); \
                break; \
            default: \
                HI_LOG_PrintfInfo((const char *)mod_name, HI_LOG_LEVEL_DEBUG, func, line, fmt, ##__VA_ARGS__); \
                break; \
        } \
    } while (0)

#define hi_log_printf(mod_name, level, fmt, ...) \
    do { \
        switch (level) { \
            case HI_LOG_LEVEL_FATAL: \
                HI_LOGF(mod_name, fmt, ##__VA_ARGS__); \
                break; \
            case HI_LOG_LEVEL_ERROR: \
                HI_LOGE(mod_name, fmt, ##__VA_ARGS__); \
                break; \
            case HI_LOG_LEVEL_WARN: \
                HI_LOGW(mod_name, fmt, ##__VA_ARGS__); \
                break; \
            case HI_LOG_LEVEL_INFO: \
                HI_LOGI(mod_name, fmt, ##__VA_ARGS__); \
                break; \
            case HI_LOG_LEVEL_DEBUG: \
            default: \
                HI_LOGD(mod_name, fmt, ##__VA_ARGS__); \
                break; \
        } \
    } while (0)

#define HI_LOG_FATAL(mode, ...)  \
    do { \
        HI_LOGF(mode, __VA_ARGS__); \
    } while (0)

#define HI_LOG_ERR(mode, ...)  \
    do { \
        HI_LOGE(mode, __VA_ARGS__); \
    } while (0)

#define HI_LOG_WARN(mode, ...)  \
    do { \
        HI_LOGW(mode, __VA_ARGS__); \
    } while (0)

#define HI_LOG_INFO(mode, ...)  \
    do { \
        HI_LOGI(mode, __VA_ARGS__); \
    } while (0)

#define HI_LOG_DEBUG(mode, ...)  \
    do { \
        HI_LOGD(mode, __VA_ARGS__); \
    } while (0)

#else

#define hi_log_printf_info(mod_name, level, func, line, fmt, ...) ((void)0)
#define hi_log_printf(mod_name, level, fmt, ...) ((void)0)
#define HI_LOG_FATAL(mode, ...) ((void)0)
#define HI_LOG_ERR(mode, ...) ((void)0)
#define HI_LOG_WARN(mode, ...) ((void)0)
#define HI_LOG_INFO(mode, ...) ((void)0)
#define HI_LOG_DEBUG(mode, ...) ((void)0)

#endif

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MW_LOG_H__ */
