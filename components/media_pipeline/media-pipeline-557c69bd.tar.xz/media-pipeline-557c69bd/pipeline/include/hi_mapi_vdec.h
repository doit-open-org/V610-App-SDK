/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VDEC_H__
#define __HI_MAPI_VDEC_H__

#include "hi_mapi_vdec_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/**
 * @brief get default video decode attribute based on base attribute
 * @param[in] baseAttr const hi_mapi_vdec_base_attr *: pointer of base attribute used to derive vdec attribute
 * @param[out] vdecAttr hi_mapi_vdec_attr *: pointer of vdec attribute to be filled
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_get_default_attr(const hi_mapi_vdec_base_attr *base_attr, hi_mapi_vdec_attr *vdec_attr);

/**
 * @brief create video decode instance
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[in] vdecAttr hi_mapi_vdec_attr: the attribute of VDEC instance
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_init(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr);

/**
 * @brief destroy video decode instance
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_deinit(td_handle vdec_hdl);

/**
 * @brief start video encode instance
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_start(td_handle vdec_hdl);

/**
 * @brief stop video encode instance
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_stop(td_handle vdec_hdl);

/**
 * @brief stop video encode instance
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[out] status hi_mapi_vdec_status: status of VDEC
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_query_status(td_handle vdec_hdl, hi_mapi_vdec_status *status);

/**
 * @brief set video encode attribute
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[in] vdecAttr hi_mapi_vdec_attr: the attribute of VDEC instance
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_set_attr(td_handle vdec_hdl, const hi_mapi_vdec_attr *vdec_attr);

/**
 * @brief get video encode attribute
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[out] vdecAttr hi_mapi_vdec_attr: the attribute of VDEC instance
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_get_attr(td_handle vdec_hdl, hi_mapi_vdec_attr *vdec_attr);

/**
 * @brief set video encode expand attribute
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[in] vdecAttrEx hi_mapi_vdec_attr: the attribute of VDEC instance
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_set_param(td_handle vdec_hdl, const hi_mapi_vdec_param *vdec_param);

/**
 * @brief get video encode expand attribute
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[in] vdecAttr hi_mapi_vdec_attr: the attribute of VDEC instance
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_get_param(td_handle vdec_hdl, hi_mapi_vdec_param *vdec_param);

/**
 * @brief get video encode expand attribute
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[in] stream hi_mapi_vdec_stream: the info of VDEC stream
 * @param[in] timeout td_s32: the timeout of VDEC send stream
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_send_stream(td_handle vdec_hdl, const hi_mapi_vdec_stream *stream, td_s32 timeout);

/**
 * @brief get video encode expand attribute
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[out] frameData HI_MAPI_FRAME_DATA_S: the info of VDEC frame
 * @param[in] timeOut td_u32: the timeout of VDEC get frame
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_get_frame(td_handle vdec_hdl, hi_mapi_frame_data *frame_data, td_u32 timeout);

/**
 * @brief get video encode expand attribute
 * @param[in] vdecHdl td_handle: handle of VDEC
 * @param[in] frameData HI_MAPI_FRAME_DATA_S: the info of VDEC frame
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vdec_release_frame(td_handle vdec_hdl, const hi_mapi_frame_data *frame_data);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
