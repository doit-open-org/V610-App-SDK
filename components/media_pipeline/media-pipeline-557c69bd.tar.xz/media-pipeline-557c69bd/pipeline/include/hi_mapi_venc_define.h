/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OT_VENC_DEFINE_H
#define OT_VENC_DEFINE_H

#include "hi_mapi_comm_define.h"
#include "hi_mapi_venc_adapt_define.h"
#include "hi_mapi_errno.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/* pack number of video encoder */
#define HI_MAPI_VENC_PACK_NUM (2)

/* max pack count of video encoder frame */
#define HI_MAPI_VENC_MAX_FRAME_PACKCOUNT (6)

/* limitless count of video encoder frame */
#define HI_MAPI_VENC_LIMITLESS_FRAME_COUNT (-1)

/* max count of video encoder frame */
#define HI_MAPI_VENC_MAX_FRAME_RATE (240)

/* error code for venc */
#define HI_MAPI_VENC_EHANDLE_ILLEGAL \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)
#define HI_MAPI_VENC_EILLEGAL_PARAM \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
#define HI_MAPI_VENC_EEXIST      HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_EXIST)
#define HI_MAPI_VENC_EUNEXIST    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_UNEXIST)
#define HI_MAPI_VENC_ENULL_PTR   HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
#define HI_MAPI_VENC_ENOT_PERM   HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
#define HI_MAPI_VENC_ENOMEM      HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)
#define HI_MAPI_VENC_ENOT_INITED HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
#define HI_MAPI_VENC_EBUF_EMPTY  HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUF_EMPTY)
#define HI_MAPI_VENC_EBUSY       HI_MAPI_DEF_ERR(HI_MAPI_MOD_VENC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUSY)

/* the attribute of H264 video encoder */
typedef struct {
    // to be extend
} hi_mapi_venc_h264_attr;

/* the attribute of H265 video encoder */
typedef struct {
    // to be extend
} hi_mapi_venc_h265_attr;

/* the attribute of SVAC3 video encoder */
typedef struct {
    // to be extend
} hi_mapi_venc_svac3_attr;

/* the attribute of JPEG encoder */
typedef struct {
    td_bool                enable_dcf;           /* <support dcf */
    hi_mapi_venc_mpf_config mpf_attr;             /* <config of mpf */
    td_u32 qfactor;                             /* <[1, 99] */
    hi_mapi_venc_pic_receive_mode receive_mode;    /* <onfig the receive mode */
    hi_mapi_venc_jpeg_encode_mode jpeg_encode_mode; /* <Jpeg snap mode */
} hi_mapi_venc_jpeg_attr;

/* the attribute of JPEG encoder */
typedef struct {
} hi_mapi_venc_mjpeg_attr;

/* the scene mode */
typedef enum {
    HI_MAPI_VENC_SCENE_MODE_NORMAL, /* <normal scene mode */
    HI_MAPI_VENC_SCENE_MODE_DV,     /* <dv scene mode */
    HI_MAPI_VENC_SCENE_MODE_CAR,    /* <car scene mode */
    HI_MAPI_VENC_SCENE_MODE_BUTT,
} hi_mapi_venc_scene_mode;

/* the attribute of encoder type */
typedef struct {
    hi_mapi_payload_type type;             /* <the type of payload */
    td_u32 width;                         /* <width of a picture to be encoded, in pixel */
    td_u32 height;                        /* <height of a picture to be encoded, in pixel */
    td_u32 buf_size;                       /* <stream buffer size */
    td_u32 profile;                       /* <H.264:   0: baseline; 1:MP; 2:HP;
                                                 H.265:   0:MP;
                                                 Jpege/MJpege:   0:Baseline */
    hi_mapi_venc_scene_mode scene_mode;     /* <scene mode */
    td_bool by_frame;                      /* mode: TD_FALSE:slice TD_TRUE:frame */
    union {
        hi_mapi_venc_h264_attr h264e_attr;  /* <attributes of H264E */
        hi_mapi_venc_h265_attr h265e_attr;  /* <attributes of H265E */
        hi_mapi_venc_svac3_attr svac3e_attr;  /* <attributes of SVAC3E */
        hi_mapi_venc_jpeg_attr jpeg_attr;  /* <attributes of jpeg  */
        hi_mapi_venc_mjpeg_attr mjpeg_attr; /* <attributes of Mjpeg */
    };
} hi_mapi_venc_payload_type_attr;

/* the rate control mode */
typedef enum {
    HI_MAPI_VENC_RC_MODE_CBR,  /* <constant bit rate */
    HI_MAPI_VENC_RC_MODE_VBR,  /* <variable bit rate */
    HI_MAPI_VENC_RC_MODE_QVBR, /* <quality variable bit rate */
    HI_MAPI_VENC_RC_MODE_CVBR, /* <constrained variable bit rate */
    HI_MAPI_VENC_RC_MODE_AVBR, /* <Adaptive variable bit rate */
    HI_MAPI_VENC_RC_MODE_BUTT,
} hi_mapi_venc_rc_mode;


/* the attribute of rate control */
typedef struct {
    hi_mapi_venc_rc_mode rc_mode; /* <the type of rc */
    union {
        hi_mapi_venc_cbr_attr cbr_attr;   /* <attributes of cbr */
        hi_mapi_venc_vbr_attr vbr_attr;   /* <attributes of vbr */
        hi_mapi_venc_qvbr_attr qvbr_attr; /* <attributes of qvbr */
        hi_mapi_venc_cvbr_attr cvbr_attr; /* <attributes of cvbr */
        hi_mapi_venc_avbr_attr avbr_attr; /* <attributes of avbr */
    };
} hi_mapi_venc_rc_attr;

/* the attribute of video encode */
typedef struct {
    hi_mapi_payload_type type;      /* <the type of payload */
    td_u32 width;                  /* <width of a picture to be encoded, in pixel */
    td_u32 height;                 /* <height of a picture to be encoded, in pixel */
    td_u32 src_frame_rate;           /* Range:[1, 240]; the input frame rate of the venc chnnel */
    td_u32 dst_frame_rate;           /* Range:[0.015625, 240]; the target frame rate of the venc chnnel,
                                      can not be larger than u32SrcFrameRate */
    td_u32 bit_rate;
    td_u32 qfactor;               /* <Range:[1, 99], just jpeg valid */
} hi_mapi_venc_base_attr;

/* the attribute of video encode */
typedef struct {
    hi_mapi_venc_payload_type_attr payload_type_attr; /* <the attribute of video encoder type */
    hi_mapi_venc_rc_attr rc_attr;              /* <the attribute of rate  ctrl */
} hi_mapi_venc_attr;

/* the data type of video encode */
typedef struct {
    hi_mapi_payload_type payload_type;            /* <H.264/H.265/JPEG/MJPEG */
    union {
        hi_mapi_venc_h264e_nalu_type h264e_type;   /* <H264E NALU types */
        hi_mapi_venc_h265e_nalu_type h265e_type;   /* <H265E NALU types */
        hi_mapi_venc_svac3e_nalu_type svac3e_type;   /* <SVAC3E NALU types */
        hi_mapi_venc_jpeg_pack_type  jpeg_type;    /* <JPEGE PACK types */
    };
} hi_mapi_venc_data_type;

/* the data pack of video encode */
typedef struct {
    td_u64 phy_addr[HI_MAPI_VENC_PACK_NUM]; /* <the physics address of stream */
    td_u8 *vir_addr[HI_MAPI_VENC_PACK_NUM];    /* <the virtual address of stream */
    td_u32 len[HI_MAPI_VENC_PACK_NUM];     /* <the length of stream */
    td_u64 time_stamp;                             /* <time stamp */
    hi_mapi_venc_data_type data_type;       /* <the type of stream */
    td_u32 offset;                          /* <the offset between the Valid data and the start address */
} hi_mapi_venc_data_pack_attr;

/* the stream information of video encode */
typedef struct {
    hi_mapi_venc_ref_type ref_type; /* <Type of encoded frames in advanced frame skipping reference mode */
    td_u32 start_qp;            /* <the start Qp of encoded frames */
} hi_mapi_venc_stream_info;

/* the data of video encode */
typedef struct {
    hi_mapi_venc_data_pack_attr data_pack[HI_MAPI_VENC_MAX_FRAME_PACKCOUNT]; /* <stream pack attribute */
    td_u32 pack_count;                                                     /* <the pack number of one frame stream */
    td_u32 seq;                                                           /* <the list number of stream */
    td_bool end_of_stream;                                                  /* <frame end flag */
    hi_mapi_venc_stream_info stream_info;                                   /* <stream info attribute */
} hi_mapi_venc_data_attr;

typedef td_s32 (*hi_mapi_venc_proc_data)(td_handle venc_hdl, hi_mapi_venc_data_attr *stream_data,
    td_void *private_data);

typedef struct {
    hi_mapi_venc_proc_data proc_data_cb;
    td_void *private_data;
} hi_mapi_venc_call_back;

/* video encoder extend attribute command */
typedef enum {
    HI_MAPI_VENC_CMD_H264_RC_ATTR_EX,    /* hi_mapi_venc_rc_param */
    HI_MAPI_VENC_CMD_H265_RC_ATTR_EX,    /* hi_mapi_venc_rc_param */
    HI_MAPI_VENC_CMD_MJPEG_RC_ATTR_EX,   /* hi_mapi_venc_rc_param */
    HI_MAPI_VENC_CMD_SVAC2_RC_ATTR_EX,   /* hi_mapi_venc_rc_param */
    HI_MAPI_VENC_CMD_GOP_MODE,            /* hi_mapi_venc_gop_attr */
    HI_MAPI_VENC_CMD_INTRA_REFRESH,       /* hi_mapi_venc_intra_refresh */
    HI_MAPI_VENC_CMD_FRAME_RATE,          /* hi_mapi_frame_rate_ctrl */
    HI_MAPI_VENC_CMD_HIERARCHICAL_QP,     /* hi_mapi_venc_hierarchical_qp */
    HI_MAPI_VENC_CMD_FRAMELOST_STRATEGY,  /* td_bool */
    HI_MAPI_VENC_CMD_BUTT
} hi_mapi_venc_cmd;

/* the gop mode */
typedef enum {
    HI_MAPI_VENC_GOPMODE_NORMALP = 0, /* <NORMALP */
    HI_MAPI_VENC_GOPMODE_DUALP = 1,   /* <DUALP */
    HI_MAPI_VENC_GOPMODE_SMARTP = 2,  /* <SMARTP */
    HI_MAPI_VENC_GOPMODE_BIPREDB = 3, /* <BIPREDB */
    HI_MAPI_VENC_GOPMODE_BUTT,
} hi_mapi_venc_gop_mode;

/* the attribute of the gop */
typedef struct {
    hi_mapi_venc_gop_mode gop_mode;        /* <Encoding GOP type */
    union {
        hi_mapi_venc_normalp_gop normalp; /* <the attribute of the normalp */
        hi_mapi_venc_dualp_gop   dualp;   /* <the attribute of the dualp */
        hi_mapi_venc_smartp_gop  smartp;  /* <the attribute of the smartp */
        hi_mapi_venc_bipredb_gop bipredb; /* <the attribute of the bipredb */
    };
} hi_mapi_venc_gop_attr;

/* video encoder static config command, must be set before channel init */
typedef enum {
    HI_MAPI_VENC_CFG_RCN_REF_SHARE,      /* hi_mapi_venc_rcn_ref_share_attr */
    HI_MAPI_VENC_CFG_H264_MINI_BUF_MODE, /* hi_mapi_venc_mini_buf_mode_attr */
    HI_MAPI_VENC_CFG_H265_MINI_BUF_MODE, /* hi_mapi_venc_mini_buf_mode_attr */
    HI_MAPI_VENC_CFG_JPEG_MINI_BUF_MODE, /* hi_mapi_venc_mini_buf_mode_attr, also covers MJPEG (shared mod param) */
    HI_MAPI_VENC_CFG_CMD_BUTT
} hi_mapi_venc_cfg_cmd;

/* the attribute of rcn ref share buffer */
typedef struct {
    td_bool ref_rcn_share_en; /* <reconstruction and reference frame share buffer enable */
} hi_mapi_venc_rcn_ref_share_attr;

/* the attribute of mini stream-buffer mode. effective per protocol (H264/H265/JPEG), module-global. */
typedef struct {
    td_u32 mini_buf_mode; /* <mini stream-buffer mode: 0 disable, 1 enable (maps to SDK ot_venc_*_mod_param.mini_buf_mode) */
} hi_mapi_venc_mini_buf_mode_attr;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef OT_VENC_DEFINE_H */
