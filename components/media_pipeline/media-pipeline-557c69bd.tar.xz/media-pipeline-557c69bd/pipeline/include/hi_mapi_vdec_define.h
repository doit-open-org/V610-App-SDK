/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VDEC_DEFINE_H__
#define __HI_MAPI_VDEC_DEFINE_H__

#include "hi_mapi_errno.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_vdec_adapt_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/* error code for venc */
#define HI_MAPI_VDEC_EHANDLE_ILLEGAL \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)
#define HI_MAPI_VDEC_EILLEGAL_PARAM \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
#define HI_MAPI_VDEC_EEXIST        HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_EXIST)
#define HI_MAPI_VDEC_EUNEXIST      HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_UNEXIST)
#define HI_MAPI_VDEC_ENULL_PTR     HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
#define HI_MAPI_VDEC_ENOT_PERM     HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
#define HI_MAPI_VDEC_ENOMEM        HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)
#define HI_MAPI_VDEC_ENOT_INITED   HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
#define HI_MAPI_VDEC_EBUF_EMPTY    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUF_EMPTY)
#define HI_MAPI_VDEC_EBUSY         HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUSY)
#define HI_MAPI_VDEC_EOPERATE_FAIL HI_MAPI_DEF_ERR(HI_MAPI_MOD_VDEC, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_OPERATE_FAIL)

typedef enum {
    HI_MAPI_VDEC_MODE_COMMON = 0, /* get frame by massage */
    HI_MAPI_VDEC_MODE_FAST,       /* get frame by datafifo  */
    HI_MAPI_VDEC_MODE_BUTT
} hi_mapi_vdec_get_frame_mode;

typedef struct {
    hi_mapi_payload_type type;    /* video type to be decoded   */
    td_u32 width;                /* max pic width */
    td_u32 height;               /* max pic height */
} hi_mapi_vdec_base_attr;

typedef struct {
    hi_mapi_payload_type type;       /* video type to be decoded   */
    hi_mapi_vdec_video_mode mode;    /* send by stream or by frame */
    hi_mapi_vdec_get_frame_mode get_frame_mode;
    td_u32 pic_width;                /* max pic width */
    td_u32 pic_height;               /* max pic height */
    td_u32 stream_buf_size;           /* stream buffer size(Byte) */
    td_u32 frame_buf_size;            /* frame buffer size(Byte) */
    td_u32 frame_buf_cnt;
    td_bool user_vb_flag;
    union {
        hi_mapi_vdec_video_attr vdec_video_attr; /* structure with video ( h264/h265) */
    };
} hi_mapi_vdec_attr;

typedef struct {
    hi_mapi_payload_type type; /* video type to be decoded */
    td_u32 left_stream_bytes; /* left stream bytes waiting for decode */
    td_u32 left_stream_frames; /* left frames waiting for decode,only valid for VIDEO_MODE_FRAME */
    td_u32 left_pics; /* pics waiting for output */
    td_bool start_recv_stream; /* had started recv stream? */
    td_u32 recv_stream_frames; /* how many frames of stream has been received. valid when send by frame. */
    td_u32 decode_stream_frames; /* how many frames of stream has been decoded. valid when send by frame. */
    td_u32 width; /* the width of the currently decoded stream */
    td_u32 height; /* the height of the currently decoded stream */
} hi_mapi_vdec_status;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
