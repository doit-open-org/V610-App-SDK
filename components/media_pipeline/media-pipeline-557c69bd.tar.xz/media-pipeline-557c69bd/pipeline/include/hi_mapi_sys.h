/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_SYS_H__
#define __HI_MAPI_SYS_H__

#include "hi_mapi_errno.h"
#include "hi_mapi_comm_define.h"

#define HI_MAPI_SYS_EILLEGAL_PARAM HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
#define HI_MAPI_SYS_ENULL_PTR      HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
#define HI_MAPI_SYS_ENOT_PERM      HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
#define HI_MAPI_SYS_ENOTREADY      HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
#define HI_MAPI_SYS_EBUSY          HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUSY)
#define HI_MAPI_SYS_ENOMEM         HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)
#define HI_MAPI_SYS_ENO_REG_MSG \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_SYS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NO_REGISTER_MSG)

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/** \addtogroup     COMM */
/** @{ */ /** <!-- [COMM] */

/**
 * @brief init sys,including message init for communicating between HuaweiLite and Linux.
 *        It must be called by both HuaweiLite's app and Linux's app.It must be called the very first.
 * @return 0  init sys success.
 * @return non 0  init sys fail.
 */
td_s32 hi_mapi_sys_init(td_void);

/**
 * @brief deinit sys.
 * @return 0  deinit sys success.
 * @return non 0  deinit sys fail.
 */
td_s32 hi_mapi_sys_deinit(td_void);


/**
 * @brief get default media attribute based on base attribute.
 * @param[in] baseAttr const hi_mapi_sys_base_attr *:pointer of base attribute used to derive media attribute.
 * @param[out] mediaAttr hi_mapi_sys_media_attr *:pointer of media attribute to be filled.
 * @return 0  get default media attribute success.
 * @return non 0  get default media attribute fail.
 */
td_s32 hi_mapi_sys_get_default_media_attr(const hi_mapi_sys_base_attr *base_attr, hi_mapi_sys_media_attr *media_attr);

/**
 * @brief init media.
 *        It must be called before other media MAPI,
 *        such as HI_MAPI_VCap_XXX,HI_MAPI_VProc_XXX,HI_MAPI_VEnc_XXX,HI_MAPI_Vo_XXX.etc.
 * @param[in] mediaAttr hi_mapi_sys_media_attr *:pointer of Media init attr.
 * @return 0  init media success.
 * @return non 0  init media fail.
 */
td_s32 hi_mapi_sys_init_media(const hi_mapi_sys_media_attr *media_attr);

/**
 * @brief deinit media.
 * @return 0  deinit media success.
 * @return non 0  deinit media fail.
 */
td_s32 hi_mapi_sys_deinit_media(td_void);

/**
 * @brief allocate buffer from MMZ.
 * @param[out] phy_addr td_u64*:The physical address of buffer.
 * @param[out] virtAddr td_void **:The virtual address of buffer.
 * @param[in] buf_len td_u32:The length of buffer.
 * @param[in] bufName td_char*:The name of buffer.
 * @param[in] is_cache td_bool:Whether the cache buffer is allocated.
 * @return 0  allocate buffer from MMZ successful.
 * @return non 0  allocate buffer from MMZ fail.
 */
td_s32 hi_mapi_sys_alloc_buffer(td_u64 *phy_addr, td_void **virt_addr, td_u32 buf_len, const td_char *buf_name,
    td_bool is_cache);

/**
 * @brief free buffer from MMZ.
 * @param[in] phy_addr td_u64:The physical address of buffer.
 * @param[in] virtAddr td_void *:The virtual address of buffer.
 * @param[in] buf_len td_u32:The length of buffer.
 * @return 0  free buffer from MMZ. successful.
 * @return non 0  free buffer from MMZ. fail.
 */
td_s32 hi_mapi_sys_free_buffer(td_u64 phy_addr, td_void *virt_addr, td_u32 buf_len);

/**
 * @brief Flush cache buffer.
 * @param[in] phy_addr td_u64:The physical address of buffer.
 * @param[out] virtAddr td_void *:The virtual address of buffer.
 * @param[in] buf_len td_u32:The length of buffer.
 * @return 0  Flush buffer successful.
 * @return non 0  Flush buffer fail.
 */
td_s32 hi_mapi_sys_flush_cache(td_u64 phy_addr, td_void *virt_addr, td_u32 buf_len);

/**
 * @brief get vb block from vb.
 * @param[in] poolHdl td_handle *:The block from vb's handle.
 * @param[out] phy_addr td_u64*:The physical address of block.
 * @param[out] virtAddr td_void *:The virtual address of block.
 * @param[in] blk_size td_u64:The length of block.
 * @param[in] mmz_name const td_char *:The name of the DDR where the pool is located
 * @return 0  get buffer successful.
 * @return non 0  get buffer fail.
 */
td_s32 hi_mapi_sys_get_video_block(td_handle *pool_hdl, td_u64 *phy_addr, td_void **vir_addr, td_u64 blk_size,
    const td_char *mmz_name);

/**
 * @brief Release a video block got by hi_mapi_sys_get_video_block.
 *        The block size is looked up from an internal record (keyed by phy_addr) that was
 *        saved at get time, so the caller no longer passes blk_size. phy_addr must be one
 *        that is currently held (got but not yet released), and vir_addr must match the
 *        recorded one; otherwise HI_MAPI_SYS_EILLEGAL_PARAM is returned.
 * @param[in] phy_addr td_u64:The physical address of block.
 * @param[in] virtAddr td_void *:The virtual address of block.
 * @return 0  release buffer successful.
 * @return non 0  release buffer fail.
 */
td_s32 hi_mapi_sys_release_video_block(td_u64 phy_addr, td_void *vir_addr);

/**
 * @brief Register font mod callback.
 * @param[in] font_attr hi_mapi_sys_font_attr:The font mod attribute.
 * @return 0  release buffer successful.
 * @return non 0  release buffer fail.
 */
td_s32 hi_mapi_sys_register_font_attr(const hi_mapi_sys_font_attr *font_attr);

/**
 * @brief Bind a source channel to a destination channel.
 *        Maintains an internal bind table; a duplicate (src,dst) returns TD_SUCCESS
 *        without dispatching to the underlying SDK.
 * @param[in] src_chn const hi_mapi_mpp_chn *: source channel descriptor.
 * @param[in] dst_chn const hi_mapi_mpp_chn *: destination channel descriptor.
 * @return 0  bind success (or already bound).
 * @return non 0  bind fail.
 */
td_s32 hi_mapi_sys_bind(const hi_mapi_mpp_chn *src_chn, const hi_mapi_mpp_chn *dst_chn);

/**
 * @brief Unbind a previously bound (src,dst) pair.
 *        If the pair is not present in the internal bind table, returns TD_SUCCESS
 *        without dispatching to the underlying SDK.
 * @param[in] src_chn const hi_mapi_mpp_chn *: source channel descriptor.
 * @param[in] dst_chn const hi_mapi_mpp_chn *: destination channel descriptor.
 * @return 0  unbind success (or not bound).
 * @return non 0  unbind fail.
 */
td_s32 hi_mapi_sys_unbind(const hi_mapi_mpp_chn *src_chn, const hi_mapi_mpp_chn *dst_chn);

/** @} */ /** <!-- ==== COMM End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_SYS_H__ */
