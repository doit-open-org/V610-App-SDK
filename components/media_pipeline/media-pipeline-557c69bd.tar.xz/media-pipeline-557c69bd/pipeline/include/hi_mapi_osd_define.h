/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_OSD_DEFINE_H__
#define __HI_MAPI_OSD_DEFINE_H__

#include "hi_mapi_osd_adapt_define.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_errno.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */


/* error code for osd */
#define HI_MAPI_OSD_EHANDLE_ILLEGAL \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_OSD, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)
#define HI_MAPI_OSD_EILLEGAL_PARAM \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_OSD, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
#define HI_MAPI_OSD_ENULL_PTR   HI_MAPI_DEF_ERR(HI_MAPI_MOD_OSD, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
#define HI_MAPI_OSD_ENOT_PERM   HI_MAPI_DEF_ERR(HI_MAPI_MOD_OSD, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
#define HI_MAPI_OSD_ENOMEM      HI_MAPI_DEF_ERR(HI_MAPI_MOD_OSD, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)
#define HI_MAPI_OSD_ENOT_INITED HI_MAPI_DEF_ERR(HI_MAPI_MOD_OSD, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
#define HI_MAPI_OSD_ENOFONT HI_MAPI_DEF_ERR(HI_MAPI_MOD_OSD, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NO_FONT)

/** struct define */
/** OSD Type Enum */
typedef enum {
    HI_MAPI_OSD_TYPE_TIME = 0,
    HI_MAPI_OSD_TYPE_STRING,
    HI_MAPI_OSD_TYPE_BITMAP,
    HI_MAPI_OSD_TYPE_CIRCLE,
    HI_MAPI_OSD_TYPE_BUTT
} hi_mapi_osd_type;

/** OSD Time Format Enum */
typedef enum {
    HI_MAPI_OSD_TIMEFMT_YMD24H = 0, /* eg. 2017-03-10 23:00:59 */
    HI_MAPI_OSD_TIMEFMT_BUTT
} hi_mapi_osd_time_fmt;

/** OSD Binded Module enum */
typedef enum {
    HI_MAPI_OSD_BINDMOD_VCAP = 0,
    HI_MAPI_OSD_BINDMOD_VPSS,
    HI_MAPI_OSD_BINDMOD_STITCH,
    HI_MAPI_OSD_BINDMOD_VENC,
    HI_MAPI_OSD_BINDMOD_DISP,
    HI_MAPI_OSD_BINDMOD_BUTT
} hi_mapi_osd_bind_mod;

typedef enum {
    HI_MAPI_OSD_COORDINATE_RATIO_COOR = 0,   /* Ratio coordinate. */
    HI_MAPI_OSD_COORDINATE_ABS_COOR          /* Absolute coordinate. */
} hi_mapi_osd_coordinate_mod;

/** OSD Display Attribute */
typedef struct {
    td_bool show;
    hi_mapi_osd_bind_mod binded_mod; /* OSD Binded Module: Static  */
    td_handle mod_hdl; /* Binded Module  Handle: Static eg.VcapPipeHdl VpssHdl  StitchHdl     DispHdl */
    td_handle chn_hdl; /* Binded Channel Handle: Static eg.PipeChnHdl  VPortHdl StitchPortHdl WndHdl  VencHdl */
    td_u32  fg_alpha;
    td_u32  bg_alpha;
    hi_mapi_osd_coordinate_mod coordinate_mod;   /* Coordinate mode of the osd start Position. */
    hi_mapi_point start_pos; /* OSD Start Position */
    hi_mapi_osd_attach_dest attach_dest; /* only for venc */
    td_u32 batch_id;
} hi_mapi_osd_disp_attr;

/** osd pixel format enum */
typedef enum {
    HI_MAPI_OSD_PIXEL_FMT_RGB1555 = 0,
    HI_MAPI_OSD_PIXEL_FMT_BUTT
} hi_mapi_osd_pixel_fmt;

typedef struct {
    hi_mapi_osd_time_fmt time_fmt;
    hi_mapi_size  font_size;
    td_u32  bg_color;
} hi_mapi_osd_time_content;

typedef struct {
    td_u32             width;
    td_u32             height;
} hi_mapi_osd_circle_content;

typedef struct {
    hi_mapi_osd_type type;
    td_u32  color;
    union {
        hi_mapi_osd_time_content time_content;
        hi_mapi_str_content str_content;
        hi_mapi_osd_circle_content circle_content;
        hi_mapi_osd_bitmap bitmap_content;
    };
} hi_mapi_osd_content;

/* OSD Parameter */
typedef struct  {
    td_u32 disp_num; /* Binded Display Number for this OSD */
    hi_mapi_osd_disp_attr disp_attr[HI_MAPI_OSD_MAX_DISP_CNT];
    hi_mapi_osd_content osd_content;
} hi_mapi_osd_attr;


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_OSD_DEFINE_H__ */
