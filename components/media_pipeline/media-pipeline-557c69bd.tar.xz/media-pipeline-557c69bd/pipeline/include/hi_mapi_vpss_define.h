/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VPSS_DEFINE_H__
#define __HI_MAPI_VPSS_DEFINE_H__

#include "hi_mapi_comm_adapt_define.h"
#include "hi_mapi_vpss_adapt_define.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_errno.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define HI_MAPI_VPSS_ENULL_PTR      HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
#define HI_MAPI_VPSS_ENOTREADY \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_SYS_NOTREADY)
#define HI_MAPI_VPSS_EINVALID_DEVID \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_DEVID)
#define HI_MAPI_VPSS_EINVALID_CHNID \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_CHNID)
#define HI_MAPI_VPSS_EEXIST         HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_EXIST)
#define HI_MAPI_VPSS_EUNEXIST       HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_UNEXIST)
#define HI_MAPI_VPSS_ENOT_SUPPORT \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_SUPPORT)
#define HI_MAPI_VPSS_ENOT_PERM      HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
#define HI_MAPI_VPSS_ENOMEM         HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)
#define HI_MAPI_VPSS_ENOBUF         HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOBUF)
#define HI_MAPI_VPSS_EILLEGAL_PARAM \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
#define HI_MAPI_VPSS_EBUSY          HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUSY)
#define HI_MAPI_VPSS_EBUF_EMPTY     HI_MAPI_DEF_ERR(HI_MAPI_MOD_VPSS, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_BUF_EMPTY)

typedef struct {
    td_u32 max_width;
    td_u32 max_height;
    hi_mapi_frame_rate_ctrl frame_rate_ctrl;
    hi_mapi_pixel_format pixel_format;
    td_bool is_nr_en;
} hi_mapi_vpss_grp_attr;

typedef struct {
    td_u32 width;
    td_u32 height;
    td_bool support_buffer_share;
    hi_mapi_frame_rate_ctrl frame_rate_ctrl;
    hi_mapi_video_format video_format;
    hi_mapi_pixel_format pixel_format;
    hi_mapi_compress_mode compress_mode;
    hi_mapi_aspect_ratio_attr aspect_ratio;
    hi_mapi_vpss_low_delay_info low_delay_info;
    td_u32 vb_pool_blk_cnt;
} hi_mapi_vpss_chn_attr;

typedef struct {
    td_handle bind_chn_hdl;
    td_u32 width;
    td_u32 height;
    hi_mapi_frame_rate_ctrl frame_rate_ctrl;
    hi_mapi_video_format video_format;
    hi_mapi_pixel_format pixel_format;
    hi_mapi_compress_mode compress_mode;
    hi_mapi_vpss_low_delay_info low_delay_info;
    td_u32 vb_pool_blk_cnt;
} hi_mapi_vpss_ext_chn_attr;

/** vpss cmd list */
typedef enum {
    HI_MAPI_VPSS_CMD_GRP_CROP,
    HI_MAPI_VPSS_CMD_CHN_MIRROR,
    HI_MAPI_VPSS_CMD_CHN_FLIP,
    HI_MAPI_VPSS_CMD_CHN_ROTATE,
    HI_MAPI_VPSS_CMD_CHN_LDC,
    HI_MAPI_VPSS_CMD_CHN_LDCV2,
    HI_MAPI_VPSS_CMD_CHN_LDCV3,
    HI_MAPI_VPSS_CMD_CHN_LDCV4,
    HI_MAPI_VPSS_CMD_CHN_GDC,
    HI_MAPI_VPSS_CMD_CHN_CROP,
    HI_MAPI_VPSS_CMD_CHN_DEPTH,
    HI_MAPI_VPSS_CMD_BUTT
} hi_mapi_vpss_cmd;

/** vpss static config cmd list (set before start_chn) */
typedef enum {
    HI_MAPI_VPSS_CONFIG_CMD_CHN_BUF_WRAP,  /* <wrap(卷绕), phy chn0; cmd_attr:hi_mapi_vpss_buf_wrap_attr */
    HI_MAPI_VPSS_CONFIG_CMD_BUTT
} hi_mapi_vpss_config_cmd;

/* buffer wrap: user configures only 'enable'; buf_line/buf_size are computed internally */
typedef struct {
    td_bool enable;
} hi_mapi_vpss_buf_wrap_attr;

/** VPSS_CMD_SetChnMirror,VPSS_CMD_GetChnMirror */
typedef struct {
    td_bool enable;
} hi_mapi_vpss_mirror_attr;

/** VPSS_CMD_SetChnFlip,VPSS_CMD_GetChnFlip */
typedef struct {
    td_bool enable;
} hi_mapi_vpss_flip_attr;

/** HI_MAPI_VPSS_CMD_CHN_DEPTH: set/get the depth of chn(chn) */
typedef struct {
    td_u32 depth;
} hi_mapi_vpss_depth_attr;

typedef struct {
    td_bool enable;
    td_u32 depth;
} hi_mapi_vpss_dump_yuv_attr;

/** @} */ /** <!-- ==== VPSS End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_VPSS_DEFINE_H__ */
