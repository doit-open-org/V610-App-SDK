/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_OSD_H__
#define __HI_MAPI_OSD_H__

#include "hi_mapi_osd_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     OSD */
/** @{ */  /** <!-- [OSD] */

/** function interface */
/**
 * @brief init osd.
 * @return 0 init osd success.
 * @return Non 0 init osd failed.
 */
td_s32 hi_mapi_osd_init(td_void);

/**
 * @brief deinit osd.
 * @return 0 deinit osd success.
 * @return Non 0 deinit osd failed.
 */
td_s32 hi_mapi_osd_deinit(td_void);

/**
 * @brief set osd attr.
 * @param[in] osdIdx td_u32: osd index.
 * @param[in] osdAttr hi_mapi_osd_attr *: osd attr.
 * @return 0 set osd attr success.
 * @return Non 0 set osd attr failed.
 */
td_s32 hi_mapi_osd_set_attr(td_u32 osd_idx, const hi_mapi_osd_attr *osd_attr);

/**
 * @brief get osd attr.
 * @param[in] osdIdx td_u32: osd index.
 * @param[out] osdAttr hi_mapi_osd_attr *: osd attr.
 * @return 0 get osd attr success.
 * @return Non 0 get osd attr failed.
 */
td_s32 hi_mapi_osd_get_attr(td_u32 osd_idx, hi_mapi_osd_attr *osd_attr);

/**
 * @brief start osd.
 * @param[in] osdIdx td_u32: osd index.
 * @return 0 start osd success.
 * @return Non 0 start osd failed.
 */
td_s32 hi_mapi_osd_start(td_u32 osd_idx);

/**
 * @brief stop osd.
 * @param[in] osdIdx td_u32: osd index.
 * @return 0 stop osd success.
 * @return Non 0 stop osd failed.
 */
td_s32 hi_mapi_osd_stop(td_u32 osd_idx);

/**
 * @brief osd batch.
 * @param[in] batch_id td_u32: osd batch index.
 * @param[in] show td_bool: show flag.
 * @return 0 osd batch success.
 * @return Non 0 osd batch failed.
 */
td_s32 hi_mapi_osd_batch(td_u32 batch_id, td_bool show);

/** @} */  /** <!-- ==== OSD End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
#endif
