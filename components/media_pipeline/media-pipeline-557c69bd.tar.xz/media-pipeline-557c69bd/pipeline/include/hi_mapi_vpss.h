/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VPSS_H__
#define __HI_MAPI_VPSS_H__

#include "hi_mapi_vpss_define.h"


#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/* *******Group******* */
/**
 * @brief init group attr.
 * @param[in] grpHdl td_handle:handle of grp. It's integer from 0 to 31.
 * @param[in] grpAttr hi_mapi_vpss_grp_attr *:pointer of grp attribute.Static attribute.
 * @return 0  init grp group attr successful.
 * @return non 0  init grp group attr fail.
 */
td_s32 hi_mapi_vpss_init(td_handle grp_hdl, const hi_mapi_vpss_grp_attr *grp_attr);

/**
 * @brief deinit group attr.
 * @param[in] grpHdl td_handle:handle of grp. It's integer from 0 to 31.
 * @return 0  deinit grp group attr successful.
 * @return non 0  deinit grp group attr fail.
 */
td_s32 hi_mapi_vpss_deinit(td_handle grp_hdl);

/* *******Chn******* */
/**
 * @brief set attribute of chn in grp.
 * @param[in] grpHdl td_handle:handle of grp.
 * @param[in] chnHdl td_handle:handle of chn.
 * @param[in] chnAttr hi_mapi_vpss_chn_attr *:pointer of chn attribute. Dynamic attribute.
 * @return 0  set attribute of chn in grp successful.
 * @return non 0  set attribute of chn in grp fail.
 */
td_s32 hi_mapi_vpss_set_chn_attr(td_handle grp_hdl, td_handle chn_hdl, const hi_mapi_vpss_chn_attr *chn_attr);

/**
 * @brief get attribute of chn in grp.
 * @param[in] grpHdl td_handle:handle of grp.
 * @param[in] chnHdl td_handle:handle of chn.
 * @param[out] chnAttr hi_mapi_vpss_chn_attr *:pointer of chn attribute.
 * @return 0  get attribute of chn in grp successful.
 * @return non 0  get attribute of chn in grp fail.
 */
td_s32 hi_mapi_vpss_get_chn_attr(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_chn_attr *chn_attr);

/**
 * @brief set attribute of extern chn in grp.
 * @param[in] grpHdl td_handle : handle of grp.
 * @param[in] chnHdl td_handle : handle of extern chn.
 * @param[in] ext_chn_attr hi_mapi_vpss_ext_chn_attr *: pointer of extern chn attribute. Dynamic attribute.
 * @return 0  set attribute of extern chn in grpsuccessful.
 * @return non 0  set attribute of extern chn in grp fail.
 */
td_s32 hi_mapi_vpss_set_ext_chn_attr(td_handle grp_hdl, td_handle chn_hdl,
    const hi_mapi_vpss_ext_chn_attr *ext_chn_attr);

/**
 * @brief get attribute of extern chn in grp.
 * @param[in] grpHdl td_handle:handle of grp.
 * @param[in] chnHdl td_handle:handle of extern chn.
 * @param[out] ext_chn_attr hi_mapi_vpss_ext_chn_attr *:pointer of extern chn attribute.
 * @return 0  get attribute of extern chn in grp successful.
 * @return non 0  get attribute of extern chn in grp fail.
 */
td_s32 hi_mapi_vpss_get_ext_chn_attr(td_handle grp_hdl, td_handle chn_hdl,
    hi_mapi_vpss_ext_chn_attr *ext_chn_attr);

/**
 * @brief start chn in grp.
 * @param[in] grpHdl td_handle : handle of grp.
 * @param[in] chnHdl td_handle : handle of chn.
 * @return 0  start chn successful.
 * @return non 0  start chn fail.
 */
td_s32 hi_mapi_vpss_start_chn(td_handle grp_hdl, td_handle chn_hdl);

/**
 * @brief stop chn in grp.
 * @param[in] grpHdl td_handle : handle of grp.
 * @param[in] chnHdl td_handle : handle of chn.
 * @return 0  stop chn successful.
 * @return non 0  stop chn fail.
 */
td_s32 hi_mapi_vpss_stop_chn(td_handle grp_hdl, td_handle chn_hdl);

/**
 * @brief set corresponding attributes of a grp,including mirror, flip, rotate etc.
 * @param[in] grpHdl td_handle :handle of grp.
 * @param[in] chnHdl td_handle : handle of chn.
 * @param[in] command hi_mapi_vpss_cmd : Setting command.
 * @param[in] cmd_attr td_void:The struct of corresponding attributes.Dynamic attribute.
 * @param[in] len td_u32: length of the extend attribute
 * @return 0  set corresponding attributes successful.
 * @return non 0 set corresponding attributes fail.
 */
td_s32 hi_mapi_vpss_set_param(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_cmd command,
    const td_void *cmd_attr, td_u32 len);

/**
 * @brief get corresponding attributes of a vpss,including mirror, flip, rotate etc.
 * @param[in] grpHdl td_handle :handle of grp.
 * @param[in] chnHdl td_handle : handle of chn.
 * @param[in] command hi_mapi_vpss_cmd : Getting command.
 * @param[out] cmd_attr td_void:The struct of corresponding attributes.
 * @param[in] len td_u32: length of the extend attribute
 * @return 0  get corresponding attributes successful.
 * @return non 0  get corresponding attributes fail.
 */
td_s32 hi_mapi_vpss_get_param(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_cmd command,
    td_void *cmd_attr, td_u32 len);

/**
 * @brief set static config (e.g. buffer wrap) of a vpss chn; call after set_chn_attr, before start_chn.
 */
td_s32 hi_mapi_vpss_set_config(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_config_cmd command,
    const td_void *cmd_attr, td_u32 len);

/**
 * @brief get static config (e.g. buffer wrap) of a vpss chn.
 */
td_s32 hi_mapi_vpss_get_config(td_handle grp_hdl, td_handle chn_hdl, hi_mapi_vpss_config_cmd command,
    td_void *cmd_attr, td_u32 len);

/**
 * @brief get frame from chn of grp.
 * @param[in] grpHdl td_handle : handle of grp.
 * @param[in] chnHdl td_handle : handle of chn.
 * @param[out] yuv_frame_data hi_mapi_frame_data *: pointer of framedata.
 * @return 0  get frame from chn of grp successful.
 * @return non 0  get frame from chn of grp fail.
 */
td_s32 hi_mapi_vpss_get_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    hi_mapi_frame_data *yuv_frame_data);

/**
 * @brief release frame from chn of grp.
 * @param[in] grpHdl td_handle : handle of grp.
 * @param[in] chnHdl td_handle : handle of chn.
 * @param[out] yuv_frame_data hi_mapi_frame_data* : pointer of framedata.
 * @return 0  release frame from chn successful.
 * @return non 0  release frame from chn fail.
 */
td_s32 hi_mapi_vpss_release_chn_frame(td_handle grp_hdl, td_handle chn_hdl,
    const hi_mapi_frame_data *yuv_frame_data);

/**
 * @brief send frame data to grp.
 * @param[in] grpHdl td_handle : handle of grp.
 * @param[in] frame_data hi_mapi_frame_data *: frame data info.
 * @return 0  successful.
 * @return non 0  fail.
 */
td_s32 hi_mapi_vpss_send_frame(td_handle grp_hdl, const hi_mapi_frame_data *frame_data);
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_VPSS_H__ */
