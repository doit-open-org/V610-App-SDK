/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VENC_H__
#define __HI_MAPI_VENC_H__

#include "hi_mapi_venc_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/**
 * @brief get default video encode attribute based on base attribute.
 * @param[in] baseAttr const hi_mapi_venc_base_attr *: pointer of base attribute used to derive venc attribute.
 * @param[out] vencAttr hi_mapi_venc_attr *: pointer of venc attribute to be filled.
 * @return 0  get default video encode attribute success.
 * @return Non 0  get default video encode attribute fail.
 */
td_s32 hi_mapi_venc_get_default_attr(const hi_mapi_venc_base_attr *base_attr, hi_mapi_venc_attr *venc_attr);

/**
 * @brief init video encode instance.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[in] vencAttr hi_mapi_venc_attr *: the attribute of VENC instance.
 * @return 0  init video encode instance success.
 * @return Non 0  init video encode instance fail.
 */
td_s32 hi_mapi_venc_init(td_handle venc_hdl, const hi_mapi_venc_attr *venc_attr);

/**
 * @brief deinit video encode instance.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @return 0  deinit video encode instance success.
 * @return Non 0  deinit video encode instance fail.
 */
td_s32 hi_mapi_venc_deinit(td_handle venc_hdl);

/**
 * @brief register callback for video encode instance.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[in] vencCB hi_mapi_venc_call_back *: callback function of VENC.
 * @return 0  register callback for video encode instance success.
 * @return Non 0  register callback for video encode instance fail.
 */
td_s32 hi_mapi_venc_register_callback(td_handle venc_hdl, const hi_mapi_venc_call_back *venc_cb);

/**
 * @brief unregister callback for video encode instance.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[in] vencCB hi_mapi_venc_call_back *: callback function of VENC.
 * @return 0  unregister callback for video encode instance success.
 * @return Non 0  unregister callback for video encode instance fail.
 */
td_s32 hi_mapi_venc_un_register_callback(td_handle venc_hdl, const hi_mapi_venc_call_back *venc_cb);

/**
 * @brief start video encode instance.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[in] frame_cnt td_s32: the frame count of VENC will to do;
              HI_MAPI_VENC_LIMITLESS_FRAME_COUNT :VENC Will not automatically stop
 *            N( N > 0) :VENC will automatically stop after encode N frame data.
 * @return 0  start video encode instance success.
 * @return Non 0  start video encode instance fail.
 */
td_s32 hi_mapi_venc_start(td_handle venc_hdl, td_s32 frame_cnt);

/**
 * @brief stop video encode instance.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @return 0  stop video encode instance success.
 * @return Non 0  stop video encode instance fail.
 */
td_s32 hi_mapi_venc_stop(td_handle venc_hdl);

/**
 * @brief set video encode attribute.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[in] vencAttr hi_mapi_venc_attr *: the attribute of VENC instance.
 * @return 0  set video encode attribute success.
 * @return Non 0  set video encode attribute fail.
 */
td_s32 hi_mapi_venc_set_attr(td_handle venc_hdl, const hi_mapi_venc_attr *venc_attr);

/**
 * @brief get video encode attribute.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[out] vencAttr hi_mapi_venc_attr *: the attribute of VENC instance.
 * @return 0  get video encode attribute success.
 * @return Non 0  get video encode attribute fail.
 */
td_s32 hi_mapi_venc_get_attr(td_handle venc_hdl, hi_mapi_venc_attr *venc_attr);

/**
 * @brief request venc IDR.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @return 0  request venc IDR success.
 * @return Non 0  request venc IDR fail.
 */
td_s32 hi_mapi_venc_request_idr(td_handle venc_hdl);

/**
 * @brief set video encode extend attribute.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[in] cmd hi_mapi_venc_cmd: command of set VENC extend attribute.
 * @param[in] attr td_void *: the extend attribute of VENC instance.
 * @param[in] attr_len td_u32: length of the extend attribute.
 * @return 0  set video encode extend attribute success.
 * @return Non 0  set video encode extend attribute fail.
 */
td_s32 hi_mapi_venc_set_param(td_handle venc_hdl, hi_mapi_venc_cmd cmd, const td_void *attr, td_u32 attr_len);

/**
 * @brief get video encode extend attribute.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[in] cmd hi_mapi_venc_cmd: command of set VENC extend attribute.
 * @param[out] attr td_void *: the extend attribute of VENC instance.
 * @param[in] attr_len td_u32: length of the extend attribute.
 * @return 0  get video encode extend attribute success.
 * @return Non 0  get video encode extend attribute fail.
 */
td_s32 hi_mapi_venc_get_param(td_handle venc_hdl, hi_mapi_venc_cmd cmd, td_void *attr, td_u32 attr_len);

/**
 * @brief set video encode static config, must be called after module init and before channel init.
 * @param[in] venc_hdl td_handle: handle of VENC.
 * @param[in] cmd hi_mapi_venc_cfg_cmd: command of set VENC static config.
 * @param[in] attr td_void *: the static config attribute of VENC instance.
 * @param[in] attr_len td_u32: length of the static config attribute.
 * @return 0  set video encode static config success.
 * @return Non 0  set video encode static config fail.
 */
td_s32 hi_mapi_venc_set_config(td_handle venc_hdl, hi_mapi_venc_cfg_cmd cmd, const td_void *attr, td_u32 attr_len);

/**
 * @brief get video encode static config, can be called before or after channel init.
 * @param[in] venc_hdl td_handle: handle of VENC.
 * @param[in] cmd hi_mapi_venc_cfg_cmd: command of get VENC static config.
 * @param[out] attr td_void *: the static config attribute of VENC instance.
 * @param[in] attr_len td_u32: length of the static config attribute.
 * @return 0  get video encode static config success.
 * @return Non 0  get video encode static config fail.
 */
td_s32 hi_mapi_venc_get_config(td_handle venc_hdl, hi_mapi_venc_cfg_cmd cmd, td_void *attr, td_u32 attr_len);

/**
 * @brief send video frame to venc.
 * @param[in] vencHdl td_handle: handle of VENC.
 * @param[in] framedata hi_mapi_frame_data: video frame data attribute.
 * @param[in] timeout td_s32: timeout of millisecond.
 * @return 0  get video encode extend attribute success.
 * @return Non 0  get video encode extend attribute fail.
 */
td_s32 hi_mapi_venc_send_frame(td_handle venc_hdl, const hi_mapi_frame_data *framedata, td_s32 timeout);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_VENC_H__ */
