/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_AENC_H__
#define __HI_MAPI_AENC_H__

#include "hi_mapi_aenc_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/** \addtogroup     AENC */
/** @{ */ /** <!-- [AENC] */

/* Interface */
/**
 * @brief init audio encoder.
 * @param[in] aenc_hdl td_handle:handle of audio encoder.
 * @param[in] aenc_attr hi_mapi_aenc_attr *:audio encoder attr.
 * @return 0  init adec success.
 * @return Non 0  init adec fail.
 */
td_s32 hi_mapi_aenc_init(td_handle aenc_hdl, const hi_mapi_aenc_attr *aenc_attr);

/**
 * @brief deinit audio encoder.
 * @param[in] aenc_hdl td_handle:handle of audio encoder.
 * @return 0  deinit adec success.
 * @return Non 0  deinit adec fail.
 */
td_s32 hi_mapi_aenc_deinit(td_handle aenc_hdl);

/**
 * @brief start audio encoder.
 * @param[in] aenc_hdl td_handle:handle of audio encoder.
 * @return 0  start adec success.
 * @return Non 0  start adec fail.
 */
td_s32 hi_mapi_aenc_start(td_handle aenc_hdl);

/**
 * @brief stop audio encoder.
 * @param[in] aenc_hdl td_handle:handle of audio encoder.
 * @return 0  stop adec success.
 * @return Non 0  stop adec fail.
 */
td_s32 hi_mapi_aenc_stop(td_handle aenc_hdl);

/**
 * @brief register audio encoder callback.
 * @param[in] aenc_hdl td_handle:handle of audio encoder.
 * @param[in] aenc_cb hi_mapi_aenc_callback *:aenc callback info.
 * @return 0  register audio encoder callback success.
 * @return Non 0  register audio encoder callback fail.
 */
td_s32 hi_mapi_aenc_register_callback(td_handle aenc_hdl, const hi_mapi_aenc_callback *aenc_cb);

/**
 * @brief unregister audio encoder callback.
 * @param[in] aenc_hdl td_handle:handle of audio encoder.
 * @param[in] aenc_cb hi_mapi_aenc_callback *:aenc callback info.
 * @return 0  unregister audio encoder callback success.
 * @return Non 0  unregister audio encoder callback fail.
 */
td_s32 hi_mapi_aenc_unregister_callback(td_handle aenc_hdl, const hi_mapi_aenc_callback *aenc_cb);

/**
 * @brief send audio frame to audio encoder manually (non-bind mode).
 * @param[in] aenc_hdl td_handle:handle of audio encode.
 * @param[in] audio_frm hi_mapi_audio_frame *:audio frame info.
 * @return 0  send audio frame success.
 * @return Non 0  send audio frame fail.
 */
td_s32 hi_mapi_aenc_send_frame(td_handle aenc_hdl, const hi_mapi_audio_frame *audio_frm);

/**
 * @brief get default aenc attribute based on encoding format.
 *        Automatically fills pt_num_per_frm, value and value_len; audio encoder registration
 *        is handled internally by hi_mapi_aenc_init / hi_mapi_aenc_deinit.
 * @param[in] aenc_format hi_mapi_audio_format:audio encoding format.
 * @param[out] aenc_attr hi_mapi_aenc_attr *:aenc attr filled with default values.
 * @return 0  get default aenc attribute success.
 * @return Non 0  get default aenc attribute fail.
 */
td_s32 hi_mapi_aenc_get_default_attr(hi_mapi_audio_format aenc_format, hi_mapi_aenc_attr *aenc_attr);

/**
 * @brief set an AENC extension parameter by command.
 *        Dispatch table keyed by cmd; new extension keeps the signature stable.
 *        `_CONFIG` suffixed commands are only permitted before hi_mapi_aenc_start;
 *        calling after STARTED returns HI_MAPI_AENC_ESTATEERR.
 * @param[in] aenc_hdl td_handle: handle of audio encoder (must be inited).
 * @param[in] cmd hi_mapi_aenc_cmd: extension command id.
 * @param[in] attr const td_void *: pointer to the command-specific attribute struct.
 * @param[in] attr_len td_u32: size of *attr in bytes (validated against expected type).
 * @return 0  success.
 * @return Non 0  failure (HI_MAPI_AENC_ENULLPTR / EINVALIDHDL / ESTATEERR / EILLPARAM).
 */
td_s32 hi_mapi_aenc_set_param(td_handle aenc_hdl, hi_mapi_aenc_cmd cmd,
                              const td_void *attr, td_u32 attr_len);

/**
 * @brief read back an AENC extension parameter by command.
 * @param[in]  aenc_hdl td_handle: handle of audio encoder.
 * @param[in]  cmd hi_mapi_aenc_cmd: extension command id.
 * @param[out] attr td_void *: caller buffer to receive the attribute value.
 * @param[in]  attr_len td_u32: size of *attr in bytes.
 * @return 0 on success; Non 0 on failure.
 */
td_s32 hi_mapi_aenc_get_param(td_handle aenc_hdl, hi_mapi_aenc_cmd cmd,
                              td_void *attr, td_u32 attr_len);

/** @} */ /** <!-- ==== AENC End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_AENC_H__ */
