/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VCAP_DEFINE_H__
#define __HI_MAPI_VCAP_DEFINE_H__

#include "hi_mapi_comm_define.h"
#include "hi_mapi_comm_adapt_define.h"
#include "hi_mapi_vcap_adapt_define.h"
#include "hi_mapi_errno.h"
#include "hi_mw_log.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

/** \addtogroup     VCAP */
/** @{ */ /** <!-- [VCAP] */

typedef unsigned int hi_mapi_sns_rst_source;
typedef unsigned int hi_mapi_sns_clk_source;


/* Max and min wb value */
#define HI_MAPI_VCAP_MAX_COLORTEMP            15000
#define HI_MAPI_VCAP_MIN_COLORTEMP            1500

/* Max and min sysgain value */
#define HI_MAPI_VCAP_SYSGAIN_MIN              0x400
#define HI_MAPI_VCAP_SYSGAIN_MAX              0xFFFFFFFF

/* LDC */
#define HI_MAPI_VCAP_MAX_LDC_CENTERX_OFFSET   511
#define HI_MAPI_VCAP_MIN_LDC_CENTERX_OFFSET   (-511)
#define HI_MAPI_VCAP_MAX_LDC_CENTERY_OFFSET   511
#define HI_MAPI_VCAP_MIN_LDC_CENTERY_OFFSET   (-511)
#define HI_MAPI_VCAP_MAX_LDC_RATIO_X          100
#define HI_MAPI_VCAP_MIN_LDC_RATIO_X          0
#define HI_MAPI_VCAP_MAX_LDC_RATIO_Y          100
#define HI_MAPI_VCAP_MIN_LDC_RATIO_Y          0
#define HI_MAPI_VCAP_MAX_LDC_RATIO_XY         100
#define HI_MAPI_VCAP_MIN_LDC_RATIO_XY         0
#define HI_MAPI_VCAP_MAX_LDC_RATIO_DISTORTION 500
#define HI_MAPI_VCAP_MIN_LDC_RATIO_DISTORTION (-300)
#define HI_MAPI_VCAP_MIN_SATURATION           0
#define HI_MAPI_VCAP_MAX_SATURATION           100
#define HI_MAPI_VCAP_MIN_LUMA                 0
#define HI_MAPI_VCAP_MAX_LUMA                 100
#define HI_MAPI_VCAP_AE_ZONE_ROW              15
#define HI_MAPI_VCAP_AE_ZONE_COLUMN           17
#define HI_MAPI_VCAP_MIN_CONTRAST             0
#define HI_MAPI_VCAP_MAX_CONTRAST             100
#define HI_MAPI_VCAP_OB_HEIGHT_END            32
#define HI_MAPI_VCAP_OB_HEIGHT_START          0
typedef enum {
    HI_MAPI_VCAP_SENSOR_UNUSED = 0,
    HI_MAPI_VCAP_SENSOR_HY_S0603,
    HI_MAPI_VCAP_SENSOR_HY006_3814_0011,
    HI_MAPI_VCAP_SENSOR_AHD,
    HI_MAPI_VCAP_SENSOR_BUTT
} hi_mapi_vcap_sensor_type;

typedef enum {
    HI_MAPI_VCAP_SENSOR_SCENE_NORMAL,
    HI_MAPI_VCAP_SENSOR_SCENE_STANDBY,

    HI_MAPI_VCAP_SENSOR_SCENE_BUT
} hi_mapi_vcap_sensor_scene;

/* VCAP PIPE type  */
typedef enum {
    HI_MAPI_VCAP_PIPE_TYPE_VIDEO,
    HI_MAPI_VCAP_PIPE_TYPE_SNAP,
    HI_MAPI_VCAP_PIPE_TYPE_BUTT
} hi_mapi_vcap_pipe_type;

typedef enum {
    HI_MAPI_SENSOR_COMMBUS_TYPE_I2C = 0,
    HI_MAPI_SENSOR_COMMBUS_TYPE_SPI,
    HI_MAPI_SENSOR_COMMBUS_TYPE_BUTT
} hi_mapi_vcap_sensor_comm_bus_type;

typedef enum {
    HI_MAPI_VCAP_MIPI_DATA_RATE_X1 = 0,  /* 1 pixel/clock */
    HI_MAPI_VCAP_MIPI_DATA_RATE_X2 = 1,  /* 2 pixel/clock */
    HI_MAPI_VCAP_MIPI_DATA_RATE_BUTT
} hi_mapi_vcap_mipi_data_rate;

typedef enum {
    HI_MAPI_VCAP_BAYER_FORMAT_RGGB = 0,
    HI_MAPI_VCAP_BAYER_FORMAT_GRBG = 1,
    HI_MAPI_VCAP_BAYER_FORMAT_GBRG = 2,
    HI_MAPI_VCAP_BAYER_FORMAT_BGGR = 3,
    HI_MAPI_VCAP_BAYER_FORMAT_BUTT
} hi_mapi_vcap_bayer_format;

/* Aperture value */
typedef struct {
    /* <RW, Range:[F32.0, F1.0], Max F number of Piris's aperture, it's related to the specific iris */
    hi_mapi_vcap_isp_iris_fno max_iris_fno_target_type;

    /* <RW, Range:[F32.0, F1.0], Min F number of Piris's aperture, it's related to the specific iris */
    hi_mapi_vcap_isp_iris_fno min_iris_fno_target_type;

    /* <RW, use equivalent gain to present FNO or not */
    td_bool fno_ex_valid;

    /* <RW, Range:[1, 1024], Max equivalent gain of F number of Piris's aperture, only used
        when bFNOExValid is true, it's related to the specific iris */
    td_u32 max_iris_fno_target;

    /* <RW, Range:[1, 1024], Min equivalent gain of F number of Piris's aperture, only used
        when bFNOExValid is true, it's related to the specific iris */
    td_u32 min_iris_fno_target;
} hi_mapi_vcap_aperture_info;

typedef struct {
    hi_mapi_vcap_wdr_mode wdr_mode;
    hi_mapi_vcap_intf_mode intf_mode;  /* <Interface mode */
    hi_mapi_yuv_data_seq data_seq; /* <Input data sequence (only the YUV format is supported) */
    hi_mapi_vcap_data_type data_type; /* <data type */
} hi_mapi_vcap_dev_attr;

typedef struct {
    hi_mapi_size dest_size;                  /* <dynamic attribute, channel Output resolution setting,
                                                     can not be dynamically modified when using GDC */
    hi_mapi_frame_rate_ctrl frame_rate_ctrl;        /* <dynamic attribute,channel Frame rate control */
    hi_mapi_pixel_format pixel_format;        /* <static attribute,[8bit,10bit,12bit,14bit,16bit] */
    hi_mapi_video_format video_format;
    td_u32 vb_pool_blk_cnt;
} hi_mapi_vcap_pipe_chn_attr;

typedef struct {
    td_float frame_rate;
    hi_mapi_size size;
    hi_mapi_vcap_isp_bayer_format bayer;
    hi_mapi_vcap_isp_sns_mirror_flip_type sns_mirror_flip;
} hi_mapi_vcap_pipe_isp_attr;

typedef struct {
    hi_mapi_vcap_pipe_type pipe_type;                 /* <static attribute,PIPE attribute */
    hi_mapi_frame_rate_ctrl frame_rate_ctrl;                /* <dynamic attribute, PIPE attribute */
    /* the attr is not support in current version */
    hi_mapi_vcap_pipe_isp_attr isp_pub_attr;                             /* <ISP pub attribute */
    td_u32 vb_pool_blk_cnt;
    hi_mapi_vcap_pipe_chn_attr pipe_chn_attr[HI_MAPI_VCAP_PIPE_MAX_CHN_NUM]; /* <attributes corresponding to PIPE channel */
} hi_mapi_vcap_pipe_attr;

typedef struct {
    hi_mapi_vcap_dev_attr vcap_dev_attr; /* <VCAP DEV attribute */

    td_u32 pipe_bind_num;                                               /* <The number of pipe bound to Vcap dev */
    td_handle pipe_id_bind[HI_MAPI_VCAP_MAX_PIPE_NUM];                    /* <The ID of the pipe bound to Vcap dev */
    hi_mapi_vcap_pipe_attr vcap_pipe_attr[HI_MAPI_VCAP_MAX_PIPE_NUM]; /* <Set attr for the pipe bound to Vcap dev */
} hi_mapi_vcap_attr;

typedef struct {
    hi_mapi_vcap_input_mode input_mode;
    hi_mapi_vcap_input_datatype input_data_type;
    td_bool use_serdes_dev;
} hi_mapi_vcap_input_dev_attr;

typedef struct {
    hi_mapi_vcap_bayer_format bayer_format;
    hi_mapi_vcap_sensor_comm_bus_type comm_bus_type;
    td_u32 sensor_dev_addr;	
} hi_mapi_vcap_sensor_input_attr;

typedef struct {
    td_void *sensor_obj;
    hi_mapi_vcap_mipi_data_rate data_rate;
    hi_mapi_vcap_sensor_input_attr input_attr;
    td_s16 lane_id[HI_MAPI_SENSOR_MAX_LANE_NUM];
} hi_mapi_vcap_sensor_dev_attr;

typedef enum {
    HI_MAPI_VCAP_LANE_DIVIDE_MODE_0 = 0,     /* 4lane */
    HI_MAPI_VCAP_LANE_DIVIDE_MODE_1 = 1,     /* 2lane + 2lane */
    HI_MAPI_VCAP_LANE_DIVIDE_MODE_BUTT
} hi_mapi_vcap_lane_divide_mode;

typedef struct {
    hi_mapi_vcap_lane_divide_mode lane_id_mode;
    hi_mapi_sns_clk_source sns_clk_source;
    hi_mapi_sns_rst_source sns_rst_source;
    td_s32 bus_id;
} hi_mapi_vcap_combo_dev_attr;

typedef struct {
    td_u32 sns_mode;
    hi_mapi_vcap_wdr_mode wdr_mode;
    hi_mapi_size size;
    hi_mapi_vcap_input_dev_attr input_dev_attr;
    hi_mapi_vcap_sensor_dev_attr sns_dev_attr;
    hi_mapi_vcap_combo_dev_attr combo_dev_attr;
} hi_mapi_vcap_sensor_attr;

typedef struct {
    combo_dev_t devno;
    td_u32 num;
    td_u32 ext_data_bit_width[MAX_EXT_DATA_TYPE_NUM];
    td_u32 ext_data_type[MAX_EXT_DATA_TYPE_NUM];
} hi_mapi_vcap_ext_data;

/* redefine a struct for the need of getSensorAllModes.
the difference of hi_mapi_vcap_sensor_attr and HI_MAPI_SENSOR_MODE_S is the addition of s32SnsMaxFrameRate */
typedef struct {
    td_s32 width;  /* it is related to mipi width */
    td_s32 height; /* it is related to mipi height */
    hi_mapi_vcap_wdr_mode wdr_mode;
    td_u32 sns_mode;
    td_float sns_max_frame_rate;
    hi_mapi_vcap_ext_data *mipi_ext_data;
} hi_mapi_vcap_sensor_mode;

/* Expand attributes */
typedef enum {
    HI_MAPI_VCAP_CMD_ISP_EXPOURSEATTR,  /* <ISP Expand attributes:Exposure time */
    HI_MAPI_VCAP_CMD_ISP_METERINGMODE,  /* <ISP Expand attributes:Metering mode  */
    HI_MAPI_VCAP_CMD_ISP_WBATTR,        /* <ISP Expand attributes:White balance mode */
    HI_MAPI_VCAP_CMD_ISP_SHARPEN,       /* <ISP Expand attributes:Sharpen */
    HI_MAPI_VCAP_CMD_ISP_LUMA,          /* <ISP Expand attributes:Luma   */
    HI_MAPI_VCAP_CMD_ISP_SATURATION,    /* <ISP Expand attributes:saturation */
    HI_MAPI_VCAP_CMD_ISP_CAC,           /* <ISP Expand attributes:Purple edge correction */
    HI_MAPI_VCAP_CMD_ISP_DNGCOLORPARAM, /* <ISP Expand attributes:Get DNG color information */
    HI_MAPI_VCAP_CMD_ISP_PIPEDIFFATTR,  /* <ISP Expand attributes:Multiple Splicing Differences
                                            ISP Pipe Discrepancy Attributes */
    HI_MAPI_VCAP_CMD_ISP_WDR,           /* <ISP Expand attributes:WDR Attributes, You can set
                                            the synthesis method andits parameters,Related to
                                            ghosting problems, indoor frequency flicker problem,
                                            Fusion mode can improve Flicker problem */
    HI_MAPI_VCAP_CMD_ISP_CONTRAST, /* <ISP Expand attributes:contrastInfo */

    HI_MAPI_VCAP_CMD_ISP_GET_DNGIMAGESTATICINFO, /* <ISP Expand attributes:Get DNG static information */
    HI_MAPI_VCAP_CMD_ISP_GET_EXPOURSEINFO,       /* <ISP Expand attributes:Query AE exposure information  */
    HI_MAPI_VCAP_CMD_ISP_GET_AWBINFO,            /* <ISP Expand attributes:Query AWB information */
    HI_MAPI_VCAP_CMD_ISP_GET_PUBINFO,            /* <ISP Expand attributes:get ISP pub Attributes */

    HI_MAPI_VCAP_CMD_ISP_SET_3AINIT,   /* <ISP Expand attributes:set 3A init Attributes.
                                            Deprecated here: moved to hi_mapi_vcap_set_config
                                            (HI_MAPI_VCAP_CONFIG_CMD_ISP_3AINIT). */
    HI_MAPI_VCAP_CMD_ISP_SET_AEDEBUG,  /* <ISP Expand attributes:set AE debug */
    HI_MAPI_VCAP_CMD_ISP_SET_AWBDEBUG, /* <ISP Expand attributes:set AWB debug */

    HI_MAPI_VCAP_CMD_LDC,        /* <CHN Expand attributes:LDC */
    HI_MAPI_VCAP_CMD_ROTATE,     /* <CHN Expand attributes:Rotate  */
    HI_MAPI_VCAP_CMD_MIRRORFLIP, /* <CHN Expand attributes:mirror/flip */

    HI_MAPI_VCAP_CMD_PIPE_GETCMPPARAM, /* <PIPE Expand attributes:ComPressParam */
    HI_MAPI_VCAP_CMD_ENTER_STANDBY,    /* <PIPE Expand attributes:Sensor enter standby mode */
    HI_MAPI_VCAP_CMD_EXIT_STANDBY,     /* <PIPE Expand attributes:Sensor exit standby mode */
    HI_MAPI_VCAP_CMD_RESTART_SENSOR,   /* <PIPE Expand attributes:Sensor restart */
    HI_MAPI_VCAP_CMD_LDCV2,            /* <CHN Expand attributes:LDC */
    HI_MAPI_VCAP_CMD_LDCV3,            /* <CHN Expand attributes:LDC */
    HI_MAPI_VCAP_CMD_LDCV4,            /* <CHN Expand attributes:LDC */
    HI_MAPI_VCAP_CMD_CHN_DEPTH,        /* <CHN Expand attributes:user frame queue depth,
                                            cmd_attr:hi_mapi_vcap_chn_depth */
    HI_MAPI_VCAP_CMD_PIPE_LOW_DELAY,   /* <PIPE Expand attributes:low delay,
                                            cmd_attr:hi_mapi_vcap_low_delay_info */
    HI_MAPI_VCAP_CMD_CHN_LOW_DELAY,    /* <CHN Expand attributes:low delay,
                                            cmd_attr:hi_mapi_vcap_low_delay_info */
    HI_MAPI_VCAP_CMD_BUTT
} hi_mapi_vcap_cmd;

/* Static config commands */
typedef enum {
    HI_MAPI_VCAP_CONFIG_CMD_ISP_3AINIT, /* <ISP AE/AWB init attr; cmd_attr:hi_mapi_vcap_isp_init_attr.
                                            Consumed at init_isp (before isp mem init). */
    HI_MAPI_VCAP_CONFIG_CMD_OB_HEIGHT,  /* <cmd_attr:hi_mapi_vcap_ob_height_cfg; handle is dev/sensor (1:1) */
    HI_MAPI_VCAP_CONFIG_CMD_PIPE_BUF_WRAP, /* <wrap(卷绕), set before start_dev, offline only;
                                            cmd_attr:hi_mapi_vcap_buf_wrap_attr */
    HI_MAPI_VCAP_CONFIG_CMD_BUTT
} hi_mapi_vcap_config_cmd;

typedef struct {
    td_u32 ob_height; /* <sensor OB line count added to MIPI RX height; default 0 */
} hi_mapi_vcap_ob_height_cfg;

typedef enum {
    HI_MAPI_VCAP_OP_TYPE_AUTO = 0,
    HI_MAPI_VCAP_OP_TYPE_MANUAL = 1,
    HI_MAPI_VCAP_OP_TYPE_DISABLE = 2,
    HI_MAPI_VCAP_OP_TYPE_BUTT
} hi_mapi_vcap_op_type;

/* Expand attributes: Exposure (exposure time, metering mode, sensitivity, exposure compensation) */
typedef struct {
    hi_mapi_vcap_op_type exp_time_op_type;
    hi_mapi_vcap_op_type a_gain_op_type;
    hi_mapi_vcap_op_type d_gain_op_type;
    hi_mapi_vcap_op_type isp_dgain_op_type;
    td_u32 exposure_time;
    td_u32 a_gain;
    td_u32 d_gain;
    td_u32 isp_dgain;
} hi_mapi_vcap_exposure_manual_mode;

typedef struct {
    td_u32 min;
    td_u32 max;
} hi_mapi_vcap_ae_range;

typedef struct {
    td_u32 ev_bias;                       /* <Exposure compensation< [0,0xFFFF] */
    hi_mapi_vcap_ae_range sys_gain_range;   /* <ISO */
} hi_mapi_vcap_exposure_auto_mode;

typedef struct {
    hi_mapi_vcap_op_type op_type;
    hi_mapi_vcap_exposure_manual_mode manu_exposure_mode;
    hi_mapi_vcap_exposure_auto_mode auto_exposure_mode;
} hi_mapi_vcap_exposure_attr;

/* Expand attributes: white balance mode */
typedef struct {
    td_u32 color_temp; /* < Unit:Kelvin,1500~15000 */
} hi_mapi_vcap_wb_manual_mode;

typedef struct {
    hi_mapi_vcap_op_type op_type;
    hi_mapi_vcap_wb_manual_mode wb_mode;
} hi_mapi_vcap_wb_attr;

/** The current exposure info.HI_MAPI_VCAP_CMD_ISP_GetExposureInfo */
typedef struct {
    td_u32 exp_time;
    td_u32 a_gain;
    td_u32 d_gain;
    td_u32 isp_dgain;
    td_u32 exposure;
    td_u32 lines_per500ms;
    td_u32 piris_fno;
    td_u32 long_exp_time;
    td_u32 short_exp_time;
    td_u32 median_exp_time;
    td_bool exposure_is_max;
    td_s16 hist_error;
    td_u8 ave_lum;
    td_u32 fps;
    td_u32 iso;
    td_u32 ref_exp_ratio;
    td_u32 first_stable_time;
} hi_mapi_vcap_exposure_info;

/* the isp init attr is changed in the newest version */
typedef struct {
    td_bool is_ir_mode;
    td_u32 exp_time;
    td_u32 a_gain;
    td_u32 d_gain;
    td_u32 isp_dgain;
    td_u32 exposure;
    td_u32 init_iso;
    td_u32 lines_per500ms;
    td_u32 piris_fno;
    td_u16 wb_rgain;
    td_u16 wb_ggain;
    td_u16 wb_bgain;
    td_u16 sample_rgain;
    td_u16 sample_bgain;
    td_u16 ccm[HI_MAPI_VCAP_ISP_CCM_MATRIX_SIZE];
    td_u32 ae_stat_pos;
} hi_mapi_vcap_isp_init_attr;

typedef struct {
    td_u8 luma_wgt[HI_MAPI_VCAP_ISP_SHARPEN_LUMA_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u16 texture_strength[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u16 edge_strength[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u16 texture_freq[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u16 edge_freq[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 over_shoot[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 under_shoot[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];

    td_u16 motion_texture_strength[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u16 motion_edge_strength[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM][HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u16 motion_texture_freq[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u16 motion_edge_freq[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 motion_over_shoot[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 motion_under_shoot[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];

    td_u8 shoot_sup_strength[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 shoot_sup_adj[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 detail_ctrl[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 detail_ctrl_threshold[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 edge_filt_strength[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 edge_filt_max_cap[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 r_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 g_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 b_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u8 skin_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
    td_u16 max_sharp_gain[HI_MAPI_VCAP_ISP_AUTO_ISO_NUM];
} hi_mapi_vcap_sharp_auto_attr;

typedef enum {
    HI_MAPI_VCAP_ISP_SHARPEN_NORMAL = 0,
    HI_MAPI_VCAP_ISP_SHARPEN_DETAIL,
    HI_MAPI_VCAP_ISP_SHARPEN_OFF,
    HI_MAPI_VCAP_ISP_SHARPEN_DIFF_NORM,
    HI_MAPI_VCAP_ISP_SHARPEN_DIFF,
    HI_MAPI_VCAP_ISP_SHARPEN_TOTAL,
    HI_MAPI_VCAP_ISP_SHARPEN_TEXTURE,
    HI_MAPI_VCAP_ISP_SHARPEN_EDGE,
    HI_MAPI_VCAP_ISP_SHARPEN_TOTAL_FREQ,
    HI_MAPI_VCAP_ISP_SHARPEN_TEXTURE_FREQ,
    HI_MAPI_VCAP_ISP_SHARPEN_EDGE_FREQ,
    HI_MAPI_VCAP_ISP_SHARPEN_BUTT
} hi_mapi_vcap_sharpen_detail_map;

/* Expand attributes: sharpness */
typedef struct {
    td_u8 luma_wgt[HI_MAPI_VCAP_ISP_SHARPEN_LUMA_NUM];
    td_u16 texture_strength[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM];
    td_u16 edge_strength[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM];
    td_u16 texture_freq;
    td_u16 edge_freq;
    td_u8 over_shoot;
    td_u8 under_shoot;

    td_u16 motion_texture_strength[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM];
    td_u16 motion_edge_strength[HI_MAPI_VCAP_ISP_SHARPEN_GAIN_NUM];
    td_u16 motion_texture_freq;
    td_u16 motion_edge_freq;
    td_u8 motion_over_shoot;
    td_u8 motion_under_shoot;
    td_u8 shoot_sup_strength;
    td_u8 shoot_sup_adj;
    td_u8 detail_ctrl;
    td_u8 detail_ctrl_threshold;
    td_u8 edge_filt_strength;
    td_u8 edge_filt_max_cap;
    td_u8 r_gain;
    td_u8 g_gain;
    td_u8 b_gain;
    td_u8 skin_gain;
    td_u16 max_sharp_gain;
} hi_mapi_vcap_sharp_manual_attr;

typedef struct {
    td_bool enable;
    td_bool motion_enable;
    td_u8 motion_threshold0;
    td_u8 motion_threshold1;
    td_u16 motion_gain0;
    td_u16 motion_gain1;
    td_u8 skin_umin;
    td_u8 skin_vmin;
    td_u8 skin_umax;
    td_u8 skin_vmax;
    hi_mapi_vcap_op_type op_type;
    hi_mapi_vcap_sharpen_detail_map  detail_map;
    hi_mapi_vcap_sharp_manual_attr manual_attr;
    hi_mapi_vcap_sharp_auto_attr auto_attr;
} hi_mapi_vcap_sharpen;

/* Expand attributes: brightness */
typedef struct {
    td_u8 luma; /* <Luma  cmd:HI_MAPI_VCAP_CMD_ISP_LUMA */
} hi_mapi_vcap_luma;

/* Expand attributes: saturation */
typedef struct {
    td_u8 saturation; /* < saturation  cmd:HI_MAPI_VCAP_CMD_ISP_SATURATION */
} hi_mapi_vcap_saturation;

typedef struct {
    /* RW; Range:[0x0, 0xF]; Format:4.0; AE weighting table */
    td_u8 weight[HI_MAPI_VCAP_AE_ZONE_ROW][HI_MAPI_VCAP_AE_ZONE_COLUMN];
} hi_mapi_vcap_metering_mode;

/* Expand attributes:mirror and flip */
typedef struct {
    td_bool mirror;
    td_bool flip;
} hi_mapi_vcap_mirror_flip_attr;

/* Expand attributes:channel user frame queue depth */
typedef struct {
    td_u32 depth; /* <Range:[0, 8], user frame queue depth. cmd:HI_MAPI_VCAP_CMD_CHN_DEPTH.
                       depth > 0 is required before hi_mapi_vcap_get_chn_frame can return frames. */
} hi_mapi_vcap_chn_depth;

/* Expand attributes: VI pipe/chn low delay. cmd:HI_MAPI_VCAP_CMD_PIPE_LOW_DELAY / HI_MAPI_VCAP_CMD_CHN_LOW_DELAY */
typedef struct {
    td_bool enable;     /* <low delay enable */
    td_u32  line_cnt;   /* <Range:[16, 8192], low delay shoreline */
    td_bool one_buf_en; /* <one buffer for low delay enable */
} hi_mapi_vcap_low_delay_info;

/* VI pipe buffer wrap (卷绕): user configures only 'enable'; buf_line is computed internally */
typedef struct {
    td_bool enable;
} hi_mapi_vcap_buf_wrap_attr;

/* Expand attributes: contrast */
typedef struct {
    td_u8 contrast; /* <contrast  cmd:HI_MAPI_VCAP_CMD_ISP_CONTRAST */
} hi_mapi_vcap_contrast;

typedef struct {
    td_s32 sensor_type;
    td_s32 sensor_mode_cnt;
    const hi_mapi_vcap_sensor_mode *sensor_mode;
} hi_mapi_vcap_sensor_describe_info;

/** Null pointer error for vcap */
#define HI_MAPI_VCAP_ENULL_PTR HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NULL_PTR)
/** illegal parameter error for vcap */
#define HI_MAPI_VCAP_EILLEGAL_PARA HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_PARAM)
/** invalid fd error for vcap */
#define HI_MAPI_VCAP_EINVALID_FD HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_INVALID_FD)
/** not support error for vcap */
#define HI_MAPI_VCAP_ENOTSUPPORT HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_SUPPORT)
/** not inited error for vcap */
#define HI_MAPI_VCAP_ENOT_INITED HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_INITED)
/** dev\pipe\chn not config attr */
#define HI_MAPI_VCAP_ENOT_CONFIG HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_CONFIG)
/** operate fail */
#define HI_MAPI_VCAP_EOPERATE_FAIL HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_OPERATE_FAIL)
/** no memery for vcap */
#define HI_MAPI_VCAP_ENOMEM HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOMEM)
/** not permit */
#define HI_MAPI_VCAP_ENOT_PERM HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_NOT_PERM)
/** not exist */
#define HI_MAPI_VCAP_EUNEXIST HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_UNEXIST)
/** illegal handle */
#define HI_MAPI_VCAP_EILLEGAL_HANDLE \
    HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_ILLEGAL_HANDLE)

#define HI_MAPI_VCAP_ETIME_OUT HI_MAPI_DEF_ERR(HI_MAPI_MOD_VCAP, MAPI_EN_ERR_LEVEL_ERROR, MAPI_EN_ERR_TIME_OUT)

/** @} */ /** <!-- ==== VCAP End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif /* End of #ifndef __HI_MAPI_VCAP_DEFINE_H__ */
