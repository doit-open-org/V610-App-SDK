/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_AO_H__
#define __HI_MAPI_AO_H__

#include "hi_mapi_ao_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/** \addtogroup     AO */
/** @{ */ /** <!-- [AO] */

/* Interface */
/**
 * @brief init ao device.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] ao_attr hi_mapi_ao_attr *:ao attr.
 * @return 0  init ao device success.
 * @return Non 0  init ao device fail.
 */
td_s32 hi_mapi_ao_init(td_handle ao_hdl, const hi_mapi_ao_attr *ao_attr);

/**
 * @brief deinit ao device.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @return 0  deinit ao device success.
 * @return Non 0  deinit ao device fail.
 */
td_s32 hi_mapi_ao_deinit(td_handle ao_hdl);

/**
 * @brief start ao device.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] ao_chn_hdl td_handle:handle of ao device chn.
 * @return 0  start ao device success.
 * @return Non 0  start ao device fail.
 */
td_s32 hi_mapi_ao_start(td_handle ao_hdl, td_handle ao_chn_hdl);

/**
 * @brief stop ao device.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] ao_chn_hdl td_handle:handle of ao device chn.
 * @return 0  stop ao device success.
 * @return Non 0  stop ao device fail.
 */
td_s32 hi_mapi_ao_stop(td_handle ao_hdl, td_handle ao_chn_hdl);

/**
 * @brief enable ao device vqe.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] ao_chn_hdl td_handle:handle of ao device chn.
 * @param[in] ao_vqe_attr hi_mapi_ao_vqe_attr *:vqe attr.
 * @return 0  enable ao device vqe success.
 * @return Non 0  enable ao device vqe fail.
 */
td_s32 hi_mapi_ao_enable_vqe(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_ao_vqe_attr *ao_vqe_attr);

/**
 * @brief disable ao device vqe.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] ao_chn_hdl td_handle:handle of ao device chn.
 * @return 0  disable ao device vqe success.
 * @return Non 0  disable ao device vqe fail.
 */
td_s32 hi_mapi_ao_disable_vqe(td_handle ao_hdl, td_handle ao_chn_hdl);

/**
 * @brief set ao volume.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] audio_gain td_s32:the value of ao gain.
 * @return 0  set ao volume success.
 * @return Non 0  set ao volume fail.
 */
td_s32 hi_mapi_ao_set_volume(td_handle ao_hdl, td_s32 audio_gain);

/**
 * @brief get ao volume.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[out] audio_gain td_s32 *:the value of ao gain.
 * @return 0  get ao volume success.
 * @return Non 0  get ao volume fail.
 */
td_s32 hi_mapi_ao_get_volume(td_handle ao_hdl, td_s32 *audio_gain);

/**
 * @brief set ao mute state.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] enable td_bool:TD_TRUE to mute, TD_FALSE to unmute.
 * @return 0  set ao mute state success.
 * @return Non 0  set ao mute state fail.
 */
td_s32 hi_mapi_ao_set_mute(td_handle ao_hdl, td_bool enable);

/**
 * @brief send pcm raw audio frame to output.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] ao_chn_hdl td_handle:handle of ao device chn.
 * @param[in] audio_frame hi_mapi_audio_frame *:audio frame info.
 * @param[in] timeout td_u32:send frame time out.
 * @return 0  send pcm raw audio frame to output success.
 * @return Non 0  send pcm raw audio frame to output fail.
 */
td_s32 hi_mapi_ao_send_frame(td_handle ao_hdl, td_handle ao_chn_hdl, const hi_mapi_audio_frame *audio_frame,
    td_u32 timeout);

/**
 * @brief send sys frame.
 * @param[in] ao_hdl td_handle:handle of ao device.
 * @param[in] audio_frame hi_mapi_audio_frame *:audio frame info.
 * @param[in] timeout td_u32:send frame time out.
 * @return 0  send sys frame success.
 * @return Non 0  send sys frame fail.
 */
td_s32 hi_mapi_ao_send_sys_frame(td_handle ao_hdl, const hi_mapi_audio_frame *audio_frame, td_u32 timeout);

/**
 * @brief get default ao attribute, only sample rate and sound mode need to be specified.
 * @param[in] sample_rate hi_mapi_audio_sample_rate:audio sample rate, should match ADEC output.
 * @param[in] sound_mode hi_mapi_audio_sound_mode:audio sound mode (mono/stereo).
 * @param[out] ao_attr hi_mapi_ao_attr *:ao attr filled with default values.
 * @return 0  get default ao attribute success.
 * @return Non 0  get default ao attribute fail.
 */
td_s32 hi_mapi_ao_get_default_attr(hi_mapi_audio_sample_rate sample_rate,
                                  hi_mapi_audio_sound_mode sound_mode,
                                  hi_mapi_ao_attr *ao_attr);

/** @} */ /** <!-- ==== AO ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_AO_H__ */
