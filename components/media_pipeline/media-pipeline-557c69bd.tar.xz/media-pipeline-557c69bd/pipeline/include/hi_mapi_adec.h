/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_ADEC_H__
#define __HI_MAPI_ADEC_H__

#include "hi_mapi_adec_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/** \addtogroup     ADEC */
/** @{ */  /** <!-- [ADEC] */

/**
 * @brief init audio Decode.
 * @param[in] adec_hdl td_handle:handle of audio Decode.
 * @param[in] adec_attr hi_mapi_adec_attr *:adec attr.
 * @return 0  init adec success.
 * @return Non 0  init adec fail.
 */
td_s32 hi_mapi_adec_init(td_handle adec_hdl, const hi_mapi_adec_attr *adec_attr);

/**
 * @brief deinit audio Decode.
 * @param[in] adec_hdl td_handle:handle of audio Decode.
 * @return 0  deinit adec success.
 * @return Non 0  deinit adec fail.
 */
td_s32 hi_mapi_adec_deinit(td_handle adec_hdl);

/**
 * @brief send audio frame to audio Decode.
 * @param[in] adec_hdl td_handle:handle of audio Decode module.
 * @param[in] adec_stream hi_mapi_audio_stream *: audio frame data info
 * @param[in] block td_bool: block sign
 * @return 0  send audio frame to adec success.
 * @return Non 0  send audio frame to adec fail.
 */
td_s32 hi_mapi_adec_send_stream(td_handle adec_hdl, const hi_mapi_audio_stream *adec_stream, td_bool block);

/**
 * @brief get pcm raw audio frame.
 * @param[in] adec_hdl td_handle:handle of audio Decode module.
 * @param[out] audio_frame_info hi_mapi_audio_frame_info *: audio frame info.
 * @param[in] block td_bool: block sign.
 * @return 0  get pcm raw audio frame success.
 * @return Non 0  get pcm raw audio frame fail.
 */
td_s32 hi_mapi_adec_get_frame(td_handle adec_hdl, hi_mapi_audio_frame_info *audio_frame_info, td_bool block);

/**
 * @brief release pcm raw audio frame.
 * @param[in] adec_hdl td_handle:handle of audio Decode module.
 * @param[in] audio_frame_info hi_mapi_audio_frame_info *: audio frame info.
 * @return 0  release pcm raw audio frame success.
 * @return Non 0  release pcm raw audio frame fail.
 */
td_s32 hi_mapi_adec_release_frame(td_handle adec_hdl, const hi_mapi_audio_frame_info *audio_frame_info);

/**
 * @brief clean audio frame buf.
 * @param[in] adec_hdl td_handle:handle of audio Decode module.
 * @return 0  clean audio frame buf success.
 * @return Non 0  clean audio frame buf fail.
 */
td_s32 hi_mapi_adec_send_end_of_stream(td_handle adec_hdl);

/**
 * @brief get default adec attribute based on decoding format.
 *        Automatically fills adec_mode with the recommended default (PACK mode).
 * @param[in] adec_format hi_mapi_audio_format:audio decoding format.
 * @param[out] adec_attr hi_mapi_adec_attr *:adec attr filled with default values.
 * @return 0  get default adec attribute success.
 * @return Non 0  get default adec attribute fail.
 */
td_s32 hi_mapi_adec_get_default_attr(hi_mapi_audio_format adec_format, hi_mapi_adec_attr *adec_attr);

/**
 * @brief set an ADEC extension parameter by command.
 *        `_CONFIG` suffixed commands are only permitted before the first
 *        hi_mapi_adec_send_stream; calling after streaming starts returns
 *        HI_MAPI_ADEC_ESTATEERR.
 * @param[in] adec_hdl td_handle: handle of audio decoder (must be inited).
 * @param[in] cmd hi_mapi_adec_cmd: extension command id.
 * @param[in] attr const td_void *: pointer to the command-specific attribute struct.
 * @param[in] attr_len td_u32: size of *attr in bytes.
 * @return 0 on success; Non 0 on failure.
 */
td_s32 hi_mapi_adec_set_param(td_handle adec_hdl, hi_mapi_adec_cmd cmd,
                              const td_void *attr, td_u32 attr_len);

/**
 * @brief read back an ADEC extension parameter by command.
 * @param[in]  adec_hdl td_handle: handle of audio decoder.
 * @param[in]  cmd hi_mapi_adec_cmd: extension command id.
 * @param[out] attr td_void *: caller buffer to receive the attribute value.
 * @param[in]  attr_len td_u32: size of *attr in bytes.
 * @return 0 on success; Non 0 on failure.
 */
td_s32 hi_mapi_adec_get_param(td_handle adec_hdl, hi_mapi_adec_cmd cmd,
                              td_void *attr, td_u32 attr_len);


/** @} */  /** <!-- ==== ADEC End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_ADEC_H__ */
