/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VGS_H__
#define __HI_MAPI_VGS_H__

#include "hi_mapi_vgs_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/**
 * @brief start job
 * @param[out] vgsHdl td_handle *: handle pointer of VGS
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_begin_job(td_handle *vgs_hdl);

/**
 * @brief add scale task
 * @param[in] vgsHdl td_handle: handle of VGS
 * @param[in] scaleTaskAttr hi_mapi_vgs_scale_task_attr *: the attribute pointer of VGS scale task
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_add_scale_task(td_handle vgs_hdl, const hi_mapi_vgs_scale_task_attr *scale_task_attr);

/**
 * @brief add cover task
 * @param[in] vgsHdl td_handle: handle of VGS
 * @param[in] coverTaskAttr hi_mapi_vgs_cover_task_attr *: the attribute pointer of VGS cover task
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_add_cover_task(td_handle vgs_hdl, const hi_mapi_vgs_cover_task_attr *cover_task_attr);

/**
 * @brief add draw line task
 * @param[in] vgsHdl td_handle: handle of VGS
 * @param[in] drawLineTaskAttr hi_mapi_vgs_draw_line_task_attr *: the attribute pointer of VGS draw line task
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_add_draw_line_task(td_handle vgs_hdl, const hi_mapi_vgs_draw_line_task_attr *draw_line_task_attr);

/**
 * @brief create region
 * @param[in] rgnTaskAttr hi_mapi_vgs_rgn_task_attr *: the attribute pointer of VGS create region task
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_create_rgn(const hi_mapi_vgs_rgn_task_attr *rgn_task_attr);

/**
 * @brief destroy region
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_destroy_rgn(td_void);

/**
 * @brief add draw line task
 * @param[in] vgsHdl td_handle: handle of VGS
 * @param[in] osdTaskAttr hi_mapi_vgs_osd_task_attr *: the attribute pointer of VGS add osd task
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_add_osd_task(td_handle vgs_hdl, const hi_mapi_vgs_osd_task_attr *osd_task_attr);
/**
 * @brief commit job
 * @param[in] vgsHdl td_handle: handle of VGS
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_end_job(td_handle vgs_hdl);

/**
 * @brief cabce job
 * @param[in] vgsHdl td_handle: handle of VGS
 * @return Non 0 indicate failed
 * @return  0 indicate success
 */
td_s32 hi_mapi_vgs_cancel_job(td_handle vgs_hdl);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_VGS_H__ */
