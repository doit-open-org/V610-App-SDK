/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_HDMI_H__
#define __HI_MAPI_HDMI_H__

#include "hi_mapi_hdmi_define.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/** \addtogroup     HDMI */
/** @{ */ /** <!-- [HDMI] */

/**
 * @brief init hdmi.
 * @param[in] hdmiId hi_mapi_hdmi_id: handle of hdmi.
 * @param[in] hdmiCallBackFunc hi_mapi_hdmi_call_back_func: hdmi event Callback info.
 * @return 0 init hdmi success.
 * @return Non 0 init hdmi failed.
 */
td_s32 hi_mapi_hdmi_init(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_call_back_func *hdmi_call_back_func);

/**
 * @brief deinit hdmi.
 * @param[in] hdmiId hi_mapi_hdmi_id: handle of hdmi.
 * @return 0 deinit hdmi success.
 * @return Non 0 deinit hdmi failed.
 */
td_s32 hi_mapi_hdmi_deinit(hi_mapi_hdmi_id hdmi_id);

/**
 * @brief get sink capability.
 * @param[in] hdmiId hi_mapi_hdmi_id: handle of hdmi.
 * @param[out] sinkCapability hi_mapi_hdmi_sink_capability: the capability of sink.
 * @return 0 get sink capability success.
 * @return Non 0 get sink capability failed.
 */
td_s32 hi_mapi_hdmi_get_sink_capability(hi_mapi_hdmi_id hdmi_id, hi_mapi_hdmi_sink_capability *sink_capability);

/**
 * @brief get hdmi attr.
 * @param[in] hdmiId hi_mapi_hdmi_id: handle of hdmi.
 * @param[out] hdmiAttr hi_mapi_hdmi_attr: the attr of hdmi.
 * @return 0 get hdmi attr success.
 * @return Non 0 get hdmi attr failed.
 */
td_s32 hi_mapi_hdmi_get_attr(hi_mapi_hdmi_id hdmi_id, hi_mapi_hdmi_attr *hdmi_attr);

/**
 * @brief set hdmi attr.
 * @param[in] hdmiId hi_mapi_hdmi_id: handle of hdmi.
 * @param[in] hdmiAttr hi_mapi_hdmi_attr: the attr of hdmi.
 * @return 0 set hdmi attr success.
 * @return Non 0 set hdmi attr failed.
 */
td_s32 hi_mapi_hdmi_set_attr(hi_mapi_hdmi_id hdmi_id, const hi_mapi_hdmi_attr *hdmi_attr);

/**
 * @brief start hdmi.
 * @param[in] hdmiId hi_mapi_hdmi_id: handle of hdmi.
 * @return 0 start hdmi success.
 * @return Non 0 start hdmi failed.
 */
td_s32 hi_mapi_hdmi_start(hi_mapi_hdmi_id hdmi_id);

/**
 * @brief stop hdmi.
 * @param[in] hdmiId hi_mapi_hdmi_id: handle of hdmi.
 * @return 0 stop hdmi success.
 * @return Non 0 stop hdmi failed.
 */
td_s32 hi_mapi_hdmi_stop(hi_mapi_hdmi_id hdmi_id);

/** @} */ /** <!-- ==== HDMI End ==== */
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_HDMI_H__ */

