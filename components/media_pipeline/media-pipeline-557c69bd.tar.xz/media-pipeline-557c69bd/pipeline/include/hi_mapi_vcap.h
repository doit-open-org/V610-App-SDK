/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __HI_MAPI_VCAP_H__
#define __HI_MAPI_VCAP_H__

#include "hi_mapi_vcap_define.h"


#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */


/** \addtogroup     VCAP */
/** @{ */ /** <!-- [VCAP] */

/**
 * @brief init sensor.
 * @param[in] vcapDevHdl td_handle:handle of video capture device.
 * @param[in] sensorAttr hi_mapi_vcap_sensor_attr *:sensor attribute (dev and sensor are one-to-one).
 * @param[in] resetSensor td_bool:sensor clock reset flag.
 * @return 0  init sensor success.
 * @return Non 0  init sensor fail.
 */
td_s32 hi_mapi_vcap_init_sensor(td_handle vcap_dev_hdl, const hi_mapi_vcap_sensor_attr *sensor_attr, td_bool reset_sensor);

/**
 * @brief deinit sensor,close mipi and sensor clock.
 * @param[in] vcapDevHdl td_handle:handle of video capture device.
 * @return 0  deinit sensor success.
 * @return Non 0  deinit sensor.
 */
td_s32 hi_mapi_vcap_deinit_sensor(td_handle vcap_dev_hdl);

/**
 * @brief Set sensor framerate,Called after isp start
 * @param[in] vcapDevHdl td_handle:handle of video capture device.
 * @param[in] frame_rate td_float:sensor framerate
 * @return 0  Set sensor attribute success.
 * @return Non 0 Set sensor attribute fail.
 */
td_s32 hi_mapi_vcap_set_sensor_frame_rate(td_handle vcap_dev_hdl, td_float frame_rate);

/**
 * @brief Get sensor framerate
 * @param[in] vcapDevHdl td_handle:handle of video capture device.
 * @param[out] frame_rate td_float *:sensor framerate
 * @return 0  Get sensor attribute success.
 * @return Non 0 Get sensor attribute fail.
 */
td_s32 hi_mapi_vcap_get_sensor_frame_rate(td_handle vcap_dev_hdl, td_float *frame_rate);

/**
 * @brief Start VCAP Device
 * @param[in] vcapDevHdl td_handle:handle of video capture device.
 * @return 0  Start VCAP Device success.
 * @return Non 0 Start VCAP Device fail.
 */
td_s32 hi_mapi_vcap_start_dev(td_handle vcap_dev_hdl);

/**
 * @brief Stop VCAP Device
 * @param[in] vcapDevHdl td_handle:handle of video capture device.
 * @return 0  Stop VCAP Device success.
 * @return Non 0 Stop VCAP Device fail.
 */
td_s32 hi_mapi_vcap_stop_dev(td_handle vcap_dev_hdl);

/**
 * @brief Start VCAP Pipe
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @return 0  Start VCAP Pipe success.
 * @return Non 0 Start VCAP Pipe fail.
 */
td_s32 hi_mapi_vcap_start_pipe(td_handle vcap_pipe_hdl);

/**
 * @brief Stop VCAP Pipe
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @return 0  Stop VCAP Pipe success.
 * @return Non 0 Stop VCAP Pipe fail.
 */
td_s32 hi_mapi_vcap_stop_pipe(td_handle vcap_pipe_hdl);

/**
 * @brief Init VCAP ISP
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @return 0  Init VCAP ISP success.
 * @return Non 0 Init VCAP ISP fail.
 */
td_s32 hi_mapi_vcap_init_isp(td_handle vcap_pipe_hdl);

/**
 * @brief deinit VCAP ISP
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @return 0  deinit VCAP ISP success.
 * @return Non 0 deinit VCAP ISP fail.
 */
td_s32 hi_mapi_vcap_deinit_isp(td_handle vcap_pipe_hdl);

/**
 * @brief Start VCAP ISP
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @return 0  Start VCAP ISP success.
 * @return Non 0 Start VCAP ISP fail.
 */
td_s32 hi_mapi_vcap_start_isp(td_handle vcap_pipe_hdl);

/**
 * @brief Stop VCAP ISP
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @return 0  Stop VCAP ISP success.
 * @return Non 0 Stop VCAP ISP fail.
 */
td_s32 hi_mapi_vcap_stop_isp(td_handle vcap_pipe_hdl);

/**
 * @brief Set VCAP attribute
 * @param[in] vcapDevHdl td_handle:handle of video capture device.
 * @param[in] vcapAttr hi_mapi_vcap_attr *:video capture attribute
 * @return 0  Set VCAP attribute success.
 * @return Non 0 Set VCAP attribute fail.
 */
td_s32 hi_mapi_vcap_set_attr(td_handle vcap_dev_hdl, const hi_mapi_vcap_attr *vcap_attr);

/**
 * @brief Get VCAP attribute
 * @param[in] vcapDevHdl td_handle:handle of video capture device.
 * @param[in] vcapAttr hi_mapi_vcap_attr *:video capture attribute
 * @return 0  Get VCAP attribute success.
 * @return Non 0 Get VCAP attribute fail.
 */
td_s32 hi_mapi_vcap_get_attr(td_handle vcap_dev_hdl, hi_mapi_vcap_attr *vcap_attr);

/**
 * @brief set VCAP expand attribute.
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @param[in] pipeChnHdl td_handle:handle of video capture PIPE's CHN.
 * @param[in] command hi_mapi_vcap_cmd:control CMD.
 * @param[in] cmd_attr td_void*:expand attribute struct.
 * @param[in] len td_u32:expand attribute struct length.
 * @return 0  set VCAP expand attribute success.
 * @return Non 0  set VCAP expand attribute fail.
 */
td_s32 hi_mapi_vcap_set_param(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_cmd command,
                              const td_void *cmd_attr, td_u32 len);

/**
 * @brief get VCAP expand attribute.
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @param[in] pipeChnHdl td_handle:handle of video capture PIPE's channel.
 * @param[in] command hi_mapi_vcap_cmd:control CMD.
 * @param[out] cmd_attr td_void*:expand attribute struct.
 * @param[in] len td_u32:expand attribute struct length.
 * @return 0  get VCAP expand attribute success.
 * @return Non 0  get VCAP expand attribute fail.
 */
td_s32 hi_mapi_vcap_get_param(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_cmd command,
                              td_void *cmd_attr, td_u32 len);

/**
 * @brief set VCAP static config attribute.
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @param[in] pipeChnHdl td_handle:handle of video capture PIPE's CHN.
 * @param[in] command hi_mapi_vcap_config_cmd:static config CMD.
 * @param[in] cmd_attr td_void*:config attribute struct.
 * @param[in] len td_u32:config attribute struct length.
 * @return 0  set VCAP static config success.
 * @return Non 0  set VCAP static config fail.
 */
td_s32 hi_mapi_vcap_set_config(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_config_cmd command,
                               const td_void *cmd_attr, td_u32 len);

/**
 * @brief get VCAP static config attribute.
 * @attention Returns the cached static config (set via hi_mapi_vcap_set_config).
 *            May be called before hi_mapi_vcap_start_dev.
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @param[in] pipeChnHdl td_handle:handle of video capture PIPE's channel.
 * @param[in] command hi_mapi_vcap_config_cmd:static config CMD.
 * @param[out] cmd_attr td_void*:config attribute struct.
 * @param[in] len td_u32:config attribute struct length.
 * @return 0  get VCAP static config success.
 * @return Non 0  get VCAP static config fail.
 */
td_s32 hi_mapi_vcap_get_config(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl, hi_mapi_vcap_config_cmd command,
                               td_void *cmd_attr, td_u32 len);

/**
 * @brief Start VCAP channel
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @param[in] pipeChnHdl td_handle:handle of video capture PIPE's channel.
 * @param[in] cmd_attr td_void*:expand attribute struct.
 * @param[in] len td_u32:expand attribute struct length.
 * @return 0  Start VCAP CHN success.
 * @return Non 0 Start VCAP CHN fail.
 */
td_s32 hi_mapi_vcap_start_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl);

/**
 * @brief Stop VCAP channel
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @param[in] pipeChnHdl td_handle:handle of video capture PIPE's channel.
 * @return 0  Stop VCAP CHN success.
 * @return Non 0 Stop VCAP CHN fail.
 */
td_s32 hi_mapi_vcap_stop_chn(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl);

/**
 * @brief Get a frame from VCAP channel
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @param[in] pipeChnHdl td_handle:handle of video capture PIPE's channel.
 * @param[out] frame_data hi_mapi_frame_data *:frame data got from the channel.
 * @return 0  Get VCAP CHN frame success.
 * @return Non 0 Get VCAP CHN frame fail.
 */
td_s32 hi_mapi_vcap_get_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
                                  hi_mapi_frame_data *frame_data);

/**
 * @brief Release a frame got from VCAP channel
 * @param[in] vcapPipeHdl td_handle:handle of video capture PIPE.
 * @param[in] pipeChnHdl td_handle:handle of video capture PIPE's channel.
 * @param[in] frame_data hi_mapi_frame_data *:frame data to be released.
 * @return 0  Release VCAP CHN frame success.
 * @return Non 0 Release VCAP CHN frame fail.
 */
td_s32 hi_mapi_vcap_release_chn_frame(td_handle vcap_pipe_hdl, td_handle pipe_chn_hdl,
                                      const hi_mapi_frame_data *frame_data);

/** @} */ /** <!-- ==== VCAP End ==== */

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __HI_MAPI_VCAP_H__ */
