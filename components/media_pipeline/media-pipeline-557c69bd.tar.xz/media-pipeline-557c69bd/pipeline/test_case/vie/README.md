# sample_pipeline_vie

展示 **VCAP(VI) → VPSS → VENC** 通路功能，演示从 sensor 采集、经 VPSS 处理、到 VENC 编码落盘的完整直调流程，并可选地往码流叠加 OSD。

**功能特性：**

- 完整编码通路：启动 VI→VPSS→VENC 通路，把编码码流写入当前目录下的文件
- 多种在线/离线组合：交互式选择 VI/VPSS 的 online/offline 模式
- H.265 / H.264 双协议：交互式选择编码协议并落盘对应裸流文件
- 可选 OSD 叠加：BITMAP（绑 VENC）/ CIRCLE（绑 VPSS），均不依赖字库，详见[功能说明](#功能说明)

通路拓扑（句柄均为 0）：

```
 sensor(HY006_3814_0011) ──MIPI RAW12──► VCAP(VI) ──bind──► VPSS ──bind──► VENC ──callback──► *.h265 / *.h264
                                  pipe0/chn0        grp0/chn0       chn0              (当前目录)
                                                      ▲              ▲
                                                  CIRCLE OSD     BITMAP OSD     ← 可选叠加点
```

---

## 目录结构

```
vie/
├── CMakeLists.txt          # 构建 sample_pipeline_vie 可执行文件
├── README.md               # sample_pipeline_vie 使用说明
└── sample_pipeline_vie.c   # 示例源码
```

## 前提条件

- Hi3516CV610 社区版 SDK：由编译流程自动从开源社区仓库 `https://gitcode.com/HiSpark/Hi3516CV610` clone到 `_build/`，提供BSP 工具链与 MPP 库
- 交叉工具链 `arm-v01c02-linux-musleabi-`，需已加入 `PATH`（默认安装于 `/opt/linux/x86-arm/...`）
- 板端须已烧录可正常启动的镜像（含内核、根文件系统等）；镜像不要求与本 sample 一一对应，可使用 gui 案例 `square_lcd_video_ui` 的编译产物（见[编译](#编译)）
- 硬件接线见 [附录 · 硬件方案](#硬件方案)；更换 sensor 见 [功能说明 · 适配其他 sensor](#适配其他-sensor)

默认采集参数：

| 项目 | 取值 |
| --- | --- |
| Sensor | HY006_3814_0011，MIPI RAW12，BGGR，2 lane |
| 分辨率 | 2560 × 1440 |
| 帧率 | 30 fps |
| 像素格式 | YVU420 SemiPlanar |
| 码率 | 4000 kbps |

## 编译

在项目根目录（`hi_aiot_solution/`）分两步执行：先编译可烧写镜像，再编译本 sample 的可执行文件。

### 步骤 1：编译烧录镜像（gui 案例 square_lcd_video_ui）

```bash
bash scripts/build.sh build --target cv610_ev_board samples gui/square_lcd_video_ui
```

> 该镜像由 gui 案例 [`square_lcd_video_ui`](../../../../../apps/cv610_ev_board/samples/gui/square_lcd_video_ui/README.md) 编译产出，含内核 + rootfs + 屏幕/触摸驱动 + ko，烧录到板端即可。

编译产物：

```
_build/install/image/gui/  # square_lcd_video_ui 烧录镜像（含内核 + rootfs + 屏幕/触摸驱动 + ko）
```

### 步骤 2：清理上一步产物，再编译测试程序

```bash
# 保存上一步的编译产物再清理上一步编译产物（共用同一 _build 目录，不清除会互相干扰）
rm -rf _build

bash scripts/build.sh build --target cv610_ev_board samples framework_media
```

编译产物：

```
_build/test_case/vie/sample_pipeline_vie  # 测试程序可执行文件
```

## 烧写

步骤 1 的 `square_lcd_video_ui` 镜像包含可烧写的文件系统镜像，使用 Toolplatform 烧写，具体参考[烧录到开发板文档](https://gitcode.com/HiSpark/hi_aiot_solution/blob/master/docs/Instruction/burning-guide.md)的 Toolplatform 章节；uboot 能够正常运行的开发板，可参考该文档中的 `build.sh` 相关章节。

步骤 2 的 `sample_pipeline_vie` 可执行文件不包含在镜像中，按[上板运行](#上板运行)经 nfs mount / scp 传输到板端可写目录后运行。

## 上板运行

将步骤 1 镜像烧录到开发板后，在开发板 shell 中按以下顺序执行：

```bash
# 1. 加载内核 MPP 驱动模块（必须最先执行）
cd /drv/ko/load_ko/
./load3516cv610_20s_debug -a

# 2. 启动 sdk_server
cd ~
./sdk_server &

# 3. 配置开发板 IP 并启动 telnet 服务
ifconfig eth0 xxx.xxx.xxx.xxx; telnetd &

# 4. nfs mount 将 sample_pipeline_vie 挂载到单板上的可写目录（如 /mnt）

# 5. 运行示例（码流写入当前工作目录）
cd /mnt
chmod +x ./sample_pipeline_vie
./sample_pipeline_vie
```

> 加载脚本有多个变体，命名规则为 `load3516cv610_<规格><封装>[_debug]`，需与实际板卡/封装匹配；`_debug` 为带调试信息版本，`-a` 表示加载全部驱动。加载完成后可用 `lsmod` 确认模块已就位。
>
> 码流文件写到“当前工作目录”，请在一个可写目录（如 `/mnt`）下启动程序，避免写入只读分区失败。
>
> 程序启动后的三次交互式选择见[功能说明 · 交互式选择](#交互式选择)

### 退出应用

应用响应 `Ctrl-C`，退出时自动停止视频通路并释放所有媒体资源；也会在抓取帧数达到 `MAX_SAVE_FRAME_COUNT` 时自动退出（见[功能说明 · 抓取帧数限制](#抓取帧数限制)）。

## 功能说明

### 交互式选择

程序启动后会提示三次选择，随后拉起整条媒体通路，把编码码流写入当前目录下的文件，直到 `Ctrl-C` 退出，或抓取帧数达到上限后自动停止：

1. **VI/VPSS online/offline 模式**
   - `(0)` VI_ONLINE_VPSS_ONLINE（默认）
   - `(1)` VI_ONLINE_VPSS_OFFLINE
   - `(2)` VI_OFFLINE_VPSS_ONLINE
   - `(3)` VI_OFFLINE_VPSS_OFFLINE
2. **编码协议**
   - `(0)` H.265（默认，输出 `sample_pipeline_vie.h265`）
   - `(1)` H.264（输出 `sample_pipeline_vie.h264`）
3. **OSD 类型**（是否往码流叠加 OSD，两种类型均**不依赖字库**，详见 [OSD 类型](#osd-类型)）
   - `(0)` NONE —— 不添加 OSD（默认，行为与原 sample 一致）
   - `(1)` BITMAP —— ARGB1555 棋盘格位图，绑定 **VENC** 通道，直接进编码码流
   - `(2)` CIRCLE —— 矩形边框，绑定 **VPSS** 通道（SDK 禁止 CIRCLE 绑 VENC），经 VPSS→VENC 进码流

交互示例：

```
vi vpss mode list:
    (0) VI_ONLINE_VPSS_ONLINE
    ...
please select mode:
0
Pipeline mode: VI ONLINE, VPSS ONLINE
encode protocol list:
    (0) H.265
    (1) H.264
please select protocol:
0
Encode protocol: H.265
osd type list:
    (0) NONE   (no osd overlay)
    (1) BITMAP (ARGB1555 checkerboard, bind VENC)
    (2) CIRCLE (rectangle box, bind VPSS)
please select osd type:
1
OSD type: BITMAP(bind VENC)
Pipeline running, encoding to ./sample_pipeline_vie.h265. Press Ctrl-C to stop.
```

> 输入非法字符会重新打印菜单；通过管道/重定向输入（EOF）时取默认值 `0`。

### OSD 类型

本 sample 提供两种 OSD 类型（均不依赖字库）：

| 类型 | 绑定模块 | 内容 | 说明 |
| --- | --- | --- | --- |
| BITMAP | VENC | ARGB1555 棋盘格（蓝 `0x801F` / 白 `0xFFFF` 交替，块边长 16px） | 像素 alpha 位恒为 1（不透明），真正“半透明”由 disp `fg_alpha=128`(≈50%) 控制；只影响这一路码流 |
| CIRCLE | VPSS | `128×64` 矩形边框 | CIRCLE 不能绑 VENC，绑 VPSS 后边框随 VPSS→VENC 进入码流 |

- OSD 默认大小 `128×64`，起始坐标 `(64, 64)`，坐标按 **2 像素对齐**；可在源码 `OSD_*` 宏处调整。
- OSD 在 `start_venc()` 之后启动（被绑通道须已就绪），退出时先 `stop`/`deinit` 再释放位图内存。

### 抓取帧数限制

为避免长时间运行写出过大的码流文件，VENC 回调内置了抓取帧数上限，由源码中的宏控制：

```c
#define MAX_SAVE_FRAME_COUNT 20000
```

每收到一帧编码码流计数一次，累计写入达到 `MAX_SAVE_FRAME_COUNT`（默认 `20000` 帧）后，程序打印 `reach max frame count 20000, quit` 并自动退出，无需 `Ctrl-C`。按默认 30 fps 估算，约对应 11 分钟码流。需要更长或更短的录制时长时，修改该宏后重新编译即可。

### 适配其他 sensor

sample 默认适配 **HY006_3814_0011**。更换 sensor 需同时改以下两个文件：

**1. [sample_pipeline_vie.c](./sample_pipeline_vie.c)**

| 位置 | 当前值 | 说明 |
|------|--------|------|
| `FRAME_WIDTH` / `FRAME_HEIGHT` / `FRAME_RATE` 宏 | `2560` / `1440` / `30` | 改为新 sensor 的输出分辨率和帧率 |
| `extern struct ot_isp_sns_obj *hy006_3814_0011_get_obj(...)` | `hy006_3814_0011_get_obj` | 改为新 sensor 的 obj getter 函数名 |
| `fill_sensor_attr()` — `input_data_type` | `HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_12BIT` | 改为新 sensor 的 RAW 位深 |
| `fill_sensor_attr()` — `sensor_obj` | `hy006_3814_0011_get_obj()` | 改为新 sensor 的 obj getter 调用 |
| `fill_sensor_attr()` — `data_rate` | `HI_MAPI_VCAP_MIPI_DATA_RATE_X1` | 改为新 sensor 的 MIPI 数据速率档位 |
| `fill_sensor_attr()` — `bayer_format` | `HI_MAPI_VCAP_BAYER_FORMAT_BGGR` | 改为新 sensor 的 Bayer 排列 |
| `fill_sensor_attr()` — `lane_id[]` | `{0, 2, -1, -1}` | 改为新 sensor 的 MIPI lane 映射 |

**2. [CMakeLists.txt](./CMakeLists.txt)**

```cmake
# sensor —— 换板时改这里
sns_hy006_3814_0011
```

将 `sns_hy006_3814_0011` 替换为新 sensor 对应的静态库名称（须与 SDK 中已提供的 `libsns_*.so` 一致）。

## 故障排查

| 现象 | 处理 |
| --- | --- |
| 链接报 undefined reference | sensor 库与 [CMakeLists.txt](./CMakeLists.txt) 中 `_sdk_libs` 列表不一致；pipeline 为 monolithic 静态库，audio/codec 依赖链需保持完整 |
| 启动即 `fopen ... failed` | 当前目录不可写，改到 `/mnt` 等可写目录再启动 |
| proc 节点无数据 / 启动失败 | 确认 ko 已加载、`LD_LIBRARY_PATH` 指向 SDK so，sensor 型号与接线匹配；先看 `/proc/umap/mipi_rx` 的 `mipi_vc0_w/h` 是否有正确分辨率 |
| 码流花屏 | 核对 sensor bayer/lane 配置与实际硬件是否一致；对照 `/proc/umap/mipi_rx` 末尾的信号质量/lane 诊断提示 |
| 各级 proc 帧计数不增长 | 从 `mipi_rx` 往后逐级定位：哪一级“收帧”不涨，问题就在它与上一级之间（绑定/在线模式/分辨率不匹配） |
| 选了 OSD 但码流看不到叠加 | 确认所选类型对应的通道已起（BITMAP→VENC，CIRCLE→VPSS）；起始坐标 `(64,64)` 与大小 `128×64` 未超出画面；BITMAP 若过淡可调大源码 `OSD_BMP_FG_ALPHA` |

## 清理

在项目工程目录下使用命令 `rm -rf _build` 清理编译产物和中间产物。

```bash
rm -rf _build
```

---

# 附录

## 硬件方案

### 硬件规格

- 开发板：cv610_ev_board
- Sensor：HY006_3814_0011，MIPI RAW12，BGGR，2 lane（data_rate x1）
- 采集分辨率 / 帧率：2560 × 1440 @ 30fps（其余默认参数见[前提条件](#前提条件)）


## 相关文档

| 文档 | 说明 |
|------|------|
| [`apps/cv610_ev_board/samples/gui/square_lcd_video_ui/README.md`](../../../../../apps/cv610_ev_board/samples/gui/square_lcd_video_ui/README.md) | 步骤 1 烧录镜像所用 gui 案例 |

