/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#include "hi_mapi_sys.h"
#include "hi_mapi_vcap.h"
#include "hi_mapi_vpss.h"
#include "hi_mapi_venc.h"
#include "hi_mapi_osd.h"
#include "hi_mapi_osd_define.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_vcap_define.h"
#include "hi_mapi_vpss_define.h"
#include "hi_mapi_venc_define.h"
#include "hi_log.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

/* Handles & resolution */
#define VCAP_DEV_HDL    0
#define VCAP_PIPE_HDL   0
#define PIPE_CHN_HDL    0
#define VPSS_GRP_HDL    0
#define VPSS_CHN_HDL    0
#define VENC_HDL        0

#define FRAME_WIDTH     2560
#define FRAME_HEIGHT    1440
#define FRAME_RATE      30
#define MAX_SAVE_FRAME_COUNT 20000

/* OSD overlay (see select_osd_type / start_osd). Both types need no font lib. */
#define OSD_IDX             0
#define OSD_W               128   /* OSD width  (bitmap / circle box) */
#define OSD_H               64    /* OSD height (bitmap / circle box) */
#define OSD_X               64    /* OSD start x, 2-pixel aligned */
#define OSD_Y               64    /* OSD start y, 2-pixel aligned */
#define OSD_BMP_TILE        16    /* checkerboard tile side, in pixels */
#define OSD_BMP_FG_ALPHA    128   /* bitmap fg alpha (0~255, 128 ~ 50% blend) */
#define OSD_CIRCLE_FG_ALPHA 255   /* circle box fg alpha, opaque */

#define OUTPUT_FILE_H265   "./sample_pipeline_vie.h265"
#define OUTPUT_FILE_H264   "./sample_pipeline_vie.h264"

/* VI/VPSS online/offline selection (see select_vi_vpss_mode) */
static td_bool g_vi_online   = TD_FALSE;
static td_bool g_vpss_online = TD_FALSE;

/* Encoding protocol selection (see select_payload_type) */
static hi_mapi_payload_type g_payload_type = HI_MAPI_PAYLOAD_TYPE_H265;
static const td_char       *g_output_file  = OUTPUT_FILE_H265;

/* OSD type selection (see select_osd_type). NONE keeps the original behaviour. */
typedef enum {
    OSD_TYPE_NONE = 0,   /* no OSD overlay */
    OSD_TYPE_BITMAP,     /* ARGB1555 checkerboard bitmap, bound to VENC */
    OSD_TYPE_CIRCLE      /* rectangle box (CIRCLE), bound to VPSS */
} osd_sel;
static osd_sel  g_osd_sel = OSD_TYPE_NONE;
static td_u16  *g_osd_bmp = TD_NULL;   /* bitmap canvas, malloc'd in make_osd_bitmap */

struct ot_isp_sns_obj;
extern struct ot_isp_sns_obj *hy006_3814_0011_get_obj(td_void);

static FILE *g_stream_fp = TD_NULL;
static volatile sig_atomic_t g_quit = 0;
static td_u32 g_saved_frame_cnt = 0;

static td_void sigint_handler(int signo)
{
    (void)signo;
    g_quit = 1;
}

/* VENC callback: dump every pack to file */
static td_s32 venc_data_cb(td_handle venc_hdl, hi_mapi_venc_data_attr *stream, td_void *priv)
{
    (void)venc_hdl;
    (void)priv;
    if (g_stream_fp == TD_NULL || stream == TD_NULL) {
        return TD_SUCCESS;
    }
    if (g_saved_frame_cnt >= MAX_SAVE_FRAME_COUNT) {
        if (!g_quit) {
            g_quit = 1;
            HI_LOGI("VIE", "reach max frame count %d, quit", MAX_SAVE_FRAME_COUNT);
        }
        return TD_SUCCESS;
    }
    for (td_u32 i = 0; i < stream->pack_count; i++) {
        hi_mapi_venc_data_pack_attr *pack = &stream->data_pack[i];
        for (td_u32 j = 0; j < HI_MAPI_VENC_PACK_NUM; j++) {
            if (pack->vir_addr[j] == TD_NULL || pack->len[j] == 0) {
                continue;
            }
            td_u32 start_off = (j == 0) ? pack->offset : 0;
            if (start_off >= pack->len[j]) {
                continue;
            }
            (void)fwrite(pack->vir_addr[j] + start_off, 1, pack->len[j] - start_off, g_stream_fp);
        }
    }
    g_saved_frame_cnt++;
    return TD_SUCCESS;
}

/* MIPI RAW12, YVU420SP capture */
static td_void fill_sensor_attr(hi_mapi_vcap_sensor_attr *sensor_attr)
{
    (void)memset(sensor_attr, 0, sizeof(*sensor_attr));
    sensor_attr->sns_mode = 0;
    sensor_attr->wdr_mode = HI_MAPI_VCAP_WDR_MODE_NONE;
    sensor_attr->size.width  = FRAME_WIDTH;
    sensor_attr->size.height = FRAME_HEIGHT;

    sensor_attr->input_dev_attr.input_mode      = HI_MAPI_VCAP_INPUT_MODE_MIPI;
    sensor_attr->input_dev_attr.input_data_type = HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_12BIT;
    sensor_attr->input_dev_attr.use_serdes_dev  = TD_FALSE;

    sensor_attr->sns_dev_attr.sensor_obj = (td_void *)hy006_3814_0011_get_obj();
    sensor_attr->sns_dev_attr.data_rate  = HI_MAPI_VCAP_MIPI_DATA_RATE_X1;
    sensor_attr->sns_dev_attr.input_attr.bayer_format    = HI_MAPI_VCAP_BAYER_FORMAT_RGGB;
    sensor_attr->sns_dev_attr.input_attr.comm_bus_type   = HI_MAPI_SENSOR_COMMBUS_TYPE_I2C;
    sensor_attr->sns_dev_attr.input_attr.sensor_dev_addr = 0;
    for (td_u32 i = 0; i < HI_MAPI_SENSOR_MAX_LANE_NUM; i++) {
        sensor_attr->sns_dev_attr.lane_id[i] = -1;
    }
    sensor_attr->sns_dev_attr.lane_id[0] = 0;
    sensor_attr->sns_dev_attr.lane_id[1] = 2;
}

static td_void fill_vcap_attr(hi_mapi_vcap_attr *vcap_attr)
{
    (void)memset(vcap_attr, 0, sizeof(*vcap_attr));

    vcap_attr->vcap_dev_attr.wdr_mode  = HI_MAPI_VCAP_WDR_MODE_NONE;
    vcap_attr->vcap_dev_attr.intf_mode = HI_MAPI_VCAP_MODE_MIPI;
    vcap_attr->vcap_dev_attr.data_seq  = HI_MAPI_DATA_SEQ_YUYV;
    vcap_attr->vcap_dev_attr.data_type = HI_MAPI_VCAP_DATA_TYPE_RGB; /* MIPI RAW Bayer */

    vcap_attr->pipe_bind_num   = 1;
    vcap_attr->pipe_id_bind[0] = VCAP_PIPE_HDL;

    hi_mapi_vcap_pipe_attr *pipe_attr = &vcap_attr->vcap_pipe_attr[VCAP_PIPE_HDL];
    pipe_attr->pipe_type                    = HI_MAPI_VCAP_PIPE_TYPE_VIDEO;
    pipe_attr->frame_rate_ctrl.src_frame_rate = -1;
    pipe_attr->frame_rate_ctrl.dst_frame_rate = -1;
    pipe_attr->isp_pub_attr.frame_rate      = (td_float)FRAME_RATE;
    pipe_attr->isp_pub_attr.size.width      = FRAME_WIDTH;
    pipe_attr->isp_pub_attr.size.height     = FRAME_HEIGHT;
    pipe_attr->isp_pub_attr.bayer           = HI_MAPI_VCAP_BAYER_RGGB;
    pipe_attr->isp_pub_attr.sns_mirror_flip = HI_MAPI_VCAP_ISP_SNS_NORMAL;
    pipe_attr->vb_pool_blk_cnt              = 0;

    hi_mapi_vcap_pipe_chn_attr *chn_attr = &pipe_attr->pipe_chn_attr[PIPE_CHN_HDL];
    chn_attr->dest_size.width                = FRAME_WIDTH;
    chn_attr->dest_size.height               = FRAME_HEIGHT;
    chn_attr->frame_rate_ctrl.src_frame_rate = FRAME_RATE;
    chn_attr->frame_rate_ctrl.dst_frame_rate = FRAME_RATE;
    chn_attr->pixel_format                   = HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    chn_attr->video_format                   = HI_MAPI_VIDEO_FORMAT_LINEAR;
    chn_attr->vb_pool_blk_cnt                = 0;
}

static td_void fill_grp_attr(hi_mapi_vpss_grp_attr *grp_attr)
{
    (void)memset(grp_attr, 0, sizeof(*grp_attr));
    grp_attr->max_width  = FRAME_WIDTH;
    grp_attr->max_height = FRAME_HEIGHT;
    grp_attr->frame_rate_ctrl.src_frame_rate = -1;
    grp_attr->frame_rate_ctrl.dst_frame_rate = -1;
    grp_attr->pixel_format = HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    grp_attr->is_nr_en     = TD_FALSE;
}

static td_void fill_chn_attr(hi_mapi_vpss_chn_attr *chn_attr)
{
    (void)memset(chn_attr, 0, sizeof(*chn_attr));
    chn_attr->width  = FRAME_WIDTH;
    chn_attr->height = FRAME_HEIGHT;
    chn_attr->support_buffer_share = TD_FALSE;
    chn_attr->frame_rate_ctrl.src_frame_rate = -1;
    chn_attr->frame_rate_ctrl.dst_frame_rate = -1;
    chn_attr->video_format      = HI_MAPI_VIDEO_FORMAT_LINEAR;
    chn_attr->pixel_format      = HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    chn_attr->compress_mode     = HI_MAPI_COMPRESS_MODE_NONE;
    chn_attr->aspect_ratio.mode = HI_MAPI_ASPECT_RATIO_NONE;
}

/* Bind helpers (VI/VPSS, VPSS/VENC via hi_mapi_sys_bind) */
static td_void make_chn(hi_mapi_mpp_chn *chn, hi_mapi_module_id mod_id, td_s32 dev_id, td_s32 chn_id)
{
    chn->mod_id = mod_id;
    chn->dev_id = dev_id;
    chn->chn_id = chn_id;
}

static td_s32 bind_vi_vpss(td_void)
{
    hi_mapi_mpp_chn src, dst;
    make_chn(&src, HI_MAPI_MOD_VCAP, VCAP_PIPE_HDL, PIPE_CHN_HDL);
    make_chn(&dst, HI_MAPI_MOD_VPSS, VPSS_GRP_HDL,  0);
    return hi_mapi_sys_bind(&src, &dst);
}

static td_void unbind_vi_vpss(td_void)
{
    hi_mapi_mpp_chn src, dst;
    make_chn(&src, HI_MAPI_MOD_VCAP, VCAP_PIPE_HDL, PIPE_CHN_HDL);
    make_chn(&dst, HI_MAPI_MOD_VPSS, VPSS_GRP_HDL,  0);
    (void)hi_mapi_sys_unbind(&src, &dst);
}

static td_s32 bind_vpss_venc(td_void)
{
    hi_mapi_mpp_chn src, dst;
    make_chn(&src, HI_MAPI_MOD_VPSS, VPSS_GRP_HDL, VPSS_CHN_HDL);
    make_chn(&dst, HI_MAPI_MOD_VENC, 0,            VENC_HDL);
    return hi_mapi_sys_bind(&src, &dst);
}

static td_void unbind_vpss_venc(td_void)
{
    hi_mapi_mpp_chn src, dst;
    make_chn(&src, HI_MAPI_MOD_VPSS, VPSS_GRP_HDL, VPSS_CHN_HDL);
    make_chn(&dst, HI_MAPI_MOD_VENC, 0,            VENC_HDL);
    (void)hi_mapi_sys_unbind(&src, &dst);
}

#define CHECK_GOTO(expr, label) do { \
        ret = (expr); \
        if ((ret) != TD_SUCCESS) { \
            HI_LOGE("CHECK_GOTO", "%s failed, ret=0x%x", #expr, (unsigned int)(ret)); \
            goto label; \
        } \
    } while (0)

static td_s32 start_vcap(const hi_mapi_vcap_sensor_attr *sensor_attr, const hi_mapi_vcap_attr *vcap_attr)
{
    td_s32 ret;
    CHECK_GOTO(hi_mapi_vcap_init_sensor(VCAP_DEV_HDL, sensor_attr, TD_TRUE), err);
    CHECK_GOTO(hi_mapi_vcap_set_attr   (VCAP_DEV_HDL, vcap_attr),            err);
    CHECK_GOTO(hi_mapi_vcap_start_dev  (VCAP_DEV_HDL),                       err);
    CHECK_GOTO(hi_mapi_vcap_start_chn  (VCAP_PIPE_HDL, PIPE_CHN_HDL),        err);
    CHECK_GOTO(hi_mapi_vcap_init_isp   (VCAP_PIPE_HDL),                      err);
    CHECK_GOTO(hi_mapi_vcap_start_pipe (VCAP_PIPE_HDL),                      err);
    CHECK_GOTO(hi_mapi_vcap_start_isp  (VCAP_PIPE_HDL),                      err);
    return TD_SUCCESS;
err:
    return ret;
}

static td_void stop_vcap(td_void)
{
    (void)hi_mapi_vcap_stop_isp   (VCAP_PIPE_HDL);
    (void)hi_mapi_vcap_stop_pipe  (VCAP_PIPE_HDL);
    (void)hi_mapi_vcap_deinit_isp (VCAP_PIPE_HDL);
    (void)hi_mapi_vcap_stop_chn   (VCAP_PIPE_HDL, PIPE_CHN_HDL);
    (void)hi_mapi_vcap_stop_dev   (VCAP_DEV_HDL);
    (void)hi_mapi_vcap_deinit_sensor(VCAP_DEV_HDL);
}

static td_s32 start_vpss(const hi_mapi_vpss_grp_attr *grp_attr, const hi_mapi_vpss_chn_attr *chn_attr)
{
    td_s32 ret;
    CHECK_GOTO(hi_mapi_vpss_init        (VPSS_GRP_HDL, grp_attr),               err);
    CHECK_GOTO(bind_vi_vpss(),                                                  err);
    CHECK_GOTO(hi_mapi_vpss_set_chn_attr(VPSS_GRP_HDL, VPSS_CHN_HDL, chn_attr), err);
    CHECK_GOTO(hi_mapi_vpss_start_chn   (VPSS_GRP_HDL, VPSS_CHN_HDL),           err);
    return TD_SUCCESS;
err:
    return ret;
}

static td_void stop_vpss(td_void)
{
    (void)hi_mapi_vpss_stop_chn(VPSS_GRP_HDL, VPSS_CHN_HDL);
    unbind_vi_vpss();
    (void)hi_mapi_vpss_deinit(VPSS_GRP_HDL);
}

static td_s32 start_venc(const hi_mapi_venc_attr *venc_attr, hi_mapi_venc_call_back *cb)
{
    td_s32 ret;
    CHECK_GOTO(hi_mapi_venc_init             (VENC_HDL, venc_attr), err);
    CHECK_GOTO(hi_mapi_venc_register_callback(VENC_HDL, cb),        err);
    CHECK_GOTO(bind_vpss_venc(),                                    err);
    CHECK_GOTO(hi_mapi_venc_start(VENC_HDL, HI_MAPI_VENC_LIMITLESS_FRAME_COUNT), err);
    return TD_SUCCESS;
err:
    return ret;
}

static td_void stop_venc(hi_mapi_venc_call_back *cb)
{
    (void)hi_mapi_venc_stop(VENC_HDL);
    unbind_vpss_venc();
    (void)hi_mapi_venc_un_register_callback(VENC_HDL, cb);
    (void)hi_mapi_venc_deinit(VENC_HDL);
}

/*
 * Read a validated single-char menu choice in [lo, hi], mirroring the SDK
 * sample_pipeline_vie input loop. Re-prints the list on invalid input; returns lo on
 * EOF/interrupt so the caller falls back to its default option.
 */
static td_char read_menu_choice(td_void (*print_list)(td_void), td_char lo, td_char hi)
{
    td_char input[8] = {0};

    print_list();
    while (!g_quit) {
        if (fgets(input, sizeof(input), stdin) == TD_NULL) {
            return lo;
        }
        size_t len = strlen(input);
        if (len > 0 && input[len - 1] == '\n') {
            input[--len] = '\0';
        }
        if (len == 1 && input[0] >= lo && input[0] <= hi) {
            return input[0];
        }
        printf("\nInvalid param, please enter again!\n\n");
        print_list();
    }
    return lo;
}

/*
 * VI/VPSS online/offline selection, mirroring the SDK sample_pipeline_vie menu:
 *   (0) VI_ONLINE_VPSS_ONLINE   (1) VI_ONLINE_VPSS_OFFLINE
 *   (2) VI_OFFLINE_VPSS_ONLINE  (3) VI_OFFLINE_VPSS_OFFLINE
 */
static td_void print_mode_list(td_void)
{
    printf("vi vpss mode list:\n");
    printf("    (0) VI_ONLINE_VPSS_ONLINE\n");
    printf("    (1) VI_ONLINE_VPSS_OFFLINE\n");
    printf("    (2) VI_OFFLINE_VPSS_ONLINE\n");
    printf("    (3) VI_OFFLINE_VPSS_OFFLINE\n");
    printf("please select mode:\n");
}

static td_void set_mode_by_char(td_char ch)
{
    switch (ch) {
        case '0':
            g_vi_online = TD_TRUE;  g_vpss_online = TD_TRUE;  break;
        case '1':
            g_vi_online = TD_TRUE;  g_vpss_online = TD_FALSE; break;
        case '2':
            g_vi_online = TD_FALSE; g_vpss_online = TD_TRUE;  break;
        case '3':
            g_vi_online = TD_FALSE; g_vpss_online = TD_FALSE; break;
        default:
            g_vi_online = TD_TRUE;  g_vpss_online = TD_TRUE;  break;
    }
}

static td_void select_vi_vpss_mode(td_void)
{
    set_mode_by_char(read_menu_choice(print_mode_list, '0', '3'));

    HI_LOGI("VIE", "Pipeline mode: VI %s, VPSS %s",
        g_vi_online   ? "ONLINE" : "OFFLINE",
        g_vpss_online ? "ONLINE" : "OFFLINE");
}

/* Encoding protocol selection: (0) H.265  (1) H.264 */
static td_void print_payload_list(td_void)
{
    printf("encode protocol list:\n");
    printf("    (0) H.265\n");
    printf("    (1) H.264\n");
    printf("please select protocol:\n");
}

static td_void set_payload_by_char(td_char ch)
{
    switch (ch) {
        case '1':
            g_payload_type = HI_MAPI_PAYLOAD_TYPE_H264;
            g_output_file  = OUTPUT_FILE_H264;
            break;
        case '0':
        default:
            g_payload_type = HI_MAPI_PAYLOAD_TYPE_H265;
            g_output_file  = OUTPUT_FILE_H265;
            break;
    }
}

static td_void select_payload_type(td_void)
{
    set_payload_by_char(read_menu_choice(print_payload_list, '0', '1'));

    HI_LOGI("VIE", "Encode protocol: %s",
        (g_payload_type == HI_MAPI_PAYLOAD_TYPE_H265) ? "H.265" : "H.264");
}

/*
 * OSD type selection: (0) none  (1) BITMAP(bind VENC)  (2) CIRCLE(bind VPSS).
 * Both BITMAP and CIRCLE need no font lib, so they can be enabled standalone.
 */
static td_void print_osd_list(td_void)
{
    printf("osd type list:\n");
    printf("    (0) NONE   (no osd overlay)\n");
    printf("    (1) BITMAP (ARGB1555 checkerboard, bind VENC)\n");
    printf("    (2) CIRCLE (rectangle box, bind VPSS)\n");
    printf("please select osd type:\n");
}

static td_void set_osd_by_char(td_char ch)
{
    switch (ch) {
        case '1':
            g_osd_sel = OSD_TYPE_BITMAP; break;
        case '2':
            g_osd_sel = OSD_TYPE_CIRCLE; break;
        case '0':
        default:
            g_osd_sel = OSD_TYPE_NONE;   break;
    }
}

static td_void select_osd_type(td_void)
{
    set_osd_by_char(read_menu_choice(print_osd_list, '0', '2'));

    HI_LOGI("VIE", "OSD type: %s",
        (g_osd_sel == OSD_TYPE_BITMAP) ? "BITMAP(bind VENC)" :
        (g_osd_sel == OSD_TYPE_CIRCLE) ? "CIRCLE(bind VPSS)" : "NONE");
}

/*
 * Build an ARGB1555 checkerboard bitmap into g_osd_bmp: blue(0x801F)/white(0xFFFF)
 * alternating tiles, alpha bit = 1 (opaque per pixel; real translucency comes from
 * the disp fg_alpha). Caller frees g_osd_bmp in stop_osd.
 */
static td_s32 make_osd_bitmap(td_void)
{
    size_t pix_count = (size_t)OSD_W * OSD_H;
    g_osd_bmp = (td_u16 *)malloc(pix_count * sizeof(td_u16));
    if (g_osd_bmp == TD_NULL) {
        HI_LOGE("VIE", "malloc osd bitmap failed");
        return TD_FAILURE;
    }
    for (td_u32 y = 0; y < OSD_H; y++) {
        for (td_u32 x = 0; x < OSD_W; x++) {
            td_u32 tile = (x / OSD_BMP_TILE + y / OSD_BMP_TILE) & 1U;
            g_osd_bmp[(size_t)y * OSD_W + x] = tile ? 0x801F : 0xFFFF; /* blue / white */
        }
    }
    return TD_SUCCESS;
}

/* Fill the common display target fields shared by both OSD types. */
static td_void fill_osd_disp(hi_mapi_osd_disp_attr *disp, hi_mapi_osd_bind_mod bind_mod,
    td_handle mod_hdl, td_handle chn_hdl, td_u32 fg_alpha)
{
    (void)memset(disp, 0, sizeof(*disp));
    disp->show           = TD_TRUE;
    disp->binded_mod     = bind_mod;
    disp->mod_hdl        = mod_hdl;
    disp->chn_hdl        = chn_hdl;
    disp->fg_alpha       = fg_alpha;
    disp->bg_alpha       = 0;
    disp->coordinate_mod = HI_MAPI_OSD_COORDINATE_ABS_COOR;
    disp->start_pos.x    = OSD_X;
    disp->start_pos.y    = OSD_Y;
    disp->batch_id       = 0;
}

/*
 * Create the selected OSD and overlay it onto the stream. Must be called after the
 * bound channel exists (BITMAP->VENC, CIRCLE->VPSS), i.e. after start_venc().
 */
static td_s32 start_osd(td_void)
{
    td_s32 ret;
    hi_mapi_osd_attr attr;

    if (g_osd_sel == OSD_TYPE_NONE) {
        return TD_SUCCESS;
    }

    CHECK_GOTO(hi_mapi_osd_init(), err);

    (void)memset(&attr, 0, sizeof(attr));
    attr.disp_num         = 1;
    attr.osd_content.color = 0xFFFF; /* RGB1555 white */

    if (g_osd_sel == OSD_TYPE_BITMAP) {
        CHECK_GOTO(make_osd_bitmap(), err_deinit);

        /* BITMAP can bind VENC (dev fixed to 0) -> directly into the encoded stream */
        fill_osd_disp(&attr.disp_attr[0], HI_MAPI_OSD_BINDMOD_VENC, 0, VENC_HDL, OSD_BMP_FG_ALPHA);
        attr.disp_attr[0].attach_dest = HI_MAPI_ATTACH_JPEG_MAIN; /* only for venc */

        attr.osd_content.type = HI_MAPI_OSD_TYPE_BITMAP;
        attr.osd_content.bitmap_content.pixel_format = HI_MAPI_PIXEL_FORMAT_ARGB_1555;
        attr.osd_content.bitmap_content.width  = OSD_W;
        attr.osd_content.bitmap_content.height = OSD_H;
        attr.osd_content.bitmap_content.data   = (td_void *)g_osd_bmp;
    } else { /* OSD_TYPE_CIRCLE */
        /* CIRCLE cannot bind VENC -> bind VPSS(grp/chn), box flows VPSS->VENC into stream */
        fill_osd_disp(&attr.disp_attr[0], HI_MAPI_OSD_BINDMOD_VPSS, VPSS_GRP_HDL, VPSS_CHN_HDL,
            OSD_CIRCLE_FG_ALPHA);

        attr.osd_content.type = HI_MAPI_OSD_TYPE_CIRCLE;
        attr.osd_content.circle_content.width  = OSD_W;
        attr.osd_content.circle_content.height = OSD_H;
    }

    CHECK_GOTO(hi_mapi_osd_set_attr(OSD_IDX, &attr), err_bmp);
    CHECK_GOTO(hi_mapi_osd_start(OSD_IDX),           err_bmp);
    return TD_SUCCESS;

err_bmp:
    if (g_osd_bmp != TD_NULL) {
        free(g_osd_bmp);
        g_osd_bmp = TD_NULL;
    }
err_deinit:
    (void)hi_mapi_osd_deinit();
err:
    return ret;
}

static td_void stop_osd(td_void)
{
    if (g_osd_sel == OSD_TYPE_NONE) {
        return;
    }
    (void)hi_mapi_osd_stop(OSD_IDX);
    (void)hi_mapi_osd_deinit();
    if (g_osd_bmp != TD_NULL) {
        free(g_osd_bmp);
        g_osd_bmp = TD_NULL;
    }
}

int main(td_void)
{
    td_s32 ret;
    hi_mapi_vcap_sensor_attr sensor_attr;
    hi_mapi_vcap_attr        vcap_attr;
    hi_mapi_vpss_grp_attr    grp_attr;
    hi_mapi_vpss_chn_attr    chn_attr;
    hi_mapi_venc_attr        venc_attr;
    hi_mapi_venc_base_attr   venc_base_attr;
    hi_mapi_sys_base_attr    base_attr;
    hi_mapi_sys_media_attr   media_attr;
    hi_mapi_venc_call_back   cb = {
        .proc_data_cb = venc_data_cb,
        .private_data = TD_NULL,
    };

    signal(SIGINT, sigint_handler);

    /* Select VI/VPSS online/offline mode, then encoding protocol, then OSD type */
    select_vi_vpss_mode();
    select_payload_type();
    select_osd_type();

    /* Attribute prep */
    fill_sensor_attr(&sensor_attr);
    fill_vcap_attr(&vcap_attr);
    fill_grp_attr(&grp_attr);
    fill_chn_attr(&chn_attr);

    (void)memset(&venc_base_attr, 0, sizeof(venc_base_attr));
    venc_base_attr.type           = g_payload_type;
    venc_base_attr.width          = FRAME_WIDTH;
    venc_base_attr.height         = FRAME_HEIGHT;
    venc_base_attr.src_frame_rate = FRAME_RATE;
    venc_base_attr.dst_frame_rate = FRAME_RATE;
    venc_base_attr.bit_rate       = 4000; /* kbps */
    venc_base_attr.qfactor        = 0;
    CHECK_GOTO(hi_mapi_venc_get_default_attr(&venc_base_attr, &venc_attr), exit_none);

    /* System / VB init */
    CHECK_GOTO(hi_mapi_sys_init(), exit_none);

    (void)memset(&base_attr, 0, sizeof(base_attr));
    base_attr.vcap_dev_num             = 1;
    base_attr.vcap_reso_size[0].width  = FRAME_WIDTH;
    base_attr.vcap_reso_size[0].height = FRAME_HEIGHT;
    base_attr.vcap_online[0]           = g_vi_online;
    base_attr.raw_bit_width            = 12;
    base_attr.is_wdr                   = TD_FALSE;
    base_attr.vpss_grp_num             = 1;
    base_attr.vpss_chn_num             = 1;
    base_attr.vpss_reso_size[VPSS_GRP_HDL][VPSS_CHN_HDL].width  = FRAME_WIDTH;
    base_attr.vpss_reso_size[VPSS_GRP_HDL][VPSS_CHN_HDL].height = FRAME_HEIGHT;
    base_attr.vpss_online[0]           = g_vpss_online;

    CHECK_GOTO(hi_mapi_sys_get_default_media_attr(&base_attr, &media_attr), exit_sys);
    CHECK_GOTO(hi_mapi_sys_init_media(&media_attr),                         exit_sys);

    /* Open output file */
    g_stream_fp = fopen(g_output_file, "wb");
    if (g_stream_fp == TD_NULL) {
        HI_LOGE("VIE", "fopen %s failed", g_output_file);
        ret = TD_FAILURE;
        goto exit_media;
    }

    /* Bring up the pipeline */
    CHECK_GOTO(start_vcap(&sensor_attr, &vcap_attr), exit_file);
    CHECK_GOTO(start_vpss(&grp_attr,    &chn_attr),  exit_vcap);
    CHECK_GOTO(start_venc(&venc_attr,   &cb),        exit_vpss);
    CHECK_GOTO(start_osd(),                          exit_venc);

    /* Run */
    printf("Pipeline running, encoding to %s. Press Ctrl-C to stop.\n", g_output_file);
    while (!g_quit) {
        sleep(1);
    }
    printf("Stopping...\n");
    ret = TD_SUCCESS;

    /* Teardown */
    stop_osd();
exit_venc:
    stop_venc(&cb);
exit_vpss:
    stop_vpss();
exit_vcap:
    stop_vcap();
exit_file:
    if (g_stream_fp != TD_NULL) {
        (void)fclose(g_stream_fp);
        g_stream_fp = TD_NULL;
    }
exit_media:
    (void)hi_mapi_sys_deinit_media();
exit_sys:
    (void)hi_mapi_sys_deinit();
exit_none:
    HI_LOGI("VIE", "sample_pipeline_vie exit, ret=0x%x", ret);
    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif
