/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "securec.h"
#include "aac.h"
#include "hi_log.h"

static uint8_t *GetNextADTS(uint8_t *pBufPtr, uint32_t u32Len)
{
    uint8_t *pEndPtr = pBufPtr + u32Len;
    while (pBufPtr < pEndPtr) {
        if (pBufPtr + 1 >= pEndPtr) {
            return NULL;
        }
        if (pBufPtr[0] == 0xFF && pBufPtr[1] == 0xF1) {
            return pBufPtr;
        } else {
            pBufPtr++;
        }
    }
    return NULL;
}

static uint32_t GetAACFrameLen(const uint8_t *adtsHeader)
{
    uint32_t frameLen = 0;
    if (adtsHeader == NULL) {
        return 0;
    }
    uint32_t fBit = adtsHeader[3]; // 3: array index
    uint32_t mBit = adtsHeader[4]; // 4: array index
    uint32_t bBit = adtsHeader[5]; // 5: array index
    frameLen += (bBit >> 5); // 5: right shifting
    frameLen += (mBit << 3); // 3: left shifting
    frameLen += ((fBit & 3) << 11); // 3, 11: left shifting
    return frameLen;
}

int32_t AAC_Open(AAC_Handle_S *pstHandle, const char *pszFilePath)
{
    if (pstHandle == NULL) {
        HI_LOGE("AUDIO", "pstHandle is null");
        return -1;
    }
    if (pszFilePath == NULL) {
        HI_LOGE("AUDIO", "pszFilePath is null");
        return -1;
    }
    return StreamOpen(&pstHandle->stStream, pszFilePath, AAC_MAX_BUFF_LEN);
}

int32_t AAC_ReadFrame(AAC_Handle_S *pstHandle, uint8_t **ppFrame, uint32_t *pu32FrameLen)
{
    if (pstHandle == NULL || pstHandle->stStream.pFile == NULL) {
        HI_LOGE("AUDIO", "pstHandle or pstHandle->stStream.pFile is null");
        return -1;
    }
    if (ppFrame == NULL || pu32FrameLen == NULL) {
        HI_LOGE("AUDIO", "ppFrame or pu32FrameLen is null");
        return -1;
    }
    if (pstHandle->stStream.pu8BufHeader == NULL) {
        HI_LOGE("AUDIO", "pstHandle->stStream.pu8BufHeader is null");
        return -1;
    }
    if (fseek(pstHandle->stStream.pFile, pstHandle->stStream.u32FileReadOffset, SEEK_SET) != EOK) {
        HI_LOGE("AUDIO", "fseek error! %s %d", __FUNCTION__, __LINE__);
        return -1;
    }
    if (memset_s(pstHandle->stStream.pu8BufHeader, pstHandle->stStream.u32BufLen, 0x00,
        pstHandle->stStream.u32BufLen) != EOK) {
        HI_LOGE("AUDIO", "memset_s error! %s %d", __FUNCTION__, __LINE__);
        return -1;
    }
    uint32_t readLen = fread(pstHandle->stStream.pu8BufHeader, 1, pstHandle->stStream.u32BufLen,
                             pstHandle->stStream.pFile);
    if (readLen == 0) {
        HI_LOGI("AUDIO", "AAC_ReadFrame read file end");
        pstHandle->stStream.u32FileReadOffset = 0;
        return -1;
    }
    pstHandle->stStream.u32AvailReadLen = readLen;
    uint8_t *pBufPtr = pstHandle->stStream.pu8BufHeader;
    uint8_t *pADTSHeader = GetNextADTS(pBufPtr, pstHandle->stStream.u32AvailReadLen);
    if (pADTSHeader != NULL) {
        uint32_t headerOffset = (uint32_t)(pADTSHeader - pBufPtr);
        uint32_t availFromHeader = readLen - headerOffset;
        *pu32FrameLen = GetAACFrameLen(pADTSHeader);
        if (*pu32FrameLen == 0 || *pu32FrameLen > availFromHeader) {
            HI_LOGW("AUDIO", "AAC_ReadFrame read incomplete frame end");
            pstHandle->stStream.u32FileReadOffset = 0;
            return -1;
        }
        *ppFrame = pADTSHeader;
        pstHandle->stStream.u32FileReadOffset += headerOffset + *pu32FrameLen;
        return 0;
    } else {
        HI_LOGI("AUDIO", "aac read EOF");
        pstHandle->stStream.u32FileReadOffset = 0;
        return -1;
    }
}

int32_t AAC_Close(AAC_Handle_S *pstHandle)
{
    if (pstHandle == NULL) {
        HI_LOGE("AUDIO", "pstHandle is null");
        return -1;
    }
    return StreamClose(&pstHandle->stStream);
}

int32_t AAC_Reset(AAC_Handle_S *pstHandle)
{
    if (pstHandle == NULL) {
        HI_LOGE("AUDIO", "pstHandle is null");
        return -1;
    }
    return StreamReset(&pstHandle->stStream);
}
