/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "securec.h"
#include "stream.h"
#include "hi_log.h"

static int32_t CheckParms(StreamHandle *pstHandle, const char *pszFilePath)
{
    if (pstHandle == NULL || pszFilePath == NULL) {
        HI_LOGE("AUDIO", "pstHandle or pszFilePath is null");
        return -1;
    }
    if (memset_s(pstHandle, sizeof(StreamHandle), 0x00, sizeof(StreamHandle)) != EOK) {
        HI_LOGE("AUDIO", "memset_s error! %s %d", __FUNCTION__, __LINE__);
        return -1;
    }
    if (strncpy_s(pstHandle->aszFileName, MAX_FILE_NAME_LEN, pszFilePath, MAX_FILE_NAME_LEN - 1) != EOK) {
        HI_LOGE("AUDIO", "strncpy_s error! %s %d", __FUNCTION__, __LINE__);
        return -1;
    }
    pstHandle->aszFileName[MAX_FILE_NAME_LEN - 1] = '\0';
    char aszResolvedpath[PATH_MAX + 1];
    if (realpath(pszFilePath, aszResolvedpath) == NULL) {
        HI_LOGE("AUDIO", "real path fail");
        pstHandle->pFile = NULL;
        return -1;
    }
    pstHandle->pFile = fopen(aszResolvedpath, "r");
    if (pstHandle->pFile == NULL) {
        HI_LOGE("AUDIO", "fopen stream fail");
        pstHandle->pFile = NULL;
        return -1;
    }
    return 0;
}

int32_t StreamOpen(StreamHandle *pstHandle, const char *pszFilePath, uint32_t u32BuffLen)
{
    if (CheckParms(pstHandle, pszFilePath) != 0) {
        return -1;
    }
    if (fseek(pstHandle->pFile, 0, SEEK_END) == -1) {
        HI_LOGE("AUDIO", "fseek stream fail");
        fclose(pstHandle->pFile);
        pstHandle->pFile = NULL;
        return -1;
    }
    int64_t ret = ftell(pstHandle->pFile);
    if (ret <= 0 || ret > UINT_MAX) { /* By default, the file length is less than UINT_MAX */
        HI_LOGE("AUDIO", "ftell stream fail");
        fclose(pstHandle->pFile);
        pstHandle->pFile = NULL;
        return -1;
    }
    pstHandle->u32FileLen = (uint32_t)ret;
    if (fseek(pstHandle->pFile, 0, SEEK_SET) == -1) {
        HI_LOGE("AUDIO", "fseek stream fail");
        fclose(pstHandle->pFile);
        pstHandle->pFile = NULL;
        return -1;
    }
    if (u32BuffLen > 0) {
        pstHandle->pu8BufHeader = (uint8_t *)malloc(u32BuffLen);
        if (pstHandle->pu8BufHeader == NULL) {
            HI_LOGE("AUDIO", "malloc failed");
            fclose(pstHandle->pFile);
            pstHandle->pFile = NULL;
            return -1;
        }
        pstHandle->u32BufLen = u32BuffLen;
        if (memset_s(pstHandle->pu8BufHeader, u32BuffLen, 0x00, u32BuffLen) != EOK) {
            HI_LOGE("AUDIO", "memset_s error! %s %d", __FUNCTION__, __LINE__);
            free(pstHandle->pu8BufHeader);
            pstHandle->pu8BufHeader = NULL;
            fclose(pstHandle->pFile);
            pstHandle->pFile = NULL;
            return -1;
        }
        pstHandle->pu8ReadOffset = 0;
    }
    pstHandle->u32FileReadOffset = 0;
    return 0;
}

int32_t StreamClose(StreamHandle *pstHandle)
{
    if (pstHandle == NULL) {
        HI_LOGE("AUDIO", "pstHandle is null");
        return -1;
    }
    if (pstHandle->pu8BufHeader != NULL) {
        free(pstHandle->pu8BufHeader);
        pstHandle->pu8BufHeader = NULL;
        }
    if (pstHandle->pFile != NULL) {
        fclose(pstHandle->pFile);
        pstHandle->pFile = NULL;
    }
    pstHandle->u32BufLen = 0;
    pstHandle->pu8ReadOffset = 0;
    pstHandle->u32AvailReadLen = 0;
    pstHandle->u32FileReadOffset = 0;
    return 0;
}

int32_t StreamReset(StreamHandle *pstHandle)
{
    if (pstHandle == NULL) {
        HI_LOGE("AUDIO", "pstHandle is null");
        return -1;
    }
    pstHandle->u32FileReadOffset = 0;
    return 0;
}