/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AUDIO_SAMPLE_COMMON_H
#define AUDIO_SAMPLE_COMMON_H

#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "hi_mapi_acap.h"
#include "hi_mapi_acap_define.h"
#include "hi_mapi_adec.h"
#include "hi_mapi_aenc.h"
#include "hi_mapi_aenc_adpt.h"
#include "hi_mapi_aenc_define.h"
#include "hi_mapi_ao.h"
#include "hi_mapi_ao_define.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_sys.h"
#include "securec.h"
#include "hi_log.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/* Configuration constants. */
#define SAMPLE_MAPI_FILEPATH                      "./"
#define FILE_FULL_PATH_MAX_LEN                    128
#define SAMPLE_U32MAX_NUM                         0xFFFFFFFF
#define SAMPLE_U64MAX_NUM                         0xFFFFFFFFFFFFFFFF

#define SAMPLE_MAPI_AI_INNER_DEV                  0   /* dev for inner acodec */
#define SAMPLE_MAPI_AO_INNER_DEV                  0   /* ao inner acodec dev id */
#define SAMPLE_MAPI_AI_CHN                        0   /* stereo sound mode */
#define SAMPLE_MAPI_AO_CHN                        0   /* stereo or left sound mode */
#define SAMPLE_MAPI_AI_IN_GAIN                    20
#define SAMPLE_MAPI_AENC_CHN                      0
#define SAMPLE_MAPI_ADEC_DEV                      0
#define SAMPLE_MAPI_AO_OUT_GAIN                   0
#define SAMPLE_MAPI_AUDIO_POINT_PER_FRAME         1024

/* Helper declarations implemented in sample_pipeline_audio_helpers.c. */
td_s32  SAMPLE_COMM_RegisterSigHandler(td_void);
td_void SAMPLE_COMM_GetLocalTime(char *timeBuffer, td_u32 size);
td_s32  SAMPLE_COMM_GetInputChar(td_char *ch);
td_bool SAMPLE_COMM_IsExitRequested(td_void);
td_void SAMPLE_COMM_RequestExit(td_void);
td_s32  SAMPLE_COMM_WaitForEnterOrExit(td_void);

/* Error-checking helpers kept local so audio sample does not depend on common/. */

#ifndef SAMPLE_CHECK_GOTO
#define SAMPLE_CHECK_GOTO(ret, express)                                                             \
    do {                                                                                            \
        ret = express;                                                                              \
        if ((ret) != TD_SUCCESS) {                                                                  \
            HI_LOGE("AUDIO", "Failed at %s: LINE: %d  (ret:0x%#x!)", __FUNCTION__, __LINE__, ret);  \
            goto exit;                                                                              \
        }                                                                                           \
    } while (0)
#endif

#ifndef SAMPLE_CHECK_RET
#define SAMPLE_CHECK_RET(express)                                                                   \
    do {                                                                                            \
        td_s32 tmpRet = express;                                                                    \
        if (tmpRet != TD_SUCCESS) {                                                                 \
            HI_LOGE("CHECK_RET", "Failed at %s: LINE: %d  (ret:0x%#x!)", __FUNCTION__, __LINE__, tmpRet); \
            return tmpRet;                                                                          \
        }                                                                                           \
    } while (0)
#endif

#define SAMPLE_CHECK_U32PRODUCT_OVERFLOW_RET(value1, value2)                                        \
    do {                                                                                            \
        if (((value1) != 0) && ((td_u32)SAMPLE_U32MAX_NUM / (value1) < (value2))) {                 \
            HI_LOGE("CHECK_U32PRODUCT_OVERFLOW", "%u * %u product overflow!", (td_u32)(value1), (td_u32)(value2));      \
            return TD_FAILURE;                                                                      \
        }                                                                                           \
    } while (0)

#define SAMPLE_CHECK_U64SUM_OVERFLOW_RET(value1, value2)                                            \
    do {                                                                                            \
        if ((td_u64)SAMPLE_U64MAX_NUM - (value1) < (value2)) {                                      \
            HI_LOGE("CHECK_U64SUM_OVERFLOW", "%llu + %llu sum overflow!", value1, value2);                          \
            return TD_FAILURE;                                                                      \
        }                                                                                           \
    } while (0)

#define SAMPLE_CHECK_U32MAX_VALUE_OVERFLOW_RET(value1)                                              \
    do {                                                                                            \
        if ((value1) > (td_u32)SAMPLE_U32MAX_NUM) {                                                 \
            HI_LOGE("CHECK_U32MAX_VALUE_OVERFLOW", "%llu > %u!", value1, SAMPLE_U32MAX_NUM);                             \
            return TD_FAILURE;                                                                      \
        }                                                                                           \
    } while (0)

#define SAMPLE_CHECK_U32MAX_VALUE_OVERFLOW_RETVOID(value1)                                          \
    do {                                                                                            \
        if ((value1) > (td_u32)SAMPLE_U32MAX_NUM) {                                                 \
            HI_LOGE("CHECK_U32MAX_VALUE_OVERFLOW", "%llu > %u!", value1, SAMPLE_U32MAX_NUM);                             \
            return;                                                                                 \
        }                                                                                           \
    } while (0)

#define SAMPLE_CHECK_POINTER_NULL_RET(pointer)                                                      \
    do {                                                                                            \
        if ((pointer) == TD_NULL) {                                                                 \
            HI_LOGE("CHECK_POINTER_NULL", "the param %s is null!", #pointer);                                    \
            return TD_FAILURE;                                                                      \
        }                                                                                           \
    } while (0)

#define SAMPLE_CHECK_POINTER_NULL_GOTO(pointer, ret, GOTO_LABLE)                                    \
    do {                                                                                            \
        if ((pointer) == TD_NULL) {                                                                 \
            ret = TD_FAILURE;                                                                       \
            HI_LOGE("CHECK_POINTER_NULL", "the param %s is null!", #pointer);                                    \
            goto GOTO_LABLE;                                                                        \
        }                                                                                           \
    } while (0)

#define SAMPLE_CHECK_WRITE_SIZE(size)                                                               \
    do {                                                                                            \
        if ((size) != 1) {                                                                          \
            HI_LOGW("CHECK_WRITE_SIZE", "fwrite error");                                                       \
        }                                                                                           \
    } while (0)

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* AUDIO_SAMPLE_COMMON_H */
