/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "hi_log.h"
#include "sample_public_audio.h"
#include "hi_mapi_aenc.h"
#include "hi_mapi_adec.h"
#include "ss_audio_opus_adp.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

// The AI module immediately sends the data to the AO module for display. Underload occurs at the beginning.
#define AO_WAIT_AI_STABLE 100000
#define SAMPLE_AUDIO_AO_INIT_RETRY_TIMES 5
#define SAMPLE_AUDIO_AO_INIT_RETRY_INTERVAL_US 200000

static td_char *g_pG711RawData = TD_NULL;

#define SAMPLE_AUDIO_DIAG_DUMP_BYTES 16
#define SAMPLE_AUDIO_DIAG_MAX_FRAMES 5
#define SAMPLE_AUDIO_OPUS_STD_LEN_BYTES 4

static const char *SAMPLE_AUDIO_Payload2Str(hi_mapi_audio_payload_format payload_format)
{
    return (payload_format == HI_MAPI_AUDIO_PAYLOAD_STANDARD) ? "standard" : "native";
}

static td_s32 SAMPLE_AUDIO_InitAoWithRetry(td_handle aoHdl, const hi_mapi_ao_attr *aoAttr)
{
    td_s32 ret = TD_SUCCESS;

    for (td_u32 i = 0; i < SAMPLE_AUDIO_AO_INIT_RETRY_TIMES; i++) {
        ret = hi_mapi_ao_init(aoHdl, aoAttr);
        if (ret == TD_SUCCESS) {
            return TD_SUCCESS;
        }
        HI_LOGW("AUDIO", "[sample-audio][ao-init] retry %u/%u after ret=0x%x",
            i + 1, SAMPLE_AUDIO_AO_INIT_RETRY_TIMES, ret);
        (td_void)hi_mapi_ao_deinit(aoHdl);
        usleep(SAMPLE_AUDIO_AO_INIT_RETRY_INTERVAL_US);
    }

    return ret;
}

static td_void SAMPLE_AUDIO_DumpBytes(const char *tag, const td_u8 *buf, td_u32 len)
{
    td_u32 dumpLen = (len < SAMPLE_AUDIO_DIAG_DUMP_BYTES) ? len : SAMPLE_AUDIO_DIAG_DUMP_BYTES;

    printf("%s len=%u first%u=", tag, len, dumpLen);
    for (td_u32 i = 0; i < dumpLen; i++) {
        printf("%02x", buf[i]);
        if (i + 1 < dumpLen) {
            printf(" ");
        }
    }
    printf("\n");
}

td_void SAMPLE_AUDIO_ConfigACapAttr(hi_mapi_acap_attr *acap_attr)
{
    if (acap_attr != TD_NULL) {
        acap_attr->sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
        acap_attr->bit_width = HI_MAPI_AUDIO_BIT_WIDTH_16;
        acap_attr->sound_mode = HI_MAPI_AUDIO_SOUND_MODE_STEREO;
        acap_attr->work_mode = HI_MAPI_AIO_MODE_I2S_MASTER;
        acap_attr->pt_num_per_frm = SAMPLE_MAPI_AUDIO_POINT_PER_FRAME;
        acap_attr->track_mode = HI_MAPI_AUDIO_TRACK_NORMAL;
        acap_attr->mixer_mic_mode = HI_MAPI_ACODEC_MIXER_IN_D;
        acap_attr->resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
        acap_attr->i2s_type = HI_MAPI_AIO_I2STYPE_INNERCODEC;
    }
}

td_void SAMPLE_AUDIO_ConfigAEncAttr(hi_mapi_aenc_attr *aencAttr,
    hi_mapi_aenc_aac_attr *aacAencAttr)
{
    if ((aencAttr != TD_NULL) && (aacAencAttr != TD_NULL)) {
        aacAencAttr->aac_type = HI_MAPI_AAC_TYPE_AACLC;
        aacAencAttr->bit_rate = HI_MAPI_AAC_BPS_48K;
        aacAencAttr->bit_width = HI_MAPI_AUDIO_BIT_WIDTH_16;
        aacAencAttr->sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
        aacAencAttr->sound_mode = HI_MAPI_AUDIO_SOUND_MODE_STEREO;
        aacAencAttr->trans_type = HI_MAPI_AAC_TRANS_TYPE_ADTS;
        aacAencAttr->band_width = 0;
        aencAttr->aenc_format = HI_MAPI_AUDIO_FORMAT_AACLC;
        aencAttr->pt_num_per_frm = SAMPLE_MAPI_AUDIO_POINT_PER_FRAME;
        aencAttr->value = aacAencAttr;
        aencAttr->value_len = sizeof(hi_mapi_aenc_aac_attr);
    }
}

#ifdef ENABLE_MP3
td_void SAMPLE_AUDIO_ConfigAEncMp3Attr(hi_mapi_aenc_attr *aencAttr,
    hi_mapi_aenc_mp3_attr *mp3Attr)
{
    if ((aencAttr != TD_NULL) && (mp3Attr != TD_NULL)) {
        mp3Attr->sound_mode = HI_MAPI_AUDIO_SOUND_MODE_STEREO;
        mp3Attr->bit_rate = HI_MAPI_MP3_BPS_320K;
        mp3Attr->bit_width = HI_MAPI_AUDIO_BIT_WIDTH_16;
        mp3Attr->sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
        mp3Attr->quality = SAMPLE_AUDIO_QUALITY_NUM;
        aencAttr->aenc_format = HI_MAPI_AUDIO_FORMAT_MP3;
        aencAttr->pt_num_per_frm = SAMPLE_AUDIO_POINT_PER_FRAME_MP3;
        aencAttr->value = mp3Attr;
        aencAttr->value_len = sizeof(hi_mapi_aenc_mp3_attr);
    }
}
#endif

td_void SAMPLE_AUDIO_ConfigAOAttr(hi_mapi_ao_attr *ao_attr)
{
    if (ao_attr != TD_NULL) {
        ao_attr->work_mode = HI_MAPI_AIO_MODE_I2S_MASTER;
        ao_attr->bit_width = HI_MAPI_AUDIO_BIT_WIDTH_16;
        ao_attr->sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
        ao_attr->sound_mode = HI_MAPI_AUDIO_SOUND_MODE_STEREO;
        ao_attr->pt_num_per_frm = SAMPLE_MAPI_AUDIO_POINT_PER_FRAME;
        ao_attr->track_mode = HI_MAPI_AUDIO_TRACK_NORMAL;
        ao_attr->in_sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
        ao_attr->i2s_type = HI_MAPI_AIO_I2STYPE_INNERCODEC;
    }
}

td_char *SAMPLE_AUDIO_Pt2Str(hi_mapi_audio_format aenc_format)
{
    if (aenc_format == HI_MAPI_AUDIO_FORMAT_G711A) {
        return "g711a";
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_G711U) {
        return "g711u";
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_AACLC) {
        return "aac";
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_MP3) {
        return "mp3";
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_LPCM) {
        return "pcm";
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_OPUS) {
        return "opus";
    } else {
        return "data";
    }
}

FILE *SAMPLE_AUDIO_OpenAudioFile(const td_char *filePath, td_u32 pathStrLen)
{
    td_char fileName[FILE_FULL_PATH_MAX_LEN + 1] = {0};
    td_s32 ret;

    if (filePath == TD_NULL) {
        HI_LOGE("AUDIO", "pFilePath is null!");
        return NULL;
    }

    if (pathStrLen > FILE_FULL_PATH_MAX_LEN) {
        HI_LOGE("AUDIO", "filePath string len > %d!", FILE_FULL_PATH_MAX_LEN);
        return NULL;
    }

    ret = snprintf_s(fileName, FILE_FULL_PATH_MAX_LEN + 1, pathStrLen, "%s", filePath);
    if (ret == TD_FAILURE) {
        HI_LOGE("AUDIO", "snprintf_s failed:%#x", ret);
        return NULL;
    }

    FILE *fd = fopen(fileName, "a+");
    if (fd == TD_NULL) {
        fd = fopen(fileName, "wb");
        HI_LOGI("AUDIO", "fopen wb");
    }
    if (fd == TD_NULL) {
        HI_LOGE("AUDIO", "open file failed!");
        return NULL;
    }

    HI_LOGI("AUDIO", "open file:\"%s\" for aenc ok", fileName);
    return fd;
}

td_void SAMPLE_AUDIO_CloseAudioFile(FILE **fd)
{
    if ((fd != NULL) && (*fd != NULL)) {
        (td_void)fclose(*fd);
        *fd = TD_NULL;
    }
}

static td_s32 SAMPLE_AUDIO_GetRawStreamWithG711(td_s16 *otVoiceData, td_s32 otSampleLen,
    td_s16 *outData, td_s32 outDataBufLen)
{
    td_s32 len;
    td_s32 outLen = 0;
    td_s32 copySampleLen;
    td_s32 ret;

    // G711 data size align at td_s16 , GetAudioFrame size align at td_char
    copySampleLen = otSampleLen / (sizeof(td_s16) / sizeof(td_char));
    if (copySampleLen % (sizeof(td_s16) / sizeof(td_char)) == 1) {
        copySampleLen = copySampleLen + 1;
    }
    td_s16 *copyOtData = otVoiceData;
    td_s16 *copyOutData = outData;

    // G711 data size align at td_s16
    while (copySampleLen >= (td_s32)(SAMPLE_AUDIO_OT_HEAD_BYTE_LEN / sizeof(td_s16))) {
        // get cleanly data with a frame
        len = (td_u32)copyOtData[1] & 0x00ff;
        if (len == 0) {
            break;
        }

        // clean ot head
        copySampleLen -= (SAMPLE_AUDIO_OT_HEAD_BYTE_LEN / sizeof(td_s16));
        // clean ot head
        copyOtData += (SAMPLE_AUDIO_OT_HEAD_BYTE_LEN / sizeof(td_s16));
        if (copySampleLen < len) {
            break;
        }
        ret = memcpy_s(copyOutData, (size_t)outDataBufLen, copyOtData, (size_t)len * sizeof(td_s16));
        if (ret != EOK) {
            HI_LOGE("AUDIO", "memcpy_s error ret:%#x", ret);
            return -1;
        }
        copyOutData += len;
        copyOtData += len;
        copySampleLen -= len;

        // return cleanly data size align at td_char
        outLen += len * (sizeof(td_s16) / sizeof(td_char));
    }

    return outLen;
}

td_s32 SAMPLE_AUDIO_DataProc(td_handle aencHdl, const hi_mapi_audio_stream *streamData, td_void *private_data)
{
    MAPI_UNUSED(aencHdl);
    SAMPLE_AUDIO_Attr *audioAttr = (SAMPLE_AUDIO_Attr *)private_data;

    if (streamData == TD_NULL || streamData->stream == TD_NULL) {
        return TD_FAILURE;
    }

    if ((audioAttr == NULL) || (audioAttr->fd == NULL)) {
        return TD_FAILURE;
    }

    if (((audioAttr->deleteOtHead == TD_TRUE)) &&
        ((audioAttr->aenc_format == HI_MAPI_AUDIO_FORMAT_G711A) ||
        (audioAttr->aenc_format == HI_MAPI_AUDIO_FORMAT_G711U))) {
        static td_u32 g711DiagCnt = 0;
        if (g711DiagCnt < SAMPLE_AUDIO_DIAG_MAX_FRAMES) {
            SAMPLE_AUDIO_DumpBytes("[sample-mode3][g711-record] aenc-raw", streamData->stream, streamData->len);
        }
        if (g_pG711RawData == NULL) {
            /* obligate buf for data head */
            g_pG711RawData = (td_char *)malloc(SAMPLE_AIO_MAX_POINT_PER_FRAME_G711 +
                SAMPLE_AUDIO_OT_HEAD_BYTE_LEN);
            if (g_pG711RawData == NULL) {
                return TD_FAILURE;
            }
        }

        td_s32 dataLen = SAMPLE_AUDIO_GetRawStreamWithG711((td_s16 *)streamData->stream, (td_s32)streamData->len,
            (td_s16 *)g_pG711RawData, SAMPLE_AIO_MAX_POINT_PER_FRAME_G711 + SAMPLE_AUDIO_OT_HEAD_BYTE_LEN);
        if (dataLen <= 0) {
            HI_LOGE("AUDIO", "[sample-mode3][g711-record] strip OT head failed, input_len=%u dataLen=%d",
                streamData->len, dataLen);
            return TD_FAILURE;
        }
        if (g711DiagCnt < SAMPLE_AUDIO_DIAG_MAX_FRAMES) {
            SAMPLE_AUDIO_DumpBytes("[sample-mode3][g711-record] payload",
                (const td_u8 *)g_pG711RawData, (td_u32)dataLen);
        }
        g711DiagCnt++;
        /* Primary G711 file keeps the SDK/AENC native 4-byte frame header because
         * hi_mapi_adec_send_stream expects this format on board playback. */
        (td_void)fwrite((const void *)streamData->stream, 1, (size_t)streamData->len, audioAttr->fd);
    } else if (audioAttr->aenc_format == HI_MAPI_AUDIO_FORMAT_OPUS &&
        audioAttr->payload_format == HI_MAPI_AUDIO_PAYLOAD_STANDARD) {
        td_u8 lenHdr[SAMPLE_AUDIO_OPUS_STD_LEN_BYTES] = {
            (td_u8)((streamData->len >> 24) & 0xFF),
            (td_u8)((streamData->len >> 16) & 0xFF),
            (td_u8)((streamData->len >> 8) & 0xFF),
            (td_u8)(streamData->len & 0xFF),
        };
        (td_void)fwrite(lenHdr, 1, sizeof(lenHdr), audioAttr->fd);
        (td_void)fwrite((const void *)streamData->stream, 1, (size_t)streamData->len, audioAttr->fd);
    } else {
        (td_void)fwrite((const void *)streamData->stream, 1, (size_t)streamData->len, audioAttr->fd);
    }

    if (fflush(audioAttr->fd) != TD_SUCCESS) {
        perror("fflush file");
    }

    return TD_SUCCESS;
}

td_void SAMPLE_AUDIO_FreeG711DataBuf(td_void)
{
    if (g_pG711RawData != NULL) {
        free(g_pG711RawData);
        g_pG711RawData = NULL;
    }
}

td_s32 SAMPLE_AUDIO_StartAcap(td_handle acapHdl, td_handle acapChnHdl, hi_mapi_audio_format aenc_format)
{
    hi_mapi_acap_attr acap_attr;
    SAMPLE_AUDIO_ConfigACapAttr(&acap_attr);
    if ((aenc_format == HI_MAPI_AUDIO_FORMAT_G711A) || (aenc_format == HI_MAPI_AUDIO_FORMAT_G711U)) {
        acap_attr.pt_num_per_frm = SAMPLE_AIO_MAX_POINT_PER_FRAME_G711;
        acap_attr.sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_8000;
        acap_attr.resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_8000;
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_MP3) {
        acap_attr.pt_num_per_frm = SAMPLE_AUDIO_POINT_PER_FRAME_MP3;
        acap_attr.resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000; /* resample */
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_AACLC) {
        acap_attr.resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000; /* resample */
    }

    HI_CHECK_RET(hi_mapi_acap_init(acapHdl, &acap_attr));
    HI_CHECK_RET(hi_mapi_acap_start(acapHdl, acapChnHdl));
    HI_CHECK_RET(hi_mapi_acap_set_volume(acapHdl, SAMPLE_MAPI_AI_IN_GAIN));

    return TD_SUCCESS;
}

td_void SAMPLE_AUDIO_StopAcap(td_handle acapHdl, td_handle acapChnHdl)
{
    hi_mapi_acap_stop(acapHdl, acapChnHdl);
    hi_mapi_acap_deinit(acapHdl);
}

td_s32 SAMPLE_AUDIO_StartAenc(td_handle aencHdl, hi_mapi_audio_format aenc_format,
    const hi_mapi_aenc_callback *aencCB, hi_mapi_audio_payload_format payload_format)
{
    HI_CHECK_NULL(aencCB, TD_FAILURE);
    hi_mapi_aenc_attr aencAttr = {0};
    hi_mapi_aenc_g711_attr aencG711Attr = {0};
    hi_mapi_aenc_lpcm_attr aencLpcmAttr = {0};
    hi_mapi_aenc_aac_attr aacAencAttr = {0};
    ot_aenc_attr_opus aencOpusAttr = {0};
#ifdef ENABLE_MP3
    hi_mapi_aenc_mp3_attr mp3Attr = {0};
#endif
    aencAttr.aenc_format = aenc_format;
    if ((aenc_format == HI_MAPI_AUDIO_FORMAT_G711A) || (aenc_format == HI_MAPI_AUDIO_FORMAT_G711U)) {
        aencAttr.pt_num_per_frm = SAMPLE_AIO_MAX_POINT_PER_FRAME_G711;
        aencAttr.value = &aencG711Attr;
        aencAttr.value_len = sizeof(hi_mapi_aenc_g711_attr);
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_LPCM) {
        aencAttr.pt_num_per_frm = SAMPLE_MAPI_AUDIO_POINT_PER_FRAME;
        aencAttr.value = &aencLpcmAttr;
        aencAttr.value_len = sizeof(hi_mapi_aenc_lpcm_attr);
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_AACLC) {
        SAMPLE_AUDIO_ConfigAEncAttr(&aencAttr, &aacAencAttr);
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_OPUS) {
        aencOpusAttr.sample_rate = OT_AUDIO_SAMPLE_RATE_16000;
        aencOpusAttr.bit_width = OT_AUDIO_BIT_WIDTH_16;
        aencOpusAttr.snd_mode = OT_AUDIO_SOUND_MODE_MONO;
        aencOpusAttr.bit_rate = OT_OPUS_BPS_48K;
        aencOpusAttr.app = OT_OPUS_APPLICATION_AUDIO;
        aencAttr.pt_num_per_frm = OT_AUDIO_SAMPLE_RATE_16000 / 100; /* 10 ms OPUS frame at 16kHz */
        aencAttr.value = &aencOpusAttr;
        aencAttr.value_len = sizeof(aencOpusAttr);
#ifdef ENABLE_MP3
    } else if (aenc_format == HI_MAPI_AUDIO_FORMAT_MP3) {
        SAMPLE_AUDIO_ConfigAEncMp3Attr(&aencAttr, &mp3Attr);
#endif
    } else {
        HI_LOGE("AUDIO", "not support Format:%d!", aenc_format);
        return TD_FAILURE;
    }

    HI_CHECK_RET(hi_mapi_aenc_init(aencHdl, &aencAttr));
    if (aenc_format == HI_MAPI_AUDIO_FORMAT_OPUS) {
        HI_CHECK_RET(hi_mapi_aenc_set_param(aencHdl, HI_MAPI_AENC_CMD_PAYLOAD_FORMAT_CONFIG,
            &payload_format, sizeof(payload_format)));
        hi_mapi_audio_payload_format actualPayload = HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE;
        HI_CHECK_RET(hi_mapi_aenc_get_param(aencHdl, HI_MAPI_AENC_CMD_PAYLOAD_FORMAT_CONFIG,
            &actualPayload, sizeof(actualPayload)));
        HI_LOGI("AUDIO", "[mode3][opus-record] aenc payload=%s", SAMPLE_AUDIO_Payload2Str(actualPayload));
    }
    HI_CHECK_RET(hi_mapi_aenc_register_callback(aencHdl, aencCB));
    HI_CHECK_RET(hi_mapi_aenc_start(aencHdl));

    return TD_SUCCESS;
}

td_void SAMPLE_AUDIO_StopAenc(td_handle aencHdl, hi_mapi_audio_format aenc_format, const hi_mapi_aenc_callback *aencCB)
{
    (td_void)aenc_format;
    hi_mapi_aenc_unregister_callback(aencHdl, aencCB);
    hi_mapi_aenc_stop(aencHdl);
    hi_mapi_aenc_deinit(aencHdl);
}

td_s32 SAMPLE_AUDIO_StartAo(td_handle aoHdl, td_handle aoChnHdl, hi_mapi_audio_sound_mode sound_mode,
    hi_mapi_audio_sample_rate sample_rate)
{
    hi_mapi_ao_attr ao_attr;
    SAMPLE_AUDIO_ConfigAOAttr(&ao_attr);
    ao_attr.i2s_type = HI_MAPI_AIO_I2STYPE_INNERCODEC;
    ao_attr.sound_mode = sound_mode;
    if (sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_BUTT) {
        ao_attr.sample_rate = sample_rate;
        ao_attr.in_sample_rate = sample_rate;
    }

    HI_CHECK_RET(SAMPLE_AUDIO_InitAoWithRetry(aoHdl, &ao_attr));
    usleep(AO_WAIT_AI_STABLE);
    HI_CHECK_RET(hi_mapi_ao_start(aoHdl, aoChnHdl));

    HI_CHECK_RET(hi_mapi_ao_set_volume(aoHdl, SAMPLE_MAPI_AO_OUT_GAIN));

    return TD_SUCCESS;
}

td_s32 SAMPLE_AUDIO_BindAdecAndStartAo(td_handle aoHdl, td_handle aoChnHdl, td_handle adecHdl,
    hi_mapi_audio_format adec_format, hi_mapi_audio_sound_mode sound_mode, hi_mapi_audio_sample_rate sample_rate,
    hi_mapi_audio_payload_format payload_format)
{
    td_s32 ret = TD_SUCCESS;
    td_bool adecInited = TD_FALSE;
    td_bool aoInited = TD_FALSE;
    td_bool bound = TD_FALSE;
    /* init and start adec */
    hi_mapi_adec_attr adecAttr = {};
    SAMPLE_CHECK_GOTO(ret, hi_mapi_adec_get_default_attr(adec_format, &adecAttr));
    SAMPLE_CHECK_GOTO(ret, hi_mapi_adec_init(adecHdl, &adecAttr));
    adecInited = TD_TRUE;
    if (adec_format == HI_MAPI_AUDIO_FORMAT_OPUS) {
        SAMPLE_CHECK_GOTO(ret, hi_mapi_adec_set_param(adecHdl, HI_MAPI_ADEC_CMD_PAYLOAD_FORMAT_CONFIG,
            &payload_format, sizeof(payload_format)));
        hi_mapi_audio_payload_format actualPayload = HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE;
        SAMPLE_CHECK_GOTO(ret, hi_mapi_adec_get_param(adecHdl, HI_MAPI_ADEC_CMD_PAYLOAD_FORMAT_CONFIG,
            &actualPayload, sizeof(actualPayload)));
        HI_LOGI("AUDIO", "[sample-mode4][opus-play] adec payload=%s", SAMPLE_AUDIO_Payload2Str(actualPayload));
    }
    HI_LOGI("AUDIO", "init ADEC complete");

    hi_mapi_ao_attr ao_attr;
    SAMPLE_AUDIO_ConfigAOAttr(&ao_attr);
    ao_attr.i2s_type = HI_MAPI_AIO_I2STYPE_INNERCODEC;
    ao_attr.sound_mode = sound_mode;
    if (sample_rate != HI_MAPI_AUDIO_SAMPLE_RATE_BUTT) {
        ao_attr.sample_rate = sample_rate;
        ao_attr.in_sample_rate = sample_rate;
    }
    if (adec_format == HI_MAPI_AUDIO_FORMAT_OPUS) {
        /* OPUS encoder uses 10ms frames (48000/100=480 samples); AO must match
         * to avoid playback speed distortion caused by pt_num_per_frm mismatch. */
        ao_attr.pt_num_per_frm = HI_MAPI_AUDIO_SAMPLE_RATE_48000 / 100;
    }

    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_InitAoWithRetry(aoHdl, &ao_attr));
    aoInited = TD_TRUE;

    /* bind via sys: src = ADEC, dst = AO */
    hi_mapi_mpp_chn src_chn = { HI_MAPI_MOD_ADEC, 0, adecHdl };
    hi_mapi_mpp_chn dst_chn = { HI_MAPI_MOD_AO,   aoHdl, aoChnHdl };
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_bind(&src_chn, &dst_chn));
    bound = TD_TRUE;

    usleep(AO_WAIT_AI_STABLE);
    SAMPLE_CHECK_GOTO(ret, hi_mapi_ao_start(aoHdl, aoChnHdl));

    SAMPLE_CHECK_GOTO(ret, hi_mapi_ao_set_volume(aoHdl, SAMPLE_MAPI_AO_OUT_GAIN));

    return ret;
exit:
    if (bound) {
        td_s32 cleanupRet = hi_mapi_sys_unbind(&src_chn, &dst_chn);
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] rollback unbind ret=0x%x", cleanupRet);
    }
    if (aoInited) {
        td_s32 cleanupRet = hi_mapi_ao_stop(aoHdl, aoChnHdl);
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] rollback ao_stop ret=0x%x", cleanupRet);
    }
    if (adecInited) {
        td_s32 cleanupRet = hi_mapi_adec_deinit(adecHdl);
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] rollback adec_deinit ret=0x%x", cleanupRet);
    }
    if (aoInited) {
        td_s32 cleanupRet = hi_mapi_ao_deinit(aoHdl);
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] rollback ao_deinit ret=0x%x", cleanupRet);
    }
    return ret;
}

td_void SAMPLE_AUDIO_StopAo(td_handle aoHdl, td_handle aoChnHdl)
{
    hi_mapi_ao_stop(aoHdl, aoChnHdl);
    hi_mapi_ao_deinit(aoHdl);
}

td_void SAMPLE_AUDIO_UnBindAdecAndStopAo(td_handle aoHdl, td_handle aoChnHdl, td_handle adecHdl,
    td_bool bound, td_bool aoInited, td_bool adecInited)
{
    hi_mapi_mpp_chn src_chn = { HI_MAPI_MOD_ADEC, 0, adecHdl };
    hi_mapi_mpp_chn dst_chn = { HI_MAPI_MOD_AO,   aoHdl, aoChnHdl };
    if (bound) {
        td_s32 ret = hi_mapi_sys_unbind(&src_chn, &dst_chn);
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] unbind ret=0x%x", ret);
    }
    if (aoInited) {
        td_s32 ret = hi_mapi_ao_stop(aoHdl, aoChnHdl);
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] ao_stop ret=0x%x", ret);
    }
    if (adecInited) {
        td_s32 ret = hi_mapi_adec_deinit(adecHdl);
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] adec_deinit ret=0x%x", ret);
    }
    if (aoInited) {
        td_s32 ret = hi_mapi_ao_deinit(aoHdl);
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] ao_deinit ret=0x%x", ret);
    }
}

td_s32 SAMPLE_AUDIO_Encode(td_handle acapHdl, const td_char *filePath, td_bool deleteOtHead,
    hi_mapi_audio_format aenc_format)
{
    HI_CHECK_NULL(filePath, TD_FAILURE);

    td_s32 ret;
    const td_handle acapChnHdl = SAMPLE_MAPI_AI_CHN;
    const td_handle aencHdl = SAMPLE_MAPI_AENC_CHN;
    SAMPLE_AUDIO_Attr audioAttr = {0};
    td_char fileName[FILE_FULL_PATH_MAX_LEN] = {0};
    hi_mapi_aenc_callback aencCB = { TD_NULL, TD_NULL };
    hi_mapi_mpp_chn src_chn = { HI_MAPI_MOD_ACAP, acapHdl, acapChnHdl };
    hi_mapi_mpp_chn dst_chn = { HI_MAPI_MOD_AENC, 0, aencHdl };

    /* init sys (must precede sys_init_media to bootstrap bind table) */
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_init());
    hi_mapi_sys_media_attr mediaAttr;
    HI_CHECK_RET(memset_s(&mediaAttr, sizeof(hi_mapi_sys_media_attr), 0, sizeof(hi_mapi_sys_media_attr)));
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_init_media(&mediaAttr));

    /* init and start acap */
    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_StartAcap(acapHdl, acapChnHdl, aenc_format));
    HI_LOGI("AUDIO", "init and start acap complete");

    /* init and start aenc */
    aencCB.proc_data_cb = SAMPLE_AUDIO_DataProc;
    char timeBuffer[FILE_FULL_PATH_MAX_LEN];
    SAMPLE_COMM_GetLocalTime(timeBuffer, FILE_FULL_PATH_MAX_LEN);
    ret = snprintf_s(fileName, FILE_FULL_PATH_MAX_LEN, FILE_FULL_PATH_MAX_LEN - 1, "%s_chn%u%s.%s",
        filePath, aencHdl, timeBuffer, SAMPLE_AUDIO_Pt2Str(aenc_format));
    if (ret == TD_FAILURE) {
        HI_LOGE("AUDIO", "snprintf_s error:%#x", ret);
        goto exit;
    }

    audioAttr.deleteOtHead = deleteOtHead;
    audioAttr.aenc_format = aenc_format;
    audioAttr.fd = SAMPLE_AUDIO_OpenAudioFile(fileName, FILE_FULL_PATH_MAX_LEN);
    aencCB.private_data = &audioAttr;
    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_StartAenc(aencHdl, aenc_format, &aencCB, HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE));
    HI_LOGI("AUDIO", "init and start aenc complete");

    /* bind via sys: src = ACAP, dst = AENC */
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_bind(&src_chn, &dst_chn));
    HI_LOGI("AUDIO", "acap bind aenc complete");

    printf("Press Enter key to stop audio record...\n");
    (td_void)SAMPLE_COMM_WaitForEnterOrExit();
    HI_LOGI("AUDIO", "ACapDumpThread stop");

exit:

    (td_void)hi_mapi_sys_unbind(&src_chn, &dst_chn);
    SAMPLE_AUDIO_StopAenc(aencHdl, aenc_format, &aencCB);
    SAMPLE_AUDIO_CloseAudioFile(&audioAttr.fd);
    SAMPLE_AUDIO_StopAcap(acapHdl, acapChnHdl);
    SAMPLE_AUDIO_FreeG711DataBuf();
    (td_void)hi_mapi_sys_deinit_media();
    (td_void)hi_mapi_sys_deinit();

    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
