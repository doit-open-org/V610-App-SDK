/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef STREAM_H
#define STREAM_H
#include <stdio.h>
#include <stdint.h>
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */
#define MAX_FILE_NAME_LEN 128

typedef struct {
    char aszFileName[MAX_FILE_NAME_LEN];
    FILE *pFile;
    uint32_t u32FileLen;
    uint32_t u32FileReadOffset;
    uint8_t *pu8BufHeader;
    uint32_t u32BufLen;
    uint32_t pu8ReadOffset;
    uint32_t u32AvailReadLen;
} StreamHandle;

int32_t StreamOpen(StreamHandle *pstHandle, const char *pszFilePath, uint32_t u32BuffLen);

int32_t StreamClose(StreamHandle *pstHandle);

int32_t StreamReset(StreamHandle *pstHandle);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
#endif
