/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "sample_public_audio.h"
#include "hi_log.h"
#include "aac.h"
#include <string.h>

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */

#define AAC_FILEPATH   "./data/1.aac"

static FILE *g_acapRawFile[SAMPLE_AUDIO_STEREO_SOUND_MODE_CHN_CNT] = { TD_NULL, TD_NULL };

static td_bool g_acapDumpThdFlg = TD_FALSE;
static pthread_t g_acapDumpThd = TD_NULL;

static td_bool g_sendFrmToAOChnThdFlg = TD_FALSE;
static pthread_t g_sendFrmAOChnThd = TD_NULL;

static td_bool g_sendFrmToAdecChnThdFlg = TD_FALSE;
pthread_mutex_t g_sendFrmToAdecChnThdFlgMutex = PTHREAD_MUTEX_INITIALIZER;

static pthread_t g_sendFrmAdecChnThd = TD_NULL;
static td_bool g_sendFrmToAencChnThdFlg = TD_FALSE;
static pthread_t g_sendFrmAencChnThd = TD_NULL;
static const td_char *g_adecFilePath = AAC_FILEPATH;
static hi_mapi_audio_format g_adecFormat = HI_MAPI_AUDIO_FORMAT_AACLC;
static hi_mapi_audio_payload_format g_adecPayloadFormat = HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE;

#define SAMPLE_AUDIO_UNISOUND_AI_IN_GAIN 40
#define SAMPLE_AUDIO_HISI_G711_AI_IN_GAIN 30
#define SAMPLE_AUDIO_G711_ADEC_STREAM_LEN SAMPLE_AIO_MAX_POINT_PER_FRAME_G711

/* ES7210 external ADC topology parameters */
#define SAMPLE_ES7210_CHN_CNT      4   /* 4-ch TDM: ch0/ch1 = dual mic, ch2 = speaker ref (AEC), ch3 = unused */
#define SAMPLE_ES7210_MIC_CNT      2   /* dual mic */
#define SAMPLE_ES7210_REF_CHN      2   /* ch2 = speaker reference for AEC */

/* External AFE (unisound NR) frame size */
#define SAMPLE_AFE_FRAME_SAMPLES   256 /* matches agent_audio_sample behavior */
#define SAMPLE_AUDIO_G711_NATIVE_STREAM_LEN (SAMPLE_AIO_MAX_POINT_PER_FRAME_G711 + SAMPLE_AUDIO_OT_HEAD_BYTE_LEN)
#define SAMPLE_AUDIO_G711_VQE_POINT_PER_FRAME (SAMPLE_AIO_MAX_POINT_PER_FRAME_G711 * 2)
#define SAMPLE_AUDIO_OPUS_STD_LEN_BYTES 4
#define SAMPLE_AUDIO_OPUS_MAX_PACKET_SIZE 4096
#define SAMPLE_AUDIO_OPUS_ADEC_STREAM_LEN 640

#define SAMPLE_AUDIO_DIAG_DUMP_BYTES 16
#define SAMPLE_AUDIO_DIAG_MAX_FRAMES 5

static td_handle g_acapHdl = SAMPLE_MAPI_AI_INNER_DEV;
static td_handle g_acapChnHdl = SAMPLE_MAPI_AI_CHN;
static td_handle g_aencHdl = SAMPLE_MAPI_AENC_CHN;
static td_handle g_adecHdl = SAMPLE_MAPI_ADEC_DEV;
static td_handle g_aoHdl = SAMPLE_MAPI_AO_INNER_DEV;
static td_handle g_aoChnHdl = SAMPLE_MAPI_AO_CHN;

static td_void SAMPLE_AUDIO_DumpBytes(const char *tag, const td_u8 *buf, td_u32 len)
{
    td_u32 dumpLen = (len < SAMPLE_AUDIO_DIAG_DUMP_BYTES) ? len : SAMPLE_AUDIO_DIAG_DUMP_BYTES;

    printf("%s len=%u first%u=", tag, len, dumpLen);
    for (td_u32 i = 0; i < dumpLen; i++) {
        printf("%02x", buf[i]);
        if (i + 1 < dumpLen) {
            printf(" ");
        }
    }
    printf("\n");
}

static td_void SAMPLE_AUDIO_DumpPcmStats(const char *tag, const hi_mapi_audio_frame *frame)
{
    if (frame == TD_NULL || frame->virt_addr[0] == TD_NULL || frame->len == 0) {
        printf("%s invalid frame=%p len=%u addr=%p\n", tag, frame, frame == TD_NULL ? 0 : frame->len,
            frame == TD_NULL ? TD_NULL : frame->virt_addr[0]);
        return;
    }

    const td_s16 *samples = (const td_s16 *)frame->virt_addr[0];
    td_u32 sampleCnt = frame->len / sizeof(td_s16);
    td_s16 minVal = 0;
    td_s16 maxVal = 0;
    td_u32 nonZeroCnt = 0;
    td_u64 absSum = 0;

    if (sampleCnt > 0) {
        minVal = samples[0];
        maxVal = samples[0];
    }
    for (td_u32 i = 0; i < sampleCnt; i++) {
        td_s32 sample = samples[i];
        if (sample < minVal) {
            minVal = (td_s16)sample;
        }
        if (sample > maxVal) {
            maxVal = (td_s16)sample;
        }
        if (sample != 0) {
            nonZeroCnt++;
        }
        absSum += (sample < 0) ? (td_u32)(-sample) : (td_u32)sample;
    }

    printf("%s len=%u samples=%u snd_mode=%d min=%d max=%d nonzero=%u avg_abs=%llu\n",
        tag, frame->len, sampleCnt, frame->snd_mode, minVal, maxVal, nonZeroCnt,
        sampleCnt == 0 ? 0 : (unsigned long long)(absSum / sampleCnt));
    SAMPLE_AUDIO_DumpBytes(tag, (const td_u8 *)frame->virt_addr[0], frame->len);
}

static td_bool SAMPLE_AUDIO_IsG711NativeStream(FILE *fd)
{
    td_u8 head[SAMPLE_AUDIO_OT_HEAD_BYTE_LEN] = {0};
    long pos = ftell(fd);
    if (pos < 0) {
        pos = 0;
    }

    (td_void)fseek(fd, 0, SEEK_SET);
    size_t readLen = fread(head, 1, sizeof(head), fd);
    (td_void)fseek(fd, pos, SEEK_SET);
    if (readLen != sizeof(head)) {
        return TD_FALSE;
    }

    return (head[0] == 0x00 && head[1] == 0x01 && head[2] == 0xf0 && head[3] == 0x00) ?
        TD_TRUE : TD_FALSE;
}

static td_void SAMPLE_AUDIO_Usage(td_void)
{
    printf("Usage : \n\t\033[33m[ao sample send frame from linux (big-little) only for demo.\n\t" \
        "pls send frame to ao on liteos for general use]\033[0m\n");
    printf("\t 0) ACap bind AEnc and dump raw.\n");
    printf("\t 1) ACap send frame to Ao normal chn\n");
    printf("\t 2) ADec bind AO, play aac\n");
    printf("\t 3) ACap get_frame -> AEnc + AFE provider switch\n");
    printf("\t    [--adc inner|es7210]  [--afe hisi|external]\n");
    printf("\t    [--fmt aac|g711a|g711u|opus] [--payload native|standard]\n");
    printf("\t    note: external AFE (postprocess NR) is AAC-only in this sample;\n");
    printf("\t          use hisi for g711/opus.\n");
    printf("\t    note: --adc es7210 selects the external ES7210 ADC topology (4-ch TDM, dual-mic + ref);\n");
    printf("\t          the board must have ot_es_drv.ko loaded before running this sample.\n");
    printf("\t 4) ADec bind AO, play  [--fmt aac|g711a|g711u|opus]  [--file <path>] [--payload native|standard]\n");

    return;
}

/* Mode 3/4 CLI helpers. */
static const char *SAMPLE_AUDIO_FindArg(int argc, char *argv[], const char *flag)
{
    for (int i = 2; i < argc - 1; i++) {
        if (argv[i] != NULL && strcmp(argv[i], flag) == 0) {
            return argv[i + 1];
        }
    }
    return NULL;
}

static td_bool SAMPLE_AUDIO_ValidateArgs(int argc, char *argv[])
{
    for (int i = 2; i < argc; i++) {
        if (argv[i] == NULL || argv[i][0] != '-') {
            continue;
        }
        if (strcmp(argv[i], "--adc") != 0 && strcmp(argv[i], "--afe") != 0 &&
            strcmp(argv[i], "--fmt") != 0 && strcmp(argv[i], "--file") != 0 &&
            strcmp(argv[i], "--payload") != 0) {
            printf("\033[31m[sample] unknown option '%s'; use --adc/--afe/--fmt/--file/--payload\033[0m\n",
                argv[i]);
            return TD_FALSE;
        }
        if (i + 1 >= argc || argv[i + 1] == NULL || argv[i + 1][0] == '-') {
            printf("\033[31m[sample] option '%s' requires a value\033[0m\n", argv[i]);
            return TD_FALSE;
        }
        i++;
    }
    return TD_TRUE;
}

static hi_mapi_audio_format SAMPLE_AUDIO_ParseFmt(const char *fmt_str, hi_mapi_audio_format fallback)
{
    if (fmt_str == NULL) {
        return fallback;
    }
    if (strcmp(fmt_str, "aac") == 0) {
        return HI_MAPI_AUDIO_FORMAT_AACLC;
    }
    if (strcmp(fmt_str, "g711a") == 0) {
        return HI_MAPI_AUDIO_FORMAT_G711A;
    }
    if (strcmp(fmt_str, "g711u") == 0) {
        return HI_MAPI_AUDIO_FORMAT_G711U;
    }
    if (strcmp(fmt_str, "opus") == 0) {
        return HI_MAPI_AUDIO_FORMAT_OPUS;
    }
    printf("\033[31m[sample] unknown --fmt '%s', using fallback\033[0m\n", fmt_str);
    return fallback;
}

static hi_mapi_audio_payload_format SAMPLE_AUDIO_ParsePayload(const char *payload_str)
{
    if (payload_str != NULL && strcmp(payload_str, "standard") == 0) {
        return HI_MAPI_AUDIO_PAYLOAD_STANDARD;
    }
    return HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE;
}

static const char *SAMPLE_AUDIO_PayloadName(hi_mapi_audio_payload_format payload_format)
{
    return (payload_format == HI_MAPI_AUDIO_PAYLOAD_STANDARD) ? "standard" : "native";
}

static const char *SAMPLE_AUDIO_FormatName(hi_mapi_audio_format fmt)
{
    switch (fmt) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            return "aac";
        case HI_MAPI_AUDIO_FORMAT_G711A:
            return "g711a";
        case HI_MAPI_AUDIO_FORMAT_G711U:
            return "g711u";
        case HI_MAPI_AUDIO_FORMAT_OPUS:
            return "opus";
        default:
            return "?";
    }
}

static td_bool SAMPLE_AUDIO_EndsWith(const td_char *str, const td_char *suffix)
{
    if (str == TD_NULL || suffix == TD_NULL) {
        return TD_FALSE;
    }

    size_t strLen = strlen(str);
    size_t suffixLen = strlen(suffix);
    if (suffixLen > strLen) {
        return TD_FALSE;
    }
    return (strcmp(str + strLen - suffixLen, suffix) == 0) ? TD_TRUE : TD_FALSE;
}

static td_bool SAMPLE_AUDIO_CheckFmtMatchesFile(const td_char *filePath, hi_mapi_audio_format fmt)
{
    const td_char *expectedSuffix = TD_NULL;
    switch (fmt) {
        case HI_MAPI_AUDIO_FORMAT_AACLC:
            expectedSuffix = ".aac";
            break;
        case HI_MAPI_AUDIO_FORMAT_G711A:
            expectedSuffix = ".g711a";
            break;
        case HI_MAPI_AUDIO_FORMAT_G711U:
            expectedSuffix = ".g711u";
            break;
        case HI_MAPI_AUDIO_FORMAT_OPUS:
            expectedSuffix = ".opus";
            break;
        default:
            return TD_FALSE;
    }

    if (!SAMPLE_AUDIO_EndsWith(filePath, expectedSuffix)) {
        HI_LOGE("AUDIO", "file '%s' does not match --fmt %s (expected suffix %s). Refuse to play to protect speaker.",
            filePath, SAMPLE_AUDIO_FormatName(fmt), expectedSuffix);
        return TD_FALSE;
    }
    return TD_TRUE;
}

static td_bool SAMPLE_AUDIO_CheckG711PlayableFile(const td_char *filePath, hi_mapi_audio_format fmt)
{
    if (fmt != HI_MAPI_AUDIO_FORMAT_G711A && fmt != HI_MAPI_AUDIO_FORMAT_G711U) {
        return TD_TRUE;
    }

    FILE *fd = fopen(filePath, "rb");
    if (fd == TD_NULL) {
        HI_LOGE("AUDIO", "open G711 file failed: %s", filePath);
        return TD_FALSE;
    }
    td_bool nativeStream = SAMPLE_AUDIO_IsG711NativeStream(fd);
    (td_void)fclose(fd);
    if (!nativeStream) {
        HI_LOGE("AUDIO", "%s is raw G711 payload. MAPI ADEC requires AENC native stream; use mode3 output. Refuse to play to avoid silent output.", filePath);
        return TD_FALSE;
    }
    return TD_TRUE;
}

static td_bool SAMPLE_AUDIO_IsSampleFmtSupported(hi_mapi_audio_format fmt)
{
    return (fmt == HI_MAPI_AUDIO_FORMAT_AACLC ||
        fmt == HI_MAPI_AUDIO_FORMAT_G711A ||
        fmt == HI_MAPI_AUDIO_FORMAT_G711U ||
        fmt == HI_MAPI_AUDIO_FORMAT_OPUS) ? TD_TRUE : TD_FALSE;
}

static td_bool SAMPLE_AUDIO_CheckFileReadable(const td_char *filePath)
{
    FILE *fd = fopen(filePath, "rb");
    if (fd == TD_NULL) {
        HI_LOGE("AUDIO", "open file failed: %s", filePath);
        return TD_FALSE;
    }
    (td_void)fclose(fd);
    return TD_TRUE;
}

static td_bool SAMPLE_AUDIO_MapAdtsSampleRate(td_u8 sampleRateIndex, hi_mapi_audio_sample_rate *sampleRate)
{
    static const hi_mapi_audio_sample_rate sampleRateTable[] = {
        HI_MAPI_AUDIO_SAMPLE_RATE_96000,
        HI_MAPI_AUDIO_SAMPLE_RATE_BUTT,  /* 88200: not exposed by hi_mapi_audio_sample_rate */
        HI_MAPI_AUDIO_SAMPLE_RATE_64000,
        HI_MAPI_AUDIO_SAMPLE_RATE_48000,
        HI_MAPI_AUDIO_SAMPLE_RATE_44100,
        HI_MAPI_AUDIO_SAMPLE_RATE_32000,
        HI_MAPI_AUDIO_SAMPLE_RATE_24000,
        HI_MAPI_AUDIO_SAMPLE_RATE_22050,
        HI_MAPI_AUDIO_SAMPLE_RATE_16000,
        HI_MAPI_AUDIO_SAMPLE_RATE_12000,
        HI_MAPI_AUDIO_SAMPLE_RATE_11025,
        HI_MAPI_AUDIO_SAMPLE_RATE_8000,
        HI_MAPI_AUDIO_SAMPLE_RATE_BUTT,  /* 7350: not exposed by hi_mapi_audio_sample_rate */
    };
    if (sampleRate == TD_NULL || sampleRateIndex >= (sizeof(sampleRateTable) / sizeof(sampleRateTable[0])) ||
        sampleRateTable[sampleRateIndex] == HI_MAPI_AUDIO_SAMPLE_RATE_BUTT) {
        return TD_FALSE;
    }
    *sampleRate = sampleRateTable[sampleRateIndex];
    return TD_TRUE;
}

static td_bool SAMPLE_AUDIO_GetAacFileAttr(const td_char *filePath, hi_mapi_audio_sample_rate *sampleRate,
    hi_mapi_audio_sound_mode *soundMode)
{
    FILE *fd = fopen(filePath, "rb");
    if (fd == TD_NULL) {
        HI_LOGE("AUDIO", "open AAC file failed: %s", filePath);
        return TD_FALSE;
    }

    td_u8 header[7] = {0};
    size_t readLen = fread(header, 1, sizeof(header), fd);
    (td_void)fclose(fd);
    if (readLen != sizeof(header) || header[0] != 0xFF || (header[1] & 0xF0) != 0xF0) {
        HI_LOGE("AUDIO", "invalid AAC ADTS header: %s", filePath);
        return TD_FALSE;
    }

    td_u8 sampleRateIndex = (header[2] & 0x3C) >> 2;
    td_u8 channelConfig = ((header[2] & 0x01) << 2) | ((header[3] & 0xC0) >> 6);
    if (!SAMPLE_AUDIO_MapAdtsSampleRate(sampleRateIndex, sampleRate)) {
        HI_LOGE("AUDIO", "unsupported AAC sample_rate_index=%u", sampleRateIndex);
        return TD_FALSE;
    }
    *soundMode = (channelConfig == 1) ? HI_MAPI_AUDIO_SOUND_MODE_MONO : HI_MAPI_AUDIO_SOUND_MODE_STEREO;
    return TD_TRUE;
}

static td_void ACapDumpThread(td_void *args)
{
    MAPI_UNUSED(args);
    td_s32 ret;
    td_handle acapHdl = g_acapHdl;
    td_handle acapChnHdl = g_acapChnHdl;
    hi_mapi_audio_frame audioFrm;
    hi_mapi_aec_frame aec_frm;
    size_t size;
    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)"ACapDumpThread", 0, 0, 0);
    while (g_acapDumpThdFlg && !SAMPLE_COMM_IsExitRequested()) {
        ret = hi_mapi_acap_get_frame(acapHdl, acapChnHdl, &audioFrm, &aec_frm);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "hi_mapi_acap_get_frame error:0x%x", ret);
            break;
        }

        /* only dump file 0 for mono(left or right channel),  dump file 0 and 1 for stereo */
        if (audioFrm.virt_addr[0] != TD_NULL) {
            size = fwrite(audioFrm.virt_addr[0], audioFrm.len, 1, g_acapRawFile[0]);
            SAMPLE_CHECK_WRITE_SIZE(size);
        }

        if (audioFrm.virt_addr[1] != TD_NULL) {
            size = fwrite(audioFrm.virt_addr[1], audioFrm.len, 1, g_acapRawFile[1]);
            SAMPLE_CHECK_WRITE_SIZE(size);
        }

        ret = hi_mapi_acap_release_frame(acapHdl, acapChnHdl, &audioFrm, &aec_frm);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "hi_mapi_acap_release_frame error:0x%x", ret);
        }
    }
    return;
}

static td_void SendFrameToAOChnThread(td_void *args)
{
    MAPI_UNUSED(args);
    td_s32 ret;
    td_handle acapHdl = g_acapHdl;
    td_handle acapChnHdl = g_acapChnHdl;
    td_handle aoHdl = g_aoHdl;
    td_handle aoChnHdl = g_aoChnHdl;
    hi_mapi_audio_frame audioFrm;
    hi_mapi_aec_frame aec_frm;

    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)"SendFrameToAOChnThread", 0, 0, 0);
    while (g_sendFrmToAOChnThdFlg && !SAMPLE_COMM_IsExitRequested()) {
        ret = hi_mapi_acap_get_frame(acapHdl, acapChnHdl, &audioFrm, &aec_frm);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "hi_mapi_acap_get_frame error:0x%x", ret);
            break;
        }

        ret = hi_mapi_ao_send_frame(aoHdl, aoChnHdl, &audioFrm, SAMPLE_AUDIO_SEND_FRAME_TIMEOUT_MS);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "hi_mapi_ao_send_frame error:0x%x", ret);
        }

        ret = hi_mapi_acap_release_frame(acapHdl, acapChnHdl, &audioFrm, &aec_frm);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "hi_mapi_acap_release_frame error:0x%x", ret);
        }
    }
    return;
}

static td_s32 SAMPLE_AUDIO_StartDumpThread(td_void)
{
    g_acapRawFile[0] = fopen(LEFT_RAW_FILEPATH, "wb");
    if (g_acapRawFile[0] == NULL) {
        HI_LOGE("AUDIO", "open file %s error!", LEFT_RAW_FILEPATH);
        return TD_FAILURE;
    }

    g_acapRawFile[1] = fopen(RIGHT_RAW_FILEPATH, "wb");
    if (g_acapRawFile[1] == NULL) {
        (td_void)fclose(g_acapRawFile[0]);
        g_acapRawFile[0] = NULL;
        HI_LOGE("AUDIO", "open file %s error!", RIGHT_RAW_FILEPATH);
        return TD_FAILURE;
    }

    g_acapDumpThdFlg = TD_TRUE;
    td_s32 ret = pthread_create(&g_acapDumpThd, TD_NULL, (td_void *)ACapDumpThread, TD_NULL);
    if (ret != TD_SUCCESS) {
        HI_LOGE("AUDIO", "pthread_create error!");
        (td_void)fclose(g_acapRawFile[0]);
        g_acapRawFile[0] = NULL;
        (td_void)fclose(g_acapRawFile[1]);
        g_acapRawFile[1] = NULL;
        g_acapDumpThdFlg = TD_FALSE;
        return TD_FAILURE;
    }

    return TD_SUCCESS;
}

static td_void SAMPLE_AUDIO_StopDumpThread(td_void)
{
    if (g_acapDumpThdFlg) {
        g_acapDumpThdFlg = TD_FALSE;
        pthread_join(g_acapDumpThd, TD_NULL);
    }
}

static td_s32 SAMPLE_AUDIO_InitMedia(td_void)
{
    /* hi_mapi_sys_init bootstraps the global bind table (g_bind_ctx); without
     * it hi_mapi_sys_bind/unbind return HI_MAPI_SYS_ENOTREADY (0xa3008010).
     * hi_mapi_sys_init_media alone does not cover this; both must be called. */
    HI_CHECK_RET(hi_mapi_sys_init());

    hi_mapi_sys_media_attr mediaAttr;
    HI_CHECK_RET(memset_s(&mediaAttr, sizeof(mediaAttr), 0, sizeof(hi_mapi_sys_media_attr)));
    mediaAttr.audio_mod_para.vqe_attr.talk_vqe_attr.open_mask =
        HI_MAPI_AI_TALKVQE_MASK_HPF | HI_MAPI_AI_TALKVQE_MASK_AEC | HI_MAPI_AI_TALKVQE_MASK_ANR;
    HI_CHECK_RET(hi_mapi_sys_init_media(&mediaAttr));

    return TD_SUCCESS;
}

static td_s32 SAMPLE_AUDIO_ACapBindAEncWithResampleDump(hi_mapi_audio_format audioFormat)
{
    td_s32 ret;
    SAMPLE_AUDIO_Attr audioAttr = {0};
    hi_mapi_mpp_chn src_chn = { HI_MAPI_MOD_ACAP, SAMPLE_MAPI_AI_INNER_DEV, SAMPLE_MAPI_AI_CHN };
    hi_mapi_mpp_chn dst_chn = { HI_MAPI_MOD_AENC, 0, SAMPLE_MAPI_AENC_CHN };

    /* init sys */
    HI_CHECK_RET(SAMPLE_AUDIO_InitMedia());

    /* init and start acap */
    g_acapHdl = SAMPLE_MAPI_AI_INNER_DEV;
    g_acapChnHdl = SAMPLE_MAPI_AI_CHN;
    SAMPLE_AUDIO_StartAcap(g_acapHdl, g_acapChnHdl, audioFormat);
    SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_enable_vqe(g_acapHdl, g_acapChnHdl,
        HI_MAPI_ACAP_VQE_TYPE_RECORD, OT_INVALID_HANDLE));
    HI_LOGI("AUDIO", "init and start acap complete");

    /* init and start aenc */
    g_aencHdl = SAMPLE_MAPI_AENC_CHN;
    hi_mapi_aenc_callback aencCB = { TD_NULL, TD_NULL };
    SAMPLE_CHECK_GOTO(ret, memset_s(&aencCB, sizeof(aencCB), 0, sizeof(hi_mapi_aenc_callback)));
    aencCB.proc_data_cb = SAMPLE_AUDIO_DataProc;

    char timeBuffer[FILE_FULL_PATH_MAX_LEN];
    SAMPLE_COMM_GetLocalTime(timeBuffer, FILE_FULL_PATH_MAX_LEN);
    td_char fileName[FILE_FULL_PATH_MAX_LEN] = {0};
    ret = snprintf_s(fileName, FILE_FULL_PATH_MAX_LEN, FILE_FULL_PATH_MAX_LEN - 1, "mode0_%s_chn%u%s.%s",
        SAMPLE_AUDIO_Pt2Str(audioFormat), g_aencHdl, timeBuffer, SAMPLE_AUDIO_Pt2Str(audioFormat));
    if (ret == TD_FAILURE) {
        HI_LOGE("AUDIO", "snprintf_s error:%#x", ret);
        goto exit;
    }

    audioAttr.fd = SAMPLE_AUDIO_OpenAudioFile(fileName, FILE_FULL_PATH_MAX_LEN);
    SAMPLE_CHECK_POINTER_NULL_GOTO(audioAttr.fd, ret, exit);
    audioAttr.aenc_format = audioFormat;
    aencCB.private_data = &audioAttr;
    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_StartAenc(g_aencHdl, audioFormat, &aencCB,
        HI_MAPI_AUDIO_PAYLOAD_HI_NATIVE));
    HI_LOGI("AUDIO", "init and start aenc complete");

    /* bind via sys: src = ACAP, dst = AENC */
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_bind(&src_chn, &dst_chn));
    HI_LOGI("AUDIO", "acap bind aenc complete");

    /* acap dump raw */
    HI_LOGI("AUDIO", "acap dump raw ...");
    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_StartDumpThread());

    printf("Press Enter key to stop audio record...\n");
    (void)SAMPLE_COMM_WaitForEnterOrExit();

    SAMPLE_AUDIO_StopDumpThread();
    HI_LOGI("AUDIO", "ACapDumpThread stop");
exit:

    SAMPLE_AUDIO_CloseAudioFile(&g_acapRawFile[0]);
    SAMPLE_AUDIO_CloseAudioFile(&g_acapRawFile[1]);
    (td_void)hi_mapi_sys_unbind(&src_chn, &dst_chn);
    SAMPLE_AUDIO_StopAenc(g_aencHdl, audioFormat, &aencCB);

    SAMPLE_AUDIO_CloseAudioFile(&audioAttr.fd);
    hi_mapi_acap_disable_vqe(g_acapHdl, g_acapChnHdl);
    SAMPLE_AUDIO_StopAcap(g_acapHdl, g_acapChnHdl);
    SAMPLE_AUDIO_FreeG711DataBuf();
    hi_mapi_sys_deinit_media();
    hi_mapi_sys_deinit();

    return ret;
}

static td_s32 SAMPLE_AUDIO_ACapSendFrameToAO(td_void)
{
    td_s32 ret;

    /* init sys (must precede sys_init_media to bootstrap bind table) */
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_init());
    hi_mapi_sys_media_attr mediaAttr;
    SAMPLE_CHECK_GOTO(ret, memset_s(&mediaAttr, sizeof(mediaAttr), 0, sizeof(hi_mapi_sys_media_attr)));
    mediaAttr.audio_mod_para.vqe_attr.talk_vqe_attr.open_mask =
        HI_MAPI_AI_TALKVQE_MASK_HPF | HI_MAPI_AI_TALKVQE_MASK_AEC | HI_MAPI_AI_TALKVQE_MASK_ANR;
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_init_media(&mediaAttr));

    /* init and start acap — Talk VQE requires MONO; use 16kHz to match VQE working rate */
    g_acapHdl = SAMPLE_MAPI_AI_INNER_DEV;
    g_acapChnHdl = SAMPLE_MAPI_AI_CHN;
    g_aoChnHdl = SAMPLE_MAPI_AO_CHN;
    hi_mapi_acap_attr acapAttr;
    SAMPLE_AUDIO_ConfigACapAttr(&acapAttr);
    acapAttr.sound_mode    = HI_MAPI_AUDIO_SOUND_MODE_MONO;
    acapAttr.sample_rate   = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
    acapAttr.resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
    SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_init(g_acapHdl, &acapAttr));
    SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_start(g_acapHdl, g_acapChnHdl));
    SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_set_volume(g_acapHdl, SAMPLE_MAPI_AI_IN_GAIN));
    HI_LOGI("AUDIO", "init and start acap complete");

    /* init and start ao — must match acap sound mode for AEC reference to work */
    g_aoHdl = SAMPLE_MAPI_AO_INNER_DEV;
    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_StartAo(g_aoHdl, g_aoChnHdl, HI_MAPI_AUDIO_SOUND_MODE_MONO,
        HI_MAPI_AUDIO_SAMPLE_RATE_16000));
    HI_LOGI("AUDIO", "init and start ao complete");

    /* Enable Talk VQE with AO as AEC reference:
     * - AEC cancels speaker echo fed back into mic (prevents howling)
     * - ANR reduces background noise floor
     * Must be called after both ACAP and AO are started so the AO reference is valid.
     * Requires CFG_SUPPORT_TALKVQE=ON at cmake time. */
    SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_enable_vqe(g_acapHdl, g_acapChnHdl,
        HI_MAPI_ACAP_VQE_TYPE_TALK, g_aoHdl));
    HI_LOGI("AUDIO", "Talk VQE (AEC+ANR) enabled, ao_ref=%d", g_aoHdl);

    /* acap send frame to ao */
    g_sendFrmToAOChnThdFlg = TD_TRUE;
    ret = pthread_create(&g_sendFrmAOChnThd, TD_NULL, (td_void *)SendFrameToAOChnThread, TD_NULL);
    if (ret != TD_SUCCESS) {
        HI_LOGE("AUDIO", "pthread_create error!");
        g_sendFrmToAOChnThdFlg = TD_FALSE;
    }
    printf("Press Enter key to stop audio record...\n");
    (void)SAMPLE_COMM_WaitForEnterOrExit();

    if (g_sendFrmToAOChnThdFlg) {
        g_sendFrmToAOChnThdFlg = TD_FALSE;
        pthread_join(g_sendFrmAOChnThd, TD_NULL);
    }

    HI_LOGI("AUDIO", "SendFrameThread stop");

exit:

    SAMPLE_AUDIO_StopAo(g_aoHdl, g_aoChnHdl);
    SAMPLE_AUDIO_StopAcap(g_acapHdl, g_acapChnHdl);
    hi_mapi_sys_deinit_media();
    hi_mapi_sys_deinit();

    return ret;
}

static td_u32 SAMPLE_AUDIO_DecodeOpusSampleLen(const td_u8 header[SAMPLE_AUDIO_OPUS_STD_LEN_BYTES])
{
    td_u32 len = 0;
    for (td_u32 i = 0; i < SAMPLE_AUDIO_OPUS_STD_LEN_BYTES; i++) {
        len = (len << 8) | header[i];
    }
    return len;
}

static td_s32 SAMPLE_AUDIO_ReadOpusStandardFrame(FILE *fd, td_u8 *buf, td_u32 bufLen, td_u32 *frameLen)
{
    if (fd == TD_NULL || buf == TD_NULL || frameLen == TD_NULL) {
        return TD_FAILURE;
    }

    td_u8 header[SAMPLE_AUDIO_OPUS_STD_LEN_BYTES] = {0};
    size_t readLen = fread(header, 1, sizeof(header), fd);
    if (readLen == 0) {
        *frameLen = 0;
        return TD_SUCCESS;
    }
    if (readLen != sizeof(header)) {
        return TD_FAILURE;
    }
    td_u32 payloadLen = SAMPLE_AUDIO_DecodeOpusSampleLen(header);
    if (payloadLen == 0 || payloadLen > SAMPLE_AUDIO_OPUS_MAX_PACKET_SIZE || payloadLen > bufLen) {
        HI_LOGE("AUDIO", "[sample-mode4][opus-play] invalid standard payload len=%u", payloadLen);
        return TD_FAILURE;
    }
    readLen = fread(buf, 1, payloadLen, fd);
    if (readLen != payloadLen) {
        return TD_FAILURE;
    }
    *frameLen = payloadLen;
    return TD_SUCCESS;
}

static td_void *SendFrameToADecThread(td_void *args)
{
    MAPI_UNUSED(args);
    td_s32 ret;
    hi_mapi_audio_stream audioStream = {0};
    td_u8 *frame = TD_NULL;
    td_u32 frameLen = 0;

    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)"SendFrameToADecThread", 0, 0, 0);
    if (g_adecFormat == HI_MAPI_AUDIO_FORMAT_AACLC) {
        AAC_Handle_S aacHandle;
        ret = AAC_Open(&aacHandle, g_adecFilePath);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "AAC_Open %s error:0x%x", g_adecFilePath, ret);
            return TD_NULL;
        }
        HI_LOGI("AUDIO", "[sample-mode4][aac-play] file=%s size=%u", g_adecFilePath, aacHandle.stStream.u32FileLen);
        td_u32 aacSendCnt = 0;
        td_u32 aacTotalBytes = 0;
        td_u32 aacResetCnt = 0;
        while (1) {
            pthread_mutex_lock(&g_sendFrmToAdecChnThdFlgMutex);
            if (!g_sendFrmToAdecChnThdFlg || SAMPLE_COMM_IsExitRequested()) {
                pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);
                break;
            }
            pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);
            ret = AAC_ReadFrame(&aacHandle, &frame, &frameLen);
            if (ret != TD_SUCCESS || frameLen <= 0) {
                aacResetCnt++;
                HI_LOGI("AUDIO", "[sample-mode4][aac-play] EOF reached, rewind. sent=%u bytes=%u rewind=%u",
                    aacSendCnt, aacTotalBytes, aacResetCnt);
                ret = AAC_Reset(&aacHandle);
                if (ret != TD_SUCCESS) {
                    HI_LOGE("AUDIO", "AAC_Reset error:0x%x", ret);
                    break;
                }
                continue;
            }

            if (aacSendCnt < SAMPLE_AUDIO_DIAG_MAX_FRAMES) {
                SAMPLE_AUDIO_DumpBytes("[sample-mode4][aac-play] send", frame, frameLen);
            }
            audioStream.stream = frame;
            audioStream.len = frameLen;
            ret = hi_mapi_adec_send_stream(g_adecHdl, &audioStream, TD_TRUE);
            if (ret != TD_SUCCESS) {
                HI_LOGE("AUDIO", "hi_mapi_adec_send_stream error:0x%x", ret);
                break;
            }
            aacSendCnt++;
            aacTotalBytes += frameLen;
        }
        HI_LOGI("AUDIO", "[sample-mode4][aac-play] exit. sent=%u bytes=%u reset=%u",
            aacSendCnt, aacTotalBytes, aacResetCnt);
        ret = AAC_Close(&aacHandle);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "AAC_Close error:0x%x", ret);
        }
    } else if (g_adecFormat == HI_MAPI_AUDIO_FORMAT_OPUS) {
        FILE *fd = fopen(g_adecFilePath, "rb");
        if (fd == TD_NULL) {
            HI_LOGE("AUDIO", "open %s failed", g_adecFilePath);
            return TD_NULL;
        }
        long opusFileSize = -1;
        if (fseek(fd, 0, SEEK_END) == 0) {
            opusFileSize = ftell(fd);
            (td_void)fseek(fd, 0, SEEK_SET);
        }
        HI_LOGI("AUDIO", "[sample-mode4][opus-play] file=%s size=%ld payload=%s",
            g_adecFilePath, opusFileSize, SAMPLE_AUDIO_PayloadName(g_adecPayloadFormat));
        td_u8 streamBuf[SAMPLE_AUDIO_OPUS_MAX_PACKET_SIZE];
        td_u32 opusSendCnt = 0;
        td_u32 opusTotalBytes = 0;
        td_u32 opusEofCnt = 0;
        while (1) {
            pthread_mutex_lock(&g_sendFrmToAdecChnThdFlgMutex);
            if (!g_sendFrmToAdecChnThdFlg || SAMPLE_COMM_IsExitRequested()) {
                pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);
                break;
            }
            pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);

            td_u32 readLen = 0;
            if (g_adecPayloadFormat == HI_MAPI_AUDIO_PAYLOAD_STANDARD) {
                ret = SAMPLE_AUDIO_ReadOpusStandardFrame(fd, streamBuf, sizeof(streamBuf), &readLen);
                if (ret != TD_SUCCESS) {
                    HI_LOGE("AUDIO", "[sample-mode4][opus-play] read standard opus frame failed. sent=%u bytes=%u eof=%u",
                        opusSendCnt, opusTotalBytes, opusEofCnt);
                    break;
                }
            } else {
                readLen = (td_u32)fread(streamBuf, 1, SAMPLE_AUDIO_OPUS_ADEC_STREAM_LEN, fd);
            }
            if (readLen == 0) {
                opusEofCnt++;
                HI_LOGI("AUDIO", "[sample-mode4][opus-play] EOF reached, rewind. sent=%u bytes=%u eof=%u",
                    opusSendCnt, opusTotalBytes, opusEofCnt);
                if (opusFileSize <= 0 || fseek(fd, 0, SEEK_SET) != 0) {
                    HI_LOGE("AUDIO", "[sample-mode4][opus-play] rewind failed, stop.");
                    break;
                }
                continue;
            }
            if (opusSendCnt < SAMPLE_AUDIO_DIAG_MAX_FRAMES) {
                SAMPLE_AUDIO_DumpBytes("[sample-mode4][opus-play] send", streamBuf, readLen);
            }
            audioStream.stream = streamBuf;
            audioStream.len = readLen;
            ret = hi_mapi_adec_send_stream(g_adecHdl, &audioStream, TD_TRUE);
            if (ret != TD_SUCCESS) {
                HI_LOGE("AUDIO", "hi_mapi_adec_send_stream error:0x%x", ret);
                break;
            }
            opusSendCnt++;
            opusTotalBytes += readLen;
        }
        HI_LOGI("AUDIO", "[sample-mode4][opus-play] exit. sent=%u bytes=%u eof=%u",
            opusSendCnt, opusTotalBytes, opusEofCnt);
        (td_void)fclose(fd);
    } else {
        FILE *fd = fopen(g_adecFilePath, "rb");
        if (fd == TD_NULL) {
            HI_LOGE("AUDIO", "open %s failed", g_adecFilePath);
            return TD_NULL;
        }
        long fileSize = -1;
        if (fseek(fd, 0, SEEK_END) == 0) {
            fileSize = ftell(fd);
            (td_void)fseek(fd, 0, SEEK_SET);
        }
        td_bool nativeStream = SAMPLE_AUDIO_IsG711NativeStream(fd);
        td_u32 frameBytes = nativeStream ? SAMPLE_AUDIO_G711_NATIVE_STREAM_LEN : SAMPLE_AUDIO_G711_ADEC_STREAM_LEN;
        HI_LOGI("AUDIO", "[sample-mode4][g711-play] file=%s size=%ld frame_bytes=%u native_stream=%s",
            g_adecFilePath, fileSize, frameBytes, nativeStream ? "yes" : "no");
        td_u8 streamBuf[SAMPLE_AUDIO_G711_NATIVE_STREAM_LEN];
        td_u32 sendCnt = 0;
        td_u32 totalBytes = 0;
        td_u32 eofCnt = 0;
        while (1) {
            pthread_mutex_lock(&g_sendFrmToAdecChnThdFlgMutex);
            if (!g_sendFrmToAdecChnThdFlg || SAMPLE_COMM_IsExitRequested()) {
                pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);
                break;
            }
            pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);

            size_t readLen = fread(streamBuf, 1, frameBytes, fd);
            if (readLen == 0) {
                eofCnt++;
                HI_LOGI("AUDIO", "[sample-mode4][g711-play] EOF reached, rewind. sent=%u bytes=%u eof=%u",
                    sendCnt, totalBytes, eofCnt);
                (td_void)hi_mapi_adec_send_end_of_stream(g_adecHdl);
                (td_void)fseek(fd, 0, SEEK_SET);
                continue;
            }
            if (sendCnt < SAMPLE_AUDIO_DIAG_MAX_FRAMES) {
                SAMPLE_AUDIO_DumpBytes("[sample-mode4][g711-play] send", streamBuf, (td_u32)readLen);
            }
            audioStream.stream = streamBuf;
            audioStream.len = (td_u32)readLen;
            ret = hi_mapi_adec_send_stream(g_adecHdl, &audioStream, TD_TRUE);
            if (ret != TD_SUCCESS) {
                HI_LOGE("AUDIO", "hi_mapi_adec_send_stream error:0x%x", ret);
                break;
            }
            sendCnt++;
            totalBytes += (td_u32)readLen;
        }
        HI_LOGI("AUDIO", "[sample-mode4][g711-play] exit. sent=%u bytes=%u eof=%u", sendCnt, totalBytes, eofCnt);
        (td_void)fclose(fd);
    }

    ret = hi_mapi_adec_send_end_of_stream(g_adecHdl);
    if (ret != TD_SUCCESS) {
        HI_LOGE("AUDIO", "hi_mapi_adec_send_end_of_stream error:0x%x", ret);
    }

    return TD_NULL;
}

/* Mode 4 helper forward declaration. */
static td_s32 SAMPLE_AUDIO_PlayFile(const td_char *filePath, hi_mapi_audio_format fmt);

static td_void SendFrameToAEncThread(td_void *args)
{
    MAPI_UNUSED(args);
    td_s32 ret;
    hi_mapi_audio_frame audioFrm;
    hi_mapi_aec_frame aecFrm;

    prctl(PR_SET_NAME, (unsigned long)(uintptr_t)"SendFrameToAEncThread", 0, 0, 0);
    td_u32 pcmDiagCnt = 0;
    while (g_sendFrmToAencChnThdFlg && !SAMPLE_COMM_IsExitRequested()) {
        ret = hi_mapi_acap_get_frame(g_acapHdl, g_acapChnHdl, &audioFrm, &aecFrm);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "hi_mapi_acap_get_frame error:0x%x", ret);
            break;
        }
        if (pcmDiagCnt < SAMPLE_AUDIO_DIAG_MAX_FRAMES) {
            SAMPLE_AUDIO_DumpPcmStats("[sample-mode3][pre-aenc-pcm]", &audioFrm);
            pcmDiagCnt++;
        }

        ret = hi_mapi_aenc_send_frame(g_aencHdl, &audioFrm);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "hi_mapi_aenc_send_frame error:0x%x", ret);
        }

        ret = hi_mapi_acap_release_frame(g_acapHdl, g_acapChnHdl, &audioFrm, &aecFrm);
        if (ret != TD_SUCCESS) {
            HI_LOGE("AUDIO", "hi_mapi_acap_release_frame error:0x%x", ret);
            break;
        }
    }
}

static td_void SAMPLE_AUDIO_ConfigMode5AcapAttr(hi_mapi_acap_attr *acapAttr, hi_mapi_audio_format fmt,
    td_bool unisoundAfe)
{
    SAMPLE_AUDIO_ConfigACapAttr(acapAttr);
    if (unisoundAfe && fmt == HI_MAPI_AUDIO_FORMAT_AACLC) {
        acapAttr->sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
        acapAttr->resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
        acapAttr->sound_mode = HI_MAPI_AUDIO_SOUND_MODE_STEREO;
        acapAttr->pt_num_per_frm = SAMPLE_MAPI_AUDIO_POINT_PER_FRAME;
    } else if ((fmt == HI_MAPI_AUDIO_FORMAT_G711A) || (fmt == HI_MAPI_AUDIO_FORMAT_G711U)) {
        /* Hisi RecordVQE supports 16K/48K only. Capture at 16K, then let ACAP resample
         * to 8K so G711 AENC still receives 480 samples per frame. */
        acapAttr->pt_num_per_frm = SAMPLE_AUDIO_G711_VQE_POINT_PER_FRAME;
        acapAttr->sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
        acapAttr->resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_8000;
        acapAttr->sound_mode = HI_MAPI_AUDIO_SOUND_MODE_MONO;
    } else if (fmt == HI_MAPI_AUDIO_FORMAT_OPUS) {
        /* ADEC OPUS defaults to 16kHz mono; encode at 16kHz to match. */
        acapAttr->pt_num_per_frm = OT_AUDIO_SAMPLE_RATE_16000 / 100; /* 160 pts = 10ms at 16kHz */
        acapAttr->sample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
        acapAttr->resample_rate = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
        acapAttr->sound_mode = HI_MAPI_AUDIO_SOUND_MODE_MONO;
    }
}

/* Build ACAP attributes for the external ES7210 ADC (4-ch TDM: dual-mic + ref).
 * Mirrors the verified template from agent_audio_sample (AGENT_ACAP_INPUT_ES7210=1).
 * Format-specific overrides (sample_rate / resample_rate / pt_num) are applied on
 * top by SAMPLE_AUDIO_ConfigMode5AcapAttr after this fills the ES7210 baseline. */
static td_void SAMPLE_AUDIO_ConfigEs7210AcapAttr(hi_mapi_acap_attr *acapAttr)
{
    if (acapAttr == TD_NULL) {
        return;
    }
    (td_void)memset_s(acapAttr, sizeof(*acapAttr), 0, sizeof(*acapAttr));
    acapAttr->sample_rate    = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
    acapAttr->bit_width      = HI_MAPI_AUDIO_BIT_WIDTH_16;
    acapAttr->sound_mode     = HI_MAPI_AUDIO_SOUND_MODE_MONO;
    acapAttr->track_mode     = HI_MAPI_AUDIO_TRACK_NORMAL;
    acapAttr->work_mode      = HI_MAPI_AIO_MODE_PCM_MASTER_STD;
    acapAttr->pt_num_per_frm = SAMPLE_MAPI_AUDIO_POINT_PER_FRAME;
    acapAttr->mixer_mic_mode = HI_MAPI_ACODEC_MIXER_BUTT;
    acapAttr->resample_rate  = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
    acapAttr->i2s_type       = HI_MAPI_AIO_I2STYPE_EXTERN;
    /* ES7210 4-ch TDM: ch0/ch1 = dual mic, ch2 = speaker ref (AEC), out_chn = logical output. */
    acapAttr->input_topology.enable     = TD_TRUE;
    acapAttr->input_topology.chn_cnt    = SAMPLE_ES7210_CHN_CNT;
    acapAttr->input_topology.clk_share  = TD_FALSE;
    acapAttr->input_topology.mic_chn_cnt = SAMPLE_ES7210_MIC_CNT;
    acapAttr->input_topology.mic_chn_hdl[0] = 0;
    acapAttr->input_topology.mic_chn_hdl[1] = 1;
    acapAttr->input_topology.ref_chn_hdl  = SAMPLE_ES7210_REF_CHN;
    acapAttr->input_topology.out_chn_hdl  = SAMPLE_MAPI_AI_CHN;
}

static td_s32 SAMPLE_AUDIO_StartMode5Aenc(td_handle aencHdl, hi_mapi_audio_format fmt,
    const hi_mapi_aenc_callback *aencCB, td_bool monoAac, hi_mapi_audio_sample_rate sampleRate,
    hi_mapi_audio_payload_format payloadFormat)
{
    if (!monoAac || fmt != HI_MAPI_AUDIO_FORMAT_AACLC) {
        return SAMPLE_AUDIO_StartAenc(aencHdl, fmt, aencCB, payloadFormat);
    }

    hi_mapi_aenc_aac_attr aacAttr = {
        .aac_type = HI_MAPI_AAC_TYPE_AACLC,
        .bit_rate = HI_MAPI_AAC_BPS_48K,
        .bit_width = HI_MAPI_AUDIO_BIT_WIDTH_16,
        .sample_rate = sampleRate,
        .sound_mode = HI_MAPI_AUDIO_SOUND_MODE_MONO,
        .trans_type = HI_MAPI_AAC_TRANS_TYPE_ADTS,
        .band_width = 0,
    };
    hi_mapi_aenc_attr aencAttr = {
        .aenc_format = HI_MAPI_AUDIO_FORMAT_AACLC,
        .pt_num_per_frm = SAMPLE_MAPI_AUDIO_POINT_PER_FRAME,
        .value = &aacAttr,
        .value_len = sizeof(aacAttr),
    };

    HI_CHECK_RET(hi_mapi_aenc_init(aencHdl, &aencAttr));
    HI_CHECK_RET(hi_mapi_aenc_register_callback(aencHdl, aencCB));
    HI_CHECK_RET(hi_mapi_aenc_start(aencHdl));
    return TD_SUCCESS;
}

/* Mode 3: capture + encode with selectable AFE provider through public hi_mapi APIs. */
static td_s32 SAMPLE_AUDIO_ACapEncWithAfeSwitch(int argc, char *argv[])
{
    td_s32 ret = TD_SUCCESS;
    td_bool sysInited = TD_FALSE;
    td_bool acapInited = TD_FALSE;
    td_bool vqeEnabled = TD_FALSE;
    td_bool aencStarted = TD_FALSE;
    if (!SAMPLE_AUDIO_ValidateArgs(argc, argv)) {
        return TD_FAILURE;
    }
    const char *adc_name = SAMPLE_AUDIO_FindArg(argc, argv, "--adc");
    const char *afe_name = SAMPLE_AUDIO_FindArg(argc, argv, "--afe");
    const char *fmt_str  = SAMPLE_AUDIO_FindArg(argc, argv, "--fmt");
    const char *payload_str = SAMPLE_AUDIO_FindArg(argc, argv, "--payload");
    if (adc_name == NULL) {
        adc_name = "inner";
    }
    if (afe_name == NULL) {
        afe_name = "hisi";
    }
    hi_mapi_audio_format fmt = SAMPLE_AUDIO_ParseFmt(fmt_str, HI_MAPI_AUDIO_FORMAT_AACLC);
    hi_mapi_audio_payload_format payloadFormat = SAMPLE_AUDIO_ParsePayload(payload_str);

    HI_LOGI("AUDIO", "[sample-mode3] adc=%s afe=%s fmt=%s payload=%s",
        adc_name, afe_name, SAMPLE_AUDIO_FormatName(fmt), SAMPLE_AUDIO_PayloadName(payloadFormat));

    if (strcmp(adc_name, "inner") != 0 && strcmp(adc_name, "es7210") != 0) {
        HI_LOGE("AUDIO", "[sample-mode3] unsupported --adc '%s' (use inner|es7210)", adc_name);
        return TD_FAILURE;
    }
    if (strcmp(afe_name, "hisi") != 0 && strcmp(afe_name, "external") != 0) {
        HI_LOGE("AUDIO", "[sample-mode3] unsupported --afe '%s' (use hisi|external)", afe_name);
        return TD_FAILURE;
    }
    if (!SAMPLE_AUDIO_IsSampleFmtSupported(fmt)) {
        HI_LOGE("AUDIO", "[sample-mode3] fmt=%s is not wired in pipeline yet; use aac/g711a/g711u/opus",
            SAMPLE_AUDIO_FormatName(fmt));
        return TD_FAILURE;
    }
    if (strcmp(afe_name, "external") == 0 && fmt != HI_MAPI_AUDIO_FORMAT_AACLC) {
        HI_LOGE("AUDIO",
            "[sample-mode3] external AFE (postprocess NR) currently outputs 16 kHz mono PCM; "
            "only --fmt aac is supported in this sample");
        return TD_FAILURE;
    }
    if (payload_str != NULL && strcmp(payload_str, "native") != 0 && strcmp(payload_str, "standard") != 0) {
        HI_LOGE("AUDIO", "[sample-mode3] unsupported --payload '%s'; use native|standard", payload_str);
        return TD_FAILURE;
    }
    if (fmt != HI_MAPI_AUDIO_FORMAT_OPUS && payload_str != NULL) {
        HI_LOGE("AUDIO", "[sample-mode3] --payload is only valid for fmt=opus");
        return TD_FAILURE;
    }

    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_InitMedia());
    sysInited = TD_TRUE;

    g_acapHdl = SAMPLE_MAPI_AI_INNER_DEV;
    g_acapChnHdl = SAMPLE_MAPI_AI_CHN;
    td_bool es7210Adc = (strcmp(adc_name, "es7210") == 0) ? TD_TRUE : TD_FALSE;
    td_bool unisoundAfe = (strcmp(afe_name, "external") == 0) ? TD_TRUE : TD_FALSE;  /* software (external) AFE */
    hi_mapi_acap_attr acapAttr;
    if (es7210Adc) {
        /* ES7210 external ADC baseline: 4-ch TDM, PCM master std, EXTERN i2s. */
        SAMPLE_AUDIO_ConfigEs7210AcapAttr(&acapAttr);
        /* Format-specific overrides on top of the ES7210 baseline. */
        if ((fmt == HI_MAPI_AUDIO_FORMAT_G711A) || (fmt == HI_MAPI_AUDIO_FORMAT_G711U)) {
            acapAttr.pt_num_per_frm = SAMPLE_AUDIO_G711_VQE_POINT_PER_FRAME;
            acapAttr.sample_rate    = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
            acapAttr.resample_rate  = HI_MAPI_AUDIO_SAMPLE_RATE_8000;
        } else if (fmt == HI_MAPI_AUDIO_FORMAT_OPUS) {
            acapAttr.pt_num_per_frm = OT_AUDIO_SAMPLE_RATE_16000 / 100;  /* 160 samples = 10ms @ 16kHz */
            acapAttr.sample_rate    = HI_MAPI_AUDIO_SAMPLE_RATE_48000;
            acapAttr.resample_rate  = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
        }
        /* External AFE (unisound NR) requires 256 samples/frame, matching
         * agent_audio_sample's behavior for both inner and ES7210 ADC. */
        if (unisoundAfe) {
            acapAttr.pt_num_per_frm = SAMPLE_AFE_FRAME_SAMPLES;
        }
    } else {
        SAMPLE_AUDIO_ConfigMode5AcapAttr(&acapAttr, fmt, unisoundAfe);
        /* Inner ADC + external AFE also needs 256 samples/frame for NR. */
        if (unisoundAfe && fmt == HI_MAPI_AUDIO_FORMAT_AACLC) {
            acapAttr.pt_num_per_frm = SAMPLE_AFE_FRAME_SAMPLES;
        }
    }
    HI_LOGI("AUDIO", "[sample-mode3] acap attr: adc=%s sample_rate=%d resample_rate=%d sound_mode=%d pt_num=%u i2s=%d",
        adc_name, acapAttr.sample_rate, acapAttr.resample_rate, acapAttr.sound_mode,
        acapAttr.pt_num_per_frm, acapAttr.i2s_type);
    SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_init(g_acapHdl, &acapAttr));
    acapInited = TD_TRUE;

    if (strcmp(afe_name, "external") == 0) {
        SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_set_param(g_acapHdl,
            HI_MAPI_ACAP_CMD_AFE_PROVIDER_CONFIG, afe_name, strlen(afe_name) + 1));
        hi_mapi_acap_afe_attr_t afeAttr = { .model_path = "./model1.bin" };
        SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_set_param(g_acapHdl,
            HI_MAPI_ACAP_CMD_AFE_ATTR_CONFIG, &afeAttr, sizeof(afeAttr)));
    }

    SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_start(g_acapHdl, g_acapChnHdl));
    td_bool g711Fmt = (fmt == HI_MAPI_AUDIO_FORMAT_G711A || fmt == HI_MAPI_AUDIO_FORMAT_G711U) ? TD_TRUE : TD_FALSE;
    /* ES7210 has no inner acodec provider; set_volume routes through acodec and
     * must be skipped for external ADC. ES7210 gain is set on-chip via I2C or
     * fixed by the module; the agent_audio_sample path does the same skip. */
    if (!es7210Adc) {
        td_s32 aiGain = SAMPLE_MAPI_AI_IN_GAIN;
        if (unisoundAfe) {
            aiGain = SAMPLE_AUDIO_UNISOUND_AI_IN_GAIN;
        } else if (g711Fmt) {
            aiGain = SAMPLE_AUDIO_HISI_G711_AI_IN_GAIN;
        }
        SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_set_volume(g_acapHdl, aiGain));
        HI_LOGI("AUDIO", "[sample-mode3] ai input gain=%d dB", aiGain);
    } else {
        HI_LOGI("AUDIO", "[sample-mode3] ES7210 external ADC: skip set_volume (no inner acodec)");
    }
    SAMPLE_CHECK_GOTO(ret, hi_mapi_acap_enable_vqe(g_acapHdl, g_acapChnHdl,
        HI_MAPI_ACAP_VQE_TYPE_RECORD, OT_INVALID_HANDLE));
    vqeEnabled = TD_TRUE;
    HI_LOGI("AUDIO", "init and start acap complete");

    g_aencHdl = SAMPLE_MAPI_AENC_CHN;
    SAMPLE_AUDIO_Attr audioAttr = {0};
    hi_mapi_aenc_callback aencCB = { TD_NULL, TD_NULL };
    SAMPLE_CHECK_GOTO(ret, memset_s(&aencCB, sizeof(aencCB), 0, sizeof(aencCB)));
    aencCB.proc_data_cb = SAMPLE_AUDIO_DataProc;

    char timeBuffer[FILE_FULL_PATH_MAX_LEN];
    SAMPLE_COMM_GetLocalTime(timeBuffer, FILE_FULL_PATH_MAX_LEN);
    td_char fileName[FILE_FULL_PATH_MAX_LEN] = {0};
    if (es7210Adc) {
        /* ES7210 path: prefix file name with "es7210_" so the recording is
         * clearly distinguishable from inner-ADC runs. */
        if (fmt == HI_MAPI_AUDIO_FORMAT_OPUS) {
            ret = snprintf_s(fileName, FILE_FULL_PATH_MAX_LEN, FILE_FULL_PATH_MAX_LEN - 1,
                "mode3_es7210_%s_%s_%s_chn%u%s.%s", afe_name, SAMPLE_AUDIO_Pt2Str(fmt),
                SAMPLE_AUDIO_PayloadName(payloadFormat), g_aencHdl, timeBuffer, SAMPLE_AUDIO_Pt2Str(fmt));
        } else {
            ret = snprintf_s(fileName, FILE_FULL_PATH_MAX_LEN, FILE_FULL_PATH_MAX_LEN - 1,
                "mode3_es7210_%s_%s_chn%u%s.%s", afe_name, SAMPLE_AUDIO_Pt2Str(fmt),
                g_aencHdl, timeBuffer, SAMPLE_AUDIO_Pt2Str(fmt));
        }
    } else {
        /* inner ADC (default): preserve the original naming so any existing
         * scripts / docs that match "mode3_<afe>_<fmt>" keep working. */
        if (fmt == HI_MAPI_AUDIO_FORMAT_OPUS) {
            ret = snprintf_s(fileName, FILE_FULL_PATH_MAX_LEN, FILE_FULL_PATH_MAX_LEN - 1,
                "mode3_%s_%s_%s_chn%u%s.%s", afe_name, SAMPLE_AUDIO_Pt2Str(fmt),
                SAMPLE_AUDIO_PayloadName(payloadFormat), g_aencHdl, timeBuffer, SAMPLE_AUDIO_Pt2Str(fmt));
        } else {
            ret = snprintf_s(fileName, FILE_FULL_PATH_MAX_LEN, FILE_FULL_PATH_MAX_LEN - 1,
                "mode3_%s_%s_chn%u%s.%s", afe_name, SAMPLE_AUDIO_Pt2Str(fmt),
                g_aencHdl, timeBuffer, SAMPLE_AUDIO_Pt2Str(fmt));
        }
    }
    if (ret == TD_FAILURE) {
        HI_LOGE("AUDIO", "snprintf_s error:%#x", ret);
        goto exit;
    }
    audioAttr.fd = SAMPLE_AUDIO_OpenAudioFile(fileName, FILE_FULL_PATH_MAX_LEN);
    SAMPLE_CHECK_POINTER_NULL_GOTO(audioAttr.fd, ret, exit);
    audioAttr.aenc_format = fmt;
    audioAttr.payload_format = payloadFormat;
    audioAttr.deleteOtHead = (fmt == HI_MAPI_AUDIO_FORMAT_G711A || fmt == HI_MAPI_AUDIO_FORMAT_G711U) ?
        TD_TRUE : TD_FALSE;
    if (audioAttr.deleteOtHead) {
        HI_LOGI("AUDIO", "[sample-mode3][g711-record] output file keeps AENC native 4-byte frame header for playback");
    }
    aencCB.private_data = &audioAttr;
    /* AAC encoder sound_mode must match the PCM sound_mode produced by ACAP.
     * ES7210 outputs per-channel MONO; external (unisound) AFE also outputs MONO.
     * Only inner ADC with hisi AFE outputs STEREO AAC-compatible PCM in this sample. */
    td_bool monoAac = unisoundAfe || es7210Adc;
    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_StartMode5Aenc(g_aencHdl, fmt, &aencCB,
        monoAac, acapAttr.resample_rate, payloadFormat));
    aencStarted = TD_TRUE;
    HI_LOGI("AUDIO", "init and start aenc complete");

    g_sendFrmToAencChnThdFlg = TD_TRUE;
    ret = pthread_create(&g_sendFrmAencChnThd, TD_NULL, (td_void *)SendFrameToAEncThread, TD_NULL);
    if (ret != TD_SUCCESS) {
        HI_LOGE("AUDIO", "pthread_create error!");
        g_sendFrmToAencChnThdFlg = TD_FALSE;
        goto exit;
    }

    printf("Press Enter key to stop audio record...\n");
    (void)SAMPLE_COMM_WaitForEnterOrExit();

exit:
    if (g_sendFrmToAencChnThdFlg) {
        g_sendFrmToAencChnThdFlg = TD_FALSE;
        pthread_join(g_sendFrmAencChnThd, TD_NULL);
    }
    if (aencStarted) {
        SAMPLE_AUDIO_StopAenc(g_aencHdl, fmt, &aencCB);
    }
    SAMPLE_AUDIO_CloseAudioFile(&audioAttr.fd);
    if (vqeEnabled) {
        (td_void)hi_mapi_acap_disable_vqe(g_acapHdl, g_acapChnHdl);
    }
    if (acapInited) {
        SAMPLE_AUDIO_StopAcap(g_acapHdl, g_acapChnHdl);
    }
    SAMPLE_AUDIO_FreeG711DataBuf();
    if (sysInited) {
        (td_void)hi_mapi_sys_deinit_media();
        (td_void)hi_mapi_sys_deinit();
    }
    return ret;
}

/* Mode 4: decode and play the selected audio format from a file. */
static td_s32 SAMPLE_AUDIO_PlayWithFmt(int argc, char *argv[])
{
    if (!SAMPLE_AUDIO_ValidateArgs(argc, argv)) {
        return TD_FAILURE;
    }
    const char *fmt_str   = SAMPLE_AUDIO_FindArg(argc, argv, "--fmt");
    const char *file_path = SAMPLE_AUDIO_FindArg(argc, argv, "--file");
    const char *payload_str = SAMPLE_AUDIO_FindArg(argc, argv, "--payload");
    hi_mapi_audio_format fmt = SAMPLE_AUDIO_ParseFmt(fmt_str, HI_MAPI_AUDIO_FORMAT_AACLC);
    hi_mapi_audio_payload_format payloadFormat = SAMPLE_AUDIO_ParsePayload(payload_str);

    if (file_path == NULL) {
        if (fmt != HI_MAPI_AUDIO_FORMAT_AACLC) {
            HI_LOGE("AUDIO", "[sample-mode4] --file is required for fmt=%s",
                SAMPLE_AUDIO_FormatName(fmt));
            return TD_FAILURE;
        }
        file_path = AAC_FILEPATH;
    }
    if (file_path[0] == '\0') {
        HI_LOGE("AUDIO", "[sample-mode4] --file is empty; please export the file variable first");
        return TD_FAILURE;
    }
    if (!SAMPLE_AUDIO_IsSampleFmtSupported(fmt)) {
        HI_LOGE("AUDIO", "[sample-mode4] fmt=%s is not wired in pipeline yet; use aac/g711a/g711u/opus",
            SAMPLE_AUDIO_FormatName(fmt));
        return TD_FAILURE;
    }
    if (payload_str != NULL && strcmp(payload_str, "native") != 0 && strcmp(payload_str, "standard") != 0) {
        HI_LOGE("AUDIO", "[sample-mode4] unsupported --payload '%s'; use native|standard", payload_str);
        return TD_FAILURE;
    }
    if (fmt != HI_MAPI_AUDIO_FORMAT_OPUS && payload_str != NULL) {
        HI_LOGE("AUDIO", "[sample-mode4] --payload is only valid for fmt=opus");
        return TD_FAILURE;
    }
    if (!SAMPLE_AUDIO_CheckFileReadable(file_path)) {
        return TD_FAILURE;
    }
    if (!SAMPLE_AUDIO_CheckFmtMatchesFile(file_path, fmt)) {
        return TD_FAILURE;
    }
    if (!SAMPLE_AUDIO_CheckG711PlayableFile(file_path, fmt)) {
        return TD_FAILURE;
    }
    g_adecPayloadFormat = payloadFormat;
    HI_LOGI("AUDIO", "[sample-mode4] fmt=%s file=%s payload=%s",
        SAMPLE_AUDIO_FormatName(fmt), file_path, SAMPLE_AUDIO_PayloadName(g_adecPayloadFormat));

    return SAMPLE_AUDIO_PlayFile(file_path, fmt);
}

static td_s32 SAMPLE_AUDIO_PlayFile(const td_char *filePath, hi_mapi_audio_format fmt)
{
    td_s32 ret;
    td_bool sysInited = TD_FALSE;
    td_bool mediaInited = TD_FALSE;
    td_bool adecAoReady = TD_FALSE;
    td_bool sendThreadStarted = TD_FALSE;

    /* init sys (must precede sys_init_media to bootstrap bind table) */
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_init());
    sysInited = TD_TRUE;
    hi_mapi_sys_media_attr mediaAttr;
    SAMPLE_CHECK_GOTO(ret, memset_s(&mediaAttr, sizeof(mediaAttr), 0, sizeof(hi_mapi_sys_media_attr)));
    mediaAttr.audio_mod_para.vqe_attr.talk_vqe_attr.open_mask =
        HI_MAPI_AI_TALKVQE_MASK_HPF | HI_MAPI_AI_TALKVQE_MASK_AEC | HI_MAPI_AI_TALKVQE_MASK_ANR;
    SAMPLE_CHECK_GOTO(ret, hi_mapi_sys_init_media(&mediaAttr));
    mediaInited = TD_TRUE;

    /* init and start ao */
    g_aoHdl = SAMPLE_MAPI_AO_INNER_DEV;
    g_adecFilePath = filePath;
    g_adecFormat = fmt;
    hi_mapi_audio_sample_rate sampleRate = ((fmt == HI_MAPI_AUDIO_FORMAT_G711A) ||
        (fmt == HI_MAPI_AUDIO_FORMAT_G711U)) ? HI_MAPI_AUDIO_SAMPLE_RATE_8000 : HI_MAPI_AUDIO_SAMPLE_RATE_BUTT;
    hi_mapi_audio_sound_mode soundMode = HI_MAPI_AUDIO_SOUND_MODE_STEREO;
    if (fmt == HI_MAPI_AUDIO_FORMAT_G711A || fmt == HI_MAPI_AUDIO_FORMAT_G711U) {
        soundMode = HI_MAPI_AUDIO_SOUND_MODE_MONO;
        HI_LOGI("AUDIO", "[sample-mode4] G711 attr: sample_rate=%d sound_mode=mono", sampleRate);
    }
    if (fmt == HI_MAPI_AUDIO_FORMAT_OPUS) {
        soundMode = HI_MAPI_AUDIO_SOUND_MODE_MONO;
        sampleRate = HI_MAPI_AUDIO_SAMPLE_RATE_16000;
        HI_LOGI("AUDIO", "[sample-mode4] OPUS attr: sample_rate=16000 sound_mode=mono");
    }
    if (fmt == HI_MAPI_AUDIO_FORMAT_AACLC) {
        SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_GetAacFileAttr(filePath, &sampleRate, &soundMode) ?
            TD_SUCCESS : TD_FAILURE);
        HI_LOGI("AUDIO", "[sample-mode4] AAC attr: sample_rate=%d sound_mode=%s", sampleRate,
            soundMode == HI_MAPI_AUDIO_SOUND_MODE_MONO ? "mono" : "stereo");
    }
    SAMPLE_CHECK_GOTO(ret, SAMPLE_AUDIO_BindAdecAndStartAo(g_aoHdl, g_aoChnHdl, g_adecHdl,
        fmt, soundMode, sampleRate, g_adecPayloadFormat));
    adecAoReady = TD_TRUE;
    HI_LOGI("AUDIO", "Bind Adec and start ao complete");

    /* read aac and send frame to adec */
    pthread_mutex_lock(&g_sendFrmToAdecChnThdFlgMutex);
    g_sendFrmToAdecChnThdFlg = TD_TRUE;
    pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);
    ret = pthread_create(&g_sendFrmAdecChnThd, TD_NULL, SendFrameToADecThread, TD_NULL);
    if (ret != TD_SUCCESS) {
        HI_LOGE("AUDIO", "pthread_create error!");
        pthread_mutex_lock(&g_sendFrmToAdecChnThdFlgMutex);
        g_sendFrmToAdecChnThdFlg = TD_FALSE;
        pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);
        goto exit;
    }
    sendThreadStarted = TD_TRUE;
    printf("Press Enter key to stop audio play...\n");
    (void)SAMPLE_COMM_WaitForEnterOrExit();
    pthread_mutex_lock(&g_sendFrmToAdecChnThdFlgMutex);
    g_sendFrmToAdecChnThdFlg = TD_FALSE;
    pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);
    pthread_join(g_sendFrmAdecChnThd, TD_NULL);
    sendThreadStarted = TD_FALSE;

    HI_LOGI("AUDIO", "SendFrameThread stop");

exit:
    if (sendThreadStarted) {
        pthread_mutex_lock(&g_sendFrmToAdecChnThdFlgMutex);
        g_sendFrmToAdecChnThdFlg = TD_FALSE;
        pthread_mutex_unlock(&g_sendFrmToAdecChnThdFlgMutex);
        pthread_join(g_sendFrmAdecChnThd, TD_NULL);
    }
    SAMPLE_AUDIO_UnBindAdecAndStopAo(g_aoHdl, g_aoChnHdl, g_adecHdl,
        adecAoReady, adecAoReady, adecAoReady);
    if (mediaInited) {
        td_s32 cleanupRet = hi_mapi_sys_deinit_media();
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] sys_deinit_media ret=0x%x", cleanupRet);
    }
    if (sysInited) {
        td_s32 cleanupRet = hi_mapi_sys_deinit();
        HI_LOGI("AUDIO", "[sample-mode4][cleanup] sys_deinit ret=0x%x", cleanupRet);
    }

    return ret;
}

int main(int argc, char *argv[])
{
    td_s32 ret;
    td_char ch;
    /* SS_LOG_SetEnabledLevel intentionally omitted: lives in libmwlog which is
     * not part of pipeline build; default log level is fine for this sample. */
    ret = SAMPLE_COMM_RegisterSigHandler();
    if (ret != TD_SUCCESS) {
        HI_LOGE("AUDIO", "SAMPLE_COMM_RegisterSigHandler fail ret:0x%x", ret);
        return TD_FAILURE;
    }

    SAMPLE_AUDIO_Usage();
    /* Read mode from argv[1] when provided so stdin remains available for the exit prompt. */
    if (argc >= 2 && argv[1] != TD_NULL && argv[1][0] != '\0') {
        ch = argv[1][0];
        printf("[argv] selected mode: %c\n", ch);
    } else {
        ret = SAMPLE_COMM_GetInputChar(&ch);
        if (ret != TD_SUCCESS) {
            return TD_FAILURE;
        }
    }
    switch (ch) {
        case '0':
            ret = SAMPLE_AUDIO_ACapBindAEncWithResampleDump(HI_MAPI_AUDIO_FORMAT_AACLC);
            break;
        case '1':
            ret = SAMPLE_AUDIO_ACapSendFrameToAO();
            break;
#if 0
        /* Legacy G711 bind-encode path is disabled for this transfer test.
         * The audio component validation uses mode 3 (get_frame + AFE + AEnc). */
        case '2':
            ret = SAMPLE_AUDIO_Encode(SAMPLE_MAPI_AI_INNER_DEV, "mode2_g711a", TD_TRUE,
                HI_MAPI_AUDIO_FORMAT_G711A);
            break;
#endif
        case '2':
            ret = SAMPLE_AUDIO_PlayFile(AAC_FILEPATH, HI_MAPI_AUDIO_FORMAT_AACLC);
            break;
        case '3':
            ret = SAMPLE_AUDIO_ACapEncWithAfeSwitch(argc, argv);
            break;
        case '4':
            ret = SAMPLE_AUDIO_PlayWithFmt(argc, argv);
            break;
        default:
            HI_LOGE("AUDIO", "the index is invalid!");
            SAMPLE_AUDIO_Usage();
            return TD_FAILURE;
    }

    if (ret == TD_SUCCESS) {
        HI_LOGI("AUDIO", "The program exited successfully!");
    } else {
        HI_LOGE("AUDIO", "The program exits abnormally, ret=0x%0x!", ret);
    }

    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
