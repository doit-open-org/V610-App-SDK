/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef SAMPLE_PUBLIC_AUDIO_H
#define SAMPLE_PUBLIC_AUDIO_H

#include "audio_sample_common.h"


#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */


#define SAMPLE_SAVE_TYPE_POSTFIX                 8
#define SAMPLE_AIO_MAX_POINT_PER_FRAME_G711      480
#define SAMPLE_AUDIO_HANDLE_FRAME_USLEEP_TIME   (5 * 1000)
#define SAMPLE_AUDIO_SEND_FRAME_MAX_TIME         10
#define SAMPLE_AUDIO_SEND_FRAME_TIMEOUT_MS       500
#define SAMPLE_AUDIO_OT_HEAD_BYTE_LEN          4
#define SAMPLE_AUDIO_STEREO_SOUND_MODE_CHN_CNT   2
#define SAMPLE_AUDIO_QUALITY_NUM                 9
#define SAMPLE_AUDIO_POINT_PER_FRAME_MP3         1152

#define LEFT_RAW_FILEPATH    "./ai_dump_ch0.raw"
#define RIGHT_RAW_FILEPATH   "./ai_dump_ch1.raw"
#define AUDIO_FILE_FILEPATH  "./audio_stream"

typedef struct {
    FILE *fd;
    hi_mapi_audio_format aenc_format;
    hi_mapi_audio_payload_format payload_format;
    td_bool deleteOtHead;
} SAMPLE_AUDIO_Attr;

td_void SAMPLE_AUDIO_ConfigACapAttr(hi_mapi_acap_attr *acap_attr);
td_void SAMPLE_AUDIO_ConfigAEncAttr(hi_mapi_aenc_attr *aencAttr,
    hi_mapi_aenc_aac_attr *aacAencAttr);
#ifdef ENABLE_MP3
td_void SAMPLE_AUDIO_ConfigAEncMp3Attr(hi_mapi_aenc_attr *aencAttr,
    hi_mapi_aenc_mp3_attr *mp3Attr);
#endif
td_void SAMPLE_AUDIO_ConfigAOAttr(hi_mapi_ao_attr *ao_attr);
td_s32 SAMPLE_AUDIO_DataProc(td_handle aencHdl, const hi_mapi_audio_stream *streamData, td_void *private_data);
FILE *SAMPLE_AUDIO_OpenAudioFile(const td_char *filePath, td_u32 pathStrLen);
td_void SAMPLE_AUDIO_CloseAudioFile(FILE **fd);
td_char *SAMPLE_AUDIO_Pt2Str(hi_mapi_audio_format aenc_format);
td_s32 SAMPLE_AUDIO_StartAcap(td_handle acapHdl, td_handle acapChnHdl, hi_mapi_audio_format aenc_format);
td_void SAMPLE_AUDIO_StopAcap(td_handle acapHdl, td_handle acapChnHdl);
td_s32 SAMPLE_AUDIO_StartAenc(td_handle aencHdl, hi_mapi_audio_format aenc_format,
    const hi_mapi_aenc_callback *aencCB, hi_mapi_audio_payload_format payload_format);
td_void SAMPLE_AUDIO_StopAenc(td_handle aencHdl, hi_mapi_audio_format aenc_format, const hi_mapi_aenc_callback *aencCB);
td_s32 SAMPLE_AUDIO_StartAo(td_handle aoHdl, td_handle aoChnHdl, hi_mapi_audio_sound_mode sound_mode,
    hi_mapi_audio_sample_rate sample_rate);
td_s32 SAMPLE_AUDIO_BindAdecAndStartAo(td_handle aoHdl, td_handle aoChnHdl, td_handle adecHdl,
    hi_mapi_audio_format adec_format, hi_mapi_audio_sound_mode sound_mode, hi_mapi_audio_sample_rate sample_rate,
    hi_mapi_audio_payload_format payload_format);
td_void SAMPLE_AUDIO_StopAo(td_handle aoHdl, td_handle aoChnHdl);
td_void SAMPLE_AUDIO_UnBindAdecAndStopAo(td_handle aoHdl, td_handle aoChnHdl, td_handle adecHdl,
    td_bool bound, td_bool aoInited, td_bool adecInited);
td_s32 SAMPLE_AUDIO_Encode(td_handle acapHdl, const td_char *filePath, td_bool deleteOtHead,
    hi_mapi_audio_format aenc_format);
td_void SAMPLE_AUDIO_FreeG711DataBuf();

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* SAMPLE_PUBLIC_AUDIO_H */
