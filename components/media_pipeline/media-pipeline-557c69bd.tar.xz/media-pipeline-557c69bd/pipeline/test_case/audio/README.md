# sample_pipeline_audio

`sample_pipeline_audio` 实现 Hi3516CV610 板端 pipeline 音频采集、播放、编码、解码、ADC 切换、AFE provider 切换和 OPUS payload 转换验证，面向音频组件接口联调与板端回归场景。

**功能特性：**

- 支持 ACAP、AENC、ADEC、AO 基础音频链路验证。
- 支持 inner（内置 Codec）、es7210（外置 ES7210 ADC）两类采集输入切换验证。
- 支持 hisi、unisound 两类 AFE provider 切换验证。
- 支持 AAC、G711A、G711U、OPUS 编码录制和文件播放验证。
- 支持按 `sample_pipeline_audio` 运行时依赖自动打包 SDK 动态库。

---

## 目录结构

```text
audio/
├── CMakeLists.txt                 # sample_pipeline_audio 编译入口
├── README.md                      # 使用说明
├── package_deploy.sh              # 部署包生成脚本
├── sample_pipeline_audio.c        # sample 主流程与各模式入口
├── sample_pipeline_audio_helpers.c
├── sample_pipeline_audio_helpers.h
├── sample_public_audio.c
├── sample_public_audio.h
├── aac.c
├── aac.h
├── stream.c
├── stream.h
└── data/
    └── 1.aac                      # mode 2 内置播放文件
```

## 前提条件

- 已编译并烧录 `agent_audio_sample` 案例。
- unisound AFE 验证依赖 `components/hiai/offline_voice/adapter/unisound/kws/tool/model1.bin`。

### 配置与依赖

- **案例依赖**：使用 `agent_audio_sample` 案例进行板端验证，编译命令如下：

```bash
bash scripts/build.sh build --target cv610_ev_board samples agent_audio_sample \
    -DAUDIO_COMP_CODEC_PROVIDER=opus_sdk \
    -DCFG_SUPPORT_TALKVQE=ON
```

## 编译

在 `hi_aiot_solution/components/media` 目录下按顺序执行：

```bash
cd hi_aiot_solution/components/media

cmake -S pipeline -B build-pipeline-audio \
    -DCMAKE_C_COMPILER=/opt/linux/x86-arm/arm-v01c02-linux-musleabi-gcc/bin/arm-v01c02-linux-musleabi-gcc \
    -DCMAKE_CXX_COMPILER=/opt/linux/x86-arm/arm-v01c02-linux-musleabi-gcc/bin/arm-v01c02-linux-musleabi-g++ \
    -DHI_SDK_ROOT=$(realpath ../../_build/sdk/Hi3516CV610) \
    -DHIAI_ADAPT_ANR_INC=$(realpath ../../components/hiai/adapt/afe/providers/unisound/include) \
    -DAUDIO_COMP_AFE_PROVIDER=hisi,external \
    -DPIPELINE_TEST_NR_PROVIDER=unisound \
    -DCFG_SUPPORT_TALKVQE=ON \
    -DBUILD_SAMPLES=ON \
    -DBUILD_SAMPLE_AUDIO=ON \
    -DBUILD_SAMPLE_VIE=OFF \
    -DBUILD_SAMPLE_VIO=OFF

cmake --build build-pipeline-audio --target sample_pipeline_audio -j

./pipeline/test_case/audio/package_deploy.sh build-pipeline-audio
```

### 构建参数


| 选项                                      | 取值                                                   | 说明                               |
| --------------------------------------- | ---------------------------------------------------- | -------------------------------- |
| `HI_SDK_ROOT`                           | `_build/sdk/Hi3516CV610`                             | 指定 SDK 根目录（由前提条件中的 `agent_audio_sample` 编译生成）。 |
| `HIAI_ADAPT_ANR_INC`                    | `components/hiai/adapt/afe/providers/unisound/include` | external AFE 依赖的 unisound ANR 头文件目录；未设置时 external AFE 配置会报错。 |
| `AUDIO_COMP_AFE_PROVIDER`               | `hisi,external`                                      | 编译 hisi 和 external AFE provider。 |
| `PIPELINE_TEST_NR_PROVIDER`             | `unisound`                                           | external AFE 使用的 NR 实现；`stub` 为空实现（仅编译验证），`unisound` 为真实云知声 NR（板测必须）。 |
| `UNISOUND_KWS_PATH`（可选）             | `components/hiai/adapt/kws/providers/unisound/sdk`   | 指定 unisound KWS 库和模型目录；不传时由 CMake 从 `HIAI_ADAPT_ANR_INC` 自动推导。 |
| `CFG_SUPPORT_TALKVQE`                   | `ON`                                                 | 启用 Talk VQE，用于 mode 1 对讲链路。      |
| `BUILD_SAMPLE_AUDIO`                    | `ON`                                                 | 编译 audio sample。                 |
| `BUILD_SAMPLE_VIE` / `BUILD_SAMPLE_VIO` | `OFF`                                                | 跳过 VIE/VIO sample，缩短编译时间。        |


### 编译产物

```text
components/media/build-pipeline-audio/test_case/audio/sample_pipeline_audio
components/media/build-pipeline-audio/test_case/audio/deploy.tgz
```

部署包内容如下：

```text
deploy/
├── sample_pipeline_audio
├── run.sh
├── data/
│   └── 1.aac
├── model1.bin
└── lib/
    ├── libgcc_s.so.1
    ├── libss_mpi.so / libss_mpi_audio.so / libot_base.so / libot_irq.so
    ├── libvqe_res.so / libvqe_talkv2.so / libvqe_*.so
    └── libsns_hy006_3814_0011.so
```

## 烧写

本 sample 不单独生成可烧写镜像。板端验证前先编译并烧录 `agent_audio_sample` 案例，具体烧录方式参考 `apps/cv610_ev_board/samples/agent_audio_sample/README.md`。

`deploy.tgz` 可通过挂载文件系统、SCP、TFTP 或 U 盘传输到开发板，也可参考增量编译方式将文件集成进文件系统镜像。

## 板端环境与 ADC 模式

`--adc inner` 与 `--adc es7210` 依赖不同的板端 rootfs 环境（由 `agent_audio_sample` 的 `AGENT_ACAP_INPUT` 编译参数决定），二者互斥：

- **inner rootfs**（默认）：只能验 `--adc inner` 全部组合。
- **ES7210 rootfs**（`AGENT_ACAP_INPUT=es7210` 编译烧录）：只能验 `--adc es7210` 全部组合。

根因：ES7210 rootfs 的 `sys_config.ko` 与 `S93extadc` 把 I2C1 / I2S pinmux 切给 ES7210，内置 Codec 通路被让出；反之 inner rootfs 不带 ES7210 驱动，ES7210 路径跑不起来。

要验全部 4 个 `ADC × AFE` 组合，需要两套 `agent_audio_sample` 镜像分别烧录。**`sample_pipeline_audio` 的 `deploy.tgz` 只编译一份即可**，同一份部署包在两种 rootfs 下都能跑。

Mode 0 / 1 / 2 / 4 不涉及 ADC 切换；但 Mode 2 / 4 的 AO 播放走内置 Codec，ES7210 rootfs 下因功放 pinmux 被禁用可能无声。

## 上板运行

1. 停止系统默认应用：

```bash
pkill AI_Agent_DEMO
```

1. 拷贝并解压部署包：

```bash
cd /mnt
rm -rf deploy
# 将 components/media/build-pipeline-audio/test_case/audio/deploy.tgz 拷贝到 /mnt
tar -xzf deploy.tgz
cd deploy
chmod +x run.sh sample_pipeline_audio
```

1. 查看命令帮助：

```bash
./run.sh
```

1. 按需执行各验证模式：

**inner rootfs 下运行**（默认 `AGENT_ACAP_INPUT=inner` 烧录，`--adc` 参数可不传）：

```bash
./run.sh 0
./run.sh 1
./run.sh 2
./run.sh 3 --afe hisi --fmt aac
./run.sh 3 --afe external --fmt aac
./run.sh 3 --afe hisi --fmt g711a
./run.sh 3 --afe hisi --fmt g711u
./run.sh 3 --afe hisi --fmt opus
./run.sh 4 --fmt aac --file <record_file>
```

**ES7210 rootfs 下运行**（需另烧 `AGENT_ACAP_INPUT=es7210` 的 `agent_audio_sample` 镜像，详见"板端环境与 ADC 模式"章节）：

```bash
./run.sh 3 --adc es7210 --afe hisi --fmt aac
./run.sh 3 --adc es7210 --afe external --fmt aac
```

### 退出应用

录制和播放命令进入等待状态后，按回车停止当前流程并触发资源释放。程序异常退出后，重新运行前先确认 `AI_Agent_DEMO` 未重新占用音频设备。

## 功能说明

### 术语说明


| 缩写   | 全称                        | 说明                                |
| ---- | ------------------------- | --------------------------------- |
| ACAP | Audio Capture             | 音频采集模块，对应板载麦克风输入。                 |
| AENC | Audio Encoder             | 音频编码模块，将 PCM 编码为 AAC、G711 或 OPUS。 |
| ADEC | Audio Decoder             | 音频解码模块，将压缩码流还原为 PCM。              |
| AO   | Audio Output              | 音频输出模块，对应板载喇叭或耳机输出。               |
| AFE  | Audio Front End           | 音频前端处理，负责 ANR、AEC 等算法。            |
| VQE  | Voice Quality Enhancement | 语音质量增强，包含 ANR、AEC、HPF、AGC 等子模块。   |


### AFE Provider


| 参数值        | 说明                                            |
| ---------- | --------------------------------------------- |
| `hisi`     | 使用 SDK 内置海思原生 VQE 算法，支持 AAC、G711A、G711U、OPUS。 |
| `external` | 使用外置第三方 AFE（postprocess NR），依赖 `model1.bin`，当前仅支持 AAC。          |


### 采集输入 ADC


| 参数值      | 说明                                                                                      |
| -------- | --------------------------------------------------------------------------------------- |
| `inner`  | 默认。板载内置 Codec，I2S master / stereo，按格式默认覆盖采样率与声道。                                  |
| `es7210` | 外置 ES7210 ADC，PCM master std / 4-ch TDM / 双 mic + 参考通道 / 16 kHz mono。需要板端事先加载 `ot_es_drv.ko`。 |


### 编码格式


| 参数值     | 采样率    | 声道     | 说明                       |
| ------- | ------ | ------ | ------------------------ |
| `aac`   | 48 kHz | stereo | 本地录制存储格式。                |
| `g711a` | 8 kHz  | mono   | 窄带 A 律语音格式。              |
| `g711u` | 8 kHz  | mono   | 窄带 μ 律语音格式。              |
| `opus`  | 16 kHz | mono   | 面向 VOIP 和 AI 对话场景的低延迟格式。 |


### Mode 0：基础 AAC 录制

ACAP bind AENC，麦克风采集后编码为 AAC 文件。

```bash
./run.sh 0
```

预期现象：

- 终端打印 `init and start acap complete`、`init and start aenc complete`。
- 按回车停止后生成 `mode0_aac_chn0_<timestamp>.aac` 或同类 AAC 文件。
- 使用 mode 4 播放录制文件，声音正常，无明显杂音或失真。

### Mode 1：采集直通播放

ACAP 以 16 kHz 单声道采集，开启 Talk VQE 后送 AO 实时播放。

```bash
./run.sh 1
```

预期现象：

- 终端打印 `Talk VQE (AEC+ANR) enabled`。
- 喇叭实时播放麦克风采集声音，无持续啸叫。
- 背景底噪被压制，说话输出清晰。

### Mode 2：内置 AAC 文件播放

ADEC bind AO，播放部署包内置的 `data/1.aac`。

```bash
./run.sh 2
```

预期现象：

- 终端打印 `Bind Adec and start ao complete`。
- 喇叭播放 `1.aac` 内容，声音无爆音、无变速。
- 回车停止后资源释放正常。

### Mode 3：AFE 处理与多格式录制

ACAP 逐帧获取 PCM，经 AFE 处理后送 AENC 编码写文件。

**inner rootfs 下**：

```bash
./run.sh 3 --afe hisi --fmt aac
./run.sh 3 --afe external --fmt aac
./run.sh 3 --afe hisi --fmt g711a
./run.sh 3 --afe hisi --fmt g711u
./run.sh 3 --afe hisi --fmt opus
```

**ES7210 rootfs 下**（需另烧 `AGENT_ACAP_INPUT=es7210` 镜像）：

```bash
./run.sh 3 --adc es7210 --afe hisi --fmt aac
./run.sh 3 --adc es7210 --afe external --fmt aac
```

`--adc` 取值：

| 参数值    | 说明                                                                                              |
| ------ | ----------------------------------------------------------------------------------------------- |
| `inner`    | 默认。使用板载内置 Codec（I2S master、stereo、48 kHz 基线，按格式覆盖采样率/声道）。                                 |
| `es7210` | 使用外置 ES7210 ADC（PCM master std、I2S extern、4-ch TDM、双 mic + 参考通道、16 kHz mono）。需要板端事先加载 `ot_es_drv.ko`。 |

`--adc inner` 与 `--adc es7210` 依赖的板端 rootfs 环境互斥，详见"板端环境与 ADC 模式"章节。

预期现象：

- `hisi` AFE 打印 VQE enable 成功日志。
- `external` AFE 打印模型加载成功日志。
- `--adc es7210` 启动日志中出现 `adc=es7210` 与 `i2s=2`（`HI_MAPI_AIO_I2STYPE_EXTERN`），`/proc/umap/ai` 中显示外置 I2S / 4 通道状态。
- `--adc inner`（默认）与原有行为一致。
- 录制文件可通过 mode 4 在板端播放（仅 inner rootfs 可用，ES7210 rootfs 下 AO 因功放 pinmux 被禁用无法启动）。
- 录制的 AAC / G711 / OPUS 文件可直接拷到 PC 播放验证，AAC 用系统播放器或 `ffplay` 即可打开，便于在 ES7210 rootfs 下验证录音内容：`scp root@<board-ip>:/mnt/deploy/mode3_*.aac .`。
- OPUS 文件播放速度为 1x，无变速变调。

### Mode 4：指定格式文件播放

ADEC bind AO，读取本地文件并按指定格式播放。

```bash
./run.sh 4 --fmt aac --file mode0_aac_chn0_<timestamp>.aac
./run.sh 4 --fmt g711a --file mode3_hisi_g711a_chn0_boot<N>_000.g711a
./run.sh 4 --fmt g711u --file mode3_hisi_g711u_chn0_boot<N>_000.g711u
./run.sh 4 --fmt opus --file mode3_hisi_opus_native_chn0_boot<N>_000.opus
```

预期现象：

- 喇叭播放对应录制内容，速度正常，无爆音。
- 回车停止后 cleanup 日志返回值为 `0x0`。
- 不出现 `MMB LEAK` 或 `Segmentation fault`。

### 误用保护

以下命令应被拒绝并打印错误，不进入播放或录制流程：

```bash
./run.sh 4 --fmt g711a --file mode3_hisi_opus_native_chn0_boot<N>_000.opus
./run.sh 3 --afe external --fmt opus
```

## 故障排查


| 现象                                                                              | 处理                                                                                                                                    |
| ------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `sample_pipeline_audio` 启动时报缺少 `libot_base.so`、`libot_irq.so` 或 `libss_mpi*.so` | 重新执行 `package_deploy.sh`，确认部署包 `deploy/lib/` 已包含 SDK 运行时库。                                                                            |
| `model1.bin not found` 或 external AFE 模型加载失败                                    | 确认 `components/hiai/offline_voice/adapter/unisound/kws/tool/model1.bin` 存在，或执行 `package_deploy.sh <build_dir> <model_path>` 显式指定模型路径。 |
| `ss_mpi_ai_set_pub_attr fail`                                                   | 确认 `AI_Agent_DEMO` 已停止，音频设备未被其他进程占用；必要时重启板端后重新验证。                                                                                     |
| `connect to server /tmp/osal_uds_server.sock fail`                              | 确认已基于 `agent_audio_sample` 案例启动板端环境，且板端内核模块和 SDK 用户态库版本一致。                                                                            |
| OPUS 播放变速或变调                                                                    | 使用本 sample 重新录制 OPUS 文件，确认录制和播放均使用 16 kHz mono OPUS native payload。                                                                   |
| `unisound` AFE 配合 G711 或 OPUS 录制失败                                                | `external` AFE 当前仅支持 `--fmt aac`，G711 和 OPUS 使用 `--afe hisi`。                                                                         |


## 清理

在项目工程目录下使用命令 `rm -rf _build` 清理工程编译产物和中间产物。

`sample_pipeline_audio` 的独立 CMake 编译目录可在 `hi_aiot_solution/components/media` 下执行以下命令清理：

```bash
rm -rf build-pipeline-audio
```

---

# 附录

## 相关文档


| 文档                                                         | 说明                              |
| ---------------------------------------------------------- | ------------------------------- |
| `apps/cv610_ev_board/samples/agent_audio_sample/README.md` | `agent_audio_sample` 案例编译和烧录说明。 |
| `components/hiai/offline_voice/adapter/unisound/kws/`      | unisound AFE 依赖库和模型文件目录。        |


