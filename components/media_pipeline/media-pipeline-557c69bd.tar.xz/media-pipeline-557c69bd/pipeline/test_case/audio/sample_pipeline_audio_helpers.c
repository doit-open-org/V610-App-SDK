/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/select.h>
#include <unistd.h>

#include "sample_public_audio.h"
#include "hi_log.h"

/* ============================================================================
 * 1) SAMPLE_COMM_* helpers
 * ========================================================================= */

static volatile sig_atomic_t g_sampleExitRequested = 0;

static td_void SAMPLE_SignalCallbackHandler(int signo)
{
    (void)signo;
    g_sampleExitRequested = 1;
}

td_s32 SAMPLE_COMM_RegisterSigHandler(void)
{
    struct sigaction sa;
    sa.sa_handler = SAMPLE_SignalCallbackHandler;
    sa.sa_flags = 0;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGINT, &sa, NULL) == -1) {
        return TD_FAILURE;
    }
    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        return TD_FAILURE;
    }
    return TD_SUCCESS;
}

td_bool SAMPLE_COMM_IsExitRequested(td_void)
{
    return g_sampleExitRequested ? TD_TRUE : TD_FALSE;
}

td_void SAMPLE_COMM_RequestExit(td_void)
{
    g_sampleExitRequested = 1;
}

td_s32 SAMPLE_COMM_WaitForEnterOrExit(td_void)
{
    while (!SAMPLE_COMM_IsExitRequested()) {
        fd_set readFds;
        struct timeval timeout = {0, 200 * 1000};
        FD_ZERO(&readFds);
        FD_SET(STDIN_FILENO, &readFds);

        td_s32 ret = select(STDIN_FILENO + 1, &readFds, TD_NULL, TD_NULL, &timeout);
        if (ret > 0 && FD_ISSET(STDIN_FILENO, &readFds)) {
            (td_void)getchar();
            return TD_SUCCESS;
        }
        if (ret < 0 && errno != EINTR) {
            return TD_FAILURE;
        }
    }

    printf("\n[sample] exit signal received, stopping...\n");
    return TD_SUCCESS;
}

td_void SAMPLE_COMM_GetLocalTime(char *timeBuffer, td_u32 size)
{
    static td_u32 fallbackSeq = 0;
    if (timeBuffer == NULL || size == 0) {
        return;
    }

    time_t now;
    (td_void)time(&now);
    struct tm *localTime = localtime(&now);
    if (localTime != NULL && localTime->tm_year + 1900 >= 2024) {
        (td_void)strftime(timeBuffer, size, "_%Y%m%d_%H%M%S", localTime);
        return;
    }

    struct timespec mono = {0};
    if (clock_gettime(CLOCK_MONOTONIC, &mono) == 0) {
        (td_void)snprintf_s(timeBuffer, size, size - 1, "_boot%ld_%03u", mono.tv_sec, fallbackSeq++);
    } else {
        struct timeval tv = {0};
        (td_void)gettimeofday(&tv, NULL);
        (td_void)snprintf_s(timeBuffer, size, size - 1, "_seq%lu_%03u", (unsigned long)tv.tv_sec, fallbackSeq++);
    }
}

#define MAX_INPUT_LENGTH 10
td_s32 SAMPLE_COMM_GetInputChar(td_char *ch)
{
    if (ch == TD_NULL) {
        printf("input is null!\n");
        return TD_FAILURE;
    }

    char input[MAX_INPUT_LENGTH];
    if (fgets(input, MAX_INPUT_LENGTH, stdin) == NULL) {
        printf("input fail!\n");
        return TD_FAILURE;
    }
    size_t len = strlen(input);
    if (len > 0 && input[len - 1] == '\n') {
        input[len - 1] = '\0';
    }
    if (strlen(input) != 1) {
        printf("input invalid, expect 1 char\n");
        return TD_FAILURE;
    }
    *ch = input[0];
    return TD_SUCCESS;
}
