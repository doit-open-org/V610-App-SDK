/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AAC_H
#define AAC_H
#include "stream.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* End of #ifdef __cplusplus */
#define AAC_MAX_BUFF_LEN (2 * 1024)
typedef struct {
    StreamHandle stStream;
} AAC_Handle_S;

int32_t AAC_Open(AAC_Handle_S *pstHandle, const char *pszFilePath);

int32_t AAC_ReadFrame(AAC_Handle_S *pstHandle, uint8_t **ppFrame, uint32_t *pu32FrameLen);

int32_t AAC_Close(AAC_Handle_S *pstHandle);

int32_t AAC_Reset(AAC_Handle_S *pstHandle);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

#endif
