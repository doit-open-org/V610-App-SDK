#!/bin/sh

set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REPO_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/../../.." && pwd)
BUILD_DIR=${1:-"$REPO_ROOT/build-pipeline-audio"}
MODEL_PATH=${2:-"$REPO_ROOT/../hiai/offline_voice/adapter/unisound/kws/tool/model1.bin"}

OUT_DIR="$BUILD_DIR/test_case/audio"
SAMPLE_BIN="$OUT_DIR/sample_pipeline_audio"
DEPLOY_DIR="$OUT_DIR/deploy"
DEPLOY_TGZ="$OUT_DIR/deploy.tgz"

if [ ! -x "$SAMPLE_BIN" ]; then
    echo "ERR: sample_pipeline_audio not found: $SAMPLE_BIN" >&2
    echo "Build it first: cmake --build $BUILD_DIR --target sample_pipeline_audio -j" >&2
    exit 1
fi

rm -rf "$DEPLOY_DIR" "$DEPLOY_TGZ"
mkdir -p "$DEPLOY_DIR/lib"

cp "$SAMPLE_BIN" "$DEPLOY_DIR/"
if [ -d "$SCRIPT_DIR/data" ]; then
    cp -R "$SCRIPT_DIR/data" "$DEPLOY_DIR/"
fi

if [ -f "$MODEL_PATH" ]; then
    cp "$MODEL_PATH" "$DEPLOY_DIR/model1.bin"
else
    echo "WARN: model1.bin not found: $MODEL_PATH" >&2
    echo "      mode 3 --afe unisound will need a valid model1.bin on board." >&2
fi

LIBGCC=$(arm-v01c02-linux-musleabi-gcc -print-file-name=libgcc_s.so.1 2>/dev/null || true)
if [ -n "$LIBGCC" ] && [ -f "$LIBGCC" ]; then
    cp "$LIBGCC" "$DEPLOY_DIR/lib/"
fi

# SDK 运行时动态库：优先从当前 build 的 CMakeCache 读取 MPP_LIB_LINUX，兼容新旧 SDK 目录
SDK_LIB_DIR=""
if [ -f "$BUILD_DIR/CMakeCache.txt" ]; then
    SDK_LIB_DIR=$(sed -n 's/^MPP_LIB_LINUX:PATH=//p' "$BUILD_DIR/CMakeCache.txt" | tail -1)
fi
if [ -z "$SDK_LIB_DIR" ] || [ ! -d "$SDK_LIB_DIR" ]; then
    for candidate in \
        "$(CDPATH= cd -- "$REPO_ROOT/../.." && pwd)/_build/sdk/Hi3516CV610/soc/libs/musl" \
        "$REPO_ROOT/_build/sdk/Hi3516CV610/soc/libs/musl" \
        "$(CDPATH= cd -- "$REPO_ROOT/../.." && pwd)/_build/sdk/Hi3516CV610_SDK_V1.0.2.0/smp/a7_linux/source/out/lib" \
        "$REPO_ROOT/_build/sdk/Hi3516CV610_SDK_V1.0.2.0/smp/a7_linux/source/out/lib"; do
        if [ -d "$candidate" ]; then
            SDK_LIB_DIR="$candidate"
            break
        fi
    done
fi

if [ -n "$SDK_LIB_DIR" ] && [ -d "$SDK_LIB_DIR" ]; then
    copied=0
    NEEDED=$(readelf -d "$SAMPLE_BIN" 2>/dev/null | grep NEEDED | awk '{print $5}' | tr -d '[]')
    for soname in $NEEDED; do
        [ "$soname" = "libc.so" ] && continue
        sofile="$SDK_LIB_DIR/$soname"
        if [ -f "$sofile" ]; then
            cp "$sofile" "$DEPLOY_DIR/lib/"
            copied=$((copied + 1))
        fi
    done
    echo "INFO: $copied SDK libs copied from $SDK_LIB_DIR" >&2
else
    echo "WARN: SDK lib dir not found, SDK .so not included in deploy package." >&2
fi

cat > "$DEPLOY_DIR/run.sh" <<'EOF'
#!/bin/sh
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export LD_LIBRARY_PATH="$HERE/lib:$LD_LIBRARY_PATH"
chmod +x "$HERE/sample_pipeline_audio"
exec "$HERE/sample_pipeline_audio" "$@"
EOF
chmod +x "$DEPLOY_DIR/run.sh" "$DEPLOY_DIR/sample_pipeline_audio"

tar -C "$OUT_DIR" -czf "$DEPLOY_TGZ" deploy
rm -rf "$DEPLOY_DIR"

echo "$DEPLOY_TGZ"
