# sample_pipeline_vio

展示 **VCAP → VPSS → DISP** 通路功能，演示从 sensor 采集、经 VPSS 处理、到 DISP 显示的完整直调流程。

**功能特性：**

- 纯视频预览：启动完整 VCAP→VPSS→DISP 通路，实时显示 sensor 画面
- 视频层 + 图形层 叠加：在视频图层之上叠加图形层界面
- 纯图形显示：仅显示图形层界面，不开启视频通路

---

## 目录结构

```
vio/
├── CMakeLists.txt          # 构建 sample_pipeline_vio 可执行文件
├── README.md               # sample_pipeline_vio 使用说明
└── sample_pipeline_vio.c   # 示例源码
```

## 前提条件

- **Hi3516CV610 社区版 SDK**：由编译流程自动从开源社区仓库 https://gitcode.com/HiSpark/Hi3516CV610 clone 到 `_build/`，提供 BSP 工具链与 MPP 库
- 需在 Kconfig 中打开 `CONFIG_OS_DRM` 与 `CONFIG_OS_LVGL`
- HY006_3814_0011 sensor 硬件及接线
- 选择与 LCD 屏幕型号一致的 gui 单屏案例进行编译烧录，屏幕接线见对应 gui 案例下的README
- **烧录镜像须选用对应 gui 下的单屏案例**（见下方编译步骤），以确保 rootfs 中包含对应屏幕驱动；具体驱动模块名称见所选案例 README

## 编译

在项目根目录（`hi_aiot_solution/`）分两步执行：

### 步骤 1：编译烧录镜像（选择与 LCD 屏幕型号一致的 gui 下的单屏案例）

```bash
# 示例：gui 单屏案例
bash scripts/build.sh build --target cv610_ev_board samples gui/<案例目录名>
```

> 可用案例见 [GUI 案例索引](https://gitcode.com/HiSpark/hi_aiot_solution_cv610_ev_board_private/blob/master/samples/gui/README.md)

编译产物：

```
_build/install/image/gui/     # gui 案例烧录镜像（含内核 + rootfs + 屏幕驱动）
```

### 步骤 2：清理上一步产物，再编译测试程序

```bash
# 清理 gui 编译产物（共用同一 _build 目录，不清除会互相干扰）
# ⚠️ 清理前请确认步骤 1 生成的镜像已烧录到开发板，或已手动备份 _build/install/image/ 目录
rm -rf _build

bash scripts/build.sh build --target cv610_ev_board samples framework_media
```

编译产物：

```
_build/test_case/vio/sample_pipeline_vio    # 二进制可执行文件
```

## 上板运行

将步骤 1 的编译产物镜像烧录到开发板，使用Toolplatform进行烧写，具体参考[烧录到开发板文档](https://gitcode.com/HiSpark/hi_aiot_solution/blob/master/docs/Instruction/burning-guide.md)的Toolplatform章节。uboot能够正常运行的开发板，可以参考[烧录到开发板文档](https://gitcode.com/HiSpark/hi_aiot_solution/blob/master/docs/Instruction/burning-guide.md)中的`build.sh`相关章节。

在开发板 shell 中按以下顺序执行：

```bash
# 1. 加载内核 MPP 驱动模块（必须最先执行）
cd /drv/ko/load_ko/
./load3516cv610_20s_debug -i
/root/sdk_server &

# 2. 加载 LCD 屏幕外设驱动
# 参考所选 gui 案例的 README.md，按其"上板运行"章节加载对应屏幕驱动

# 3. 配置开发板 IP 并启动 telnet 服务
ifconfig eth0 xxx.xxx.xxx.xxx; telnetd &

# 4. nfs mount 将 sample_pipeline_vio 挂载到单板上

# 5. 运行示例（选择对应模式）
chmod +x sample_pipeline_vio 
./sample_pipeline_vio 0   # 模式 0：纯视频预览（默认）
./sample_pipeline_vio 1   # 模式 1：视频层 + 图形层 叠加
./sample_pipeline_vio 2   # 模式 2：纯图形（无视频）
```

驱动加载顺序：

| 顺序 | 步骤 | 原因 |
| --- | --- | --- |
| 1 | `load3516cv610_20s_debug -i` | 加载 MPP 基础内核模块并配置引脚复用，必须最先执行 |
| 2 | LCD 屏幕外设驱动（见所选 gui 案例 README） | 注册显示设备节点，须在应用启动前就绪 |
| 3 | `sample_pipeline_vio` | 应用启动时立即打开显示设备，设备节点不存在则直接退出 |

### 退出应用

应用响应 `Ctrl+C` 或 `SIGTERM`，退出时自动停止视频通路并释放所有媒体资源。

## 功能说明

### 模式 0：纯视频预览

启动完整 VCAP→VPSS→DISP 通路，HY006_3814_0011 sensor 以 2560×1440@30fps 采集，经 VPSS 按屏幕宽高比居中裁剪后缩放至屏幕分辨率，以 15 fps 输出到 LCD 屏幕上。

### 模式 1：视频层 + 图形层 叠加

在模式 0 视频通路之上，通过 `hi_mapi_disp_get_video_screen()` 获取 LVGL 屏幕对象并创建叠加控件（示例中在顶部居中显示 "Video overlay UI" 标签），实现视频与图形叠加显示。

### 模式 2：纯图形显示

仅初始化 DISP 图形图层，不开启视频通路。LVGL 在 `hi_mapi_disp_init()` 后自动启动，示例创建全屏对象并显示 "Graphic Only" 居中标签。不消耗 sensor 及 ISP 资源。

### 适配 sensor

sample 默认适配 **HY006_3814_0011**。更换 sensor 需同时改以下两个文件：

**1. [sample_pipeline_vio.c](./sample_pipeline_vio.c)**

| 位置 | 当前值 | 说明 |
|------|--------|------|
| `SNS_WIDTH` / `SNS_HEIGHT` / `SNS_FRAME_RATE` 宏 | `2560` / `1440` / `30` | 改为新 sensor 的输出分辨率和帧率 |
| `extern struct ot_isp_sns_obj *hy006_3814_0011_get_obj(...)` | `hy006_3814_0011_get_obj` | 改为新 sensor 的 obj getter 函数名 |
| `fill_sensor_attr()` — `input_data_type` | `RAW_12BIT` | 改为新 sensor 的 RAW 位深 |
| `fill_sensor_attr()` — `sensor_obj` | `hy006_3814_0011_get_obj()` | 改为新 sensor 的 obj getter 调用 |
| `fill_sensor_attr()` — `bayer_format` | `BGGR` | 改为新 sensor 的 Bayer 排列 |
| `fill_sensor_attr()` — `lane_id[]` | `{0, 2, -1, ...}` | 改为新 sensor 的 MIPI lane 映射 |

**2. [CMakeLists.txt](./CMakeLists.txt)**

```cmake
# sensor —— 换板时改这里
sns_hy006_3814_0011
```

将 `sns_hy006_3814_0011` 替换为新 sensor 对应的静态库名称。

## 故障排查

| 现象 | 处理 |
| --- | --- |
| 应用启动后立即退出 | 确认 LCD 外设驱动已加载且显示设备节点存在；驱动须在应用前就绪 |
| 无视频画面（模式 0/1） | 确认 `load3516cv610_20s_debug -i` 已执行，MPP 引脚复用配置完成；检查 sensor 接线 |

## 清理

```bash
rm -rf _build
```
