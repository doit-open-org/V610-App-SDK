/*
 * Copyright (c) 2026 HiSilicon (Shanghai) Technologies Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#include "hi_mapi_sys.h"
#include "hi_mapi_vcap.h"
#include "hi_mapi_vpss.h"
#include "hi_mapi_disp.h"
#include "hi_mapi_comm_define.h"
#include "hi_mapi_vcap_define.h"
#include "hi_mapi_vpss_define.h"
#include "hi_mapi_disp_define.h"
#include "hi_log.h"

#ifdef SUPPORT_LVGL
#include "lvgl.h"
#endif

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

/* ------------------------------------------------------------------ */
/* Handles                                                             */
/* ------------------------------------------------------------------ */
#define VCAP_DEV_HDL    0
#define VCAP_PIPE_HDL   0
#define PIPE_CHN_HDL    0
#define VPSS_GRP_HDL    0
#define VPSS_CHN_HDL   0
#define DISP_HDL        0
#define DISP_WND_HDL    0

/* ------------------------------------------------------------------ */
/* Sensor / frame parameters                                           */
/* ------------------------------------------------------------------ */
#define SNS_WIDTH        2560
#define SNS_HEIGHT       1440
#define SNS_FRAME_RATE   30

/* Display output frame rate (15 fps as required) */
#define DISP_FRAME_RATE  15

/* ------------------------------------------------------------------ */
/* Running modes                                                       */
/* ------------------------------------------------------------------ */
#define VIO_MODE_VIDEO_ONLY  0   /* pure video layer */
#define VIO_MODE_VIDEO_UI    1   /* video layer + LVGL UI overlay */
#define VIO_MODE_UI_ONLY     2   /* pure graphic layer (no video) */

/* ------------------------------------------------------------------ */
/* Sensor obj — sc4336p driver from libsns_hy006_3814_0011.a                  */
/* ------------------------------------------------------------------ */
struct ot_isp_sns_obj;
extern struct ot_isp_sns_obj *hy006_3814_0011_get_obj(td_void);

/* ------------------------------------------------------------------ */
/* Global state                                                        */
/* ------------------------------------------------------------------ */
static volatile sig_atomic_t g_quit = 0;

static td_void sigint_handler(int signo)
{
    (void)signo;
    g_quit = 1;
}

/* ------------------------------------------------------------------ */
/* Error-handling helper                                               */
/* ------------------------------------------------------------------ */
#define CHECK_GOTO(expr, label) do { \
        ret = (expr); \
        if ((ret) != TD_SUCCESS) { \
            HI_LOGE("CHECK_GOTO", "%s failed, ret=0x%x", #expr, (unsigned int)(ret)); \
            goto label; \
        } \
    } while (0)

/* ------------------------------------------------------------------ */
/* Attribute fill functions                                            */
/* ------------------------------------------------------------------ */
static td_void fill_sensor_attr(hi_mapi_vcap_sensor_attr *attr)
{
    (void)memset(attr, 0, sizeof(*attr));
    attr->sns_mode = 0;
    attr->wdr_mode = HI_MAPI_VCAP_WDR_MODE_NONE;
    attr->size.width  = SNS_WIDTH;
    attr->size.height = SNS_HEIGHT;

    attr->input_dev_attr.input_mode      = HI_MAPI_VCAP_INPUT_MODE_MIPI;
    attr->input_dev_attr.input_data_type = HI_MAPI_VCAP_INPUT_DATA_TYPE_RAW_12BIT;
    attr->input_dev_attr.use_serdes_dev  = TD_FALSE;

    attr->sns_dev_attr.sensor_obj = (td_void *)hy006_3814_0011_get_obj();
    attr->sns_dev_attr.data_rate  = HI_MAPI_VCAP_MIPI_DATA_RATE_X1;
    attr->sns_dev_attr.input_attr.bayer_format    = HI_MAPI_VCAP_BAYER_FORMAT_RGGB;
    attr->sns_dev_attr.input_attr.comm_bus_type   = HI_MAPI_SENSOR_COMMBUS_TYPE_I2C;
    attr->sns_dev_attr.input_attr.sensor_dev_addr = 0;
    for (td_u32 i = 0; i < HI_MAPI_SENSOR_MAX_LANE_NUM; i++) {
        attr->sns_dev_attr.lane_id[i] = -1;
    }
    attr->sns_dev_attr.lane_id[0] = 0;
    attr->sns_dev_attr.lane_id[1] = 2;
}

static td_void fill_vcap_attr(hi_mapi_vcap_attr *attr)
{
    (void)memset(attr, 0, sizeof(*attr));

    attr->vcap_dev_attr.wdr_mode  = HI_MAPI_VCAP_WDR_MODE_NONE;
    attr->vcap_dev_attr.intf_mode = HI_MAPI_VCAP_MODE_MIPI;
    attr->vcap_dev_attr.data_seq  = HI_MAPI_DATA_SEQ_YUYV;
    attr->vcap_dev_attr.data_type = HI_MAPI_VCAP_DATA_TYPE_RGB;

    attr->pipe_bind_num   = 1;
    attr->pipe_id_bind[0] = VCAP_PIPE_HDL;

    hi_mapi_vcap_pipe_attr *pipe_attr = &attr->vcap_pipe_attr[VCAP_PIPE_HDL];
    pipe_attr->pipe_type                       = HI_MAPI_VCAP_PIPE_TYPE_VIDEO;
    pipe_attr->frame_rate_ctrl.src_frame_rate  = -1;
    pipe_attr->frame_rate_ctrl.dst_frame_rate  = -1;
    pipe_attr->isp_pub_attr.frame_rate         = (td_float)SNS_FRAME_RATE;
    pipe_attr->isp_pub_attr.size.width         = SNS_WIDTH;
    pipe_attr->isp_pub_attr.size.height        = SNS_HEIGHT;
    pipe_attr->isp_pub_attr.bayer              = HI_MAPI_VCAP_BAYER_RGGB;
    pipe_attr->isp_pub_attr.sns_mirror_flip    = HI_MAPI_VCAP_ISP_SNS_NORMAL;
    pipe_attr->vb_pool_blk_cnt                 = 0;

    hi_mapi_vcap_pipe_chn_attr *chn_attr = &pipe_attr->pipe_chn_attr[PIPE_CHN_HDL];
    chn_attr->dest_size.width             = SNS_WIDTH;
    chn_attr->dest_size.height            = SNS_HEIGHT;
    chn_attr->frame_rate_ctrl.src_frame_rate = SNS_FRAME_RATE;
    chn_attr->frame_rate_ctrl.dst_frame_rate = SNS_FRAME_RATE;
    chn_attr->pixel_format                = HI_MAPI_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    chn_attr->video_format                = HI_MAPI_VIDEO_FORMAT_LINEAR;
    chn_attr->vb_pool_blk_cnt             = 0;
}

static td_void fill_grp_attr(hi_mapi_vpss_grp_attr *attr)
{
    (void)memset(attr, 0, sizeof(*attr));
    /* Use sensor resolution as VB upper bound; actual output is set via port attr */
    attr->max_width  = SNS_WIDTH;
    attr->max_height = SNS_HEIGHT;
    attr->frame_rate_ctrl.src_frame_rate = -1;
    attr->frame_rate_ctrl.dst_frame_rate = -1;
    attr->pixel_format = OT_PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    attr->is_nr_en     = TD_FALSE;
}

static td_void fill_vport_attr(hi_mapi_vpss_chn_attr *attr, td_u32 scr_w, td_u32 scr_h)
{
    (void)memset(attr, 0, sizeof(*attr));
    /* Scale vpss output to screen resolution and throttle to 15 fps */
    attr->width  = scr_w;
    attr->height = scr_h;
    attr->support_buffer_share           = TD_FALSE;
    attr->frame_rate_ctrl.src_frame_rate = SNS_FRAME_RATE;
    attr->frame_rate_ctrl.dst_frame_rate = DISP_FRAME_RATE;
    attr->video_format  = HI_MAPI_VIDEO_FORMAT_LINEAR;
    attr->pixel_format  = OT_PIXEL_FORMAT_YUV_SEMIPLANAR_420;
    attr->compress_mode = HI_MAPI_COMPRESS_MODE_NONE;
    attr->aspect_ratio.mode = HI_MAPI_ASPECT_RATIO_NONE;
}

static td_void fill_disp_attr(hi_mapi_disp_attr *attr)
{
    (void)memset(attr, 0, sizeof(*attr));
    attr->pub_attr.bg_color   = 0x6ee0f2; // blue bg color
    attr->pub_attr.intf_type  = HI_MAPI_DISP_INTF_LCD;
}

static td_void fill_video_layer_attr(hi_mapi_disp_video_layer_attr *attr,
    td_u32 scr_w, td_u32 scr_h)
{
    (void)memset(attr, 0, sizeof(*attr));
    attr->image_size.width  = scr_w;
    attr->image_size.height = scr_h;
    attr->frame_rate        = DISP_FRAME_RATE;
    attr->buf_len           = 2; /* SUPPORT_LVGL not use */
}

/* ------------------------------------------------------------------ */
/* Bind helpers                                                        */
/* ------------------------------------------------------------------ */
static td_void make_chn(hi_mapi_mpp_chn *chn, hi_mapi_module_id mod_id, td_s32 dev_id, td_s32 ch_id)
{
    chn->mod_id = mod_id;
    chn->dev_id = dev_id;
    chn->chn_id = ch_id;
}

static td_s32 bind_vcap_vpss(td_void)
{
    hi_mapi_mpp_chn src, dst;
    make_chn(&src, HI_MAPI_MOD_VCAP,  VCAP_PIPE_HDL, PIPE_CHN_HDL);
    make_chn(&dst, HI_MAPI_MOD_VPSS, VPSS_GRP_HDL,  0);
    return hi_mapi_sys_bind(&src, &dst);
}

static td_void unbind_vcap_vpss(td_void)
{
    hi_mapi_mpp_chn src, dst;
    make_chn(&src, HI_MAPI_MOD_VCAP,  VCAP_PIPE_HDL, PIPE_CHN_HDL);
    make_chn(&dst, HI_MAPI_MOD_VPSS, VPSS_GRP_HDL,  0);
    (void)hi_mapi_sys_unbind(&src, &dst);
}

static td_s32 bind_vpss_disp(td_void)
{
    hi_mapi_mpp_chn src, dst;
    make_chn(&src, HI_MAPI_MOD_VPSS, VPSS_GRP_HDL,  VPSS_CHN_HDL);
    make_chn(&dst, HI_MAPI_MOD_DISP,  DISP_HDL,      DISP_WND_HDL);
    return hi_mapi_sys_bind(&src, &dst);
}

static td_void unbind_vpss_disp(td_void)
{
    hi_mapi_mpp_chn src, dst;
    make_chn(&src, HI_MAPI_MOD_VPSS, VPSS_GRP_HDL,  VPSS_CHN_HDL);
    make_chn(&dst, HI_MAPI_MOD_DISP,  DISP_HDL,      DISP_WND_HDL);
    (void)hi_mapi_sys_unbind(&src, &dst);
}

/* ------------------------------------------------------------------ */
/* vcap lifecycle                                                      */
/* ------------------------------------------------------------------ */
static td_s32 start_vcap(const hi_mapi_vcap_sensor_attr *sensor_attr, const hi_mapi_vcap_attr *vcap_attr)
{
    td_s32 ret;
    CHECK_GOTO(hi_mapi_vcap_init_sensor(VCAP_DEV_HDL, sensor_attr, TD_TRUE), err);
    CHECK_GOTO(hi_mapi_vcap_set_attr   (VCAP_DEV_HDL, vcap_attr),            err);
    CHECK_GOTO(hi_mapi_vcap_start_dev  (VCAP_DEV_HDL),              err);
    CHECK_GOTO(hi_mapi_vcap_start_chn  (VCAP_PIPE_HDL, PIPE_CHN_HDL), err);
    CHECK_GOTO(hi_mapi_vcap_init_isp   (VCAP_PIPE_HDL),             err);
    CHECK_GOTO(hi_mapi_vcap_start_pipe (VCAP_PIPE_HDL),             err);
    CHECK_GOTO(hi_mapi_vcap_start_isp  (VCAP_PIPE_HDL),             err);
    return TD_SUCCESS;
err:
    return ret;
}

static td_void stop_vcap(td_void)
{
    (void)hi_mapi_vcap_stop_isp    (VCAP_PIPE_HDL);
    (void)hi_mapi_vcap_stop_pipe   (VCAP_PIPE_HDL);
    (void)hi_mapi_vcap_deinit_isp  (VCAP_PIPE_HDL);
    (void)hi_mapi_vcap_stop_chn    (VCAP_PIPE_HDL, PIPE_CHN_HDL);
    (void)hi_mapi_vcap_stop_dev    (VCAP_DEV_HDL);
    (void)hi_mapi_vcap_deinit_sensor(VCAP_DEV_HDL);
}

/* ------------------------------------------------------------------ */
/* vpss lifecycle                                                     */
/* ------------------------------------------------------------------ */
static td_s32 start_vpss(const hi_mapi_vpss_grp_attr *grp_attr, const hi_mapi_vpss_chn_attr *port_attr)
{
    td_s32 ret;
    CHECK_GOTO(hi_mapi_vpss_init         (VPSS_GRP_HDL, grp_attr),                  err);
    CHECK_GOTO(bind_vcap_vpss(),                                                      err);
    CHECK_GOTO(hi_mapi_vpss_set_chn_attr(VPSS_GRP_HDL, VPSS_CHN_HDL, port_attr), err);
    CHECK_GOTO(hi_mapi_vpss_start_chn   (VPSS_GRP_HDL, VPSS_CHN_HDL),            err);
    return TD_SUCCESS;
err:
    return ret;
}

static td_void calc_grp_crop_rect(td_u32 scr_w, td_u32 scr_h, hi_mapi_rect *rect)
{
    td_u32 crop_w, crop_h;
    if (scr_w * SNS_HEIGHT > scr_h * SNS_WIDTH) {
        crop_w = SNS_WIDTH;
        crop_h = SNS_WIDTH * scr_h / scr_w;
    } else {
        crop_h = SNS_HEIGHT;
        crop_w = SNS_HEIGHT * scr_w / scr_h;
    }
    rect->x      = (td_s32)((SNS_WIDTH  - crop_w) / 2);
    rect->y      = (td_s32)((SNS_HEIGHT - crop_h) / 2);
    rect->width  = crop_w;
    rect->height = crop_h;
}

static td_s32 set_vpss_grp_crop(td_u32 scr_w, td_u32 scr_h)
{
    td_s32 ret;
    hi_mapi_vpss_crop_info crop_info;
    ret = hi_mapi_vpss_get_param(VPSS_GRP_HDL, VPSS_CHN_HDL,
        HI_MAPI_VPSS_CMD_GRP_CROP, &crop_info, sizeof(crop_info));
    if (ret != TD_SUCCESS) {
        return ret;
    }
    crop_info.enable          = TD_TRUE;
    crop_info.crop_coordinate = HI_MAPI_VPSS_CROP_ABS_COOR;
    calc_grp_crop_rect(scr_w, scr_h, &crop_info.crop_rect);
    return hi_mapi_vpss_set_param(VPSS_GRP_HDL, VPSS_CHN_HDL,
        HI_MAPI_VPSS_CMD_GRP_CROP, &crop_info, sizeof(crop_info));
}

static td_void stop_vpss(td_void)
{
    (void)hi_mapi_vpss_stop_chn(VPSS_GRP_HDL, VPSS_CHN_HDL);
    unbind_vcap_vpss();
    (void)hi_mapi_vpss_deinit(VPSS_GRP_HDL);
}

/* ------------------------------------------------------------------ */
/* Video pipeline lifecycle (modes 0 and 1)                           */
/* ------------------------------------------------------------------ */
static td_s32 start_video_pipeline(const hi_mapi_vcap_sensor_attr *sensor_attr,
    const hi_mapi_vcap_attr *vcap_attr, const hi_mapi_vpss_grp_attr *grp_attr,
    td_u32 scr_w, td_u32 scr_h)
{
    td_s32 ret;
    hi_mapi_vpss_chn_attr       vport_attr;
    hi_mapi_disp_video_layer_attr vl_attr;
    fill_vport_attr      (&vport_attr, scr_w, scr_h);
    fill_video_layer_attr(&vl_attr,    scr_w, scr_h);

    CHECK_GOTO(start_vcap(sensor_attr, vcap_attr),         err);
    CHECK_GOTO(start_vpss(grp_attr, &vport_attr),         err_vcap);
    CHECK_GOTO(set_vpss_grp_crop(scr_w, scr_h),           err_vpss);
    CHECK_GOTO(bind_vpss_disp(),                        err_vpss);
    CHECK_GOTO(hi_mapi_disp_start(DISP_HDL, &vl_attr), err_bind);
    return TD_SUCCESS;
err_bind:
    unbind_vpss_disp();
err_vpss:
    stop_vpss();
err_vcap:
    stop_vcap();
err:
    return ret;
}

/* ------------------------------------------------------------------ */
/* Media init helper                                                   */
/* ------------------------------------------------------------------ */
static td_s32 init_sys_media(td_bool need_vcap)
{
    td_s32 ret;
    hi_mapi_sys_base_attr  base_attr;
    hi_mapi_sys_media_attr media_attr;

    (void)memset(&base_attr,  0, sizeof(base_attr));
    (void)memset(&media_attr, 0, sizeof(media_attr));

    if (need_vcap == TD_TRUE) {
        base_attr.vcap_dev_num             = 1;
        base_attr.vcap_reso_size[0].width  = SNS_WIDTH;
        base_attr.vcap_reso_size[0].height = SNS_HEIGHT;
        base_attr.vcap_online[0]           = TD_FALSE;
        base_attr.raw_bit_width            = 12;
        base_attr.is_wdr                   = TD_FALSE;
        base_attr.vpss_grp_num            = 1;
        base_attr.vpss_chn_num           = 1;
        /* Allocate VB using sensor resolution as upper bound;
           actual vpss port output will be set to screen resolution later */
        base_attr.vpss_reso_size[VPSS_GRP_HDL][VPSS_CHN_HDL].width  = SNS_WIDTH;
        base_attr.vpss_reso_size[VPSS_GRP_HDL][VPSS_CHN_HDL].height = SNS_HEIGHT;
        base_attr.vpss_online[0] = TD_FALSE;
    }
    /* need_vcap == TD_FALSE: all-zero base_attr gives minimal VB (mode 2) */

    CHECK_GOTO(hi_mapi_sys_get_default_media_attr(&base_attr, &media_attr), err);
    CHECK_GOTO(hi_mapi_sys_init_media(&media_attr), err);
    return TD_SUCCESS;
err:
    return ret;
}

/* ------------------------------------------------------------------ */
/* main                                                                */
/* ------------------------------------------------------------------ */
int main(int argc, char *argv[])
{
    td_s32 ret = TD_SUCCESS;
    td_s32 run_mode = VIO_MODE_VIDEO_ONLY;

    /* 1. Parse mode ------------------------------------------------- */
    if (argc >= 2) {
        run_mode = atoi(argv[1]);
    }
    if (run_mode < VIO_MODE_VIDEO_ONLY || run_mode > VIO_MODE_UI_ONLY) {
        printf("Usage: %s [mode]\n", argv[0]);
        printf("  0 - only video layer (default)\n");
        printf("  1 - video layer & UI graphic overlay\n");
        printf("  2 - only graphic layer (no video)\n");
        return TD_FAILURE;
    }
    HI_LOGI("VIO", "VIO sample mode %d", run_mode);
    signal(SIGINT, sigint_handler);

    /* 2. Prepare common disp attributes ----------------------------- */
    hi_mapi_disp_attr disp_attr;
    fill_disp_attr(&disp_attr);

    /* Prepare vcap/vpss attributes for mode 0/1 ------------------- */
    hi_mapi_vcap_sensor_attr sensor_attr;
    hi_mapi_vcap_attr        vcap_attr;
    hi_mapi_vpss_grp_attr   grp_attr;
    if (run_mode != VIO_MODE_UI_ONLY) {
        fill_sensor_attr(&sensor_attr);
        fill_vcap_attr  (&vcap_attr);
        fill_grp_attr   (&grp_attr);
    }

    /* 3. System init ------------------------------------------------ */
    CHECK_GOTO(hi_mapi_sys_init(), exit_none);

    /* 4. Media init (mode 2: vcap_dev_num=0, minimal VB) ----------- */
    // CHECK_GOTO(init_sys_media(run_mode != VIO_MODE_UI_ONLY), exit_sys);
    if (run_mode != VIO_MODE_UI_ONLY) {
        CHECK_GOTO(init_sys_media(TD_TRUE), exit_sys);
    }

    /* 5. Disp init (starts LVGL main thread on hi3516cv610) --------- */
    CHECK_GOTO(hi_mapi_disp_init(DISP_HDL, &disp_attr), exit_media);

    /* 6. Get actual screen resolution (only valid after disp_init) -- */
    td_u32 scr_w = 720;
    td_u32 scr_h = 1280;
#ifdef SUPPORT_LVGL
    CHECK_GOTO(hi_mapi_disp_get_screen_resolution(DISP_HDL, &scr_w, &scr_h), exit_disp);
#endif
    HI_LOGI("VIO", "Screen resolution: %u x %u", scr_w, scr_h);

    /* 7+8. Mode-specific startup and main loop --------------------- */
    switch (run_mode) {
    case VIO_MODE_VIDEO_ONLY:
        CHECK_GOTO(start_video_pipeline(&sensor_attr, &vcap_attr, &grp_attr, scr_w, scr_h), exit_disp);
        /* video image defaults to full screen; just switch to the video screen */
        CHECK_GOTO(hi_mapi_disp_start_window(DISP_HDL, DISP_WND_HDL), exit_disp);
        printf("Mode 0: only video. Press Ctrl-C to stop.\n");
        while (!g_quit) {
            sleep(1);
        }
        break;

    case VIO_MODE_VIDEO_UI:
        CHECK_GOTO(start_video_pipeline(&sensor_attr, &vcap_attr, &grp_attr, scr_w, scr_h), exit_disp);
        printf("Mode 1: video + UI overlay. Press Ctrl-C to stop.\n");
#ifdef SUPPORT_LVGL
        {
            void     *video_screen = hi_mapi_disp_get_video_screen(DISP_HDL);
            lv_lock();
            lv_obj_t *label = lv_label_create((lv_obj_t *)video_screen);
            lv_label_set_text(label, "Video overlay UI");
            lv_obj_align(label, LV_ALIGN_TOP_MID, 0, 20);
            lv_unlock();
            (void)hi_mapi_disp_release_video_screen(DISP_HDL, video_screen);
        }
#endif
        /* video image defaults to full screen; just switch to the video screen */
        CHECK_GOTO(hi_mapi_disp_start_window(DISP_HDL, DISP_WND_HDL), exit_disp);
        while (!g_quit) {
            sleep(1);
        }
        break;

    case VIO_MODE_UI_ONLY:
        /* LVGL is already running after disp_init; no video pipeline needed */
        printf("Mode 2: only graphic. Press Ctrl-C to stop.\n");
#ifdef SUPPORT_LVGL
        {
            lv_lock();
            lv_obj_t *screen = lv_obj_create(NULL);
            lv_obj_t *label  = lv_label_create(screen);
            lv_label_set_text(label, "Graphic Only");
            lv_obj_align(label, LV_ALIGN_CENTER, 0, 0);
            lv_scr_load(screen);
            lv_unlock();
        }
#endif
        while (!g_quit) {
            sleep(1);
        }
        break;

    default:
        break;
    }

    printf("Stopping...\n");
    ret = TD_SUCCESS;

    /* 9. Mode-specific cleanup (reverse order) ---------------------- */
    switch (run_mode) {
    case VIO_MODE_VIDEO_ONLY:
    case VIO_MODE_VIDEO_UI:
        (void)hi_mapi_disp_stop_window(DISP_HDL, DISP_WND_HDL);
        unbind_vpss_disp();
        (void)hi_mapi_disp_stop(DISP_HDL);
        (void)hi_mapi_disp_deinit(DISP_HDL);
        stop_vpss();
        stop_vcap();
        goto exit_media;
    case VIO_MODE_UI_ONLY:
        (void)hi_mapi_disp_deinit(DISP_HDL);
        goto exit_media;
    default:
        break;
    }

exit_disp:
    (void)hi_mapi_disp_deinit(DISP_HDL);
exit_media:
    (void)hi_mapi_sys_deinit_media();
exit_sys:
    (void)hi_mapi_sys_deinit();
exit_none:
    HI_LOGI("VIO", "sample_pipeline_vio exit, ret=0x%x", ret);
    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif
